/**
 * FlatPackStackOptimizer — Full 2D bin packing port from desktop C#.
 * Optimizes stacking arrangement of flat-pack enclosure panels for shipping.
 * Uses 2D bin packing to arrange panels side-by-side in layers, calculates
 * box dimensions, and generates filler pieces to prevent shifting.
 *
 * Desktop source: Services/FlatPackStackOptimizer.cs (~830 lines)
 */

import type { CutListItem } from './types/enclosure';

// ─── Constants ──────────────────────────────────────────────────────────────

const THICKNESS_18MM = 0.709;
const THICKNESS_24MM = 0.945;
const THICKNESS_MDF_3_4 = 0.75;
const THICKNESS_MDF_1 = 1.0;
const DENSITY_BALTIC_BIRCH = 0.0246; // lb/in³
const DENSITY_MDF = 0.029;           // lb/in³
const DEFAULT_SIDE_PADDING = 0.5;    // inches per side
const DEFAULT_VERTICAL_PADDING = 0.5;
const DEFAULT_PACKAGING_WEIGHT = 3.0; // lbs
const BOX_WALL_LW = 0.5512;          // 14mm — length/width offset
const BOX_WALL_H = 1.1024;           // 28mm — height offset
const DIM_WEIGHT_FACTOR_UPS = 139;
const DIM_WEIGHT_FACTOR_USPS = 166;
const OVERLAP_TOLERANCE = 0.001;
const MIN_FILLER_SIZE = 2.0;         // minimum filler piece dimension (inches)

// ─── Types ──────────────────────────────────────────────────────────────────

export interface FlatPackSettings {
  sidePadding: number;
  verticalPadding: number;
  birchDensity: number;
  mdfDensity: number;
  packagingWeight: number;
}

export const DEFAULT_FLAT_PACK_SETTINGS: FlatPackSettings = {
  sidePadding: DEFAULT_SIDE_PADDING,
  verticalPadding: DEFAULT_VERTICAL_PADDING,
  birchDensity: DENSITY_BALTIC_BIRCH,
  mdfDensity: DENSITY_MDF,
  packagingWeight: DEFAULT_PACKAGING_WEIGHT,
};

interface FlatPackPanel {
  partName: string;
  length: number;  // longer dimension
  width: number;   // shorter dimension
  thickness: number;
  material: string;
  weight: number;
  quantity: number;
}

interface PlacedPanel {
  panel: FlatPackPanel;
  x: number;
  y: number;
  isRotated: boolean;
  placedLength: number;
  placedWidth: number;
}

interface StackLayer {
  layerNumber: number;
  thickness: number;
  placedPanels: PlacedPanel[];
}

export interface FillerPiece {
  layerNumber: number;
  x: number;
  y: number;
  length: number;
  width: number;
  thickness: number;
  weight: number;
}

interface Rect {
  x: number;
  y: number;
  length: number;
  width: number;
}

interface PackResult {
  placed: PlacedPanel[];
  unplaced: FlatPackPanel[];
}

export interface StackedPanelInfo {
  stackPosition: number;
  partName: string;
  length: number;
  width: number;
}

export interface FlatPackResult {
  footprintLength: number;
  footprintWidth: number;
  stackHeight: number;
  boxLength: number;
  boxWidth: number;
  boxHeight: number;
  exteriorLength: number;
  exteriorWidth: number;
  exteriorHeight: number;
  panelCount: number;
  layerCount: number;
  panelWeight: number;
  fillerPieces: FillerPiece[];
  fillerPieceCount: number;
  fillerWeight: number;
  packagingWeight: number;
  totalShippedWeight: number;
  dimensionalWeightUPS: number;
  dimensionalWeightUSPS: number;
  billableWeightUPS: number;
  billableWeightUSPS: number;
  pkgTopBottomArea: number;
  pkgFrontBackArea: number;
  pkgSidesArea: number;
  pkgTotalArea: number;
  stackedPanels: StackedPanelInfo[];
  warnings: string[];
}

// ─── Thickness Logic ────────────────────────────────────────────────────────

function getPanelThickness(material: string, partName: string, dutyType: string): number {
  const mat = material.toLowerCase();
  const duty = dutyType.toUpperCase();

  if (mat.includes('mdf')) {
    return (duty === 'HD' || mat.includes('heavy')) ? THICKNESS_MDF_1 : THICKNESS_MDF_3_4;
  }

  if (mat.includes('24mm') && !mat.includes('/')) {
    return THICKNESS_24MM;
  }

  if (mat.includes('18mm') && !mat.includes('/')) {
    return THICKNESS_18MM;
  }

  // Mixed 18mm/24mm
  if (mat.includes('/') || (mat.includes('18mm') && mat.includes('24mm'))) {
    if (duty === 'HD') return THICKNESS_24MM;
    // RD: Baffle gets 24mm, everything else 18mm
    if (partName.toLowerCase().includes('baffle')) return THICKNESS_24MM;
    return THICKNESS_18MM;
  }

  // Default to birch 18mm
  return THICKNESS_18MM;
}

// ─── 2D Overlap Detection ───────────────────────────────────────────────────

function rectanglesOverlap(r1: Rect, r2: Rect): boolean {
  return !(
    r1.x + r1.length <= r2.x + OVERLAP_TOLERANCE ||
    r2.x + r2.length <= r1.x + OVERLAP_TOLERANCE ||
    r1.y + r1.width <= r2.y + OVERLAP_TOLERANCE ||
    r2.y + r2.width <= r1.y + OVERLAP_TOLERANCE
  );
}

// ─── Candidate Position Generation ──────────────────────────────────────────

function getCandidatePositions(
  occupiedRects: Rect[],
  footprintLength: number,
  footprintWidth: number
): Array<{ x: number; y: number }> {
  const positions: Array<{ x: number; y: number }> = [{ x: 0, y: 0 }];

  for (const r of occupiedRects) {
    // Right edge
    positions.push({ x: r.x + r.length, y: r.y });
    // Top edge
    positions.push({ x: r.x, y: r.y + r.width });
    // Top-right corner
    positions.push({ x: r.x + r.length, y: r.y + r.width });
  }

  // Filter to valid positions within footprint
  const valid = positions.filter(p =>
    p.x >= 0 && p.y >= 0 && p.x < footprintLength && p.y < footprintWidth
  );

  // Sort by Y ascending, then X ascending (bottom-left preference)
  valid.sort((a, b) => a.y !== b.y ? a.y - b.y : a.x - b.x);

  return valid;
}

// ─── Panel Placement ────────────────────────────────────────────────────────

function findPositionForPanel(
  panelLength: number,
  panelWidth: number,
  occupiedRects: Rect[],
  footprintLength: number,
  footprintWidth: number
): { x: number; y: number } | null {
  const candidates = getCandidatePositions(occupiedRects, footprintLength, footprintWidth);

  for (const pos of candidates) {
    // Check if panel fits within footprint
    if (pos.x + panelLength > footprintLength + OVERLAP_TOLERANCE) continue;
    if (pos.y + panelWidth > footprintWidth + OVERLAP_TOLERANCE) continue;

    // Check no overlap with existing rectangles
    const newRect: Rect = { x: pos.x, y: pos.y, length: panelLength, width: panelWidth };
    let overlaps = false;
    for (const existing of occupiedRects) {
      if (rectanglesOverlap(newRect, existing)) {
        overlaps = true;
        break;
      }
    }

    if (!overlaps) return pos;
  }

  return null;
}

// ─── Layer Packing: Exhaustive Rotation (≤6 panels) ────────────────────────

function tryPackWithRotations(
  panels: FlatPackPanel[],
  rotations: boolean[],
  footprintLength: number,
  footprintWidth: number
): PackResult {
  const placed: PlacedPanel[] = [];
  const unplaced: FlatPackPanel[] = [];
  const occupiedRects: Rect[] = [];

  for (let i = 0; i < panels.length; i++) {
    const panel = panels[i];
    let useRotated = rotations[i];

    let pLength = useRotated ? panel.width : panel.length;
    let pWidth = useRotated ? panel.length : panel.width;

    // Validate orientation fits within footprint; flip if needed
    if (pLength > footprintLength || pWidth > footprintWidth) {
      // Try other orientation
      useRotated = !useRotated;
      pLength = useRotated ? panel.width : panel.length;
      pWidth = useRotated ? panel.length : panel.width;

      if (pLength > footprintLength || pWidth > footprintWidth) {
        unplaced.push(panel);
        continue;
      }
    }

    const pos = findPositionForPanel(pLength, pWidth, occupiedRects, footprintLength, footprintWidth);
    if (pos) {
      placed.push({
        panel,
        x: pos.x,
        y: pos.y,
        isRotated: useRotated,
        placedLength: pLength,
        placedWidth: pWidth,
      });
      occupiedRects.push({ x: pos.x, y: pos.y, length: pLength, width: pWidth });
    } else {
      unplaced.push(panel);
    }
  }

  return { placed, unplaced };
}

function packLayerWithRotationExploration(
  panels: FlatPackPanel[],
  footprintLength: number,
  footprintWidth: number
): PackResult {
  const n = panels.length;
  const totalCombinations = 1 << n; // 2^N

  let bestResult: PackResult = { placed: [], unplaced: [...panels] };
  let bestArea = 0;

  for (let mask = 0; mask < totalCombinations; mask++) {
    const rotations: boolean[] = [];
    for (let i = 0; i < n; i++) {
      rotations.push((mask & (1 << i)) !== 0);
    }

    const result = tryPackWithRotations(panels, rotations, footprintLength, footprintWidth);

    if (result.placed.length > bestResult.placed.length) {
      bestResult = result;
      bestArea = result.placed.reduce((sum, p) => sum + p.placedLength * p.placedWidth, 0);
    } else if (result.placed.length === bestResult.placed.length) {
      const area = result.placed.reduce((sum, p) => sum + p.placedLength * p.placedWidth, 0);
      if (area > bestArea) {
        bestResult = result;
        bestArea = area;
      }
    }
  }

  return bestResult;
}

// ─── Layer Packing: Greedy Heuristic (7+ panels) ───────────────────────────

function packLayerImprovedGreedy(
  panels: FlatPackPanel[],
  footprintLength: number,
  footprintWidth: number
): PackResult {
  // Sort by area descending
  const sorted = [...panels].sort((a, b) => (b.length * b.width) - (a.length * a.width));

  const placed: PlacedPanel[] = [];
  const unplaced: FlatPackPanel[] = [];
  const occupiedRects: Rect[] = [];

  for (const panel of sorted) {
    // Try non-rotated
    const posNormal = findPositionForPanel(
      panel.length, panel.width, occupiedRects, footprintLength, footprintWidth
    );

    // Try rotated
    const posRotated = findPositionForPanel(
      panel.width, panel.length, occupiedRects, footprintLength, footprintWidth
    );

    if (!posNormal && !posRotated) {
      unplaced.push(panel);
      continue;
    }

    // Choose orientation that leaves more usable space
    let useRotated = false;
    let chosenPos: { x: number; y: number };

    if (posNormal && posRotated) {
      // Calculate remaining space for each option
      const remainingNormal = (footprintLength - (posNormal.x + panel.length)) *
        (footprintWidth - (posNormal.y + panel.width));
      const remainingRotated = (footprintLength - (posRotated.x + panel.width)) *
        (footprintWidth - (posRotated.y + panel.length));

      if (remainingRotated > remainingNormal) {
        useRotated = true;
        chosenPos = posRotated;
      } else {
        chosenPos = posNormal;
      }
    } else if (posNormal) {
      chosenPos = posNormal;
    } else {
      useRotated = true;
      chosenPos = posRotated!;
    }

    const pLength = useRotated ? panel.width : panel.length;
    const pWidth = useRotated ? panel.length : panel.width;

    placed.push({
      panel,
      x: chosenPos.x,
      y: chosenPos.y,
      isRotated: useRotated,
      placedLength: pLength,
      placedWidth: pWidth,
    });
    occupiedRects.push({ x: chosenPos.x, y: chosenPos.y, length: pLength, width: pWidth });
  }

  return { placed, unplaced };
}

// ─── Layer Packing Dispatcher ───────────────────────────────────────────────

function packLayerGreedy(
  panels: FlatPackPanel[],
  footprintLength: number,
  footprintWidth: number
): PackResult {
  if (panels.length <= 6) {
    return packLayerWithRotationExploration(panels, footprintLength, footprintWidth);
  }
  return packLayerImprovedGreedy(panels, footprintLength, footprintWidth);
}

// ─── Pack All Panels Into Layers ────────────────────────────────────────────

function packPanelsIntoLayers(
  panels: FlatPackPanel[],
  footprintLength: number,
  footprintWidth: number
): StackLayer[] {
  // Group by thickness (can only share layer if same thickness)
  const byThickness = new Map<number, FlatPackPanel[]>();
  for (const panel of panels) {
    const key = Math.round(panel.thickness * 1000) / 1000;
    const group = byThickness.get(key) || [];
    group.push(panel);
    byThickness.set(key, group);
  }

  // Sort thickness groups descending (thicker panels at bottom)
  const thicknessGroups = [...byThickness.entries()]
    .sort(([a], [b]) => b - a);

  const layers: StackLayer[] = [];
  let layerNumber = 1;

  for (const [thickness, groupPanels] of thicknessGroups) {
    // Expand panels by quantity
    const expandedPanels: FlatPackPanel[] = [];
    for (const panel of groupPanels) {
      for (let i = 0; i < panel.quantity; i++) {
        expandedPanels.push({ ...panel, quantity: 1 });
      }
    }

    // Sort by area descending
    expandedPanels.sort((a, b) => (b.length * b.width) - (a.length * a.width));

    let remaining = expandedPanels;

    while (remaining.length > 0) {
      const result = packLayerGreedy(remaining, footprintLength, footprintWidth);

      if (result.placed.length === 0) {
        // Can't place any more panels — they don't fit
        break;
      }

      layers.push({
        layerNumber,
        thickness,
        placedPanels: result.placed,
      });
      layerNumber++;

      remaining = result.unplaced;
    }
  }

  return layers;
}

// ─── Filler Piece Generation ────────────────────────────────────────────────

function tryExpandRectangle(
  rect: Rect,
  occupiedRects: Rect[],
  footprintLength: number,
  footprintWidth: number
): Rect {
  let { x, y, length, width } = rect;

  // Try expanding right
  const xCoords = new Set<number>();
  xCoords.add(footprintLength);
  for (const r of occupiedRects) {
    xCoords.add(r.x);
    xCoords.add(r.x + r.length);
  }
  const sortedX = [...xCoords].filter(v => v > x + length).sort((a, b) => a - b);

  for (const nextX of sortedX) {
    const expandedRect: Rect = { x, y, length: nextX - x, width };
    let blocked = false;
    for (const occ of occupiedRects) {
      if (rectanglesOverlap(expandedRect, occ)) {
        blocked = true;
        break;
      }
    }
    if (blocked) break;
    length = nextX - x;
  }

  // Try expanding up (width direction)
  const yCoords = new Set<number>();
  yCoords.add(footprintWidth);
  for (const r of occupiedRects) {
    yCoords.add(r.y);
    yCoords.add(r.y + r.width);
  }
  const sortedY = [...yCoords].filter(v => v > y + width).sort((a, b) => a - b);

  for (const nextY of sortedY) {
    const expandedRect: Rect = { x, y, length, width: nextY - y };
    let blocked = false;
    for (const occ of occupiedRects) {
      if (rectanglesOverlap(expandedRect, occ)) {
        blocked = true;
        break;
      }
    }
    if (blocked) break;
    width = nextY - y;
  }

  return { x, y, length, width };
}

function findEmptyRectangles(
  occupiedRects: Rect[],
  footprintLength: number,
  footprintWidth: number
): Rect[] {
  // Create grid of coordinates
  const xSet = new Set<number>([0, footprintLength]);
  const ySet = new Set<number>([0, footprintWidth]);
  for (const r of occupiedRects) {
    xSet.add(r.x);
    xSet.add(r.x + r.length);
    ySet.add(r.y);
    ySet.add(r.y + r.width);
  }

  const xList = [...xSet].sort((a, b) => a - b);
  const yList = [...ySet].sort((a, b) => a - b);

  const emptyRects: Rect[] = [];
  const expandedSet = new Set<string>();

  for (let i = 0; i < xList.length - 1; i++) {
    for (let j = 0; j < yList.length - 1; j++) {
      const cellX = xList[i];
      const cellY = yList[j];
      const cellLength = xList[i + 1] - cellX;
      const cellWidth = yList[j + 1] - cellY;

      // Skip cells smaller than minimum filler size
      if (cellLength < MIN_FILLER_SIZE || cellWidth < MIN_FILLER_SIZE) continue;

      // Check if cell overlaps any occupied rectangle
      const cellRect: Rect = { x: cellX, y: cellY, length: cellLength, width: cellWidth };
      let isOccupied = false;
      for (const occ of occupiedRects) {
        if (rectanglesOverlap(cellRect, occ)) {
          isOccupied = true;
          break;
        }
      }

      if (!isOccupied) {
        // Try to expand the rectangle
        const expanded = tryExpandRectangle(cellRect, occupiedRects, footprintLength, footprintWidth);
        const key = `${expanded.x.toFixed(3)},${expanded.y.toFixed(3)},${expanded.length.toFixed(3)},${expanded.width.toFixed(3)}`;

        if (!expandedSet.has(key)) {
          expandedSet.add(key);
          emptyRects.push(expanded);
        }
      }
    }
  }

  // Remove rectangles that are contained within larger ones
  return emptyRects.filter((r, idx) => {
    for (let k = 0; k < emptyRects.length; k++) {
      if (k === idx) continue;
      const other = emptyRects[k];
      if (
        r.x >= other.x - OVERLAP_TOLERANCE &&
        r.y >= other.y - OVERLAP_TOLERANCE &&
        r.x + r.length <= other.x + other.length + OVERLAP_TOLERANCE &&
        r.y + r.width <= other.y + other.width + OVERLAP_TOLERANCE &&
        (other.length * other.width) > (r.length * r.width)
      ) {
        return false; // contained within a larger rectangle
      }
    }
    return true;
  });
}

function generateFillerPieces(
  layers: StackLayer[],
  footprintLength: number,
  footprintWidth: number,
  settings: FlatPackSettings
): FillerPiece[] {
  const fillers: FillerPiece[] = [];

  for (const layer of layers) {
    const occupiedRects: Rect[] = layer.placedPanels.map(p => ({
      x: p.x,
      y: p.y,
      length: p.placedLength,
      width: p.placedWidth,
    }));

    const emptyRects = findEmptyRectangles(occupiedRects, footprintLength, footprintWidth);

    for (const rect of emptyRects) {
      const weight = rect.length * rect.width * layer.thickness * settings.birchDensity;
      fillers.push({
        layerNumber: layer.layerNumber,
        x: rect.x,
        y: rect.y,
        length: rect.length,
        width: rect.width,
        thickness: layer.thickness,
        weight,
      });
    }
  }

  return fillers;
}

// ─── Main Calculator ────────────────────────────────────────────────────────

/**
 * Calculate optimal flat pack stack arrangement using full 2D bin packing.
 * Matches desktop FlatPackStackOptimizer.CalculateOptimalStack().
 */
export function calculateOptimalStack(
  cutList: CutListItem[],
  dutyType: string,
  settings: FlatPackSettings = DEFAULT_FLAT_PACK_SETTINGS
): FlatPackResult {
  const warnings: string[] = [];

  // Step 1: Convert CutListItems → FlatPackPanels
  const panels: FlatPackPanel[] = cutList.map(item => {
    const thickness = getPanelThickness(item.material, item.partName, dutyType);
    const isMdf = item.material.toLowerCase().includes('mdf');
    const density = isMdf ? settings.mdfDensity : settings.birchDensity;
    // Normalize: length ≥ width
    const length = Math.max(item.width, item.height);
    const width = Math.min(item.width, item.height);
    const weight = length * width * thickness * density;

    return {
      partName: item.partName,
      length,
      width,
      thickness,
      material: item.material,
      weight: weight * item.quantity,
      quantity: item.quantity,
    };
  });

  if (panels.length === 0) {
    return emptyResult(settings);
  }

  // Step 2: Determine footprint from Top/Bottom panels
  let footprintLength: number;
  let footprintWidth: number;

  const topBottom = panels.find(p =>
    p.partName === 'Top' || p.partName === 'Bottom'
  );

  if (topBottom) {
    footprintLength = topBottom.length;
    footprintWidth = topBottom.width;
  } else {
    // Fallback to largest panel
    const sorted = [...panels].sort((a, b) => (b.length * b.width) - (a.length * a.width));
    footprintLength = sorted[0].length;
    footprintWidth = sorted[0].width;
  }

  // Step 3: Validate all panels fit within footprint
  for (const panel of panels) {
    const fitsNormal = panel.length <= footprintLength && panel.width <= footprintWidth;
    const fitsRotated = panel.width <= footprintLength && panel.length <= footprintWidth;
    if (!fitsNormal && !fitsRotated) {
      warnings.push(`Panel "${panel.partName}" (${panel.length.toFixed(1)}x${panel.width.toFixed(1)}) exceeds footprint`);
    }
  }

  // Step 4: Pack panels into layers
  const layers = packPanelsIntoLayers(panels, footprintLength, footprintWidth);

  // Step 5: Calculate stack height
  const stackHeight = layers.reduce((sum, l) => sum + l.thickness, 0);

  // Step 6: Calculate panel weight
  const panelWeight = panels.reduce((sum, p) => sum + p.weight, 0);

  // Step 7: Generate filler pieces
  const fillerPieces = generateFillerPieces(layers, footprintLength, footprintWidth, settings);
  const fillerWeight = fillerPieces.reduce((sum, f) => sum + f.weight, 0);

  // Step 8: Calculate box dimensions
  const boxLength = footprintLength + 2 * settings.sidePadding;
  const boxWidth = footprintWidth + 2 * settings.sidePadding;
  const boxHeight = stackHeight + 2 * settings.verticalPadding;

  const exteriorLength = boxLength + BOX_WALL_LW;
  const exteriorWidth = boxWidth + BOX_WALL_LW;
  const exteriorHeight = boxHeight + BOX_WALL_H;

  // Step 9: Calculate weights
  const totalShippedWeight = roundShippingWeight(panelWeight + settings.packagingWeight);
  const volume = exteriorLength * exteriorWidth * exteriorHeight;
  const dimensionalWeightUPS = volume / DIM_WEIGHT_FACTOR_UPS;
  const dimensionalWeightUSPS = volume / DIM_WEIGHT_FACTOR_USPS;
  const billableWeightUPS = roundShippingWeight(Math.max(totalShippedWeight, dimensionalWeightUPS));
  const billableWeightUSPS = roundShippingWeight(Math.max(totalShippedWeight, dimensionalWeightUSPS));

  // Step 10: Packaging plywood (crating) area calculations
  const pkgTopBottomArea = 2 * boxLength * boxWidth;
  const pkgFrontBackArea = 2 * boxLength * stackHeight;
  const pkgSidesArea = 2 * Math.max(0, boxWidth - 1.0) * stackHeight;
  const pkgTotalArea = (pkgTopBottomArea + pkgFrontBackArea + pkgSidesArea) * 1.20; // 20% waste

  const panelCount = panels.reduce((sum, p) => sum + p.quantity, 0);

  // Build stacked panels list for display (Bottom → Top)
  const stackedPanels: StackedPanelInfo[] = [];
  let pos = 1;
  for (const layer of layers) {
    for (const placed of layer.placedPanels) {
      stackedPanels.push({
        stackPosition: pos++,
        partName: placed.panel.partName,
        length: placed.panel.length,
        width: placed.panel.width,
      });
    }
  }

  return {
    footprintLength,
    footprintWidth,
    stackHeight,
    boxLength,
    boxWidth,
    boxHeight,
    exteriorLength,
    exteriorWidth,
    exteriorHeight,
    panelCount,
    layerCount: layers.length,
    panelWeight,
    fillerPieces,
    fillerPieceCount: fillerPieces.length,
    fillerWeight,
    packagingWeight: settings.packagingWeight,
    totalShippedWeight,
    dimensionalWeightUPS,
    dimensionalWeightUSPS,
    billableWeightUPS,
    billableWeightUSPS,
    pkgTopBottomArea,
    pkgFrontBackArea,
    pkgSidesArea,
    pkgTotalArea,
    stackedPanels,
    warnings,
  };
}

function emptyResult(settings: FlatPackSettings): FlatPackResult {
  return {
    footprintLength: 0, footprintWidth: 0, stackHeight: 0,
    boxLength: 0, boxWidth: 0, boxHeight: 0,
    exteriorLength: 0, exteriorWidth: 0, exteriorHeight: 0,
    panelCount: 0, layerCount: 0, panelWeight: 0,
    fillerPieces: [], fillerPieceCount: 0, fillerWeight: 0,
    packagingWeight: settings.packagingWeight,
    totalShippedWeight: roundShippingWeight(settings.packagingWeight),
    dimensionalWeightUPS: 0, dimensionalWeightUSPS: 0,
    billableWeightUPS: 0, billableWeightUSPS: 0,
    pkgTopBottomArea: 0, pkgFrontBackArea: 0, pkgSidesArea: 0, pkgTotalArea: 0,
    stackedPanels: [],
    warnings: [],
  };
}
import { roundShippingWeight } from './shipping-weight';
