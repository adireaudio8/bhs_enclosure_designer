/**
 * Enclosure Calculator - Calculation Engine
 * Ported from C# WPF EnclosureViewModel.Calculations.cs + EnclosureViewModel.CutList.cs
 *
 * All calculations are O(1) complexity - simple arithmetic operations.
 */

import {
  EnclosureInputs,
  EnclosureCalculations,
  CutListItem,
  BaffleCheckResult,
  ShippingInfo,
  MaterialConfig,
  DEFAULT_MATERIAL_CONFIG,
  DEFAULT_GLUE_TOLERANCE,
} from './types/enclosure';
import { resolveSupbAutoCenterY } from './subwoofer-placement';
import { buildAcrylicWindowCutListEntry } from './acrylic-window';

// ─── Material Assignment Matrix ──────────────────────────────────────────────
// Ported from C# Models/MaterialAssignmentMatrix.cs
// Determines which material type and thickness each part uses per config.

export interface PartMaterial {
  materialType: string;       // 'Birch Ply' | 'MDF'
  materialDescription: string; // '18mm Birch Ply', '24mm Birch Ply', '3/4" MDF', '1" MDF'
  thicknessInches: number;
  thicknessCode: string;      // B1, B2, D1, D2
}

/**
 * Get material assignment for a specific part and enclosure configuration.
 *
 * Regular Duty thick-panel rule depends on the enclosure configuration:
 *   - SBPB (Subs Back / Port Back): Baffle is the load-bearing panel — Baffle = 24mm/1", rest = 18mm/3/4"
 *   - SUPB (Subs Up / Port Back):   Top is the load-bearing panel    — Top    = 24mm/1", rest = 18mm/3/4"
 *
 * SD always uses thin everywhere; HD always uses thick everywhere; only RD
 * branches on configuration.
 */
export function getPartMaterial(
  partName: string,
  enclosureType: string,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  enclosureConfiguration: string = 'Subs Back/Port Back',
): PartMaterial {
  const useMDF = isMDF(enclosureType);
  const useStandard = isStandardDuty(enclosureType);
  const useHeavy = isHeavyDuty(enclosureType);
  const isSUPB = enclosureConfiguration === 'Subs Up/Port Back';

  if (useMDF) {
    if (useStandard) {
      return { materialType: 'MDF', materialDescription: '3/4" MDF', thicknessInches: config.D1, thicknessCode: 'D1' };
    } else if (useHeavy) {
      return { materialType: 'MDF', materialDescription: '1" MDF', thicknessInches: config.D2, thicknessCode: 'D2' };
    } else {
      // Regular Duty: thick panel is Top in SUPB, Baffle in SBPB; rest = 3/4" (D1)
      const thickPart = isSUPB ? 'Top' : 'Baffle';
      if (partName === thickPart) {
        return { materialType: 'MDF', materialDescription: '1" MDF', thicknessInches: config.D2, thicknessCode: 'D2' };
      }
      return { materialType: 'MDF', materialDescription: '3/4" MDF', thicknessInches: config.D1, thicknessCode: 'D1' };
    }
  } else {
    if (useStandard) {
      return { materialType: 'Birch Ply', materialDescription: '18mm Birch Ply', thicknessInches: config.B1, thicknessCode: 'B1' };
    } else if (useHeavy) {
      return { materialType: 'Birch Ply', materialDescription: '24mm Birch Ply', thicknessInches: config.B2, thicknessCode: 'B2' };
    } else {
      // Regular Duty: thick panel is Top in SUPB, Baffle in SBPB; rest = 18mm (B1)
      const thickPart = isSUPB ? 'Top' : 'Baffle';
      if (partName === thickPart) {
        return { materialType: 'Birch Ply', materialDescription: '24mm Birch Ply', thicknessInches: config.B2, thicknessCode: 'B2' };
      }
      return { materialType: 'Birch Ply', materialDescription: '18mm Birch Ply', thicknessInches: config.B1, thicknessCode: 'B1' };
    }
  }
}

/**
 * Get all part materials for a given enclosure type and configuration.
 */
export function getAllPartMaterials(
  enclosureType: string,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  enclosureConfiguration: string = 'Subs Back/Port Back',
): Record<string, PartMaterial> {
  const partNames = [
    'Top', 'Bottom', 'Back', 'Baffle', 'Side Left', 'Side Right',
    'Port Piece 1', 'Port Piece 2', 'Gusset 1', 'Gusset 2', 'Gusset 3',
  ];
  const materials: Record<string, PartMaterial> = {};
  for (const partName of partNames) {
    materials[partName] = getPartMaterial(partName, enclosureType, config, enclosureConfiguration);
  }
  return materials;
}

// ─── Utility Helpers ─────────────────────────────────────────────────────────

/**
 * Get the number of subwoofers based on quantity selection
 */
export function getSubwooferCount(quantity: string): number {
  switch (quantity) {
    case 'Single': return 1;
    case 'Dual': return 2;
    case 'Triple': return 3;
    case 'Quad': return 4;
    default: return 1;
  }
}

/**
 * Get the number of gussets based on subwoofer quantity
 */
export function getGussetCount(quantity: string): number {
  switch (quantity) {
    case 'Single': return 0;
    case 'Dual': return 1;
    case 'Triple': return 2;
    case 'Quad': return 3;
    default: return 0;
  }
}

export function isMDF(enclosureType: string): boolean {
  return enclosureType.includes('MDF');
}

export function isStandardDuty(enclosureType: string): boolean {
  return enclosureType.includes('Standard Duty');
}

export function isRegularDuty(enclosureType: string): boolean {
  return enclosureType.includes('Regular Duty');
}

export function isHeavyDuty(enclosureType: string): boolean {
  return enclosureType.includes('Heavy Duty');
}

/**
 * Get primary material thickness based on enclosure type
 * Standard/Regular: Birch=B1, MDF=D1 | Heavy: Birch=B2, MDF=D2
 */
export function getMaterialThickness(
  enclosureType: string,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG
): number {
  const useMDF = isMDF(enclosureType);
  const useHeavy = isHeavyDuty(enclosureType);

  if (useMDF) {
    return useHeavy ? config.D2 : config.D1;
  } else {
    return useHeavy ? config.B2 : config.B1;
  }
}

/**
 * Round up to the nearest 1/8 of an inch
 * Ported from C# RoundUpToEighth()
 */
export function roundUpToEighth(value: number): number {
  return Math.ceil(value * 8.0) / 8.0;
}

// ─── Baffle Check (Subwoofer Fit Validation) ─────────────────────────────────
// Ported from C# EnclosureViewModel.Calculations.cs lines 427-528

/**
 * Calculate baffle check — validates whether subwoofers physically fit
 * on the mounting surface (baffle for SBPB, top panel for SUPB).
 */
export function calculateBaffleCheck(
  inputs: EnclosureInputs,
  s2LeftWidth: number,
  boxWidth: number,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  s1RightWidth: number = 0,
  internalHeight: number = 0,
): BaffleCheckResult {
  const {
    outsideDiameter,
    portWidth,
    enclosureType,
    enclosureConfiguration,
    subwooferQuantity,
    portQuantity,
  } = inputs;

  const visible = outsideDiameter > 0;
  const isSubsUpPortBack = enclosureConfiguration === 'Subs Up/Port Back';
  const subCount = getSubwooferCount(subwooferQuantity);
  const isDualPort = portQuantity === 'Dual';
  const useMDF = isMDF(enclosureType);
  const useHeavy = isHeavyDuty(enclosureType);

  // Calculate net usable width on the mounting surface
  let netWidth: number;
  let mountLabel = isSubsUpPortBack ? 'Top Panel (S2 Left)' : 'Baffle';

  if (isSubsUpPortBack) {
    if (isDualPort) {
      // Dual port: each chamber is separate, sub mounts in S2 Left
      netWidth = s2LeftWidth;
    } else {
      // Single port: prefer S2 alone; if S2 is too small for the sub, fall back
      // to the combined chamber (s2 + s1) since L-shape geometry connects them.
      // This is what makes RD-SUPB's narrower S2 still fit a sub by spanning
      // across the L into S1.
      const s2EdgeClearance = subCount > 0 && outsideDiameter > 0
        ? (s2LeftWidth - outsideDiameter * subCount) / (subCount + 1)
        : 0;
      if (s2EdgeClearance > 0) {
        netWidth = s2LeftWidth;
      } else {
        netWidth = s2LeftWidth + s1RightWidth;
        mountLabel = 'Top Panel (S2 + S1)';
      }
    }
  } else {
    // SBPB: Replicate baffle width formula from cut list
    const roundedBoxWidth = roundUpToEighth(boxWidth);
    // Desktop always uses Birch values (B1/B2) for baffleThicknessForWidth, even for MDF.
    // This represents the PP2 wall thickness the baffle sits against (same material as walls).
    const baffleThicknessForWidth = useHeavy ? config.B2 : config.B1;

    let baffleWidth: number;
    if (isDualPort) {
      baffleWidth = roundedBoxWidth - (2 * portWidth + 2 * baffleThicknessForWidth);
    } else {
      baffleWidth = roundedBoxWidth - (portWidth + baffleThicknessForWidth);
    }

    // Side Left thickness = standard wall material
    const sideLeftThick = getMaterialThickness(enclosureType, config);

    // Port Piece 1 thickness: same as wall for SD/RD, heavy for HD
    const pp1Thick = useHeavy
      ? (useMDF ? config.D2 : config.B2)
      : getMaterialThickness(enclosureType, config);

    netWidth = baffleWidth - sideLeftThick - pp1Thick;
  }

  // ─── X-direction edge clearance ──────────────────────────────────────────
  // Gap between sub OD and the panel's left/right edges (chamber walls for
  // SUPB, baffle outer X for SBPB). For multi-sub it's the gap on each side
  // of the array — same value as the inter-sub gap for evenly-distributed
  // layouts, hence subToSubGap below.
  let xEdgeClearance = 0;
  if (subCount > 0 && outsideDiameter > 0) {
    xEdgeClearance = (netWidth - outsideDiameter * subCount) / (subCount + 1);
  }

  // ─── Y-direction edge clearance ──────────────────────────────────────────
  // Gap between sub OD and the panel's perpendicular edges (top/bottom of
  // baffle for SBPB, front/back of top panel for SUPB). The subwoofer is
  // centered along this axis (or shifted by subwooferYOffset for SUPB), so
  // we take the smaller of front/back to surface the worst-case clearance.
  // SBPB: panel = baffle (height = internalHeight), sub centered → both
  //       sides equal, clearance = (internalHeight − OD) / 2.
  // SUPB: panel = top (depth = boxDepth). subY defaults to boxDepth/2 (or
  //       the combined-chamber fallback (boxDepth − portWidth − t)/2 when
  //       S2 alone is too narrow), plus user subwooferYOffset.
  let yEdgeClearance: number | null = null;
  if (subCount > 0 && outsideDiameter > 0) {
    const halfOD = outsideDiameter / 2;
    if (isSubsUpPortBack) {
      const boxDepth = inputs.boxDepth;
      if (boxDepth > 0) {
        // Determine if combined-chamber fallback is in effect (= S2 alone
        // can't fit the sub at the desired count, sub spans into S1).
        const wallT = useMDF ? config.D1 : config.B1;
        const useCombinedSupb = !isDualPort && subCount > 0 && outsideDiameter > 0
          && ((s2LeftWidth - outsideDiameter * subCount) / (subCount + 1)) <= 0;
        // Mirror resolveSupbAutoCenterY so the displayed clearance reflects
        // the same auto-position the slider, DXF, and 3D viewer all use.
        const cutoutD = inputs.subCutoutDiameter || outsideDiameter;
        const s1DepthFb = useCombinedSupb
          ? Math.max(0, boxDepth - 2 * wallT - portWidth - wallT)
          : 0;
        const baseCenterY = resolveSupbAutoCenterY({
          boxDepth,
          portWidth,
          wallT,
          tBaffle: wallT,
          tBack: wallT,
          s1Depth: s1DepthFb,
          useCombined: useCombinedSupb,
          halfOD,
          halfCutout: cutoutD / 2,
        });
        const subYOff = inputs.subwooferYOffset ?? 0;
        const subCenterY = baseCenterY + subYOff;
        const frontClear = subCenterY - halfOD;
        const backClear = boxDepth - subCenterY - halfOD;
        yEdgeClearance = Math.min(frontClear, backClear);
      }
    } else {
      // SBPB: sub on baffle, centered vertically. Clearance is symmetric.
      if (internalHeight > 0) {
        yEdgeClearance = (internalHeight - outsideDiameter) / 2;
      }
    }
  }

  // The reported edgeClearance is the WORST direction — driving the
  // status thresholds — so a sub close to ANY panel edge surfaces correctly.
  const edgeClearance = yEdgeClearance !== null
    ? Math.min(xEdgeClearance, yEdgeClearance)
    : xEdgeClearance;

  // Sub-to-sub gap is always X-direction (subs spread along X); keep
  // computing from xEdgeClearance directly so the displayed sub-gap value
  // doesn't get pulled down by a tight Y dimension.
  const subToSubGap = xEdgeClearance;
  const showSubGap = subCount > 1;

  // Status thresholds (driven by worst-direction edgeClearance)
  let status: BaffleCheckResult['status'];
  if (edgeClearance <= 0.25) {
    status = 'DOES NOT FIT';
  } else if (edgeClearance <= 0.5) {
    status = 'Tight Fit';
  } else {
    status = 'OK';
  }

  // ─── Flush mount baffle height check ────────────────────────────────────
  // When recessed mounting is on, the structural baffle has a flange-recess
  // hole sized to subOD + 0.25". To cut that cleanly we need at least 0.5"
  // of material above and below the cutout — so the minimum baffle height
  // is subOD + 1.25". If internalHeight (= baffle height for SBPB) falls
  // short, the flange recess can't be cut and we fail the design.
  // SBPB-only (matches the engine-side gating) — SUPB doesn't apply yet.
  let isFail = edgeClearance <= 0.25;
  let isWarning = edgeClearance > 0.25 && edgeClearance <= 0.5;
  const recessedActive = !!inputs.recessedMounting && !isSubsUpPortBack;
  if (recessedActive && outsideDiameter > 0 && internalHeight > 0) {
    const minBaffleHeight = outsideDiameter + 0.25 + 1.0;
    if (internalHeight < minBaffleHeight) {
      status = 'DOES NOT FIT';
      isFail = true;
      isWarning = false;
      mountLabel = 'Baffle (flush mount needs taller box)';
    }
  }

  return {
    visible,
    mountLabel,
    netWidth,
    edgeClearance,
    subToSubGap,
    showSubGap,
    status,
    isFail,
    isWarning,
  };
}

// ─── Main Calculation Engine ─────────────────────────────────────────────────

/**
 * Calculate all enclosure values from inputs
 * This is the main calculation engine
 */
export function calculateEnclosure(
  inputs: EnclosureInputs,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG
): EnclosureCalculations {
  const {
    boxDepth,
    boxHeight,
    portWidth,
    tuningFrequency,
    netAirSpace,
    subDisplacement,
    subCutoutDiameter,
    enclosureType,
    enclosureConfiguration,
    subwooferQuantity,
    portQuantity,
  } = inputs;

  const isDualPort = portQuantity === 'Dual';
  const subCount = getSubwooferCount(subwooferQuantity);
  const gussetCount = getGussetCount(subwooferQuantity);
  const thickness = getMaterialThickness(enclosureType, config);
  const useMDF = isMDF(enclosureType);
  const useStandard = isStandardDuty(enclosureType);
  const useRegular = isRegularDuty(enclosureType);
  const isSubsUpPortBack = enclosureConfiguration === 'Subs Up/Port Back';

  // ----- Net Air Space Calculations -----
  const netAirSpaceForPortCalculations = isDualPort ? netAirSpace / 2.0 : netAirSpace;
  const netAirSpacePerChamber = isDualPort ? netAirSpace / 2.0 : netAirSpace;

  // ----- Internal Height -----
  // Top + Bottom thickness sum, matched to actual material:
  //   SD / RD-SBPB: 1.5  (D1+D1 exact / B1+B1 over by 0.082)
  //   RD-SUPB:      1.75 (D1+D2 exact / B1+B2 over by 0.096) — Top is now thick
  //   HD:           2.0  (D2+D2 exact / B2+B2 over by 0.11)
  let internalHeight: number;
  if (useStandard || (useRegular && !isSubsUpPortBack)) {
    internalHeight = boxHeight - 1.5;
  } else if (useRegular && isSubsUpPortBack) {
    internalHeight = boxHeight - 1.75;
  } else {
    internalHeight = boxHeight - 2.0;
  }

  // ----- Internal Depth With DB -----
  // Baffle + Back thickness sum, matched to actual material. In SUPB-RD
  // the Baffle is 18 mm and the Back is 18 mm (same as SD), so the formula
  // uses 2·B1 / 2·D1 — different from RD-SBPB which has a 24 mm baffle.
  let internalDepthWithDB: number;
  if (useMDF) {
    if (useStandard || (useRegular && isSubsUpPortBack)) {
      internalDepthWithDB = boxDepth - (2.0 * config.D1);
    } else if (useRegular) {
      internalDepthWithDB = boxDepth - (config.D1 + config.D2);
    } else {
      internalDepthWithDB = boxDepth - (2.0 * config.D2);
    }
  } else {
    if (useStandard || (useRegular && isSubsUpPortBack)) {
      internalDepthWithDB = boxDepth - (2.0 * config.B1);
    } else if (useRegular) {
      internalDepthWithDB = boxDepth - (config.B1 + config.B2);
    } else {
      internalDepthWithDB = boxDepth - (2.0 * config.B2);
    }
  }

  // ----- Mounting Depth Available -----
  // Same baffle/back rule as internalDepthWithDB, minus port width.
  let mountingDepthAvail: number;
  if (useMDF) {
    if (useStandard || (useRegular && isSubsUpPortBack)) {
      mountingDepthAvail = boxDepth - (portWidth + (2.0 * config.D1));
    } else if (useRegular) {
      mountingDepthAvail = boxDepth - (portWidth + config.D1 + config.D2);
    } else {
      mountingDepthAvail = boxDepth - (portWidth + (2.0 * config.D2));
    }
  } else {
    if (useStandard || (useRegular && isSubsUpPortBack)) {
      mountingDepthAvail = boxDepth - (portWidth + (2.0 * config.B1));
    } else if (useRegular) {
      mountingDepthAvail = boxDepth - (portWidth + config.B1 + config.B2);
    } else {
      mountingDepthAvail = boxDepth - (portWidth + (2.0 * config.B2));
    }
  }

  // ----- Flush mount (recessed sub mounting) depth adjustment -----
  // SBPB / SUPP: structural-baffle thinning (24mm → 18mm for RD/HD) plus
  // the inner sub-mount plate (24mm RD/HD or 18mm SD glued behind the
  // structural baffle) nets out to exactly one B1/D1 of additional wood
  // in front of the chamber, regardless of duty. So we can capture the
  // whole effect with a single subtraction here. The chamber gets B1/D1
  // shallower; mounting depth available drops by the same amount since
  // the sub now mounts to the inner plate's back face, not the structural
  // baffle's back face.
  const isRecessed = !!inputs.recessedMounting && !isSubsUpPortBack;
  if (isRecessed) {
    const recessedDepthReduction = useMDF ? config.D1 : config.B1;
    internalDepthWithDB -= recessedDepthReduction;
    mountingDepthAvail -= recessedDepthReduction;
  }

  // ----- Flush mount (recessed sub mounting) HEIGHT adjustment for SUPB -----
  // SUPB construction: an 18mm "Sub Mount Cap" sits on top of the
  // enclosure (full outer footprint) and recesses the sub flange. Because
  // boxHeight is the total external dimension (cap inclusive), adding the
  // cap effectively eats one B1 (or D1 for MDF) out of the chamber. Port
  // height, gusset height, port piece height, and port length all derive
  // from internalHeight, so reducing it here ripples through automatically.
  const isRecessedSupb = !!inputs.recessedMounting && isSubsUpPortBack;
  if (isRecessedSupb) {
    const capThickness = useMDF ? config.D1 : config.B1;
    internalHeight -= capThickness;
  }

  // ----- Port Calculations -----
  const portHeight = internalHeight;
  const portArea = portWidth * portHeight;

  // Port Length 1 = BoxDepth - (MaterialThickness + (PortWidth/2))
  // `thickness` is the actual wall material (B1/D1 for SD/RD, B2/D2 for HD)
  // — SUPB-RD's PP1 is the thin material so this stays correct.
  const portLength1 = boxDepth - (thickness + (portWidth / 2.0));

  // Port Length No EC - Complex resonance formula
  const portAreaCalc = portWidth * portHeight;
  const sqrtValue = Math.sqrt(portAreaCalc / 3.14159);
  const effectiveRadius = (2.0 * sqrtValue) / 2.0;
  const numerator = 14630000.0 * effectiveRadius * effectiveRadius;
  const denominator = tuningFrequency * tuningFrequency * netAirSpaceForPortCalculations * 1728.0;
  const portLengthNoEC = denominator > 0
    ? (numerator / denominator) - (1.463 * effectiveRadius)
    : 0;

  // Port Length 2 = PortLengthNoEC - PortLength1
  const portLength2 = portLengthNoEC - portLength1;

  // Sq in Per Cube = PortArea / NetAirSpaceForPortCalculations
  const sqInPerCube = netAirSpaceForPortCalculations > 0
    ? portArea / netAirSpaceForPortCalculations
    : 0;

  // ----- S1 Right Calculations -----
  // `thickness` is the actual PP1 material (B1/D1 for SD/RD-SUPB/RD-SBPB,
  // B2/D2 for HD) — matches reality for every config.
  const s1RightWidth = portLength2 - (portWidth + thickness);
  const s1RightHeight = internalHeight;
  const s1RightDepth = internalDepthWithDB - (portWidth + thickness);
  const s1RightArea = (s1RightWidth * s1RightHeight * s1RightDepth) / 1728.0;

  // ----- S2 Left Calculations -----
  const s2LeftHeight = internalHeight;
  const s2LeftDepth = internalDepthWithDB;

  // ----- Volume Calculations -----
  // Sub Cut-out Add - uses the mounting panel's thickness. The cutout sits in
  // the Baffle for SBPB and in the Top panel for SUPB. The thick panel is
  // always the mounting panel for RD/HD, which is why the legacy code's
  // "baffle thickness = thick" formula was correct for SBPB but happened to
  // also produce the right number for SUPB-RD when the Top was thick. With
  // the SUPB-RD top↔baffle swap this still resolves to the thick panel for
  // RD/HD, so the formula is unchanged in value but the variable name now
  // reflects the actual geometry.
  const mountingPanelThickness = useMDF
    ? (useStandard ? config.D1 : config.D2)
    : (useStandard ? config.B1 : config.B2);

  const baseCutoutVolume = (Math.PI * Math.pow(subCutoutDiameter / 2.0, 2.0) * mountingPanelThickness) / 1728.0;
  let subCutoutAdd = baseCutoutVolume * subCount;
  if (isDualPort) {
    subCutoutAdd /= 2.0;
  }

  // Gusset Displacement
  const singleGussetVolume = gussetCount > 0
    ? (5.0 * internalHeight * thickness) / 1728.0
    : 0;
  const gussetDisplacement = singleGussetVolume * gussetCount;

  // Total Needed
  let subDisplacementForChamber = subDisplacement * subCount;
  if (isDualPort) {
    subDisplacementForChamber /= 2.0;
  }
  const totalNeeded = netAirSpacePerChamber + subDisplacementForChamber + gussetDisplacement;

  // Adjusted Needed
  const adjustedNeeded = totalNeeded - subCutoutAdd;

  // S1 Right Still Needed
  const s1RightStillNeeded = adjustedNeeded - s1RightArea;

  // S2 Left Still Needed (convert to cubic inches)
  const s2LeftStillNeeded = s1RightStillNeeded * 1728.0;

  // S2 Left Width
  const s2LeftWidth = s2LeftHeight > 0 && s2LeftDepth > 0
    ? (s2LeftStillNeeded / s2LeftHeight) / s2LeftDepth
    : 0;
  const s2LeftArea = (s2LeftWidth * s2LeftHeight * s2LeftDepth) / 1728.0;

  // ----- Box Width -----
  let boxWidth: number;
  if (isDualPort) {
    const oneSide = s1RightWidth + s2LeftWidth + portWidth + (thickness * 3.0);
    const doubled = oneSide * 2.0;
    const subtract = thickness * 2.0;
    boxWidth = doubled - subtract;
  } else {
    boxWidth = s1RightWidth + s2LeftWidth + portWidth + (thickness * 3.0);
  }

  // Internal Width
  const internalWidth = boxWidth - (2.0 * thickness);

  // Baffle Check
  const baffleCheck = calculateBaffleCheck(inputs, s2LeftWidth, boxWidth, config, s1RightWidth, internalHeight);

  return {
    totalNeeded,
    subCutoutAdd,
    gussetDisplacement,
    adjustedNeeded,
    netAirSpaceForPortCalculations,
    netAirSpacePerChamber,
    internalHeight,
    internalDepthWithDB,
    mountingDepthAvail,
    boxWidth,
    internalWidth,
    portHeight,
    portArea,
    portLength1,
    portLengthNoEC,
    portLength2,
    sqInPerCube,
    s1RightWidth,
    s1RightHeight,
    s1RightDepth,
    s1RightArea,
    s1RightStillNeeded,
    s2LeftWidth,
    s2LeftHeight,
    s2LeftDepth,
    s2LeftArea,
    s2LeftStillNeeded,
    baffleCheck,
  };
}

// ─── Cut List Generation ─────────────────────────────────────────────────────
// Ported from C# EnclosureViewModel.CutList.cs
// Uses MaterialAssignmentMatrix, glue tolerance, edge mill values, rounding to 1/8"

/**
 * Generate the cut list from inputs and calculations.
 * Matches desktop C# logic including:
 * - BoxWidth rounded up to nearest 1/8"
 * - Glue tolerance applied to Side Left, Side Right, Port Piece 1
 * - Edge mill values (C/E) used for sides and port pieces
 * - Baffle width varies by port config (single vs dual)
 * - Per-part material assignment, configuration-aware:
 *     RD-SBPB: Baffle = 24mm (thick), Top = 18mm (thin)
 *     RD-SUPB: Top    = 24mm (thick), Baffle = 18mm (thin)
 *     SD: all thin   HD: all thick
 * - In RD-SUPB the baffle is genuinely 18mm, so Side Left and Port Piece 1
 *   widths use the both-thin (E1+E1 / C1+C1) formula instead of the SBPB
 *   thin+thick formula.
 */
export function generateCutList(
  inputs: EnclosureInputs,
  calculations: EnclosureCalculations,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance: number = DEFAULT_GLUE_TOLERANCE
): CutListItem[] {
  const {
    boxDepth,
    portWidth,
    enclosureType,
    enclosureConfiguration,
    subwooferQuantity,
    portQuantity,
  } = inputs;

  const {
    boxWidth,
    internalHeight,
    portHeight,
    portLength2,
  } = calculations;

  const useMDF = isMDF(enclosureType);
  const useStandard = isStandardDuty(enclosureType);
  const useRegular = isRegularDuty(enclosureType);
  const useHeavy = isHeavyDuty(enclosureType);
  const gussetCount = getGussetCount(subwooferQuantity);
  const isDualPort = portQuantity === 'Dual';
  const isSubsUpPortBack = enclosureConfiguration === 'Subs Up/Port Back';

  // Round BoxWidth up to nearest 1/8 inch (matches desktop RoundUpToEighth)
  const roundedBoxWidth = roundUpToEighth(boxWidth);

  const cutList: CutListItem[] = [];

  // --- Top ---
  const topMaterial = getPartMaterial('Top', enclosureType, config, enclosureConfiguration);
  cutList.push({
    partName: 'Top',
    width: roundedBoxWidth,
    height: boxDepth,
    quantity: 1,
    material: topMaterial.materialDescription,
    thickness: topMaterial.thicknessInches,
  });

  // --- Bottom ---
  const bottomMaterial = getPartMaterial('Bottom', enclosureType, config, enclosureConfiguration);
  cutList.push({
    partName: 'Bottom',
    width: roundedBoxWidth,
    height: boxDepth,
    quantity: 1,
    material: bottomMaterial.materialDescription,
    thickness: bottomMaterial.thicknessInches,
  });

  // --- Sub Mount Cap (SUPB flush mount only) ─────────────────────────────
  // Sits on top of the enclosure (full outer footprint) and recesses the
  // sub flange. Adds 18mm Birch (B1) on top — boxHeight is treated as the
  // total external dimension so the chamber loses 18mm of internal height
  // (handled in calculateEnclosure via internalHeight reduction).
  // Width × Height = boxWidth × boxDepth (matches Top panel footprint).
  // No drill holes — purely glued to the underside (top panel above) of
  // the box and the sub flange recess. MDF flush mount is not modeled.
  const isRecessedSupb = !!inputs.recessedMounting && isSubsUpPortBack && !useMDF;
  if (isRecessedSupb) {
    cutList.push({
      partName: 'Sub Mount Cap',
      width: roundedBoxWidth,
      height: boxDepth,
      quantity: 1,
      material: '18mm Birch Ply',
      thickness: config.B1,
    });
  }

  // --- Back ---
  const backMaterial = getPartMaterial('Back', enclosureType, config, enclosureConfiguration);
  cutList.push({
    partName: 'Back',
    width: roundedBoxWidth,
    height: internalHeight,
    quantity: 1,
    material: backMaterial.materialDescription,
    thickness: backMaterial.thicknessInches,
  });

  // --- Flush mount derived state (recessed sub mounting) ─────────────────
  // SBPB-only (SUPB will get its own implementation later). When active:
  //   - Structural baffle becomes 18mm Birch (was 24mm for RD-SBPB and HD)
  //   - Inner sub-mount plate is added (24mm RD/HD, 18mm SD)
  //   - Side Left / Port Piece 1 widths use the thin-front-panel formula
  // Birch only for V1 — MDF flush mount is not modeled.
  const isRecessed = !!inputs.recessedMounting && !isSubsUpPortBack && !useMDF;

  // --- Baffle ---
  // Width varies by port config. baffleThicknessForWidth represents the PP2
  // wall thickness the baffle butts against (always Birch B1/B2 — same
  // material as walls), not the baffle's own thickness, so this stays B1
  // for SD/RD regardless of SUPB/SBPB.
  // When isRecessed, the structural baffle is 18mm regardless of duty.
  const baffleMaterialOriginal = getPartMaterial('Baffle', enclosureType, config, enclosureConfiguration);
  const baffleMaterial = isRecessed
    ? { materialType: 'Birch Ply', materialDescription: '18mm Birch Ply', thicknessInches: config.B1, thicknessCode: 'B1' }
    : baffleMaterialOriginal;
  const baffleThicknessForWidth = useHeavy ? config.B2 : config.B1;

  let baffleWidth: number;
  if (isDualPort) {
    // Dual port: subtract both port widths and both material thicknesses
    baffleWidth = roundedBoxWidth - (2 * portWidth + 2 * baffleThicknessForWidth);
  } else {
    // Single port
    baffleWidth = roundedBoxWidth - (portWidth + baffleThicknessForWidth);
  }

  cutList.push({
    partName: 'Baffle',
    width: baffleWidth,
    height: internalHeight,
    quantity: 1,
    material: baffleMaterial.materialDescription,
    thickness: baffleMaterial.thicknessInches,
  });

  // --- Sub Mount Plate (flush mount only) ───────────────────────────────
  // Sits flat against the back of the structural baffle, BETWEEN Side Left
  // and Port Piece 1 (it slips inside the chamber rather than spanning the
  // full baffle outline). So plate width = baffleWidth minus TWO wall
  // thicknesses (one for Side Left + one for Port Piece 1). The wall
  // thicknesses include a ~0.010" tolerance each so the plate slides into
  // place during assembly:
  //   SD / RD walls (18mm): 0.719 × 2 = 1.438" subtracted
  //   HD walls   (24mm):    0.955 × 2 = 1.910" subtracted
  // Glued + screwed to the baffle's back face during assembly — no dowel
  // holes, no joinery to side panels. The sub mounts to this plate, not
  // the structural baffle.
  // Height = internalHeight (full chamber height).
  // Thickness = 24mm (B2) for RD/HD, 18mm (B1) for SD.
  if (isRecessed) {
    const subMountThickness = useStandard ? config.B1 : config.B2;
    const subMountMaterial = useStandard ? '18mm Birch Ply' : '24mm Birch Ply';
    const subMountWidthSubtraction = useHeavy ? 0.955 * 2 : 0.719 * 2;
    cutList.push({
      partName: 'Sub Mount Plate',
      width: baffleWidth - subMountWidthSubtraction,
      height: internalHeight,
      quantity: 1,
      material: subMountMaterial,
      thickness: subMountThickness,
    });
  }

  // --- Side Left ---
  // Uses edge mill values (C/E) and glue tolerance.
  // RD-SUPB: baffle is 18mm so the front edge mill is C1/E1 (matches the
  // back edge); RD-SBPB: baffle is 24mm so the front edge mill is C2/E2.
  // When isRecessed (flush mount), the structural baffle is forced to
  // 18mm regardless of duty so the front edge mill drops to C1/E1 too —
  // RD-SBPB matches RD-SUPB; HD's front mill becomes C1 while the back
  // panel stays C2.
  const sideLeftMaterial = getPartMaterial('Side Left', enclosureType, config, enclosureConfiguration);
  // "Front panel is thin" = SD, RD-SUPB, or flush-mount (any duty).
  const frontPanelIsThin = useStandard || (useRegular && isSubsUpPortBack) || isRecessed;
  // Front edge-mill values per material — pick C1/E1 when the structural
  // baffle is 18mm; C2/E2 when it's 24mm.
  const frontMillC = frontPanelIsThin ? config.C1 : config.C2;
  const frontMillE = frontPanelIsThin ? config.E1 : config.E2;
  // Back edge-mill values — back panel is 18mm everywhere except HD,
  // and flush mount doesn't change the back panel.
  const backMillC = useHeavy ? config.C2 : config.C1;
  const backMillE = useHeavy ? config.E2 : config.E1;
  let sideLeftWidth: number;

  if (isDualPort) {
    // Dual port: Same as Side Right (symmetric construction)
    if (useMDF) {
      sideLeftWidth = useHeavy
        ? boxDepth - (config.E2 + glueTolerance)
        : boxDepth - (config.E1 + glueTolerance);
    } else {
      sideLeftWidth = useHeavy
        ? boxDepth - (config.C2 + glueTolerance)
        : boxDepth - (config.C1 + glueTolerance);
    }
  } else {
    // Single port: Two edge mills (front baffle + back panel)
    if (useMDF) {
      sideLeftWidth = boxDepth - (frontMillE + backMillE + glueTolerance * 2);
    } else {
      sideLeftWidth = boxDepth - (frontMillC + backMillC + glueTolerance * 2);
    }
  }

  cutList.push({
    partName: 'Side Left',
    width: sideLeftWidth,
    height: internalHeight,
    quantity: 1,
    material: sideLeftMaterial.materialDescription,
    thickness: sideLeftMaterial.thicknessInches,
  });

  // --- Side Right ---
  // Uses After Edge Mill Down values (C/E). SD/RD uses C1/E1, HD uses C2/E2
  const sideRightMaterial = getPartMaterial('Side Right', enclosureType, config, enclosureConfiguration);
  let sideRightWidth: number;
  if (useMDF) {
    sideRightWidth = useHeavy
      ? boxDepth - (config.E2 + glueTolerance)
      : boxDepth - (config.E1 + glueTolerance);
  } else {
    sideRightWidth = useHeavy
      ? boxDepth - (config.C2 + glueTolerance)
      : boxDepth - (config.C1 + glueTolerance);
  }

  cutList.push({
    partName: 'Side Right',
    width: sideRightWidth,
    height: internalHeight,
    quantity: 1,
    material: sideRightMaterial.materialDescription,
    thickness: sideRightMaterial.thicknessInches,
  });

  // --- Port Piece 1 ---
  // Edge mill values + PP2 thickness + glue tolerance.
  //   front edge = baffle's C/E value (depends on whether front panel is thin)
  //   back edge  = back panel's C/E value (depends on duty only)
  //   pp2        = PP2 panel thickness — full thickness, not edge-milled
  // Flush mount routes through frontMillC/E (front baffle is 18mm) but
  // does NOT change PP2 thickness — PP2 stays B2 for HD, B1 otherwise.
  const portPiece1Material = getPartMaterial('Port Piece 1', enclosureType, config, enclosureConfiguration);
  const pp2BirchThickness = useHeavy ? config.B2 : config.B1;
  const pp2MdfThickness = useHeavy ? config.D2 : config.D1;
  let portPiece1Width: number;

  if (useMDF) {
    portPiece1Width = boxDepth - (portWidth + frontMillE + backMillE + pp2MdfThickness + glueTolerance * 2);
  } else {
    portPiece1Width = boxDepth - (portWidth + frontMillC + backMillC + pp2BirchThickness + glueTolerance * 2);
  }

  if (isDualPort) {
    // Dual port: separate Left and Right entries
    cutList.push({
      partName: 'Port Piece 1 Left',
      width: portPiece1Width,
      height: portHeight,
      quantity: 1,
      material: portPiece1Material.materialDescription,
      thickness: portPiece1Material.thicknessInches,
    });
    cutList.push({
      partName: 'Port Piece 1 Right',
      width: portPiece1Width,
      height: portHeight,
      quantity: 1,
      material: portPiece1Material.materialDescription,
      thickness: portPiece1Material.thicknessInches,
    });
  } else {
    cutList.push({
      partName: 'Port Piece 1',
      width: portPiece1Width,
      height: portHeight,
      quantity: 1,
      material: portPiece1Material.materialDescription,
      thickness: portPiece1Material.thicknessInches,
    });
  }

  // --- Port Piece 2 ---
  // Width = PortLength2 - PortWidth
  const portPiece2Material = getPartMaterial('Port Piece 2', enclosureType, config, enclosureConfiguration);
  const portPiece2Width = portLength2 - portWidth;

  if (isDualPort) {
    cutList.push({
      partName: 'Port Piece 2 Left',
      width: portPiece2Width,
      height: portHeight,
      quantity: 1,
      material: portPiece2Material.materialDescription,
      thickness: portPiece2Material.thicknessInches,
    });
    cutList.push({
      partName: 'Port Piece 2 Right',
      width: portPiece2Width,
      height: portHeight,
      quantity: 1,
      material: portPiece2Material.materialDescription,
      thickness: portPiece2Material.thicknessInches,
    });
  } else {
    cutList.push({
      partName: 'Port Piece 2',
      width: portPiece2Width,
      height: portHeight,
      quantity: 1,
      material: portPiece2Material.materialDescription,
      thickness: portPiece2Material.thicknessInches,
    });
  }

  // --- Gussets ---
  for (let i = 0; i < gussetCount; i++) {
    const gussetMaterial = getPartMaterial(`Gusset ${i + 1}`, enclosureType, config, enclosureConfiguration);
    cutList.push({
      partName: `Gusset ${i + 1}`,
      width: 5.0,
      height: internalHeight,
      quantity: 1,
      material: gussetMaterial.materialDescription,
      thickness: gussetMaterial.thicknessInches,
    });
  }

  // --- Acrylic Window (V1, optional) ---
  // Adds an "Acrylic Window 12x12" / "Acrylic Window 24x12" / "Acrylic Window
  // custom" line item when `inputs.windowEnabled === true`. Plate dimensions
  // come from the size tier (NOT the cutout — see acrylic-window.ts for the
  // convention); the wood cutout is plate − 2 × 1.25" per side. Plate auto-
  // shrinks to fit the host panel's safe area (1" clearance from baffle, PP1,
  // PP2, and side walls). Acrylic thickness picked by duty (1/4" SD/RD, 3/8"
  // HD). Material = `'Acrylic'` — cost-calc should treat this as a per-tier
  // upcharge via `pricing_modifiers.acrylicWindow`, not the standard sheet
  // path that handles Birch/MDF.
  const windowEntry = buildAcrylicWindowCutListEntry(inputs, calculations, cutList);
  if (windowEntry) {
    cutList.push(windowEntry);
  }

  return cutList;
}

// ─── Model Number Generation ─────────────────────────────────────────────────
// Ported from C# EnclosureViewModel.Configurations.cs EnclosureModelNumber property

/**
 * Generate the enclosure model number.
 * Includes -C# suffix for custom enclosures and -FP suffix for Flat Pack.
 */
export function generateModelNumber(
  inputs: EnclosureInputs,
  brandCode: string = 'XXX'
): string {
  const {
    enclosureType,
    enclosureConfiguration,
    subwooferQuantity,
    portQuantity,
    size,
    assemblyMethod,
    subwooferModel,
    isCustomEnclosure,
    customNumber,
  } = inputs;

  // Config prefix (S=Single, D=Dual, T=Triple, Q=Quad)
  const configPrefix = {
    'Single': 'S',
    'Dual': 'D',
    'Triple': 'T',
    'Quad': 'Q',
  }[subwooferQuantity] || 'S';

  // Size number (remove quote mark)
  const sizeNumber = size.replace('"', '');
  const configCode = configPrefix + sizeNumber;

  // Duty code
  let dutyCode = 'SD';
  if (enclosureType.includes('Regular Duty')) dutyCode = 'RD';
  else if (enclosureType.includes('Heavy Duty')) dutyCode = 'HD';

  // FM modifier (flush mount) — separate segment before the duty code,
  // e.g. BHSP-PE-S12-2.0V2-FM-RD when recessedMounting is on.
  const fmSuffix = inputs.recessedMounting ? '-FM' : '';

  // Port quantity suffix
  const portSuffix = portQuantity === 'Dual' ? '-2P' : '';

  // Material suffix
  const materialSuffix = enclosureType.includes('MDF') ? '-MDF' : '';

  // Model code
  const modelCode = subwooferModel || 'MOD';

  // Build model number
  let modelNumber: string;

  // Special logic for Performance brand
  if (brandCode === 'PE') {
    if (enclosureConfiguration === 'Subs Up/Port Back') {
      modelNumber = `${brandCode}-${configCode}-${modelCode}-SUPB${portSuffix}${fmSuffix}-${dutyCode}${materialSuffix}`;
    } else {
      modelNumber = `${brandCode}-${configCode}-${modelCode}${portSuffix}${fmSuffix}-${dutyCode}${materialSuffix}`;
    }
  } else {
    if (enclosureConfiguration === 'Subs Up/Port Back') {
      modelNumber = `${brandCode}-${modelCode}-${configCode}-SUPB${portSuffix}${fmSuffix}-${dutyCode}${materialSuffix}`;
    } else {
      modelNumber = `${brandCode}-${modelCode}-${configCode}${portSuffix}${fmSuffix}-${dutyCode}${materialSuffix}`;
    }
  }

  // Append custom suffix if this is a custom enclosure
  if (isCustomEnclosure && customNumber) {
    modelNumber = `${modelNumber}-C${customNumber}`;
  }

  // Append Flat Pack suffix
  if (assemblyMethod === 'Flat Pack') {
    modelNumber = `${modelNumber}-FP`;
  }

  return modelNumber;
}

// ─── Weight & Shipping Calculations ──────────────────────────────────────────
// Ported from C# BuildTabViewModel.MaterialCosting.cs + BuildTabViewModel.Properties.cs
// Constants from FlatPackConstants/FlatPackSettings.cs

// Material densities (lb/cubic inch)
const DENSITY_BALTIC_BIRCH = 0.0246; // 680 kg/m³
const DENSITY_MDF = 0.029;

// DIM weight factor (cubic inches per pound) — UPS/FedEx standard
const DIM_FACTOR_UPS_FEDEX = 139.0;

// Cardboard box wall thickness (inches) — 350 DW cardboard
const BOX_WALL_LW = 0.5512;  // 14mm — single wall for length/width
const BOX_WALL_H = 1.1024;   // 28mm — top + bottom flaps for height

// Packaging weight (lbs)
const DEFAULT_PACKAGING_WEIGHT = 3.0;

/**
 * Calculate weight and shipping info from inputs, calculations, and cut list.
 * Ported from desktop C# BuildTabViewModel.
 */
export function calculateShippingInfo(
  inputs: EnclosureInputs,
  calculations: EnclosureCalculations,
  cutList: CutListItem[]
): ShippingInfo {
  const { boxDepth, boxHeight } = inputs;
  const { boxWidth } = calculations;
  const roundedBoxWidth = roundUpToEighth(boxWidth);

  // ── Cardboard box auto-dimensions ──
  // Desktop: CartonLength = Depth + 1.125", CartonWidth = Height + 1.0", CartonHeight = TopWidth + 1.1875"
  const cartonLength = boxDepth + 1.125;
  const cartonWidth = boxHeight + 1.0;
  const cartonHeight = roundedBoxWidth + 1.1875;

  // ── External shipping dimensions (carton + cardboard wall) ──
  const externalLength = cartonLength + BOX_WALL_LW;
  const externalWidth = cartonWidth + BOX_WALL_LW;
  const externalHeight = cartonHeight + BOX_WALL_H;

  // ── Enclosure weight ──
  // Sum of each part: area (sq in) × thickness (in) × density (lb/cu in)
  let enclosureWeight = 0;
  for (const part of cutList) {
    const area = part.width * part.height * part.quantity;
    const density = part.material.includes('MDF') ? DENSITY_MDF : DENSITY_BALTIC_BIRCH;
    enclosureWeight += area * part.thickness * density;
  }

  // ── Shipping weight = enclosure + packaging ──
  const shippingWeight = enclosureWeight > 0 ? enclosureWeight + DEFAULT_PACKAGING_WEIGHT : 0;

  // ── Dimensional weight = (L × W × H) / 139 ──
  const dimensionalWeight = (externalLength > 0 && externalWidth > 0 && externalHeight > 0)
    ? (externalLength * externalWidth * externalHeight) / DIM_FACTOR_UPS_FEDEX
    : 0;

  // ── Billable weight = max(shipping, dimensional) ──
  const billableWeight = Math.max(shippingWeight, dimensionalWeight);

  return {
    cartonLength,
    cartonWidth,
    cartonHeight,
    externalLength,
    externalWidth,
    externalHeight,
    enclosureWeight,
    shippingWeight,
    dimensionalWeight,
    billableWeight,
  };
}

// ─── Formatting Helpers ──────────────────────────────────────────────────────

export function formatNumber(value: number, decimals: number = 3): string {
  return value.toFixed(decimals);
}

export function formatDimension(value: number, unit: string = '"'): string {
  return `${formatNumber(value)}${unit}`;
}
