import React from 'react';
import type { Texture } from 'three';
import { TerminalPanelPreview } from './terminal-panel-preview';
import { TERMINAL_WIDTH, TERMINAL_HEIGHT, TERMINAL_BOTTOM_OFFSET } from './terminal-placement';

export interface SideLeftTerminalPreviewProps {
  width: number; height: number; thickness: number;
  frontInset: number; floorInset: number; scale: number;
  offset: number; rotated: boolean; roundoverRadius: number;
  color: string; opacity: number; texture?: Texture; showEdges?: boolean;
}

/** Hole and outside lip are a single surface, sharing center and orientation.
 * Panel local +X maps to world -Z, so mirror the operator's front-to-back offset. */
export function SideLeftTerminalPreview(p: SideLeftTerminalPreviewProps) {
  return <TerminalPanelPreview width={p.width} height={p.height} thickness={p.thickness}
    centerX={p.width / 2 - p.offset}
    centerY={p.rotated ? p.height / 2 : (TERMINAL_BOTTOM_OFFSET + TERMINAL_HEIGHT / 2) * p.scale}
    openingWidth={(p.rotated ? TERMINAL_HEIGHT : TERMINAL_WIDTH) * p.scale}
    openingHeight={(p.rotated ? TERMINAL_WIDTH : TERMINAL_HEIGHT) * p.scale}
    cornerRadius={0.375 * p.scale} roundoverRadius={p.roundoverRadius}
    position={[0, p.floorInset, p.frontInset + p.width]} rotation={[0, Math.PI / 2, 0]}
    color={p.color} opacity={p.opacity} texture={p.texture} showEdges={p.showEdges} />;
}
