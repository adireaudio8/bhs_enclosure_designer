import type { CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import { getSupbEditablePositions, resolveSupbSubLayout, type SupbLayoutResult } from './subwoofer-placement';
import { checkProfileBaffle, profileBaffleCenters, baffleBraceCenters, bafflePositionBounds } from './subwoofer-profile';
import { measureSubwooferLayout } from './subwoofer-layout-measurements';
import { BAFFLE_FRAME_OVERHANG_IN, baffleFrameClearances, braceGapIn } from './subwoofer-clearances';

export const subwooferCount = (inputs: EnclosureInputs) => ({ Single: 1, Dual: 2, Triple: 3, Quad: 4 })[inputs.subwooferQuantity];

export class SubwooferPlacementError extends Error {
  readonly canExportForReview: boolean;
  constructor(layout: SupbLayoutResult) {
    super(`Subwoofer placement is unsafe: ${layout.diagnostic || 'no safe layout exists'}`);
    this.name = 'SubwooferPlacementError';
    this.canExportForReview = layout.diagnosticCode === 'brace-clearance';
  }
}

/** An explicit review export never changes the layout or the normal fit verdict. */
export function assertSubwooferExportLayout(layout: SupbLayoutResult, review = false): void {
  if (!layout.safe && !(review && layout.diagnosticCode === 'brace-clearance')) {
    throw new SubwooferPlacementError(layout);
  }
}

/** Finished mounting-panel coordinates, before DXF milling margins or mirroring. */
export function subwooferMountingPanel(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[]) {
  const top = inputs.enclosureConfiguration === 'Subs Up/Port Back';
  const panel = parts.find(p => top ? p.partName === 'Top' : p.partName === 'Baffle' || p.partName === 'Baffle + Port 1');
  return { top, width: !top && calc.roundPort?.active ? calc.roundPort.subRightLimitIn
    : panel?.kerf?.baffleRunIn ?? panel?.width ?? calc.boxWidth,
    height: panel?.height ?? (top ? inputs.boxDepth : calc.internalHeight) };
}

/** Front braces follow the gap between outside frames, including their drilling. */
export function resolveBaffleSubLayout(inputs: EnclosureInputs, calc: EnclosureCalculations,
  parts: CutListItem[], clearance = 0): SupbLayoutResult {
  const points = profileBaffleCenters(inputs, calc, parts);
  const count = subwooferCount(inputs);
  const center = points.length ? { cx: points.reduce((s,p) => s+p.x,0)/points.length,
    cy: points.reduce((s,p) => s+p.y,0)/points.length } : { cx: 0, cy: 0 };
  const result = (diagnostic?: string, diagnosticCode?: SupbLayoutResult['diagnosticCode']): SupbLayoutResult => ({ safe: !diagnostic,
    mode: inputs.subwooferPositions !== undefined ? 'manual' : count === 1 ? 'single' : 'straight',
    points, center, gussets: [], baffleBraces: baffleBraceCenters(inputs,parts,calc), diagnostic, diagnosticCode });
  if ((inputs.subwooferPositions !== undefined && (!Array.isArray(inputs.subwooferPositions) || inputs.subwooferPositions.length !== count)) || points.length !== count || points.some(p => !Number.isFinite(p.x) || !Number.isFinite(p.y)))
    return result(`Enter finite X and Y centers for all ${count} subwoofers.`);
  if (inputs.subwooferCutoutProfile) return result(checkProfileBaffle(inputs, calc, parts, clearance).diagnostic);
  const { width, height } = subwooferMountingPanel(inputs, calc, parts);
  const radius = inputs.subCutoutDiameter / 2 + clearance;
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter;
  if (!(radius > 0) || !(od > 0)) return result('Enter the subwoofer cutout and outside diameter first.');
  const metrics = measureSubwooferLayout(points, width, height, od);
  if(!metrics) return result('Enter valid mounting panel and subwoofer dimensions.');
  const recess = inputs.recessedMounting ? .125 : 0;
  // A frame may run 1/8 in past the baffle's top and bottom (the top and bottom panels sit flush
  // around it); the side edges, the other frames and flush recesses keep 1/4 in (2026-11-16).
  const room = baffleFrameClearances(points, width, height, od, od);
  const verticalNeed = inputs.recessedMounting ? .25 + recess : -BAFFLE_FRAME_OVERHANG_IN;
  if (room.side < .25 + recess - 1e-7 || room.vertical < verticalNeed - 1e-7
    || (count > 1 && metrics.subToSubGap < .25 + 2*recess - 1e-7))
    return result(inputs.recessedMounting
      ? 'Keep the outside frames and flush recesses clear of panel edges and each other by at least 0.25 inch.'
      : 'Keep the outside frames 0.25 inch from the side edges and each other; they may run no more than 0.125 inch past the top and bottom of the baffle.');
  const limits=bafflePositionBounds(inputs,calc,parts,clearance);
  if (points.some(p => p.x < limits.xMin-1e-7 || p.x > limits.xMax+1e-7
    || p.y < limits.yMin-1e-7 || p.y > limits.yMax+1e-7))
    return result(inputs.recessedMounting
      ? 'The flush recess needs 0.5 inch of wood above and below it, and the opening must clear the walls and mounting plate.'
      : 'A subwoofer frame or opening would overlap a chamber wall, port, mounting plate or panel edge clearance.');
  const braceT = parts.find(p => p.partName.startsWith('Gusset'))?.thickness ?? 0;
  if (count>1 && !(braceT>0)) return result('The baffle brace thickness is missing.');
  // The frames need the brace's gap between them: 1.25 in heavy duty, 1 in regular and standard.
  const gap = braceGapIn(inputs, braceT);
  if (braceT > 0 && baffleBraceCenters(inputs, parts,calc).some(x => points.some(p => Math.abs(p.x-x) < Math.max(radius,od/2+recess)+gap/2-1e-7)))
    return result(`Leave at least ${(gap+2*recess).toFixed(3)} inches between the outside frames for the ${braceT.toFixed(3)}-inch brace.`, 'brace-clearance');
  return result();
}

/** Per-driver editing limits. Neighbor limits reserve the full-height baffle
 * brace between ODs even when the drivers have different Y coordinates. */
export function getSubwooferMovementBounds(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[], index:number) {
  const panel=subwooferMountingPanel(inputs,calc,parts), frame=inputs.subwooferCutoutProfile?.frame;
  const halfW=(frame?.width || inputs.outsideDiameter || inputs.subCutoutDiameter)/2;
  const halfH=(frame?.height || inputs.outsideDiameter || inputs.subCutoutDiameter)/2;
  const recess=inputs.recessedMounting ? .125 : 0;
  const bounds=panel.top ? {xMin:halfW+.5+recess,xMax:panel.width-halfW-.5-recess,
    yMin:halfH+.5+recess,yMax:panel.height-halfH-.5-recess} : bafflePositionBounds(inputs,calc,parts);
  if (!panel.top) {
    const points=getEditableSubwooferPositions(inputs,calc,parts);
    const order=points.map((p,i)=>({...p,i})).sort((a,b)=>a.x-b.x||a.i-b.i), at=order.findIndex(p=>p.i===index);
    const braceT=parts.find(p=>p.partName.startsWith('Gusset'))?.thickness ?? 0;
    const spacing=2*halfW+(braceT>0 ? braceGapIn(inputs,braceT) : .5)+2*recess;
    if(at>0) bounds.xMin=Math.max(bounds.xMin,order[at-1].x+spacing);
    if(at>=0 && at<order.length-1) bounds.xMax=Math.min(bounds.xMax,order[at+1].x-spacing);
  }
  return bounds;
}

/** Every input method uses the same placement check. Clamp a move from a safe
 * layout at its first unsafe boundary, without translating another driver. */
export function moveSubwooferPosition(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[], index:number, axis:'x'|'y', requested:number) {
  const points=getEditableSubwooferPositions(inputs,calc,parts), bounds=getSubwooferMovementBounds(inputs,calc,parts,index);
  const min=axis==='x'?bounds.xMin:bounds.yMin, max=axis==='x'?bounds.xMax:bounds.yMax;
  if(!points[index] || !Number.isFinite(requested) || !Number.isFinite(min) || !Number.isFinite(max) || min>max)
    return {points,diagnostic:'No movement is available on this axis until the panel or neighboring positions have enough space.'};
  const value=Math.max(min,Math.min(max,requested)), original=points[index][axis];
  const at=(v:number)=>points.map((p,i)=>i===index?{...p,[axis]:v}:{...p});
  const check=(v:number)=>resolveSubwooferLayout({...inputs,subwooferPositions:at(v),subwooferXOffset:undefined,subwooferYOffset:undefined},calc,parts);
  const current=check(original);
  // Invalid loaded designs may need several corrections. Hard bounds still apply.
  if(!current.safe) {const candidate=check(value);return {points:at(value),diagnostic:candidate.diagnostic};}
  let last=original;
  for(let i=1;i<=16;i++) {
    const next=original+(value-original)*i/16, checked=check(next);
    if(!checked.safe) {
      let good=last,bad=next;
      for(let k=0;k<24;k++) {const mid=(good+bad)/2;if(check(mid).safe)good=mid;else bad=mid;}
      return {points:at(good),diagnostic:checked.diagnostic};
    }
    last=next;
  }
  return {points:at(value),diagnostic:value!==requested?'Stopped at the safe placement limit.':undefined};
}

export function resolveSubwooferLayout(inputs: EnclosureInputs, calc: EnclosureCalculations,
  parts: CutListItem[], clearance = 0): SupbLayoutResult {
  return inputs.enclosureConfiguration === 'Subs Up/Port Back'
    ? resolveSupbSubLayout(inputs, calc, parts, undefined, undefined, clearance)
    : resolveBaffleSubLayout(inputs, calc, parts, clearance);
}

/** Invalid saved arrays remain invalid in validation/export; editor-only seeds
 * let the operator repair them without losing any finite requested centers. */
export function getEditableSubwooferPositions(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[]) {
  const automatic = { ...inputs, subwooferPositions: undefined };
  const seeds = inputs.enclosureConfiguration === 'Subs Up/Port Back'
    ? getSupbEditablePositions(automatic, calc, parts) : profileBaffleCenters(automatic, calc, parts);
  return Array.from({length: subwooferCount(inputs)}, (_, i) => {
    const saved = inputs.subwooferPositions?.[i];
    return saved && Number.isFinite(saved.x) && Number.isFinite(saved.y) ? {...saved} : {...seeds[i]};
  });
}
