import type { CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import { getSupbEditablePositions, resolveSupbSubLayout, type SupbLayoutResult } from './subwoofer-placement';
import { checkProfileBaffle, profileBaffleCenters, baffleBraceCenters } from './subwoofer-profile';
import { measureSubwooferLayout } from './subwoofer-layout-measurements';

export const subwooferCount = (inputs: EnclosureInputs) => ({ Single: 1, Dual: 2, Triple: 3, Quad: 4 })[inputs.subwooferQuantity];

/** Finished mounting-panel coordinates, before DXF milling margins or mirroring. */
export function subwooferMountingPanel(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[]) {
  const top = inputs.enclosureConfiguration === 'Subs Up/Port Back';
  const panel = parts.find(p => top ? p.partName === 'Top' : p.partName === 'Baffle' || p.partName === 'Baffle + Port 1');
  return { top, width: panel?.kerf?.baffleRunIn ?? panel?.width ?? calc.boxWidth,
    height: panel?.height ?? (top ? inputs.boxDepth : calc.internalHeight) };
}

/** Front-baffle braces stay at their existing drilled locations. Moving a
 * driver does not silently move a full-height structural brace or its dowels. */
export function resolveBaffleSubLayout(inputs: EnclosureInputs, calc: EnclosureCalculations,
  parts: CutListItem[], clearance = 0): SupbLayoutResult {
  const points = profileBaffleCenters(inputs, calc, parts);
  const count = subwooferCount(inputs);
  const center = points.length ? { cx: points.reduce((s,p) => s+p.x,0)/points.length,
    cy: points.reduce((s,p) => s+p.y,0)/points.length } : { cx: 0, cy: 0 };
  const result = (diagnostic?: string): SupbLayoutResult => ({ safe: !diagnostic,
    mode: inputs.subwooferPositions !== undefined ? 'manual' : count === 1 ? 'single' : 'straight',
    points, center, gussets: [], diagnostic });
  if ((inputs.subwooferPositions !== undefined && (!Array.isArray(inputs.subwooferPositions) || inputs.subwooferPositions.length !== count)) || points.length !== count || points.some(p => !Number.isFinite(p.x) || !Number.isFinite(p.y)))
    return result(`Enter finite X and Y centers for all ${count} subwoofers.`);
  if (inputs.subwooferCutoutProfile) return result(checkProfileBaffle(inputs, calc, parts, clearance).diagnostic);
  const { width, height } = subwooferMountingPanel(inputs, calc, parts);
  const radius = inputs.subCutoutDiameter / 2 + clearance;
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter;
  if (!(radius > 0) || !(od > 0)) return result('Enter the subwoofer cutout and outside diameter first.');
  const metrics = measureSubwooferLayout(points, width, height, od)!;
  const recess = inputs.recessedMounting ? .125 : 0;
  if (metrics.edgeClearance < .25 + recess - 1e-7 || (count > 1 && metrics.subToSubGap < .25 + 2*recess - 1e-7))
    return result('Keep the outside frames and flush recesses clear of panel edges and each other by at least 0.25 inch.');
  const wall = parts.find(p => p.partName === 'Side Left')?.thickness ?? 0;
  const plate = parts.find(p => p.partName === 'Sub Mount Plate');
  const inset = plate ? Math.max(0, (width-plate.width)/2) : 0;
  const left = Math.max(wall, inset), right = Math.min(wall+calc.baffleCheck.netWidth, width-inset);
  if (points.some(p => p.x-radius < left+.25-1e-7 || p.x+radius > right-.25+1e-7
    || p.y-radius < .25-1e-7 || p.y+radius > height-.25+1e-7))
    return result('A subwoofer opening would overlap a chamber wall, port, mounting plate or panel edge.');
  const braceT = parts.find(p => p.partName.startsWith('Gusset'))?.thickness ?? 0;
  if (braceT > 0 && baffleBraceCenters(inputs, parts).some(x => points.some(p => Math.abs(p.x-x) < radius+braceT/2+.25-1e-7)))
    return result('A subwoofer opening would overlap a fixed baffle brace. Move the sub clear of the brace.');
  return result();
}

export function resolveSubwooferLayout(inputs: EnclosureInputs, calc: EnclosureCalculations,
  parts: CutListItem[], clearance = 0): SupbLayoutResult {
  return inputs.enclosureConfiguration === 'Subs Up/Port Back'
    ? resolveSupbSubLayout(inputs, calc, parts, undefined, undefined, clearance)
    : resolveBaffleSubLayout(inputs, calc, parts, clearance);
}

/** Invalid saved arrays remain invalid in validation/export; editor-only seeds
 * let the operator repair them without losing any finite requested centers. */
export function getEditableSubwooferPositions(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[]) {
  const automatic = { ...inputs, subwooferPositions: undefined };
  const seeds = inputs.enclosureConfiguration === 'Subs Up/Port Back'
    ? getSupbEditablePositions(automatic, calc, parts) : profileBaffleCenters(automatic, calc, parts);
  return Array.from({length: subwooferCount(inputs)}, (_, i) => {
    const saved = inputs.subwooferPositions?.[i];
    return saved && Number.isFinite(saved.x) && Number.isFinite(saved.y) ? {...saved} : {...seeds[i]};
  });
}
