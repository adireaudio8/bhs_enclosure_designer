/**
 * Canonical ACC machine-program naming.
 *
 * Track labels, generated .acc files, and the letter-size barcode PDF must all
 * use this module. A barcode that differs from the filename by even one
 * character scans successfully but opens no program on the drilling machine.
 *
 * ACC values intentionally have no fixed character limit. The complete,
 * readable design identity is more useful on the shop floor than an opaque
 * shortened code; physical scan testing will determine whether a limit is
 * needed later.
 */

function cleanToken(token: string): string {
  return token.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
}

interface AccIdentity {
  core: string[];
  suffix: string;
}

function parseAccIdentity(prefix: string): AccIdentity {
  const input = (prefix || '')
    .trim()
    .replace(/\.json$/i, '');
  const raw = input.replace(/^(?:BHSP|BHSF|BHSS)-/i, '');

  const core: string[] = [];
  let isSupb = false;
  let isDualPort = false;
  let isFlush = false;
  let duty = '';
  let isMdf = false;
  let isKerf = false;

  for (const token of raw.split(/[-_]+/).filter(Boolean)) {
    const upper = token.toUpperCase();
    if (upper === 'FP') continue;
    if (upper === 'SUPB') isSupb = true;
    else if (upper === '2P') isDualPort = true;
    else if (upper === 'FM') isFlush = true;
    else if (upper === 'SD' || upper === 'RD' || upper === 'HD') duty = upper[0];
    else if (upper === 'MDF') isMdf = true;
    else if (upper === 'KP') isKerf = true;
    else {
      const cleaned = cleanToken(token);
      if (cleaned) core.push(cleaned);
    }
  }

  return {
    core,
    suffix: [
      isSupb ? 'U' : '',
      isDualPort ? 'P' : '',
      isFlush ? 'F' : '',
      duty,
      isMdf ? 'M' : '',
      isKerf ? 'K' : '',
    ].join(''),
  };
}

function formatAccIdentity(identity: AccIdentity): string {
  return `${identity.core.join('')}${identity.suffix}`;
}

/**
 * Build the readable physical-design code.
 *
 * Sales/finish prefixes and Flat Pack are omitted because they do not change
 * ACC drilling geometry. No legacy marker is added to unprefixed designs.
 * Geometry-bearing tokens remain in full, including D12/S12 configuration
 * tokens, while common feature suffixes use their established abbreviations:
 *   SUPB=U, 2P=P, FM=F, SD/RD/HD=S/R/H, MDF=M, KP=K.
 * Custom C# tokens remain because separately saved custom designs can have
 * different dimensions even when the catalog model matches.
 */
export function naturalAccBaseName(prefix: string): string {
  return formatAccIdentity(parseAccIdentity(prefix)) || 'ENCLOSURE';
}

/**
 * Backward-compatible API name used throughout the application. It now returns
 * the complete readable identity without applying character compaction.
 */
export function compactAccBaseName(prefix: string): string {
  return naturalAccBaseName(prefix);
}

/** Complete value encoded by Code 128 and used as the .acc filename stem. */
export function accBarcodeValue(prefix: string, partNumber: number): string {
  if (!Number.isSafeInteger(partNumber) || partNumber < 1) {
    throw new Error(`ACC part number must be a positive integer; received ${partNumber}`);
  }
  return `${compactAccBaseName(prefix)}${partNumber}`;
}

export function accFilename(prefix: string, partNumber: number): string {
  return `${accBarcodeValue(prefix, partNumber)}.acc`;
}
