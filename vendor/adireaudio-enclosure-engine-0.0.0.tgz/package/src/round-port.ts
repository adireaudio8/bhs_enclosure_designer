/**
 * Round port flared on both ends ("aero" style), optionally with one 90-degree elbow.
 *
 * Pure geometry and acoustics for one design's port: area, the length it must be for the
 * tuning, whether it needs an elbow to fit the box, how much airspace it takes up, and how
 * far it stands in front of the wall it runs along.  Nothing here knows about cut files.
 * The port mounts in the baffle or in the right side panel (RoundPortLocation); the tuning
 * rule is the same for both, only where the tube lies differs.
 *
 * Where the numbers come from (November 2026 port study, OpenFOAM simulations of a 2 cu ft
 * box tuned to 32 Hz):
 *   - A flare is part of the port's length but counts for less than the same length of
 *     straight tube, because it is wider.  Its share is the integral of
 *     (throat area / local area) along the flare.
 *   - The open-end correction of a flared mouth is the square-ended one (the 1.463 x radius
 *     the slot formula uses for both ends together) scaled by throat area / mouth area.
 *     With no flare this reduces exactly to the slot formula.
 *   - An elbow acts slightly shorter than its centreline: the air takes the inside line.
 *     For a round tube of radius a on a centreline radius R the effective length of a
 *     quarter turn is (pi/2) * a^2 / (2 * (R - sqrt(R^2 - a^2))).
 *   Checked against the simulations: a 5 in tube 22.2 in long with 40 mm flares behaved
 *   like 603 mm of air (this model: 605 mm); a one-diameter elbow made the same tube act
 *   13 mm shorter (this model: 13.4 mm).  4 in and 4.5 in tubes agree within 3 %.
 *   The rule has not yet been checked against a measured port.
 */

import type { EnclosureInputs } from './types/enclosure';

/** Same constant as the slot-port resonance formula in calculations.ts. */
const RESONANCE_CONSTANT = 14630000.0;
/** Both open ends together, in tube radii, for a square-ended port (slot formula value). */
const END_CORRECTION_RADII = 1.463;
const INTEGRATION_STEPS = 400;

export interface RoundPortInputs {
  /** Inside diameter of the tube, inches. */
  diameterIn: number;
  /** How many identical tubes share the tuning. */
  quantity: number;
  /** Radius of the quarter-round flare on each end, inches.  0 = square ends. */
  flareRadiusIn: number;
  /** Wall thickness of tube, flares and elbow, inches. */
  wallIn: number;
  /** Centreline radius of the elbow, in tube diameters.  Must be above 0.5. */
  elbowRadiusDiameters: number;
  /** Width of the mounting flange round the outside flare, beyond the hole in the baffle, inches. */
  flangeWidthIn: number;
}

/**
 * Flange width and thickness follow the shop's own printed 4 in flare (measured from its 3D
 * files, November 2026): a 6.0 in body in a 6 in hole, a 7.5 in flange 3/16 in thick on the
 * face of the baffle.  Its pipe is 4.0 in inside and 4.25 in outside, and its elbow turns
 * on a 4.0 in centreline radius: the 1/8 in wall and one-diameter elbow used here.
 */
export const ROUND_PORT_DEFAULTS = {
  quantity: 1,
  flareRadiusIn: 1.6,
  wallIn: 0.125,
  elbowRadiusDiameters: 1.0,
  flangeWidthIn: 0.75,
} as const;
/** Thickness of the mounting flange (drawn in the viewer; it sits on the face of the baffle). */
export const ROUND_PORT_FLANGE_THICKNESS_IN = 0.1875;

/** The space the port has to live in. */
export interface RoundPortBoxContext {
  /** Net airspace the port is tuned against, cubic feet. */
  netAirSpaceCuFt: number;
  tuningFrequencyHz: number;
  /** From the outside face of the panel the port mounts in, to the inside face of the wall opposite. */
  faceToFarWallIn: number;
  /** Thickness of the panel the port mounts in. */
  mountPanelThicknessIn: number;
  /** Lay the port out with an elbow even if a straight tube would fit this distance. Used where
   *  the distance itself depends on the port (a port across the box's width: see
   *  calculateRoundPortEnclosure). Absent or false = decide from the distance, as always. */
  forceElbow?: boolean;
}

export type RoundPortProblem =
  | 'invalid-input'
  | 'elbow-radius-too-small'
  | 'port-too-short-for-flares'
  | 'box-too-shallow-for-elbow';

export interface RoundPortGeometry {
  valid: boolean;
  problems: RoundPortProblem[];
  /** Open area of one tube and of all tubes, square inches. */
  areaEachSqIn: number;
  areaTotalSqIn: number;
  /** Outside diameter of the tube, and of a flare at its mouth. */
  tubeOutsideDiameterIn: number;
  flareOutsideDiameterIn: number;
  /** Hole to cut in the mounting panel (baffle or right side) for the outside flare: the outside
   *  of the flare at its mouth. */
  holeDiameterIn: number;
  /** Outside diameter of the mounting flange on the outside face of that panel. */
  flangeOutsideDiameterIn: number;
  /** Length of air the port must behave like for the tuning (end effects included). */
  effectiveLengthIn: number;
  /** Face-to-face length of a straight tube with these flares that gives the tuning. */
  straightLengthIn: number;
  /** True when the straight tube would end closer than one diameter to the far wall. */
  needsElbow: boolean;
  /** Face-to-face length along the centreline, as built (elbow included when needed). */
  lengthIn: number;
  /** Elbow centreline radius and arc length (0 when no elbow). */
  elbowRadiusIn: number;
  elbowArcIn: number;
  /** Straight run from the mounting face to the elbow, and from the elbow to the inner mouth.
   *  Both include their flare.  Without an elbow leg1 is the whole length and leg2 is 0. */
  leg1In: number;
  leg2In: number;
  /** How far the inner mouth is from the port's axis at the mounting face, across the box (0 when straight).
   *  Port in the baffle: toward the left side. Port in the right side: toward the baffle. */
  sidewaysReachIn: number;
  /** How far the second leg stands out from the far wall, to the far edge of its tube (0 when
   *  straight). Port in the baffle: the depth of box it occupies in front of the back wall where
   *  it crosses behind the drivers. Port in the right side: the width it occupies along the left
   *  side wall (mounting depth is worked out separately there, see round-port-side.ts). */
  depthTakenAtFarWallIn: number;
  /** Airspace one tube takes out of the box, cubic inches (outside of tube, flares and elbow,
   *  from the inside face of the mounting panel inward). */
  displacementEachCuIn: number;
  /** All tubes, cubic feet. */
  displacementTotalCuFt: number;
}

/** Inside radius of the port at distance s along its centreline from the mounting face. */
export function roundPortRadiusAt(s: number, radiusIn: number, flareRadiusIn: number, lengthIn: number): number {
  const rf = Math.max(0, flareRadiusIn);
  if (rf === 0) return radiusIn;
  const intoFlare = Math.max(Math.min(rf - s, rf), 0, Math.min(s - (lengthIn - rf), rf));
  if (intoFlare === 0) return radiusIn;             // the plain tube, exactly
  return radiusIn + rf - Math.sqrt(Math.max(0, rf * rf - intoFlare * intoFlare));
}

/** Length of straight tube that one flare is worth acoustically. */
export function flareEffectiveLengthIn(radiusIn: number, flareRadiusIn: number): number {
  const rf = Math.max(0, flareRadiusIn);
  if (rf === 0 || radiusIn <= 0) return 0;
  const dx = rf / INTEGRATION_STEPS;
  let sum = 0;
  for (let i = 0; i < INTEGRATION_STEPS; i += 1) {
    const x = (i + 0.5) * dx;                       // from the mouth inward
    const local = radiusIn + rf - Math.sqrt(rf * rf - (rf - x) * (rf - x));
    sum += (radiusIn / local) * (radiusIn / local) * dx;
  }
  return sum;
}

/** Length of straight tube that a quarter-turn elbow is worth acoustically. */
export function elbowEffectiveLengthIn(radiusIn: number, centrelineRadiusIn: number): number {
  if (radiusIn <= 0 || centrelineRadiusIn <= radiusIn) return 0;
  const inside = centrelineRadiusIn - Math.sqrt(centrelineRadiusIn * centrelineRadiusIn - radiusIn * radiusIn);
  return (Math.PI / 2) * radiusIn * radiusIn / (2 * inside);
}

/** Length of air the port must behave like: the slot formula's first term, for the total area. */
export function requiredEffectiveLengthIn(areaTotalSqIn: number, netAirSpaceCuFt: number, tuningFrequencyHz: number): number {
  const denominator = tuningFrequencyHz * tuningFrequencyHz * netAirSpaceCuFt * 1728.0;
  if (!(denominator > 0) || !(areaTotalSqIn > 0)) return 0;
  return RESONANCE_CONSTANT * (areaTotalSqIn / Math.PI) / denominator;
}

/** Outside volume of the port between two centreline distances (flares and wall included). */
function outsideVolumeCuIn(from: number, to: number, radiusIn: number, flareRadiusIn: number, lengthIn: number, wallIn: number): number {
  if (to <= from) return 0;
  const steps = INTEGRATION_STEPS * 4;
  const ds = (to - from) / steps;
  let sum = 0;
  for (let i = 0; i < steps; i += 1) {
    const outer = roundPortRadiusAt(from + (i + 0.5) * ds, radiusIn, flareRadiusIn, lengthIn) + wallIn;
    sum += outer * outer * ds;
  }
  return Math.PI * sum;
}

function invalid(problems: RoundPortProblem[], partial: Partial<RoundPortGeometry> = {}): RoundPortGeometry {
  return {
    valid: false, problems, areaEachSqIn: 0, areaTotalSqIn: 0, tubeOutsideDiameterIn: 0, flareOutsideDiameterIn: 0,
    holeDiameterIn: 0, flangeOutsideDiameterIn: 0,
    effectiveLengthIn: 0, straightLengthIn: 0, needsElbow: false, lengthIn: 0, elbowRadiusIn: 0, elbowArcIn: 0,
    leg1In: 0, leg2In: 0, sidewaysReachIn: 0, depthTakenAtFarWallIn: 0, displacementEachCuIn: 0, displacementTotalCuFt: 0,
    ...partial,
  };
}

export function resolveRoundPort(port: RoundPortInputs, box: RoundPortBoxContext): RoundPortGeometry {
  const d = port.diameterIn;
  const count = Math.round(port.quantity);
  const rf = port.flareRadiusIn;
  const wall = port.wallIn;
  const finite = [d, port.quantity, rf, wall, port.elbowRadiusDiameters, port.flangeWidthIn, box.netAirSpaceCuFt, box.tuningFrequencyHz,
    box.faceToFarWallIn, box.mountPanelThicknessIn].every(Number.isFinite);
  if (!finite || !(d > 0) || count < 1 || rf < 0 || wall < 0 || port.flangeWidthIn < 0 || !(box.netAirSpaceCuFt > 0) || !(box.tuningFrequencyHz > 0)
    || !(box.faceToFarWallIn > 0) || box.mountPanelThicknessIn < 0) {
    return invalid(['invalid-input']);
  }

  const r = d / 2;
  const areaEachSqIn = Math.PI * r * r;
  const areaTotalSqIn = areaEachSqIn * count;
  const tubeOutsideDiameterIn = d + 2 * wall;
  const flareOutsideRadius = r + rf + wall;
  const flareOutsideDiameterIn = 2 * flareOutsideRadius;
  const effectiveLengthIn = requiredEffectiveLengthIn(areaTotalSqIn, box.netAirSpaceCuFt, box.tuningFrequencyHz);
  const endCorrection = END_CORRECTION_RADII * r * r / (r + rf);
  const straightLengthIn = effectiveLengthIn - endCorrection - 2 * flareEffectiveLengthIn(r, rf) + 2 * rf;
  const shared = { areaEachSqIn, areaTotalSqIn, tubeOutsideDiameterIn, flareOutsideDiameterIn,
    holeDiameterIn: flareOutsideDiameterIn, flangeOutsideDiameterIn: flareOutsideDiameterIn + 2 * port.flangeWidthIn,
    effectiveLengthIn, straightLengthIn };

  if (straightLengthIn < 2 * rf || straightLengthIn <= box.mountPanelThicknessIn) {
    return invalid(['port-too-short-for-flares'], shared);
  }

  // A straight port needs at least one tube diameter between its inner mouth and the far wall.
  const needsElbow = box.forceElbow === true || straightLengthIn > box.faceToFarWallIn - d;
  let lengthIn = straightLengthIn;
  let elbowRadiusIn = 0;
  let elbowArcIn = 0;
  let leg1In = straightLengthIn;
  let leg2In = 0;
  let sidewaysReachIn = 0;
  let depthTakenAtFarWallIn = 0;
  const problems: RoundPortProblem[] = [];

  if (needsElbow) {
    elbowRadiusIn = port.elbowRadiusDiameters * d;
    if (!(elbowRadiusIn > r + wall)) {
      return invalid(['elbow-radius-too-small'], { ...shared, needsElbow });
    }
    elbowArcIn = (Math.PI / 2) * elbowRadiusIn;
    lengthIn = straightLengthIn + (elbowArcIn - elbowEffectiveLengthIn(r, elbowRadiusIn));
    // The second leg runs along the far wall with the flare on its inner end just clear of that wall.
    const standOff = Math.max(flareOutsideRadius, r + wall);
    leg1In = box.faceToFarWallIn - standOff - elbowRadiusIn;
    leg2In = lengthIn - elbowArcIn - leg1In;
    if (leg2In < rf) {
      // Nearly fits straight: keep a flare's length of second leg and pull the port forward instead.
      leg2In = rf;
      leg1In = lengthIn - elbowArcIn - leg2In;
    }
    if (leg1In < Math.max(rf, box.mountPanelThicknessIn)) problems.push('box-too-shallow-for-elbow');
    sidewaysReachIn = elbowRadiusIn + leg2In;
    depthTakenAtFarWallIn = box.faceToFarWallIn - (leg1In + elbowRadiusIn) + (r + wall);
  }

  const displacementEachCuIn = outsideVolumeCuIn(box.mountPanelThicknessIn, lengthIn, r, rf, lengthIn, wall);
  return {
    valid: problems.length === 0,
    problems,
    ...shared,
    needsElbow,
    lengthIn,
    elbowRadiusIn,
    elbowArcIn,
    leg1In,
    leg2In,
    sidewaysReachIn,
    depthTakenAtFarWallIn,
    displacementEachCuIn,
    displacementTotalCuFt: displacementEachCuIn * count / 1728.0,
  };
}

// ─── The port in a design ───────────────────────────────────────────────────

/** Wood left between a port hole and the side wall, the top, the bottom and the next hole. */
export const ROUND_PORT_EDGE_GAP_IN = 0.5;
/** A flange may run over the edge of the side, top or bottom panel, but stops this far short of the box's outside edge. */
export const ROUND_PORT_FLANGE_EDGE_GAP_IN = 0.25;

/**
 * True when the design is built with round flared ports. Front-port boxes with the
 * single slot-port setting only; kerf, forced labyrinth and flush mount keep the slot.
 */
export function roundPortGate(inputs: EnclosureInputs): boolean {
  if (!inputs.roundPortEnabled) return false;
  const frontPort = inputs.enclosureConfiguration !== 'Subs Up/Port Back';
  const singlePort = (inputs.portQuantity || 'Single') === 'Single';
  return frontPort && singlePort && !inputs.kerfPortEnabled && !inputs.forceLabyrinthPort && !inputs.recessedMounting;
}

/** The design's round-port settings with the defaults filled in. */
export function roundPortInputsOf(inputs: EnclosureInputs): RoundPortInputs {
  return {
    diameterIn: inputs.roundPortDiameter ?? 0,
    quantity: inputs.roundPortQuantity ?? ROUND_PORT_DEFAULTS.quantity,
    flareRadiusIn: inputs.roundPortFlareRadius ?? ROUND_PORT_DEFAULTS.flareRadiusIn,
    wallIn: inputs.roundPortWall ?? ROUND_PORT_DEFAULTS.wallIn,
    elbowRadiusDiameters: inputs.roundPortElbowRadius ?? ROUND_PORT_DEFAULTS.elbowRadiusDiameters,
    flangeWidthIn: inputs.roundPortFlangeWidth ?? ROUND_PORT_DEFAULTS.flangeWidthIn,
  };
}

/**
 * Which panel carries the port: its hole, its flange and its outside flare.
 *   'Baffle'      beside the drivers; the tube runs toward the back wall (the first location built).
 *   'Side Right'  in the right side panel, for boxes whose baffle has no room for a driver and a
 *                 flare; the tube runs across the box toward the left side. Always the right side:
 *                 the left side carries the terminal cup.
 */
export type RoundPortLocation = 'Baffle' | 'Side Right';
export const ROUND_PORT_LOCATIONS: RoundPortLocation[] = ['Baffle', 'Side Right'];

/** The design's port location. Anything but 'Side Right' (missing included) is the baffle. */
export function roundPortLocationOf(inputs: Pick<EnclosureInputs, 'roundPortLocation'>): RoundPortLocation {
  return inputs.roundPortLocation === 'Side Right' ? 'Side Right' : 'Baffle';
}

/** Extra layout facts for a port in the right side panel. Depths are measured from the outside
 *  face of the baffle toward the back of the box. */
export interface RoundPortSideLayout {
  /** Front edge of the finished Side Right panel (where it meets the baffle). */
  panelFrontIn: number;
  /** The port's axis where it goes through the side panel (the same for every tube). */
  axisDepthIn: number;
  /** The inner mouth: the axis depth for a straight tube, nearer the baffle after an elbow. */
  innerMouthDepthIn: number;
  /** Centre of the hole above the bottom edge of the side panel, as used; with two or more
   *  tubes, the centre of the group. Half the panel's height unless the design gives a height. */
  heightIn: number;
  /** The lowest and highest that centre may be: each hole keeps half an inch of wood above and
   *  below, and a flange may run no more than half an inch past the panel's top or bottom edge. */
  heightMinIn: number;
  heightMaxIn: number;
  /** True when some part of a tube lies behind a driver opening. Set by checkRoundPortInSide. */
  passesBehindDriver: boolean;
  /** What the tube takes from the back wall where it lies behind a driver opening: from the back
   *  wall's inside face to the nearest part of the tube. 0 when it lies behind none. */
  depthTakenIn: number;
  /** True when the drivers were placed in the space to the right of an elbowed tube's second leg
   *  (between its inner flare and the right side panel) and not centred on the whole baffle.
   *  Set by calculateRoundPortEnclosure; see driverSpaceRightOfTube. */
  driversRightOfTube: boolean;
}

export interface RoundPortLayout {
  /** True when the design is built with round ports. */
  active: boolean;
  /** The panel that carries the hole(s), flange(s) and outside flare(s). */
  location: RoundPortLocation;
  port: RoundPortInputs;
  geometry: RoundPortGeometry;
  /** Port centres on that finished panel, y from its bottom edge. Baffle: x from its left edge.
   *  Side Right: x from its front edge (the edge that meets the baffle). */
  centers: Array<{ x: number; y: number }>;
  /** The drivers' frames must stay left of this x on the baffle. Port in the baffle: the edge of
   *  the port flange(s). Port in the side: the baffle's own right edge (its whole width). */
  subRightLimitIn: number;
  /** Width the drivers are centred in. Port in the baffle: the baffle's left edge to
   *  subRightLimit plus one side wall. Port in the side: the whole baffle, or, with the
   *  drivers right of an elbowed tube, that space plus one side wall at each end. */
  subSpanWidthIn: number;
  /** Where that width starts, from the baffle's left edge. Absent or 0 everywhere except with
   *  the drivers right of an elbowed side tube (side.driversRightOfTube). */
  subSpanStartIn?: number;
  /** Present only for a port in the right side panel. */
  side?: RoundPortSideLayout;
  /** Fit problems in plain words. Empty when the port fits. */
  diagnostics: string[];
}

export function roundPortProblemText(problem: RoundPortProblem, location: RoundPortLocation = 'Baffle'): string {
  switch (problem) {
    case 'invalid-input': return 'Enter the round port diameter, the tuning and the net airspace.';
    case 'elbow-radius-too-small': return 'The elbow radius must be more than half the tube diameter.';
    case 'port-too-short-for-flares': return 'At this tuning the port would be shorter than its two flares. Use a smaller tube or smaller flares.';
    case 'box-too-shallow-for-elbow': return location === 'Side Right'
      ? 'The box is not wide enough for the elbow at this radius.'
      : 'The box is not deep enough for the elbow at this radius.';
  }
}

/** True when the hole(s) and flange(s) fit one above the other in a panel of this height: every
 *  hole keeps half an inch of wood above, below and between; a flange may run half an inch over
 *  the top or bottom panel's edge, and flanges keep a quarter inch between them. */
function roundPortsFitHeight(count: number, hole: number, flange: number, heightIn: number): boolean {
  const pitch = heightIn / count;
  const holesFit = count * hole + (count + 1) * ROUND_PORT_EDGE_GAP_IN <= heightIn + 1e-9;
  const flangesFit = flange <= pitch + (count === 1 ? 2 * ROUND_PORT_EDGE_GAP_IN : -ROUND_PORT_FLANGE_EDGE_GAP_IN) + 1e-9;
  return holesFit && flangesFit;
}

/**
 * Where the port(s) sit on the baffle and whether they fit. The ports stand one above the
 * other at the right-hand side of the baffle; an elbow turns them toward the left, behind
 * the drivers. Each hole keeps half an inch of wood round it; each flange lies on the face
 * and may run over the edge of the side, top or bottom panel.
 */
export function layoutRoundPortOnBaffle(
  port: RoundPortInputs,
  geometry: RoundPortGeometry,
  panel: { baffleWidthIn: number; baffleHeightIn: number; sideThicknessIn: number },
): RoundPortLayout {
  const count = Math.max(1, Math.round(port.quantity));
  const hole = geometry.holeDiameterIn;
  const flange = geometry.flangeOutsideDiameterIn;
  const fromRightEdge = Math.max(
    panel.sideThicknessIn + ROUND_PORT_EDGE_GAP_IN + hole / 2,
    ROUND_PORT_FLANGE_EDGE_GAP_IN + flange / 2,
  );
  const x = panel.baffleWidthIn - fromRightEdge;
  const pitch = panel.baffleHeightIn / count;
  const centers = Array.from({ length: count }, (_, i) => ({ x, y: pitch * (i + 0.5) }));
  const subRightLimitIn = x - flange / 2;
  const diagnostics = geometry.problems.map(problem => roundPortProblemText(problem));
  // every hole keeps half an inch of wood above, below and between; a flange may run half an
  // inch over the top or bottom panel's edge, and flanges keep a quarter inch between them
  const holesFit = count * hole + (count + 1) * ROUND_PORT_EDGE_GAP_IN <= panel.baffleHeightIn + 1e-9;
  const flangesFit = flange <= pitch + (count === 1 ? 2 * ROUND_PORT_EDGE_GAP_IN : -ROUND_PORT_FLANGE_EDGE_GAP_IN) + 1e-9;
  if (hole > 0 && (!holesFit || !flangesFit)) {
    diagnostics.push(count === 1
      ? `The port needs a ${hole.toFixed(2)} in hole and a ${flange.toFixed(2)} in flange, which do not fit the ${panel.baffleHeightIn.toFixed(2)} in inside height.`
      : `${count} ports with ${hole.toFixed(2)} in holes and ${flange.toFixed(2)} in flanges do not fit one above the other in the ${panel.baffleHeightIn.toFixed(2)} in inside height.`);
  }
  if (geometry.needsElbow && x - geometry.sidewaysReachIn - panel.sideThicknessIn < port.diameterIn) {
    diagnostics.push('The inner end of the port would be closer than one tube diameter to the side wall. The box is too narrow for this port.');
  }
  if (!(subRightLimitIn > panel.sideThicknessIn)) {
    diagnostics.push('The port leaves no room on the baffle for the drivers.');
  }
  return { active: true, location: 'Baffle', port, geometry, centers, subRightLimitIn, subSpanWidthIn: subRightLimitIn + panel.sideThicknessIn, diagnostics };
}

/**
 * Where the port(s) sit on the right side panel and whether they fit. The same rules as on the
 * baffle with depth and width swapped:
 *   - centred in the panel's height unless the design gives a height (two or more: one above
 *     the other, evenly spaced, and the height is the centre of the group);
 *   - as far toward the back wall as the hole and the flange allow, because the driver's motor
 *     is near the baffle: half an inch of wood between the hole and the back wall's inside face,
 *     and the flange a quarter inch short of the box's back edge. Inside the box the flare is
 *     never wider than its hole, so the hole's half inch also keeps the flare off the back wall;
 *   - the tube runs across the box toward the left side. With an elbow (resolveRoundPort decides)
 *     its second leg runs forward along the left side wall toward the baffle, the inner flare
 *     just clear of that wall, and must end at least one tube diameter short of the baffle.
 * The drivers get the whole baffle, or, where that leaves more mounting depth, the space to the
 * right of an elbowed tube's second leg (driverSpaceRightOfTube). What else the tube must clear
 * inside the box (terminal cup, braces) and what it costs in mounting depth is checked in
 * round-port-side.ts, once the drivers are placed.
 */
export function layoutRoundPortOnSide(
  port: RoundPortInputs,
  geometry: RoundPortGeometry,
  panel: {
    /** Finished outside width of the box; the baffle spans all of it. */
    boxWidthIn: number;
    boxDepthIn: number;
    /** Inside height of the box = height of the side panel. */
    panelHeightIn: number;
    /** Front edge of the finished Side Right panel, from the outside face of the baffle. */
    panelFrontIn: number;
    baffleThicknessIn: number;
    backThicknessIn: number;
    /** Centre of the hole (of the group, with two or more tubes) above the bottom edge of the
     *  panel. Absent or not a number = centred in the panel's height. */
    heightIn?: number;
  },
): RoundPortLayout {
  const count = Math.max(1, Math.round(port.quantity));
  const hole = geometry.holeDiameterIn;
  const flange = geometry.flangeOutsideDiameterIn;
  const fromBackEdge = Math.max(
    panel.backThicknessIn + ROUND_PORT_EDGE_GAP_IN + hole / 2,
    ROUND_PORT_FLANGE_EDGE_GAP_IN + flange / 2,
  );
  const axisDepthIn = panel.boxDepthIn - fromBackEdge;
  const pitch = panel.panelHeightIn / count;
  // Height on the panel. The tubes keep their even spacing; a height moves the group up or down
  // from centred. It may move until the first hole has only its half inch of wood left, or the
  // first flange runs half an inch past the panel's edge.
  const centredIn = panel.panelHeightIn / 2;
  const raised = panel.heightIn !== undefined && Number.isFinite(panel.heightIn);
  const heightIn = raised ? panel.heightIn as number : centredIn;
  const reach = Math.max(0, Math.min(pitch / 2 - ROUND_PORT_EDGE_GAP_IN - hole / 2, pitch / 2 + ROUND_PORT_EDGE_GAP_IN - flange / 2));
  const centers = Array.from({ length: count }, (_, i) => ({
    x: axisDepthIn - panel.panelFrontIn,
    y: raised ? pitch * (i + 0.5) + (heightIn - centredIn) : pitch * (i + 0.5),
  }));
  const innerMouthDepthIn = axisDepthIn - geometry.sidewaysReachIn;
  const diagnostics = geometry.problems.map(problem => roundPortProblemText(problem, 'Side Right'));
  if (hole > 0 && !roundPortsFitHeight(count, hole, flange, panel.panelHeightIn)) {
    diagnostics.push(count === 1
      ? `The port needs a ${hole.toFixed(2)} in hole and a ${flange.toFixed(2)} in flange, which do not fit the ${panel.panelHeightIn.toFixed(2)} in inside height.`
      : `${count} ports with ${hole.toFixed(2)} in holes and ${flange.toFixed(2)} in flanges do not fit one above the other in the ${panel.panelHeightIn.toFixed(2)} in inside height.`);
  } else if (hole > 0 && raised && Math.abs(heightIn - centredIn) > reach + 1e-9) {
    // refuse, do not repair: the height asked for is not moved to the nearest one that fits
    diagnostics.push(`The port cannot sit ${heightIn.toFixed(2)} in up the side panel: the hole needs half an inch of wood above and below it and the flange must stay on the panel. Its centre can be from ${(centredIn - reach).toFixed(2)} to ${(centredIn + reach).toFixed(2)} in up.`);
  }
  // toward the front the hole keeps the same half inch from the baffle, the flange the same quarter inch from the box edge
  const holeClearsBaffle = axisDepthIn - hole / 2 >= panel.baffleThicknessIn + ROUND_PORT_EDGE_GAP_IN - 1e-9;
  const flangeClearsFront = axisDepthIn - flange / 2 >= ROUND_PORT_FLANGE_EDGE_GAP_IN - 1e-9;
  if (hole > 0 && (!holeClearsBaffle || !flangeClearsFront)) {
    diagnostics.push(`The port needs a ${hole.toFixed(2)} in hole and a ${flange.toFixed(2)} in flange, which do not fit the right side of a box ${panel.boxDepthIn.toFixed(2)} in deep.`);
  }
  if (geometry.needsElbow && innerMouthDepthIn - panel.baffleThicknessIn < port.diameterIn) {
    diagnostics.push('The inner end of the port would be closer than one tube diameter to the baffle. The box is not deep enough for this port.');
  }
  return {
    active: true, location: 'Side Right', port, geometry, centers,
    subRightLimitIn: panel.boxWidthIn, subSpanWidthIn: panel.boxWidthIn,
    side: {
      panelFrontIn: panel.panelFrontIn, axisDepthIn, innerMouthDepthIn,
      heightIn, heightMinIn: centredIn - reach, heightMaxIn: centredIn + reach,
      passesBehindDriver: false, depthTakenIn: 0, driversRightOfTube: false,
    },
    diagnostics,
  };
}

/**
 * The space for the drivers to the right of an elbowed side tube: from the right-hand side of
 * the inner flare (the widest part of the second leg, which runs forward along the left wall) to
 * the inside face of the right side panel. Measured across the box from the outside of the left
 * side. Null when the tube runs straight or there is no such space.
 */
export function driverSpaceRightOfTube(
  layout: RoundPortLayout,
  box: { widthIn: number; sideThicknessIn: number },
): { leftIn: number; rightIn: number } | null {
  const geometry = layout.geometry;
  if (!layout.side || !geometry.needsElbow || !(geometry.lengthIn > 0)) return null;
  const leftIn = box.widthIn - geometry.leg1In - geometry.elbowRadiusIn + geometry.flareOutsideDiameterIn / 2;
  const rightIn = box.widthIn - box.sideThicknessIn;
  return rightIn > leftIn ? { leftIn, rightIn } : null;
}

// ─── The tube's path, for clearance checks and drawing ──────────────────────

/**
 * One cross-section of a tube, in the port's own flat frame: `along` runs from the outside face
 * of the mounting panel into the box, `across` runs the way the elbow turns (0 for a straight
 * tube). The tangent is a unit vector in the same frame.
 */
export interface RoundPortStation {
  /** Distance along the centreline from the mounting face. */
  s: number;
  along: number;
  across: number;
  tangentAlong: number;
  tangentAcross: number;
  /** Outside radius of the tube or flare here. */
  outerRadiusIn: number;
}

export function roundPortStationAt(port: RoundPortInputs, geometry: RoundPortGeometry, s: number): RoundPortStation {
  const outerRadiusIn = roundPortRadiusAt(s, port.diameterIn / 2, port.flareRadiusIn, geometry.lengthIn) + port.wallIn;
  const elbow = geometry.needsElbow && geometry.elbowRadiusIn > 0;
  const leg1 = elbow ? geometry.leg1In : geometry.lengthIn;
  if (!elbow || s <= leg1) return { s, along: s, across: 0, tangentAlong: 1, tangentAcross: 0, outerRadiusIn };
  const bend = geometry.elbowRadiusIn;
  if (s < leg1 + geometry.elbowArcIn) {
    const a = (s - leg1) / bend;
    return { s, along: leg1 + bend * Math.sin(a), across: bend * (1 - Math.cos(a)), tangentAlong: Math.cos(a), tangentAcross: Math.sin(a), outerRadiusIn };
  }
  return { s, along: leg1 + bend, across: bend + (s - leg1 - geometry.elbowArcIn), tangentAlong: 0, tangentAcross: 1, outerRadiusIn };
}

/** Cross-sections from the mounting face to the inner mouth, both ends included. */
export function roundPortStations(port: RoundPortInputs, geometry: RoundPortGeometry, stepIn = 0.05): RoundPortStation[] {
  const length = geometry.lengthIn;
  if (!(length > 0) || !(stepIn > 0)) return [];
  const count = Math.max(1, Math.ceil(length / stepIn));
  return Array.from({ length: count + 1 }, (_, i) => roundPortStationAt(port, geometry, (length * i) / count));
}
