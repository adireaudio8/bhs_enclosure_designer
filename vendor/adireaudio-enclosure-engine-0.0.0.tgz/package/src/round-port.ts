/**
 * Round port flared on both ends ("aero" style), optionally with one 90-degree elbow.
 *
 * Pure geometry and acoustics for one design's port: area, the length it must be for the
 * tuning, whether it needs an elbow to fit the box, how much airspace it takes up, and how
 * far it stands in front of the back wall.  Nothing here knows about panels or cut files.
 *
 * Where the numbers come from (November 2026 port study, OpenFOAM simulations of a 2 cu ft
 * box tuned to 32 Hz):
 *   - A flare is part of the port's length but counts for less than the same length of
 *     straight tube, because it is wider.  Its share is the integral of
 *     (throat area / local area) along the flare.
 *   - The open-end correction of a flared mouth is the square-ended one (the 1.463 x radius
 *     the slot formula uses for both ends together) scaled by throat area / mouth area.
 *     With no flare this reduces exactly to the slot formula.
 *   - An elbow acts slightly shorter than its centreline: the air takes the inside line.
 *     For a round tube of radius a on a centreline radius R the effective length of a
 *     quarter turn is (pi/2) * a^2 / (2 * (R - sqrt(R^2 - a^2))).
 *   Checked against the simulations: a 5 in tube 22.2 in long with 40 mm flares behaved
 *   like 603 mm of air (this model: 605 mm); a one-diameter elbow made the same tube act
 *   13 mm shorter (this model: 13.4 mm).  4 in and 4.5 in tubes agree within 3 %.
 *   The rule has not yet been checked against a measured port.
 */

import type { EnclosureInputs } from './types/enclosure';

/** Same constant as the slot-port resonance formula in calculations.ts. */
const RESONANCE_CONSTANT = 14630000.0;
/** Both open ends together, in tube radii, for a square-ended port (slot formula value). */
const END_CORRECTION_RADII = 1.463;
const INTEGRATION_STEPS = 400;

export interface RoundPortInputs {
  /** Inside diameter of the tube, inches. */
  diameterIn: number;
  /** How many identical tubes share the tuning. */
  quantity: number;
  /** Radius of the quarter-round flare on each end, inches.  0 = square ends. */
  flareRadiusIn: number;
  /** Wall thickness of tube, flares and elbow, inches. */
  wallIn: number;
  /** Centreline radius of the elbow, in tube diameters.  Must be above 0.5. */
  elbowRadiusDiameters: number;
  /** Width of the mounting flange round the outside flare, beyond the hole in the baffle, inches. */
  flangeWidthIn: number;
}

/**
 * Flange width and thickness follow the shop's own printed 4 in flare (measured from its 3D
 * files, November 2026): a 6.0 in body in a 6 in hole, a 7.5 in flange 3/16 in thick on the
 * face of the baffle.  Its pipe is 4.0 in inside and 4.25 in outside, and its elbow turns
 * on a 4.0 in centreline radius: the 1/8 in wall and one-diameter elbow used here.
 */
export const ROUND_PORT_DEFAULTS = {
  quantity: 1,
  flareRadiusIn: 1.6,
  wallIn: 0.125,
  elbowRadiusDiameters: 1.0,
  flangeWidthIn: 0.75,
} as const;
/** Thickness of the mounting flange (drawn in the viewer; it sits on the face of the baffle). */
export const ROUND_PORT_FLANGE_THICKNESS_IN = 0.1875;

/** The space the port has to live in. */
export interface RoundPortBoxContext {
  /** Net airspace the port is tuned against, cubic feet. */
  netAirSpaceCuFt: number;
  tuningFrequencyHz: number;
  /** From the outside face of the panel the port mounts in, to the inside face of the wall opposite. */
  faceToFarWallIn: number;
  /** Thickness of the panel the port mounts in. */
  mountPanelThicknessIn: number;
}

export type RoundPortProblem =
  | 'invalid-input'
  | 'elbow-radius-too-small'
  | 'port-too-short-for-flares'
  | 'box-too-shallow-for-elbow';

export interface RoundPortGeometry {
  valid: boolean;
  problems: RoundPortProblem[];
  /** Open area of one tube and of all tubes, square inches. */
  areaEachSqIn: number;
  areaTotalSqIn: number;
  /** Outside diameter of the tube, and of a flare at its mouth. */
  tubeOutsideDiameterIn: number;
  flareOutsideDiameterIn: number;
  /** Hole to cut in the baffle for the outside flare (the outside of the flare at its mouth). */
  holeDiameterIn: number;
  /** Outside diameter of the mounting flange on the face of the baffle. */
  flangeOutsideDiameterIn: number;
  /** Length of air the port must behave like for the tuning (end effects included). */
  effectiveLengthIn: number;
  /** Face-to-face length of a straight tube with these flares that gives the tuning. */
  straightLengthIn: number;
  /** True when the straight tube would end closer than one diameter to the far wall. */
  needsElbow: boolean;
  /** Face-to-face length along the centreline, as built (elbow included when needed). */
  lengthIn: number;
  /** Elbow centreline radius and arc length (0 when no elbow). */
  elbowRadiusIn: number;
  elbowArcIn: number;
  /** Straight run from the mounting face to the elbow, and from the elbow to the inner mouth.
   *  Both include their flare.  Without an elbow leg1 is the whole length and leg2 is 0. */
  leg1In: number;
  leg2In: number;
  /** How far the inner mouth is from the port's axis at the mounting face, across the box (0 when straight). */
  sidewaysReachIn: number;
  /** Depth of box the port occupies in front of the far wall where it crosses behind the
   *  drivers (0 when straight: a straight port stays beside them). */
  depthTakenAtFarWallIn: number;
  /** Airspace one tube takes out of the box, cubic inches (outside of tube, flares and elbow,
   *  from the inside face of the mounting panel inward). */
  displacementEachCuIn: number;
  /** All tubes, cubic feet. */
  displacementTotalCuFt: number;
}

/** Inside radius of the port at distance s along its centreline from the mounting face. */
export function roundPortRadiusAt(s: number, radiusIn: number, flareRadiusIn: number, lengthIn: number): number {
  const rf = Math.max(0, flareRadiusIn);
  if (rf === 0) return radiusIn;
  const intoFlare = Math.max(Math.min(rf - s, rf), 0, Math.min(s - (lengthIn - rf), rf));
  if (intoFlare === 0) return radiusIn;             // the plain tube, exactly
  return radiusIn + rf - Math.sqrt(Math.max(0, rf * rf - intoFlare * intoFlare));
}

/** Length of straight tube that one flare is worth acoustically. */
export function flareEffectiveLengthIn(radiusIn: number, flareRadiusIn: number): number {
  const rf = Math.max(0, flareRadiusIn);
  if (rf === 0 || radiusIn <= 0) return 0;
  const dx = rf / INTEGRATION_STEPS;
  let sum = 0;
  for (let i = 0; i < INTEGRATION_STEPS; i += 1) {
    const x = (i + 0.5) * dx;                       // from the mouth inward
    const local = radiusIn + rf - Math.sqrt(rf * rf - (rf - x) * (rf - x));
    sum += (radiusIn / local) * (radiusIn / local) * dx;
  }
  return sum;
}

/** Length of straight tube that a quarter-turn elbow is worth acoustically. */
export function elbowEffectiveLengthIn(radiusIn: number, centrelineRadiusIn: number): number {
  if (radiusIn <= 0 || centrelineRadiusIn <= radiusIn) return 0;
  const inside = centrelineRadiusIn - Math.sqrt(centrelineRadiusIn * centrelineRadiusIn - radiusIn * radiusIn);
  return (Math.PI / 2) * radiusIn * radiusIn / (2 * inside);
}

/** Length of air the port must behave like: the slot formula's first term, for the total area. */
export function requiredEffectiveLengthIn(areaTotalSqIn: number, netAirSpaceCuFt: number, tuningFrequencyHz: number): number {
  const denominator = tuningFrequencyHz * tuningFrequencyHz * netAirSpaceCuFt * 1728.0;
  if (!(denominator > 0) || !(areaTotalSqIn > 0)) return 0;
  return RESONANCE_CONSTANT * (areaTotalSqIn / Math.PI) / denominator;
}

/** Outside volume of the port between two centreline distances (flares and wall included). */
function outsideVolumeCuIn(from: number, to: number, radiusIn: number, flareRadiusIn: number, lengthIn: number, wallIn: number): number {
  if (to <= from) return 0;
  const steps = INTEGRATION_STEPS * 4;
  const ds = (to - from) / steps;
  let sum = 0;
  for (let i = 0; i < steps; i += 1) {
    const outer = roundPortRadiusAt(from + (i + 0.5) * ds, radiusIn, flareRadiusIn, lengthIn) + wallIn;
    sum += outer * outer * ds;
  }
  return Math.PI * sum;
}

function invalid(problems: RoundPortProblem[], partial: Partial<RoundPortGeometry> = {}): RoundPortGeometry {
  return {
    valid: false, problems, areaEachSqIn: 0, areaTotalSqIn: 0, tubeOutsideDiameterIn: 0, flareOutsideDiameterIn: 0,
    holeDiameterIn: 0, flangeOutsideDiameterIn: 0,
    effectiveLengthIn: 0, straightLengthIn: 0, needsElbow: false, lengthIn: 0, elbowRadiusIn: 0, elbowArcIn: 0,
    leg1In: 0, leg2In: 0, sidewaysReachIn: 0, depthTakenAtFarWallIn: 0, displacementEachCuIn: 0, displacementTotalCuFt: 0,
    ...partial,
  };
}

export function resolveRoundPort(port: RoundPortInputs, box: RoundPortBoxContext): RoundPortGeometry {
  const d = port.diameterIn;
  const count = Math.round(port.quantity);
  const rf = port.flareRadiusIn;
  const wall = port.wallIn;
  const finite = [d, port.quantity, rf, wall, port.elbowRadiusDiameters, port.flangeWidthIn, box.netAirSpaceCuFt, box.tuningFrequencyHz,
    box.faceToFarWallIn, box.mountPanelThicknessIn].every(Number.isFinite);
  if (!finite || !(d > 0) || count < 1 || rf < 0 || wall < 0 || port.flangeWidthIn < 0 || !(box.netAirSpaceCuFt > 0) || !(box.tuningFrequencyHz > 0)
    || !(box.faceToFarWallIn > 0) || box.mountPanelThicknessIn < 0) {
    return invalid(['invalid-input']);
  }

  const r = d / 2;
  const areaEachSqIn = Math.PI * r * r;
  const areaTotalSqIn = areaEachSqIn * count;
  const tubeOutsideDiameterIn = d + 2 * wall;
  const flareOutsideRadius = r + rf + wall;
  const flareOutsideDiameterIn = 2 * flareOutsideRadius;
  const effectiveLengthIn = requiredEffectiveLengthIn(areaTotalSqIn, box.netAirSpaceCuFt, box.tuningFrequencyHz);
  const endCorrection = END_CORRECTION_RADII * r * r / (r + rf);
  const straightLengthIn = effectiveLengthIn - endCorrection - 2 * flareEffectiveLengthIn(r, rf) + 2 * rf;
  const shared = { areaEachSqIn, areaTotalSqIn, tubeOutsideDiameterIn, flareOutsideDiameterIn,
    holeDiameterIn: flareOutsideDiameterIn, flangeOutsideDiameterIn: flareOutsideDiameterIn + 2 * port.flangeWidthIn,
    effectiveLengthIn, straightLengthIn };

  if (straightLengthIn < 2 * rf || straightLengthIn <= box.mountPanelThicknessIn) {
    return invalid(['port-too-short-for-flares'], shared);
  }

  // A straight port needs at least one tube diameter between its inner mouth and the far wall.
  const needsElbow = straightLengthIn > box.faceToFarWallIn - d;
  let lengthIn = straightLengthIn;
  let elbowRadiusIn = 0;
  let elbowArcIn = 0;
  let leg1In = straightLengthIn;
  let leg2In = 0;
  let sidewaysReachIn = 0;
  let depthTakenAtFarWallIn = 0;
  const problems: RoundPortProblem[] = [];

  if (needsElbow) {
    elbowRadiusIn = port.elbowRadiusDiameters * d;
    if (!(elbowRadiusIn > r + wall)) {
      return invalid(['elbow-radius-too-small'], { ...shared, needsElbow });
    }
    elbowArcIn = (Math.PI / 2) * elbowRadiusIn;
    lengthIn = straightLengthIn + (elbowArcIn - elbowEffectiveLengthIn(r, elbowRadiusIn));
    // The second leg runs along the far wall with the flare on its inner end just clear of that wall.
    const standOff = Math.max(flareOutsideRadius, r + wall);
    leg1In = box.faceToFarWallIn - standOff - elbowRadiusIn;
    leg2In = lengthIn - elbowArcIn - leg1In;
    if (leg2In < rf) {
      // Nearly fits straight: keep a flare's length of second leg and pull the port forward instead.
      leg2In = rf;
      leg1In = lengthIn - elbowArcIn - leg2In;
    }
    if (leg1In < Math.max(rf, box.mountPanelThicknessIn)) problems.push('box-too-shallow-for-elbow');
    sidewaysReachIn = elbowRadiusIn + leg2In;
    depthTakenAtFarWallIn = box.faceToFarWallIn - (leg1In + elbowRadiusIn) + (r + wall);
  }

  const displacementEachCuIn = outsideVolumeCuIn(box.mountPanelThicknessIn, lengthIn, r, rf, lengthIn, wall);
  return {
    valid: problems.length === 0,
    problems,
    ...shared,
    needsElbow,
    lengthIn,
    elbowRadiusIn,
    elbowArcIn,
    leg1In,
    leg2In,
    sidewaysReachIn,
    depthTakenAtFarWallIn,
    displacementEachCuIn,
    displacementTotalCuFt: displacementEachCuIn * count / 1728.0,
  };
}

// ─── The port in a design ───────────────────────────────────────────────────

/** Wood left between a port hole and the side wall, the top, the bottom and the next hole. */
export const ROUND_PORT_EDGE_GAP_IN = 0.5;
/** A flange may run over the edge of the side, top or bottom panel, but stops this far short of the box's outside edge. */
export const ROUND_PORT_FLANGE_EDGE_GAP_IN = 0.25;

/**
 * True when the design is built with round flared ports. Front-port boxes with the
 * single slot-port setting only; kerf, forced labyrinth and flush mount keep the slot.
 */
export function roundPortGate(inputs: EnclosureInputs): boolean {
  if (!inputs.roundPortEnabled) return false;
  const frontPort = inputs.enclosureConfiguration !== 'Subs Up/Port Back';
  const singlePort = (inputs.portQuantity || 'Single') === 'Single';
  return frontPort && singlePort && !inputs.kerfPortEnabled && !inputs.forceLabyrinthPort && !inputs.recessedMounting;
}

/** The design's round-port settings with the defaults filled in. */
export function roundPortInputsOf(inputs: EnclosureInputs): RoundPortInputs {
  return {
    diameterIn: inputs.roundPortDiameter ?? 0,
    quantity: inputs.roundPortQuantity ?? ROUND_PORT_DEFAULTS.quantity,
    flareRadiusIn: inputs.roundPortFlareRadius ?? ROUND_PORT_DEFAULTS.flareRadiusIn,
    wallIn: inputs.roundPortWall ?? ROUND_PORT_DEFAULTS.wallIn,
    elbowRadiusDiameters: inputs.roundPortElbowRadius ?? ROUND_PORT_DEFAULTS.elbowRadiusDiameters,
    flangeWidthIn: inputs.roundPortFlangeWidth ?? ROUND_PORT_DEFAULTS.flangeWidthIn,
  };
}

export interface RoundPortLayout {
  /** True when the design is built with round ports. */
  active: boolean;
  port: RoundPortInputs;
  geometry: RoundPortGeometry;
  /** Port centres on the finished baffle: x from its left edge, y from its bottom edge. */
  centers: Array<{ x: number; y: number }>;
  /** The drivers' frames must stay left of this x on the baffle: the edge of the port flange(s). */
  subRightLimitIn: number;
  /** Width the drivers are centred in: the baffle's left edge to subRightLimit plus one side wall. */
  subSpanWidthIn: number;
  /** Fit problems in plain words. Empty when the port fits. */
  diagnostics: string[];
}

export function roundPortProblemText(problem: RoundPortProblem): string {
  switch (problem) {
    case 'invalid-input': return 'Enter the round port diameter, the tuning and the net airspace.';
    case 'elbow-radius-too-small': return 'The elbow radius must be more than half the tube diameter.';
    case 'port-too-short-for-flares': return 'At this tuning the port would be shorter than its two flares. Use a smaller tube or smaller flares.';
    case 'box-too-shallow-for-elbow': return 'The box is not deep enough for the elbow at this radius.';
  }
}

/**
 * Where the port(s) sit on the baffle and whether they fit. The ports stand one above the
 * other at the right-hand side of the baffle; an elbow turns them toward the left, behind
 * the drivers. Each hole keeps half an inch of wood round it; each flange lies on the face
 * and may run over the edge of the side, top or bottom panel.
 */
export function layoutRoundPortOnBaffle(
  port: RoundPortInputs,
  geometry: RoundPortGeometry,
  panel: { baffleWidthIn: number; baffleHeightIn: number; sideThicknessIn: number },
): RoundPortLayout {
  const count = Math.max(1, Math.round(port.quantity));
  const hole = geometry.holeDiameterIn;
  const flange = geometry.flangeOutsideDiameterIn;
  const fromRightEdge = Math.max(
    panel.sideThicknessIn + ROUND_PORT_EDGE_GAP_IN + hole / 2,
    ROUND_PORT_FLANGE_EDGE_GAP_IN + flange / 2,
  );
  const x = panel.baffleWidthIn - fromRightEdge;
  const pitch = panel.baffleHeightIn / count;
  const centers = Array.from({ length: count }, (_, i) => ({ x, y: pitch * (i + 0.5) }));
  const subRightLimitIn = x - flange / 2;
  const diagnostics = geometry.problems.map(roundPortProblemText);
  // every hole keeps half an inch of wood above, below and between; a flange may run half an
  // inch over the top or bottom panel's edge, and flanges keep a quarter inch between them
  const holesFit = count * hole + (count + 1) * ROUND_PORT_EDGE_GAP_IN <= panel.baffleHeightIn + 1e-9;
  const flangesFit = flange <= pitch + (count === 1 ? 2 * ROUND_PORT_EDGE_GAP_IN : -ROUND_PORT_FLANGE_EDGE_GAP_IN) + 1e-9;
  if (hole > 0 && (!holesFit || !flangesFit)) {
    diagnostics.push(count === 1
      ? `The port needs a ${hole.toFixed(2)} in hole and a ${flange.toFixed(2)} in flange, which do not fit the ${panel.baffleHeightIn.toFixed(2)} in inside height.`
      : `${count} ports with ${hole.toFixed(2)} in holes and ${flange.toFixed(2)} in flanges do not fit one above the other in the ${panel.baffleHeightIn.toFixed(2)} in inside height.`);
  }
  if (geometry.needsElbow && x - geometry.sidewaysReachIn - panel.sideThicknessIn < port.diameterIn) {
    diagnostics.push('The inner end of the port would be closer than one tube diameter to the side wall. The box is too narrow for this port.');
  }
  if (!(subRightLimitIn > panel.sideThicknessIn)) {
    diagnostics.push('The port leaves no room on the baffle for the drivers.');
  }
  return { active: true, port, geometry, centers, subRightLimitIn, subSpanWidthIn: subRightLimitIn + panel.sideThicknessIn, diagnostics };
}
