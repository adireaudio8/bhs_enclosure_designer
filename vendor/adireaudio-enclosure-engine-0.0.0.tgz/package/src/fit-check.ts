/**
 * The fit check: every reason a design cannot be built as drawn, or only just fits, each with
 * the part it is about. The calculator's Fit Check panel lists these. It only reports: nothing
 * here moves a part or changes the design, and baffleCheck (which the customer designer reads to
 * stop a checkout) keeps its meaning.
 *
 * Parts checked:
 *   Subwoofer        the drivers on their mounting surface, flush recesses included
 *                    (calc.subwooferFit: the drivers alone, before a port that does not fit
 *                    fails the design)
 *   Subwoofer depth  the subwoofer's mounting depth, when the design gives one, against the
 *                    room behind the face its frame sits on (subwooferDepthCheck)
 *   Port             a round port's own reasons (calc.roundPort.diagnostics, less the terminal one)
 *   Terminal cup     the cup's place on its panel (the same check the cutting files make), and a
 *                    round port tube that comes too close to it
 *   Window           the acrylic window as it will be cut: the saved offsets kept inside the safe
 *                    area, the plate made smaller when it does not fit (as the cutting files do)
 */

import type { BaffleCheckResult, CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import {
  checkTerminalPlacement, resolveTerminalPanel, resolveTerminalPlacementOffset, terminalPanelLabel,
} from './terminal-placement';
import { checkWindowPlacement, resolveEffectiveWindowOffsets } from './acrylic-window';
import { roundPortGate } from './round-port';

export type FitPart = 'Subwoofer' | 'Subwoofer depth' | 'Port' | 'Terminal cup' | 'Window';

export interface FitProblem {
  part: FitPart;
  /** 'fail': it cannot be built this way. 'warning': it fits, with little to spare. */
  severity: 'fail' | 'warning';
  message: string;
}

/** A subwoofer with less room than this behind it, inches, is a tight fit. */
export const SUBWOOFER_DEPTH_SPARE_IN = 0.25;

export interface SubwooferDepthCheck {
  /** The subwoofer's mounting depth as given: from the face its frame sits on to the back of its motor. */
  depthIn: number;
  /** The room behind that face, to the first thing the motor would meet. */
  roomIn: number;
  /** What the motor would meet. */
  limit: 'the port wall' | 'the port tube' | 'the back panel' | 'the bottom panel';
  /** roomIn less depthIn; below 0 the subwoofer is too deep for the box. */
  spareIn: number;
  severity: 'ok' | 'warning' | 'fail';
}

export interface DesignFitCheck {
  /** The worst of the problems: any fail is DOES NOT FIT, any warning Tight Fit. */
  status: BaffleCheckResult['status'];
  problems: FitProblem[];
  /** The depth comparison, when the design gives a subwoofer depth. */
  depth: SubwooferDepthCheck | null;
}

const inches = (value: number) => `${value.toFixed(2)} in`;

/**
 * The subwoofer's mounting depth against the room behind its mounting face. Null when the design
 * gives no depth.
 *
 * Room. Drivers on the baffle: the box's mounting depth (calc.mountingDepthAvail), measured from
 * the face the frame sits on: to the port's wall behind the drivers for a slot port, to the
 * nearest part of a round port's tube that lies behind an opening, or to the back panel when no
 * tube does. Drivers on the top (Subs Up/Port Back): from the top panel's outside face to the
 * bottom panel; the slot port runs up the back and stays out of the way.
 */
export function subwooferDepthCheck(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList?: CutListItem[],
): SubwooferDepthCheck | null {
  const depthIn = inputs.subwooferMountingDepth;
  if (!(typeof depthIn === 'number' && Number.isFinite(depthIn) && depthIn > 0)) return null;

  let roomIn: number;
  let limit: SubwooferDepthCheck['limit'];
  if (inputs.enclosureConfiguration === 'Subs Up/Port Back') {
    const top = cutList?.find(part => part.partName === 'Top');
    roomIn = calc.internalHeight + (top?.thickness ?? 0);
    limit = 'the bottom panel';
  } else {
    roomIn = calc.mountingDepthAvail;
    const round = roundPortGate(inputs) && calc.roundPort?.active ? calc.roundPort : null;
    if (!round) limit = 'the port wall';
    else if (round.side) limit = round.side.passesBehindDriver ? 'the port tube' : 'the back panel';
    else limit = round.geometry.depthTakenAtFarWallIn > 0 ? 'the port tube' : 'the back panel';
  }
  const spareIn = roomIn - depthIn;
  const severity = spareIn < -1e-9 ? 'fail' : spareIn < SUBWOOFER_DEPTH_SPARE_IN - 1e-9 ? 'warning' : 'ok';
  return { depthIn, roomIn, limit, spareIn, severity };
}

/** The drivers' own verdict on their mounting surface as fit problems. */
function subwooferProblems(check: BaffleCheckResult): FitProblem[] {
  if (!check.visible || (!check.isFail && !check.isWarning)) return [];
  const severity = check.isFail ? 'fail' : 'warning';
  if (check.diagnostic) return [{ part: 'Subwoofer', severity, message: check.diagnostic }];
  const measured = check.clearanceBasis !== 'unavailable' && Number.isFinite(check.edgeClearance);
  const message = !measured
    ? 'The subwoofers have no safe place on the mounting panel.'
    : check.isFail
      ? `A subwoofer frame is ${inches(check.edgeClearance)} from the edge of the mounting panel or the next subwoofer. It needs more than 0.25 in.`
      : `A subwoofer frame is ${inches(check.edgeClearance)} from the edge of the mounting panel or the next subwoofer. Under 0.50 in is a tight fit.`;
  return [{ part: 'Subwoofer', severity, message }];
}

/**
 * Everything the fit check finds wrong with a design, by part. `cutList` must be the design's
 * own cut list (generateCutList for these inputs and calculations).
 */
export function checkDesignFit(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): DesignFitCheck {
  const problems: FitProblem[] = [];

  // Subwoofer: the drivers alone. calc.subwooferFit is absent on calculation rows that were not
  // made by calculateEnclosure; baffleCheck is then the best there is.
  problems.push(...subwooferProblems(calc.subwooferFit ?? calc.baffleCheck));

  // Subwoofer depth
  const depth = subwooferDepthCheck(inputs, calc, cutList);
  if (depth && depth.severity === 'fail') {
    problems.push({ part: 'Subwoofer depth', severity: 'fail',
      message: `The subwoofer is ${inches(depth.depthIn)} deep but the box has ${inches(depth.roomIn)} of mounting depth, to ${depth.limit}. It is ${inches(-depth.spareIn)} too deep.` });
  } else if (depth && depth.severity === 'warning') {
    problems.push({ part: 'Subwoofer depth', severity: 'warning',
      message: `The subwoofer is ${inches(depth.depthIn)} deep and the box has ${inches(depth.roomIn)} of mounting depth, to ${depth.limit}: ${inches(depth.spareIn)} to spare.` });
  }

  // Port: a round port's own reasons. The one about the terminal cup is listed under the cup.
  const round = roundPortGate(inputs) && calc.roundPort?.active ? calc.roundPort : null;
  const terminalReason = round?.side?.terminalDiagnostic;
  for (const message of round?.diagnostics ?? []) {
    problems.push({ part: message === terminalReason ? 'Terminal cup' : 'Port', severity: 'fail', message });
  }

  // Terminal cup: its place on its panel, the check the cutting files make before cutting.
  const panel = resolveTerminalPanel(inputs);
  if (panel !== 'None') {
    const placed = checkTerminalPlacement(inputs, calc, cutList, panel, resolveTerminalPlacementOffset(inputs, calc, cutList, panel));
    if (!placed.safe) {
      problems.push({ part: 'Terminal cup', severity: 'fail',
        message: `Not safe on the ${terminalPanelLabel(panel, inputs)} panel: ${placed.conflict?.label ?? 'it does not fit there'}. Move it under Extras, Terminal Cup Placement.` });
    }
  }

  // Window: as it will be cut.
  if (inputs.windowEnabled) {
    const offsets = resolveEffectiveWindowOffsets(inputs, calc, cutList);
    const window = checkWindowPlacement(inputs, calc, offsets.x, offsets.y, cutList);
    if (!window.safe) {
      problems.push({ part: 'Window', severity: 'fail', message: `${window.conflict?.label ?? 'It does not fit its panel'}.` });
    } else if (window.shrunk) {
      const { plateW, plateH } = window.dimensions;
      problems.push({ part: 'Window', severity: 'warning',
        message: `Cut smaller to fit: a ${inches(plateW)} x ${inches(plateH)} plate instead of ${inches(window.requested.plateW)} x ${inches(window.requested.plateH)}.` });
    }
  }

  const status: DesignFitCheck['status'] = problems.some(problem => problem.severity === 'fail')
    ? 'DOES NOT FIT'
    : problems.length > 0 ? 'Tight Fit' : 'OK';
  return { status, problems, depth };
}
