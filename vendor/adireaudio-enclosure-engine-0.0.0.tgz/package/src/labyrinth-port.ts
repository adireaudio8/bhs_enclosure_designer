/**
 * Automatic serpentine ("labyrinth") slot-port geometry.
 *
 * The legacy calculator can represent one 90-degree fold: PP1 runs along
 * the enclosure depth and PP2 runs across the enclosure width.  When the
 * volume solve makes the remaining S2 chamber negative, that transverse PP2
 * is physically longer than the box can contain.  A labyrinth replaces the
 * transverse PP2 with parallel dividers that alternate front/back anchoring.
 * The air path keeps a constant width and snakes around each free end.
 *
 * Acoustic convention used here:
 *   - total length is measured on the port centerline;
 *   - every lane-to-lane turn contributes one lane pitch
 *     (port width + divider thickness);
 *   - a full return run spans internalDepth - portWidth;
 *   - the last divider may be shortened to land the requested length.
 *
 * This module is deliberately UI-free. Calculations, cut list, fit checking,
 * and the 3-D viewer all consume the same resolved layout.
 */

export type LabyrinthAnchor = 'front' | 'back';

export interface LabyrinthPortPanel {
  /** 1-based cut-list number: 1 => Port Piece 1, etc. */
  partNumber: number;
  /** Ideal physical run before manufacturing mate/glue adjustments. */
  idealLength: number;
  /** Fraction of a full-depth divider. Used to scale the cut-list PP1 width. */
  fullLengthFraction: number;
  anchoredAt: LabyrinthAnchor;
  laneIndex: number;
}

export interface LabyrinthPortLayout {
  active: boolean;
  /** Human-readable diagnostic for UI and tests. */
  reason: string;
  portWidth: number;
  dividerThickness: number;
  lanePitch: number;
  fullDividerLength: number;
  acousticLength: number;
  initialLegLength: number;
  /** Final centerline distance that terminates within the last open turn. */
  terminalTurnLength: number;
  mazeWidth: number;
  panels: LabyrinthPortPanel[];
}

export interface LabyrinthPortResolveInput {
  portLengthNoEC: number;
  portLength1: number;
  portLength2: number;
  portWidth: number;
  dividerThickness: number;
  internalDepth: number;
  /** Legacy volume solve. Negative means its one-piece PP2 cannot fit. */
  legacyS2Width: number;
  isDualPort: boolean;
  kerfPortEnabled: boolean;
  /** Bypass the normal-fit check while retaining all topology safety gates. */
  forceLabyrinthPort: boolean;
}

const EPSILON = 1e-7;

export function resolveLabyrinthPortLayout(
  input: LabyrinthPortResolveInput,
): LabyrinthPortLayout {
  const {
    portLengthNoEC,
    portLength1,
    portLength2,
    portWidth,
    dividerThickness,
    internalDepth,
    legacyS2Width,
    isDualPort,
    kerfPortEnabled,
    forceLabyrinthPort,
  } = input;

  const inactive = (reason: string): LabyrinthPortLayout => ({
    active: false,
    reason,
    portWidth,
    dividerThickness,
    lanePitch: Math.max(0, portWidth + dividerThickness),
    fullDividerLength: Math.max(0, internalDepth - portWidth),
    acousticLength: portLengthNoEC,
    initialLegLength: portLength1,
    terminalTurnLength: 0,
    mazeWidth: 0,
    panels: [],
  });

  if (isDualPort) return inactive('Dual-port labyrinth geometry is not enabled.');
  if (kerfPortEnabled) return inactive('Kerf ports retain their dedicated single-fold geometry.');
  if (![portLengthNoEC, portLength1, portLength2, portWidth, dividerThickness, internalDepth, legacyS2Width]
    .every(Number.isFinite)) {
    return inactive('Port geometry contains a non-finite value.');
  }
  if (portWidth <= 0 || dividerThickness <= 0 || internalDepth <= portWidth) {
    return inactive('The enclosure is too shallow for a constant-width labyrinth turn.');
  }
  if (portLength2 <= 0) return inactive('The port does not require a second leg.');
  if (!forceLabyrinthPort && legacyS2Width >= -EPSILON) {
    return inactive('The normal folded port fits inside the enclosure.');
  }

  const lanePitch = portWidth + dividerThickness;
  const fullDividerLength = internalDepth - portWidth;
  let remaining = Math.max(0, portLengthNoEC - portLength1);
  let terminalTurnLength = 0;
  const panels: LabyrinthPortPanel[] = [{
    partNumber: 1,
    idealLength: fullDividerLength,
    fullLengthFraction: 1,
    anchoredAt: 'front',
    laneIndex: 0,
  }];

  // Each new lane first crosses one pitch at the open end, then travels
  // longitudinally beside the next divider. Full lanes alternate which wall
  // the divider touches, producing the front/back snake in the reference.
  let partNumber = 2;
  while (remaining > EPSILON) {
    const afterTurn = remaining - lanePitch;
    if (afterTurn <= EPSILON) {
      // A turn with no usable longitudinal run would create a tiny loose
      // strip. Fold that residual into the preceding lane; the centerline
      // error is recorded by the panel fraction and remains below one pitch.
      terminalTurnLength = remaining;
      remaining = 0;
      break;
    }
    const run = Math.min(fullDividerLength, afterTurn);
    panels.push({
      partNumber,
      idealLength: run,
      fullLengthFraction: Math.min(1, run / fullDividerLength),
      anchoredAt: partNumber % 2 === 0 ? 'back' : 'front',
      laneIndex: partNumber - 1,
    });
    remaining -= lanePitch + run;
    partNumber += 1;

    // A hard guard keeps malformed inputs from producing an unbounded list.
    if (panels.length >= 24) break;
  }

  const mazeWidth = panels.length * lanePitch;
  return {
    active: true,
    reason: forceLabyrinthPort
      ? 'Labyrinth mode was manually activated for this design.'
      : 'The normal folded Port Piece 2 exceeds the volume-derived enclosure width.',
    portWidth,
    dividerThickness,
    lanePitch,
    fullDividerLength,
    acousticLength: portLengthNoEC,
    initialLegLength: portLength1,
    terminalTurnLength,
    mazeWidth,
    panels,
  };
}
