/** Directed surface-to-dowel ramps. DXF start/end order is machining data. */
export const DOW_CHANNEL_LAYER = 'DOW_CHANNEL_RAMP_0_4';
export const DOW_CHANNEL_LENGTH_IN = 0.5;
export const DOW_CHANNEL_DEPTH_IN = 0.4;
export const DOW_CHANNEL_TOOL_DIAMETER_IN = 0.375;
export const DOW_CHANNEL_PASS_DEPTH_IN = 0.1;
