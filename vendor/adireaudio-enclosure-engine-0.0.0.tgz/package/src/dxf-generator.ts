/**
 * DXF File Generator
 * Generates DXF (Drawing eXchange Format) text files for CNC cutting.
 * Ported from C# DxfPartGenerator.cs
 *
 * DXF is a text-based format. Each entity has group codes (integers) and values.
 * Key group codes:
 *   0 = entity type, 2 = name, 8 = layer, 10/20 = X/Y start, 11/21 = X/Y end
 *   40 = radius (circle), 62 = color code, 70 = flags
 */

import { DEFAULT_GLUE_TOLERANCE, DEFAULT_MATERIAL_CONFIG } from './types/enclosure';
import { kerfGrooveLayerName, type KerfGeometry } from './kerf-port';
import { getSubwooferCount } from './calculations';
import { parseEpsPaths, calculatePathsBounds, filterBoundingBoxPaths, epsPathsToDxfEntities } from './eps-parser';
import { generatePocketLogoToolpath } from './pocket-logo-toolpath';
import { appendDebug } from './debug-log';
import { checkTerminalPlacementFlat } from './terminal-placement';
import { resolveSupbAutoCenterY, resolveSupbSubLayout } from './subwoofer-placement';
import type { CutListItem, EnclosureInputs, EnclosureCalculations, MaterialConfig } from './types/enclosure';
import {
  resolveWindowSafeArea,
  resolveAutoFitPlateDimensions,
  resolveEffectiveWindowOffsets,
} from './acrylic-window';
import { accBarcodeValue, accFilename } from './acc-naming';

// ─── Constants ─────────────────────────────────────────────────────────────────

const SHEET_WIDTH = 96;   // inches (4' × 8' sheet) — used only for logo DXF
const SHEET_HEIGHT = 48;
// Desktop has NO sheet-level part offset for individual part DXFs.
// Parts start at (0,0) with only mill-down offsets (xOffset/yOffset).
// The 1.9775 value is ONLY used in logo DXF generation for panel positioning within the sheet.
const LOGO_PANEL_OFFSET_Y = 1.9775; // logo DXF only: panel offset from bottom of 96x48 sheet

// DXF color codes (must match desktop ACI values for CNC compatibility)
const COLOR_WHITE = 7;   // CUT layer, DRILL layers
const COLOR_GRAY = 8;    // GUIDES layer (sheet outlines)
const COLOR_RED = 1;     // CUT_INSIDE layer / box dieline fold lines
const COLOR_BLUE = 5;    // MILL_DOWN layers (desktop ACI 5) + Box dieline cuts
const COLOR_CYAN = 4;    // ENGRAVE layer
const COLOR_MAGENTA_GUIDE = 6; // Guide rectangles (desktop ACI 6)

// ─── DXF Primitives ───────────────────────────────────────────────────────────

function dxfLine(layer: string, x1: number, y1: number, x2: number, y2: number): string {
  return [
    '0', 'LINE', '8', layer,
    '10', x1.toFixed(4), '20', y1.toFixed(4), '30', '0.0',
    '11', x2.toFixed(4), '21', y2.toFixed(4), '31', '0.0',
  ].join('\n') + '\n';
}

function dxfArc(layer: string, cx: number, cy: number, radius: number, startAngle: number, endAngle: number): string {
  return [
    '0', 'ARC', '8', layer,
    '10', cx.toFixed(4), '20', cy.toFixed(4), '30', '0.0',
    '40', radius.toFixed(4),
    '50', startAngle.toFixed(4),
    '51', endAngle.toFixed(4),
  ].join('\n') + '\n';
}

function dxfCircle(layer: string, cx: number, cy: number, radius: number): string {
  return [
    '0', 'CIRCLE', '8', layer,
    '10', cx.toFixed(4), '20', cy.toFixed(4), '30', '0.0',
    '40', radius.toFixed(4),
  ].join('\n') + '\n';
}

/** Closed POLYLINE rectangle (AC1009 format — POLYLINE + 4 VERTEX + SEQEND).
 *  Matches desktop Polyline2D with isClosed=true. CNC reads as single closed path.
 *  Flag 70=1 means closed polyline. */
function dxfRect(layer: string, x: number, y: number, w: number, h: number): string {
  return [
    '0', 'POLYLINE', '8', layer, '66', '1', '70', '1',  // 66=vertices-follow, 70=closed
    '0', 'VERTEX', '8', layer, '10', x.toFixed(4), '20', y.toFixed(4), '30', '0.0',
    '0', 'VERTEX', '8', layer, '10', (x + w).toFixed(4), '20', y.toFixed(4), '30', '0.0',
    '0', 'VERTEX', '8', layer, '10', (x + w).toFixed(4), '20', (y + h).toFixed(4), '30', '0.0',
    '0', 'VERTEX', '8', layer, '10', x.toFixed(4), '20', (y + h).toFixed(4), '30', '0.0',
    '0', 'SEQEND', '8', layer,
  ].join('\n') + '\n';
}

/** Closed POLYLINE with optional per-vertex bulges (AC1009 format).
 *  Bulge at vertex i describes the segment from vertex i → vertex i+1.
 *  Bulge = tan(includedAngle / 4); positive = CCW arc, negative = CW, 0 = line.
 *  Used for the box dieline cuts so VCarve sees one continuous tool path. */
function dxfPolylineWithBulges(
  layer: string,
  vertices: Array<{ x: number; y: number; bulge: number }>,
): string {
  const parts: string[] = [
    '0', 'POLYLINE', '8', layer, '66', '1', '70', '1',
  ];
  for (const v of vertices) {
    parts.push('0', 'VERTEX', '8', layer,
      '10', v.x.toFixed(4), '20', v.y.toFixed(4), '30', '0.0');
    if (v.bulge !== 0) parts.push('42', v.bulge.toFixed(6));
  }
  parts.push('0', 'SEQEND', '8', layer);
  return parts.join('\n') + '\n';
}

// ─── Segment stitcher (cut lines + arcs → single closed polyline) ─────────────

/** A directional cut segment: walks from (x1,y1) to (x2,y2). Bulge of 0 = line.
 *  For arcs: bulge = tan(sweep/4) when traversed start→end (matches DXF CCW). */
interface CutSegment {
  x1: number; y1: number;
  x2: number; y2: number;
  bulge: number;
}

/** Convert a DXF arc (CCW, sa→ea in degrees) to a CutSegment whose bulge is
 *  correct when traversed from the start-angle point to the end-angle point. */
function arcToSegment(cx: number, cy: number, r: number, sa: number, ea: number): CutSegment {
  const saRad = (sa * Math.PI) / 180;
  const eaRad = (ea * Math.PI) / 180;
  const sweepRad = ((ea - sa) * Math.PI) / 180;
  return {
    x1: cx + r * Math.cos(saRad),
    y1: cy + r * Math.sin(saRad),
    x2: cx + r * Math.cos(eaRad),
    y2: cy + r * Math.sin(eaRad),
    bulge: Math.tan(sweepRad / 4),
  };
}

/** Stitch a list of cut segments into one closed loop of vertices.
 *  Endpoints are matched at 0.001 mm tolerance (well below toFixed(4)).
 *  Throws loudly if segments don't form a single closed loop — the caller
 *  expects the geometry to be one continuous perimeter. */
function stitchClosedPath(
  segments: CutSegment[],
  contextLabel: string,
): Array<{ x: number; y: number; bulge: number }> {
  if (segments.length === 0) {
    throw new Error(`stitchClosedPath(${contextLabel}): no segments`);
  }
  const key = (x: number, y: number) => `${x.toFixed(3)},${y.toFixed(3)}`;
  const adj = new Map<string, Array<{ idx: number; reversed: boolean }>>();
  for (let i = 0; i < segments.length; i++) {
    const s = segments[i];
    const k1 = key(s.x1, s.y1);
    const k2 = key(s.x2, s.y2);
    if (!adj.has(k1)) adj.set(k1, []);
    if (!adj.has(k2)) adj.set(k2, []);
    adj.get(k1)!.push({ idx: i, reversed: false });
    adj.get(k2)!.push({ idx: i, reversed: true });
  }
  // Sanity: every endpoint should be touched by exactly 2 segments for a clean closed loop.
  for (const [k, list] of adj.entries()) {
    if (list.length !== 2) {
      throw new Error(
        `stitchClosedPath(${contextLabel}): endpoint ${k} touched by ${list.length} segment(s); expected exactly 2 for a closed loop`,
      );
    }
  }

  const used = new Set<number>();
  const ordered: Array<{ x: number; y: number; bulge: number }> = [];
  const first = segments[0];
  const startKey = key(first.x1, first.y1);
  ordered.push({ x: first.x1, y: first.y1, bulge: first.bulge });
  used.add(0);
  let curX = first.x2, curY = first.y2;
  let curKey = key(curX, curY);

  while (used.size < segments.length) {
    const candidates = adj.get(curKey) || [];
    const next = candidates.find(c => !used.has(c.idx));
    if (!next) {
      throw new Error(
        `stitchClosedPath(${contextLabel}): stuck at (${curX.toFixed(3)}, ${curY.toFixed(3)}); ${segments.length - used.size} segment(s) unvisited — cuts don't form a single closed loop`,
      );
    }
    const seg = segments[next.idx];
    used.add(next.idx);
    let bulge: number;
    let nextX: number, nextY: number;
    if (next.reversed) {
      bulge = -seg.bulge;
      nextX = seg.x1;
      nextY = seg.y1;
    } else {
      bulge = seg.bulge;
      nextX = seg.x2;
      nextY = seg.y2;
    }
    ordered.push({ x: curX, y: curY, bulge });
    curX = nextX;
    curY = nextY;
    curKey = key(curX, curY);
  }

  if (curKey !== startKey) {
    throw new Error(
      `stitchClosedPath(${contextLabel}): walk ended at (${curX.toFixed(3)}, ${curY.toFixed(3)}), expected start (${first.x1.toFixed(3)}, ${first.y1.toFixed(3)}) — open path`,
    );
  }
  return ordered;
}

// ─── DXF Document Builder ─────────────────────────────────────────────────────

interface LayerDef {
  name: string;
  color: number;
}

function buildDxfDocument(entities: string, layers: LayerDef[], unitsMm = false): string {
  // HEADER section
  const header = [
    '0', 'SECTION', '2', 'HEADER',
    '9', '$INSUNITS', '70', unitsMm ? '4' : '1',  // 4=mm, 1=inches
    '9', '$ACADVER', '1', 'AC1009', // AutoCAD R12 format (simple text DXF, no handles required)
    '0', 'ENDSEC',
  ].join('\n') + '\n';

  // TABLES section (layer definitions)
  // Include default '0' layer + all custom layers to avoid empty record warnings
  const allLayers: LayerDef[] = [{ name: '0', color: COLOR_WHITE }, ...layers.filter(l => l.name && l.name !== '0')];
  let layerTable = [
    '0', 'SECTION', '2', 'TABLES',
    '0', 'TABLE', '2', 'LAYER', '70', String(allLayers.length),
  ].join('\n') + '\n';

  for (const layer of allLayers) {
    layerTable += [
      '0', 'LAYER',
      '2', layer.name,
      '70', '0',
      '62', String(layer.color),
      '6', 'Continuous',
    ].join('\n') + '\n';
  }

  layerTable += ['0', 'ENDTAB', '0', 'ENDSEC'].join('\n') + '\n';

  // ENTITIES section
  const entitiesSection = [
    '0', 'SECTION', '2', 'ENTITIES',
  ].join('\n') + '\n' + entities + ['0', 'ENDSEC'].join('\n') + '\n';

  // EOF
  const eof = '0\nEOF\n';

  return header + layerTable + entitiesSection + eof;
}

// ─── Part DXF Generation ──────────────────────────────────────────────────────

export interface PartDxfOptions {
  subCutoutDiameter?: number;
  subwooferQuantity?: string;
  outsideDiameter?: number;
  /** Kerf-port geometry for the merged "Baffle + Port 1" bent part — set from the
   *  cut-list item by generateAllFiles. When present, generatePartDxf emits the
   *  kerf panel (outline + sub cutout on the baffle leg + groove centerlines). */
  kerf?: KerfGeometry;
  buildStrength?: string;       // 'Standard Duty' | 'Regular Duty' | 'Heavy Duty'
  isBirchPly?: boolean;         // true = Birch (has mill-down), false = MDF (no mill-down)
  enclosureConfiguration?: string; // 'Subs Back/Port Back' | 'Subs Up/Port Back'
  portQuantity?: string;        // 'Single' | 'Dual'
  portWidth?: number;           // port opening width (inches) — from design inputs
  port1PartWidth?: number;      // Port Piece 1 cut list width (for drill hole Y positioning)
  port2PartWidth?: number;      // Port Piece 2 cut list width (for drill hole X positioning)
  s2LeftWidth?: number;         // S2 Left chamber width (for SUPB sub positioning)
  s1RightWidth?: number;        // S1 Right chamber width (for SUPB sub positioning)
  materialThickness?: number;   // primary wall thickness (B1 or D1)
  heavyThickness?: number;      // heavy material thickness (B2 or D2)
  materialConfig?: MaterialConfig; // full-stock + milled mate dimensions used by joinery placement
  glueTolerance?: number;       // clearance per mating edge (default 0.01")
  includeGuides?: boolean;      // true = add guide rectangles (with-guides version)
  baffleWidth?: number;         // baffle part width (for bottom/top guide positioning)
  cutOutTolerance?: number;     // added to subwoofer cutout diameter (inches, default 0)
  // Extra hole counts (user-configurable, matching desktop BuildTabViewModel)
  extraHolesBack?: number;      // extra holes along back edge of bottom/top
  extraHolesFront?: number;     // extra holes along front (baffle) edge
  extraHolesRight?: number;     // extra holes along right side edge
  extraHolesLeft?: number;      // extra holes along left side edge
  extraHolesHeight?: number;    // extra holes along height of Back/Baffle/Port2 panels
  port2VerticalOffset?: number; // user-configurable Port 2 vertical offset from Build tab settings
  sideLeftDepth?: number;       // Side Left cut list width (for Bottom/Top guide positioning)
  sideRightDepth?: number;      // Side Right cut list width (for Bottom/Top guide positioning)
  backWidth?: number;           // Back panel cut list width (for Bottom/Top guide positioning)
  // Terminal cup placement (V1 user-customizable). Both undefined = legacy
  // hardcoded behavior: Side Left for single port, Back for dual port,
  // centered horizontally. See src/lib/terminal-placement.ts.
  terminalPanel?: 'Side Left' | 'Back' | 'None';
  terminalXOffset?: number;     // inches from panel's horizontal center; +X right/back
  // Subwoofer cutout placement override (SUPB only). Both undefined = legacy
  // auto positioning. See src/lib/subwoofer-placement.ts.
  subwooferXOffset?: number;    // inches; + shifts toward Side Right
  subwooferYOffset?: number;    // inches; + shifts toward back of box
  // Recessed (flush) sub mounting. When true:
  //   - Structural baffle: hole = outsideDiameter + 0.25" (flange recess),
  //     no sub mounting drill holes (sub mounts to the inner plate),
  //     cut layers force to the material's thin stock regardless of duty
  //     (18mm Birch or 3/4" MDF).
  //   - Sub Mount Plate (separate cut list entry): outline cut + standard
  //     sub through-cutout. Layer follows the plate's actual thickness
  //     (24MM for RD/HD, 18MM for SD). No drill holes, no mill-down, no
  //     terminal cutout, no joinery.
  // SBPB / SUPP only — the engine gates this at the cut-list level for SUPB.
  recessedMounting?: boolean;
  // Acrylic window (V1). Adds a rounded-rectangle cutout + screw pilot ring
  // to the panel auto-determined by enclosureConfiguration:
  //   SBPB → Top, SUPB → Baffle, SUPU → Bottom.
  // Caller threads inputs.windowEnabled / windowSize / orientation / X/Y
  // offsets / corner radius. See src/acrylic-window.ts for the helper module.
  windowEnabled?: boolean;
  windowSize?: '12x12' | '24x12' | 'custom';
  windowOrientation?: 'landscape' | 'portrait';
  windowXOffset?: number;
  windowYOffset?: number;
  windowCornerRadius?: number;
  windowCustomWidth?: number;
  windowCustomHeight?: number;
  // Optional design context for window auto-shrink. When all three are
  // present, the wood cutout + screw ring are sized to the auto-fitted
  // plate dims (1" clearance from baffle, PP1, PP2, sides); otherwise
  // generatePartDxf falls back to the raw tier size for direct callers
  // without design context.
  inputs?: EnclosureInputs;
  calc?: EnclosureCalculations;
  cutList?: CutListItem[];
}

// ─── Layer Helpers ────────────────────────────────────────────────────────────

function isHD(bs: string | undefined): boolean { return (bs || '').toUpperCase().includes('HEAVY'); }
function isRD(bs: string | undefined): boolean { return (bs || '').toUpperCase().includes('REGULAR'); }
function isSD(bs: string | undefined): boolean { return !isHD(bs) && !isRD(bs); }

/** True if the named part is the thick (24mm/1") panel for the given build
 *  strength + configuration combo. Mirrors getPartMaterial's RD branch:
 *  RD-SBPB → Baffle is thick; RD-SUPB → Top is thick. SD/HD don't branch. */
function isPartThick(bs: string | undefined, partName: string, enclosureConfiguration: string | undefined): boolean {
  if (isHD(bs)) return true;
  if (isSD(bs)) return false;
  const isSUPB = enclosureConfiguration === 'Subs Up/Port Back';
  return isSUPB ? partName === 'Top' : partName === 'Baffle';
}

/** Material+thickness token appended to duty-dependent layer names.
 *  Birch: 18MM / 24MM (nominal metric ply, true 0.709"/0.945").
 *  MDF: _75INCH (3/4") / 1INCH (1") — the leading underscore is the shop's
 *  decimal-point convention (like __5_DEEP = 0.5" deep), so names render as
 *  CUT_OUT__75INCH / CUT_OUT_1INCH. MDF stock is true-dimension (0.75"/1.0"),
 *  so the toolpath operations mapped to these layers cut correspondingly
 *  deeper than their Birch counterparts. */
function matToken(isBirch: boolean, thick: boolean): string {
  if (isBirch) return thick ? '24MM' : '18MM';
  return thick ? '1INCH' : '_75INCH';
}

/** Fallback wall thicknesses used when the caller omits materialThickness /
 *  heavyThickness. Material-aware: MDF stock is true-dimension (D1 0.75" /
 *  D2 1.0" — never milled, operator ruling 2026-07-08); Birch keeps the
 *  historical B1/B2 fallbacks. The calculator app always passes explicit
 *  thicknesses, so these only fire for direct API callers. Before this,
 *  the bare 0.709/0.945 fallbacks on MDF paths could even reject valid MDF
 *  parts: an HD MDF part cuts on CUT_OUT_1INCH (1.0" deep) but the 0.945
 *  fallback thickness tripped assertCutDepthsSafe's overcut guard. */
function fallbackThinIn(isBirch: boolean): number { return isBirch ? 0.709 : 0.75; }
function fallbackHeavyIn(isBirch: boolean): number { return isBirch ? 0.945 : 1.0; }

/** CUT_OUT layer: panel-outline cut depth must match the panel thickness so
 *  the router goes through the material exactly once. SD all thin, HD all
 *  thick; RD branches on configuration via isPartThick. */
function getCutOutLayer(bs: string | undefined, partName: string, enclosureConfiguration: string | undefined, isBirch: boolean): string {
  return `CUT_OUT_${matToken(isBirch, isPartThick(bs, partName, enclosureConfiguration))}`;
}

/** CUT_INSIDE layer for cutouts that go fully through the host part.
 *  Depth must match the host PART's thickness, not just the build duty:
 *    - SD: every part is 18mm → 18MM.
 *    - HD: every part is 24mm → 24MM.
 *    - RD: only one part is thick (SBPB → Baffle, SUPB → Top). The OTHER
 *      panels are 18mm even in RD, so cutting them on the 24mm layer
 *      sends the router 6mm past the material into the spoilboard.
 *  This is why we ask `isPartThick` instead of just the duty — it's the
 *  same matrix used by `getCutOutLayer` and the drill layer pickers.
 *  Defaults to a generic "thick" check when no part is given (legacy
 *  callers that don't know which panel they're on; should be reviewed
 *  and migrated to pass partName). */
function getCutInsideLayer(bs: string | undefined, partName: string | undefined, enclosureConfiguration: string | undefined, isBirch: boolean): string {
  if (partName !== undefined) {
    return `CUT_INSIDE_${matToken(isBirch, isPartThick(bs, partName, enclosureConfiguration))}`;
  }
  return `CUT_INSIDE_${matToken(isBirch, isHD(bs) || isRD(bs))}`;
}

/** CUT_INSIDE layer for terminal cup cutout (Side Left / Back):
 *  HD=thick, SD/RD=thin — matches desktop GenerateSideLeftRectangle line 707.
 *  Different rule than sub cutouts: RD uses thin material for Side Left. */
function getTerminalCutInsideLayer(bs: string | undefined, isBirch: boolean): string {
  return `CUT_INSIDE_${matToken(isBirch, isHD(bs))}`;
}

/** 8mm drill layer: matches the panel thickness so the operator runs the
 *  drill on the correct stock. HD=thick all parts, SD=thin all parts; RD
 *  branches per part via isPartThick (RD-SUPB Top → thick, rest → thin). */
function getDrillLayer(bs: string | undefined, partName: string | undefined, enclosureConfiguration: string | undefined, isBirch: boolean): string {
  return `8MM_DRILL__5_DEEP_${matToken(isBirch, isPartThick(bs, partName ?? '', enclosureConfiguration))}`;
}

/** 25mm drill layer (terminal mounting): HD=thick, others=thin */
function getDrill25Layer(bs: string | undefined, isBirch: boolean): string {
  return `25_DRILL__5_DEEP_${matToken(isBirch, isHD(bs))}`;
}

/** Mill-down layer: HD=MILL_DOWN__03 (1.125" wide), SD/RD=MILL_DOWN__034 (0.875" wide) */
function getMillDownLayer(bs: string | undefined): string {
  return isHD(bs) ? 'MILL_DOWN__03' : 'MILL_DOWN__034';
}

/** Mill-down rectangle width: HD=1.125", SD/RD=0.875" */
function getMillDownWidth(bs: string | undefined): number {
  return isHD(bs) ? 1.125 : 0.875;
}

/** OD-aware subwoofer X positions: equal edge gaps accounting for outside diameter */
function getSubwooferXPositions(baffleWidth: number, outsideDiameter: number, subCount: number): number[] {
  const od = outsideDiameter > 0 ? outsideDiameter : 0;
  const gap = (baffleWidth - od * subCount) / (subCount + 1);
  const positions: number[] = [];
  for (let i = 0; i < subCount; i++) {
    positions.push(gap * (i + 1) + od * i + od / 2);
  }
  return positions;
}

// ─── Mill-Down Generation ─────────────────────────────────────────────────────

/** Generate mill-down rectangles for Back panel (Birch only). Two vertical strips on left/right edges. */
function generateBackMillDown(entities: string, width: number, height: number, bs: string | undefined, xOffset: number): string {
  const layer = getMillDownLayer(bs);
  const mw = getMillDownWidth(bs);
  const mh = height + 0.5; // 0.25" overhang above and below
  // Left mill-down
  entities += dxfRect(layer, 0, 0, mw, mh);
  // Right mill-down
  const rightX = (width + xOffset) - (isHD(bs) ? 1.0 : 0.75);
  entities += dxfRect(layer, rightX, 0, mw, mh);
  return entities;
}

/** Generate mill-down rectangles for Baffle (Birch only). Same as Back. */
function generateBaffleMillDown(entities: string, width: number, height: number, bs: string | undefined, xOffset: number): string {
  return generateBackMillDown(entities, width, height, bs, xOffset);
}

/** Generate mill-down rectangle for Port 2 (Birch only). Single strip on right edge. */
function generatePort2MillDown(entities: string, width: number, height: number, bs: string | undefined): string {
  const layer = getMillDownLayer(bs);
  const mw = getMillDownWidth(bs);
  const mh = height + 0.5;
  const rightX = width - mw + 0.125;
  entities += dxfRect(layer, rightX, 0, mw, mh);
  return entities;
}

/** Name of the bounding-box layer added for parts with mill-down rectangles.
 *  Nesting software often misreads mill-down strips (which extend past the
 *  part outline) as separate parts. A single rectangle on this layer gives
 *  the nester an unambiguous envelope for each part. */
const BOUNDING_FOR_NEST_LAYER = 'BOUNDING_FOR_NEST';

/** Dimensions of the bounding-box envelope for a mill-down part.
 *  Independent of HD vs SD/RD — the geometry is designed so the outer
 *  mill-down edges always land at the same offsets past the part edge.
 *
 *  Offset by a small epsilon so the rect STRICTLY encloses every other
 *  entity. Nesters get confused by coincident edges (the bounding rect's
 *  left edge at x=0 was landing exactly on the left mill-down rect's
 *  left edge, making NestProfessor unable to decide which was the outer
 *  boundary). With the epsilon, the envelope is unambiguously outermost. */
function generateBoundingForNest(
  entities: string,
  partName: string,
  width: number,
  height: number,
): string {
  // Back/Baffle: mill-down on left (x=0) and right — right edge of right
  //   mill-down lands at width + 0.25, regardless of duty.
  // Port Piece 2: mill-down on right only — right edge lands at width + 0.125.
  // Vertically: mill-downs extend 0.25" above and below the part (height + 0.5).
  const EPS = 0.0001;
  const numericPortPiece = numberedPortPiece(partName);
  const isPort2 = partName.startsWith('Port Piece 2')
    || (numericPortPiece !== null && numericPortPiece >= 2);
  const bboxWidth = width + (isPort2 ? 0.125 : 0.25) + EPS * 2;
  const bboxHeight = height + 0.5 + EPS * 2;
  entities += dxfRect(BOUNDING_FOR_NEST_LAYER, -EPS, -EPS, bboxWidth, bboxHeight);
  return entities;
}

// ─── Drill Hole Generation ────────────────────────────────────────────────────

const DRILL_HOLE_DIAMETER = 0.315;
const DRILL_HOLE_RADIUS = DRILL_HOLE_DIAMETER / 2;
const EDGE_INSET = 0.375;     // drill hole inset from edges
const CORNER_INSET = 1.25;    // drill hole inset from corners

/** Generate drill holes for Back panel: left/right edges + HeightExtraHoles between corners.
 *  Desktop: GenerateBackHoles adds HeightExtraHoles on BOTH left and right edges. */
function generateBackDrillHoles(entities: string, width: number, height: number, bs: string | undefined, xOffset: number, yOffset: number, extraHeight: number, enclosureConfiguration: string | undefined, isBirch: boolean): string {
  const layer = getDrillLayer(bs, 'Back', enclosureConfiguration, isBirch);
  const leftX = EDGE_INSET + xOffset;
  const rightX = width - EDGE_INSET + xOffset;
  const bottomY = CORNER_INSET + yOffset;
  const topY = height - CORNER_INSET + yOffset;
  // Corner holes
  entities += dxfCircle(layer, leftX, bottomY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, leftX, topY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, rightX, bottomY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, rightX, topY, DRILL_HOLE_RADIUS);
  // HeightExtraHoles: evenly spaced between corner holes on both edges
  if (extraHeight > 0) {
    const span = topY - bottomY;
    for (let i = 1; i <= extraHeight; i++) {
      const ey = bottomY + span * i / (extraHeight + 1);
      entities += dxfCircle(layer, leftX, ey, DRILL_HOLE_RADIUS);
      entities += dxfCircle(layer, rightX, ey, DRILL_HOLE_RADIUS);
    }
  }
  return entities;
}

/** Generate drill holes for Baffle: left/right edges + HeightExtraHoles + center brace holes for multi-sub.
 *  Flush mount: skip the multi-sub center brace holes — those move to the
 *  Sub Mount Plate (gussets attach to the plate now, not the baffle). The
 *  edge dowels (joinery to side panels) stay regardless. */
function generateBaffleDrillHoles(entities: string, width: number, height: number, bs: string | undefined, xOffset: number, yOffset: number, subCount: number, od: number, extraHeight: number, enclosureConfiguration: string | undefined, isRecessed: boolean, subwooferXOffset: number, isBirch: boolean): string {
  // Flush construction always uses the material's thin stock for the
  // structural baffle, even on RD/HD designs.
  const layer = isRecessed
    ? `8MM_DRILL__5_DEEP_${matToken(isBirch, false)}`
    : getDrillLayer(bs, 'Baffle', enclosureConfiguration, isBirch);
  const leftX = EDGE_INSET + xOffset;
  const rightX = width - EDGE_INSET + xOffset;
  const bottomY = CORNER_INSET + yOffset;
  const topY = height - CORNER_INSET + yOffset;
  // Corner holes
  entities += dxfCircle(layer, leftX, bottomY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, leftX, topY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, rightX, bottomY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, rightX, topY, DRILL_HOLE_RADIUS);
  // HeightExtraHoles on both edges
  if (extraHeight > 0) {
    const span = topY - bottomY;
    for (let i = 1; i <= extraHeight; i++) {
      const ey = bottomY + span * i / (extraHeight + 1);
      entities += dxfCircle(layer, leftX, ey, DRILL_HOLE_RADIUS);
      entities += dxfCircle(layer, rightX, ey, DRILL_HOLE_RADIUS);
    }
  }
  // Center brace holes for multi-subwoofer (gusset positions).
  // Skipped under flush mount — the gusset attaches to the Sub Mount Plate
  // instead, so its dowel holes appear there (see generateSubMountPlateDrillHoles).
  // Skipped for SUPB — the gusset doesn't touch the baffle on SUPB designs;
  // it's a free-standing column dowelled into the Top + Bottom panels via
  // generateSupbGussetDrillHoles.
  const isSUPB = enclosureConfiguration === 'Subs Up/Port Back';
  if (subCount > 1 && od > 0 && !isRecessed && !isSUPB) {
    const braceOffset = isSD(bs) ? 0.0205 : -0.0975;
    const xPositions = getSubwooferXPositions(width, od, subCount);
    const allYPositions = [bottomY, topY];
    if (extraHeight > 0) {
      const span = topY - bottomY;
      for (let i = 1; i <= extraHeight; i++) {
        allYPositions.push(bottomY + span * i / (extraHeight + 1));
      }
    }
    for (let i = 0; i < subCount - 1; i++) {
      // SUPB designs let the user shift the sub pattern on the top panel via
      // subwooferXOffset; the gusset (and therefore its dowel holes on the
      // baffle) follows the shift so it stays between the subs.
      const braceX = xOffset + (xPositions[i] + xPositions[i + 1]) / 2 + braceOffset + subwooferXOffset;
      for (const by of allYPositions) {
        entities += dxfCircle(layer, braceX, by, DRILL_HOLE_RADIUS);
      }
    }
  }
  return entities;
}

/** Generate drill holes for Sub Mount Plate (flush mount, multi-sub only).
 *  ONLY the gusset brace dowels — corner/edge dowels are skipped because the
 *  plate has no joinery to side panels (it's an interior glue-up part).
 *  X positions reference the structural baffle's width and shift left by the
 *  plate's gap so the dowels align with where the gusset physically lands
 *  in the assembled enclosure. Layer follows the plate's own material and
 *  thickness: thick stock for RD/HD, thin stock for SD. */
function generateSubMountPlateDrillHoles(entities: string, plateWidth: number, baffleWidth: number, height: number, bs: string | undefined, subCount: number, od: number, extraHeight: number, isBirch: boolean): string {
  if (subCount <= 1 || od <= 0) return entities;
  // Plate is thick for RD/HD and thin for SD, using Birch or MDF layer names.
  const layer = `8MM_DRILL__5_DEEP_${matToken(isBirch, isHD(bs) || isRD(bs))}`;
  const bottomY = CORNER_INSET;
  const topY = height - CORNER_INSET;
  const allYPositions = [bottomY, topY];
  if (extraHeight > 0) {
    const span = topY - bottomY;
    for (let i = 1; i <= extraHeight; i++) {
      allYPositions.push(bottomY + span * i / (extraHeight + 1));
    }
  }
  const braceOffset = isSD(bs) ? 0.0205 : -0.0975;
  // Compute brace X using the BAFFLE's width so positions align with the
  // baffle's recess holes in world space, then shift left by the plate's
  // gap (each side) to convert into plate-local coordinates.
  const xPositions = getSubwooferXPositions(baffleWidth, od, subCount);
  const plateGapX = Math.max(0, (baffleWidth - plateWidth) / 2);
  for (let i = 0; i < subCount - 1; i++) {
    const braceX = ((xPositions[i] + xPositions[i + 1]) / 2) + braceOffset - plateGapX;
    for (const by of allYPositions) {
      entities += dxfCircle(layer, braceX, by, DRILL_HOLE_RADIUS);
    }
  }
  return entities;
}

/**
 * Generate gusset brace dowel holes on the Top OR Bottom panel for SUPB
 * multi-sub designs. The gusset is a free-standing 5"-deep × internalHeight-tall
 * column that hangs between Top and Bottom panels, sitting in the chamber
 * directly under each pair of adjacent subs. Two dowels per panel-edge of
 * the gusset (front & back of its 5" depth, 1.25" `CORNER_INSET` from each
 * end), so 4 dowels per gusset total (2 in Top + 2 in Bottom).
 *
 * X positions: chamber-frame midpoint between adjacent sub centers, in
 * world coords. The Top panel DXF is X-mirrored (drawX = panelW − worldX);
 * the Bottom panel DXF is not. The caller passes `mirrorX` so this helper
 * stays panel-agnostic.
 *
 * Y position: panel-local depth coordinate `subY` (the same Y the sub
 * cutouts use on the Top panel, so the gusset sits directly under the
 * subs even when the operator slides the pattern with `subwooferYOffset`).
 *
 * Note: the underlying X axis the SUPB sub cutouts use is the chamber
 * frame, not the baffle frame, so this fixes the ~0.05" misalignment that
 * existed when the gusset's brace dowels were drilled into the baffle in
 * baffle-frame coords.
 */
function generateSupbGussetDrillHoles(
  entities: string,
  panelW: number,
  bs: string | undefined,
  isTop: boolean,
  worldGussets: Array<{ x: number; y: number }>,
  enclosureConfiguration: string | undefined,
  isBirch: boolean,
): string {
  if (worldGussets.length === 0) return entities;
  const layer = getDrillLayer(bs, isTop ? 'Top' : 'Bottom', enclosureConfiguration, isBirch);
  // Top panel mirrors X; Bottom does not (matches generateBottomTopDrillHoles).
  const mx = (x: number) => isTop ? panelW - x : x;
  // Two dowels per gusset along its 5" depth: 1.25" inset from each end of
  // the gusset, centered on the sub Y. Net spacing = 2.5" between dowels.
  const halfGussetSpacing = 1.25; // CORNER_INSET equivalent for the 5" gusset
  for (const gusset of worldGussets) {
    const xDraw = mx(gusset.x);
    const yPositions = [gusset.y - halfGussetSpacing, gusset.y + halfGussetSpacing];
    for (const y of yPositions) {
      entities += dxfCircle(layer, xDraw, y, DRILL_HOLE_RADIUS);
    }
  }
  return entities;
}

/** Generate drill holes for Port 2: right edge only + HeightExtraHoles */
function generatePort2DrillHoles(entities: string, width: number, height: number, bs: string | undefined, yOffset: number, extraHeight: number, enclosureConfiguration: string | undefined, isBirch: boolean): string {
  const layer = getDrillLayer(bs, 'Port Piece 2', enclosureConfiguration, isBirch);
  const rightX = width - EDGE_INSET;
  const bottomY = CORNER_INSET + yOffset;
  const topY = height - CORNER_INSET + yOffset;
  // Corner holes
  entities += dxfCircle(layer, rightX, bottomY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, rightX, topY, DRILL_HOLE_RADIUS);
  // HeightExtraHoles on right edge
  if (extraHeight > 0) {
    const span = topY - bottomY;
    for (let i = 1; i <= extraHeight; i++) {
      entities += dxfCircle(layer, rightX, bottomY + span * i / (extraHeight + 1), DRILL_HOLE_RADIUS);
    }
  }
  return entities;
}

// ─── Build-strength-dependent drill Y offsets (matching desktop DrillHoleGenerator) ──
// These values define where side panel dowel holes align with top/bottom panels.
// They account for material thickness + mill-down groove geometry. The desktop
// stored the default 0.01" glue clearance inside numeric literals; this engine
// derives it so cut-list sizing, DXF placement, guides, and ACC programs stay
// aligned when the operator changes Glue Tolerance or measured stock values.
//
// Inset anatomy (corner-relative values are CORNER_INSET 1.25 + the edge inset):
//   Birch 18mm milled mate: 0.709 − 0.034 mill relief + 0.01 glue ≈ 0.68 → 1.93
//   Birch 24mm milled mate: 0.945 − 0.034 mill relief + 0.01 glue ≈ 0.92 → 2.17
//   MDF 3/4" mate:  0.75 + 0.01 glue = 0.76 → 2.01   (MDF has NO mill-down relief)
//   MDF 1" mate:    1.00 + 0.01 glue = 1.01 → 2.26
// The desktop DrillHoleGenerator's MDF branches use exactly 2.01/2.26/0.76/1.01
// where they exist (SD/RD right side, RD single-port left, RD-SUPB/RD-SBPB/HD
// yOffset). Where the desktop OMITTED an MDF branch (SD yOffset, SD single-port
// left, all HD side holes) it silently reused the Birch constant — field
// measurement on exported MDF panels confirmed those insets are wrong, so the
// web engine completes the matrix from first principles (true thickness + the
// configured glue clearance) instead of reproducing the gap.

function resolveGlueTolerance(value: number | undefined): number {
  if (value === undefined) return DEFAULT_GLUE_TOLERANCE;
  if (!Number.isFinite(value) || value < 0) {
    throw new Error(`Glue tolerance must be a finite, non-negative number; received ${String(value)}`);
  }
  return value;
}

/** Thickness consumed by a mating edge before the fixed corner inset.
 *  Birch mates use their milled C1/C2 dimensions; MDF is never milled and
 *  therefore uses full-stock D1/D2 dimensions. */
function getMateOffset(
  isBirch: boolean,
  isThick: boolean,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance?: number,
): number {
  const mateThickness = isBirch
    ? (isThick ? config.C2 : config.C1)
    : (isThick ? config.D2 : config.D1);
  if (!Number.isFinite(mateThickness) || mateThickness <= 0) {
    throw new Error(`Invalid ${isBirch ? 'Birch' : 'MDF'} mate thickness: ${String(mateThickness)}`);
  }
  return mateThickness + resolveGlueTolerance(glueTolerance);
}

function getCornerMateInset(
  isBirch: boolean,
  isThick: boolean,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance?: number,
): number {
  return CORNER_INSET + getMateOffset(isBirch, isThick, config, glueTolerance);
}

/** Right side hole Y insets from bottom/top edges (same for all configs) */
function getRightSideInsets(
  bs: string | undefined,
  isBirch: boolean,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance?: number,
): { bottomInset: number; topInset: number } {
  // HD: back panel is 24mm/1". Desktop had no MDF branch here (used 2.17);
  // 2.26 = 1.25 + 1.01 completes it (1" true MDF + 0.01 glue, no mill relief).
  if (isHD(bs)) return { bottomInset: CORNER_INSET, topInset: getCornerMateInset(isBirch, true, config, glueTolerance) };
  // SD and RD have same right-side values
  return { bottomInset: CORNER_INSET, topInset: getCornerMateInset(isBirch, false, config, glueTolerance) };
}

/** Left side hole Y insets — differs for single vs dual port due to port connection geometry.
 *  bottomInset = front-edge inset, anchored to the structural BAFFLE thickness:
 *    18mm baffle → 1.93" Birch / 3/4" MDF → 2.01;
 *    24mm baffle → 2.17" Birch / 1" MDF → 2.26.
 *  topInset = back-edge inset, anchored to the BACK PANEL thickness:
 *    18mm back → 1.93" Birch / 2.01 MDF; 24mm back (HD only) → 2.17" Birch / 2.26 MDF.
 *  Flush mount (SBPB only) thins the structural baffle to 18mm/3/4" regardless
 *  of duty, so bottomInset drops to the thin-mate value for RD-SBPB and
 *  HD-flush. Top inset is unaffected because flush mount doesn't change the
 *  back panel.
 *  Desktop-parity note: the desktop's GetSideHoleYPositions has MDF branches
 *  only for RD (2.26/2.01); its SD single-port (1.93) and HD (2.17) branches
 *  had no MDF variant — completed here from first principles (see block
 *  comment above getRightSideInsets). */
function getLeftSideInsets(
  bs: string | undefined,
  isBirch: boolean,
  isDualPort: boolean,
  isRecessed: boolean = false,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance?: number,
): { bottomInset: number; topInset: number } {
  // Dual port: left side mirrors right side (symmetric)
  if (isDualPort) return getRightSideInsets(bs, isBirch, config, glueTolerance);
  // Flush mount overrides the duty-derived bottom inset since the structural
  // baffle is genuinely 18mm (3/4" MDF) regardless of duty. Top inset still
  // follows the back panel's actual thickness.
  if (isRecessed) {
    if (isHD(bs)) return {
      bottomInset: getCornerMateInset(isBirch, false, config, glueTolerance),
      topInset: getCornerMateInset(isBirch, true, config, glueTolerance),
    };
    const thinInset = getCornerMateInset(isBirch, false, config, glueTolerance);
    return { bottomInset: thinInset, topInset: thinInset };
  }
  // Single port: left side has different offsets due to Side Left meeting port panel
  if (isHD(bs)) {
    const thickInset = getCornerMateInset(isBirch, true, config, glueTolerance);
    return { bottomInset: thickInset, topInset: thickInset };
  }
  if (isRD(bs)) return {
    bottomInset: getCornerMateInset(isBirch, true, config, glueTolerance),
    topInset: getCornerMateInset(isBirch, false, config, glueTolerance),
  };
  // SD
  const thinInset = getCornerMateInset(isBirch, false, config, glueTolerance);
  return { bottomInset: thinInset, topInset: thinInset };
}

/** Port 1/Port 2 base Y offsets on Bottom/Top panels — must match
 *  getGuideYOffset since these positions are anchored to where the side
 *  panels actually meet the back face of the structural baffle. Flush
 *  mount (SBPB only) thins the structural baffle to 18mm (3/4" MDF)
 *  regardless of duty, so the offset drops to the thin-mate value
 *  (0.68 Birch / 0.76 MDF).
 *  Desktop-parity note: the desktop's SD branch is a bare 0.68 with no MDF
 *  variant even though its RD-SUPB branch (same 18mm baffle) is 0.76 for
 *  MDF — completed here from first principles (0.75 + 0.01 glue = 0.76,
 *  no mill relief on MDF), confirmed by field measurement. */
function getPortBaseOffset(
  bs: string | undefined,
  isBirch: boolean,
  isSUPB: boolean,
  isRecessed: boolean = false,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance?: number,
): number {
  if (isRecessed && !isSUPB) return getMateOffset(isBirch, false, config, glueTolerance);
  if (isSD(bs)) return getMateOffset(isBirch, false, config, glueTolerance);
  if (isRD(bs) && isSUPB) return getMateOffset(isBirch, false, config, glueTolerance);
  if (isRD(bs)) return getMateOffset(isBirch, true, config, glueTolerance);
  // HD
  return getMateOffset(isBirch, true, config, glueTolerance);
}

/** Get extra hole counts from options, falling back to desktop reset defaults.
 *  Desktop defaults: BottomExtraHoles(left)=1, BottomRightExtraHoles=1,
 *  BottomBackExtraHoles=2, BottomFrontExtraHoles=2 */
function getExtraHoleCounts(opts: PartDxfOptions): {
  back: number; front: number; right: number; left: number;
} {
  return {
    back: opts.extraHolesBack ?? 2,   // desktop default BottomBackExtraHoles = 2
    front: opts.extraHolesFront ?? 2, // desktop default BottomFrontExtraHoles = 2
    right: opts.extraHolesRight ?? 1, // desktop default BottomRightExtraHoles = 1
    left: opts.extraHolesLeft ?? 1,   // desktop default BottomExtraHoles (left) = 1
  };
}

function numberedPortPiece(partName: string): number | null {
  const match = /^Port Piece (\d+)$/.exec(partName);
  if (!match) return null;
  const value = Number(match[1]);
  return Number.isSafeInteger(value) && value > 0 ? value : null;
}

interface LabyrinthDividerPlacement {
  partNumber: number;
  anchoredAt: 'front' | 'back';
  /** Right face of the divider in the unmirrored Bottom-panel coordinate frame. */
  xRight: number;
  yStart: number;
  length: number;
}

/**
 * Resolve the manufactured labyrinth-divider rectangles on a Top/Bottom panel.
 * This is the single placement source for drill holes, guide rectangles, the
 * assembly-reference DXF, and the human-readable review manifest.
 */
function labyrinthDividerPlacements(
  panelWidth: number,
  panelDepth: number,
  opts: PartDxfOptions,
): LabyrinthDividerPlacement[] {
  const layout = opts.calc?.labyrinthPort;
  if (!layout?.active || !opts.cutList) return [];

  const isBirch = opts.isBirchPly !== false;
  const frontMate = getPortBaseOffset(
    opts.buildStrength,
    isBirch,
    opts.enclosureConfiguration === 'Subs Up/Port Back',
    !!opts.recessedMounting,
    opts.materialConfig,
    opts.glueTolerance,
  );
  // Back is heavy only on HD enclosures. RD's thick panel is the Baffle
  // (SBPB/SUPU) or Top (SUPB), so its Back still uses the thin mate.
  const backMate = getMateOffset(
    isBirch,
    isHD(opts.buildStrength),
    opts.materialConfig,
    opts.glueTolerance,
  );
  const baffleWidth = opts.baffleWidth || panelWidth;

  return layout.panels.map((panel) => {
    const part = opts.cutList!.find(item => item.partName === `Port Piece ${panel.partNumber}`);
    const fallbackPort1 = opts.cutList!.find(item => item.partName === 'Port Piece 1');
    const length = part?.width
      ?? (fallbackPort1 ? fallbackPort1.width * panel.fullLengthFraction : 0);
    const xRight = baffleWidth - panel.laneIndex * layout.lanePitch;
    const yStart = panel.anchoredAt === 'front'
      ? frontMate
      : panelDepth - backMate - length;
    return {
      partNumber: panel.partNumber,
      anchoredAt: panel.anchoredAt,
      xRight,
      yStart,
      length,
    };
  }).filter(placement =>
    placement.length > 0
    && placement.xRight > 0
    && placement.xRight <= panelWidth + 1e-6
    && placement.yStart >= -1e-6
    && placement.yStart + placement.length <= panelDepth + 1e-6
  );
}

/** Two 1.25"-inset alignment dowels, or one centered dowel on a short final divider. */
function dividerAlignmentOffsets(length: number): number[] {
  if (!Number.isFinite(length) || length <= 0) return [];
  if (length <= CORNER_INSET * 2) return [length / 2];
  return [CORNER_INSET, length - CORNER_INSET];
}

/** Generate drill holes for Bottom/Top panels with build-strength-dependent positioning.
 *  Matches desktop DrillHoleGenerator: side holes use joint-specific Y offsets,
 *  extra holes evenly spaced between corners, port holes, full X mirroring for Top. */
function generateBottomTopDrillHoles(entities: string, width: number, height: number, bs: string | undefined, isTop: boolean, opts: PartDxfOptions): string {
  const isBirch = opts.isBirchPly !== false;
  const layer = getDrillLayer(bs, isTop ? 'Top' : 'Bottom', opts.enclosureConfiguration, isBirch);
  const isDualPort = opts.portQuantity === 'Dual';
  const isSUPB = opts.enclosureConfiguration === 'Subs Up/Port Back';

  // Desktop mirrors ALL X coordinates on Top panel: drawX = width - x
  const mx = (x: number) => isTop ? width - x : x;

  // Build-strength-dependent Y insets
  const rightInsets = getRightSideInsets(bs, isBirch, opts.materialConfig, opts.glueTolerance);
  const isRecessed = !!opts.recessedMounting;
  const leftInsets = getLeftSideInsets(bs, isBirch, isDualPort, isRecessed, opts.materialConfig, opts.glueTolerance);
  const extras = getExtraHoleCounts(opts);

  // --- Right side holes (X = width - EDGE_INSET) ---
  const rightX = mx(width - EDGE_INSET);
  const rightBottomY = rightInsets.bottomInset;
  const rightTopY = height - rightInsets.topInset;
  entities += dxfCircle(layer, rightX, rightBottomY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, rightX, rightTopY, DRILL_HOLE_RADIUS);
  // Extra right side holes
  if (extras.right > 0) {
    const span = rightTopY - rightBottomY;
    for (let i = 1; i <= extras.right; i++) {
      entities += dxfCircle(layer, rightX, rightBottomY + span * i / (extras.right + 1), DRILL_HOLE_RADIUS);
    }
  }

  // --- Left side holes (X = EDGE_INSET) ---
  const leftX = mx(EDGE_INSET);
  const leftBottomY = leftInsets.bottomInset;
  const leftTopY = height - leftInsets.topInset;
  entities += dxfCircle(layer, leftX, leftBottomY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, leftX, leftTopY, DRILL_HOLE_RADIUS);
  // Extra left side holes
  if (extras.left > 0) {
    const span = leftTopY - leftBottomY;
    for (let i = 1; i <= extras.left; i++) {
      entities += dxfCircle(layer, leftX, leftBottomY + span * i / (extras.left + 1), DRILL_HOLE_RADIUS);
    }
  }

  // --- Back edge holes (Y = height - EDGE_INSET) ---
  const backY = height - EDGE_INSET;
  entities += dxfCircle(layer, mx(CORNER_INSET), backY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, mx(width - CORNER_INSET), backY, DRILL_HOLE_RADIUS);
  // Extra back edge holes
  if (extras.back > 0) {
    const backSpan = (width - 2 * CORNER_INSET);
    for (let i = 1; i <= extras.back; i++) {
      entities += dxfCircle(layer, mx(CORNER_INSET + backSpan * i / (extras.back + 1)), backY, DRILL_HOLE_RADIUS);
    }
  }

  // --- Baffle offset for Dual Port HD (desktop: baffleOffset = B2 + portOpeningWidth) ---
  // This shifts front edge and port holes to account for the left port area
  const bw = opts.baffleWidth || width;
  const pw = opts.portWidth || 0;
  let baffleOffset = 0;
  if (isDualPort && isHD(bs)) {
    const b2 = opts.heavyThickness || fallbackHeavyIn(isBirch);
    baffleOffset = b2 + pw;
  }

  // --- Front (baffle) edge holes (Y = EDGE_INSET) ---
  const frontY = EDGE_INSET;
  entities += dxfCircle(layer, mx(baffleOffset + CORNER_INSET), frontY, DRILL_HOLE_RADIUS);
  entities += dxfCircle(layer, mx(baffleOffset + bw - CORNER_INSET), frontY, DRILL_HOLE_RADIUS);
  // Extra front edge holes
  if (extras.front > 0) {
    const frontSpan = (bw - 2 * CORNER_INSET);
    for (let i = 1; i <= extras.front; i++) {
      entities += dxfCircle(layer, mx(baffleOffset + CORNER_INSET + frontSpan * i / (extras.front + 1)), frontY, DRILL_HOLE_RADIUS);
    }
  }

  // --- Port 1 hole(s) on Bottom/Top panel ---
  // Desktop uses port1Width (cut list Port Piece 1 width) for Y positioning.
  // Desktop has no bw<width guard — port holes are generated whenever port1Width > 0.
  const p1w = opts.port1PartWidth || pw; // fallback to portWidth if cut list width not provided
  if (p1w > 0) {
    const portBase = getPortBaseOffset(bs, isBirch, isSUPB, !!opts.recessedMounting, opts.materialConfig, opts.glueTolerance);
    const port1Y = (p1w / 2) + portBase;
    if (!isDualPort) {
      // Single port: one hole at baffle right edge
      entities += dxfCircle(layer, mx(baffleOffset + bw - EDGE_INSET), port1Y, DRILL_HOLE_RADIUS);
    } else {
      // Dual port: two holes at baffle left and right edges
      entities += dxfCircle(layer, mx(baffleOffset + EDGE_INSET), port1Y, DRILL_HOLE_RADIUS);
      entities += dxfCircle(layer, mx(baffleOffset + bw - EDGE_INSET), port1Y, DRILL_HOLE_RADIUS);
    }
  }

  // --- Port 2 / labyrinth divider hole(s) on Bottom/Top panel ---
  // Desktop: X positions are WITHIN the baffle area (bw - CORNER_INSET), NOT beyond it.
  // Desktop: port2Y = port1Width + portBase + port2VerticalOffset + 0.375
  const labyrinthDividers = labyrinthDividerPlacements(width, height, opts).filter(panel => panel.partNumber >= 2);
  const p2w = opts.port2PartWidth || pw; // fallback to portWidth if not provided
  if (labyrinthDividers.length > 0) {
    // Every PP2+ divider receives the same two-point Top/Bottom alignment
    // convention. The last shortened divider falls back to one centered dowel
    // when it cannot physically hold the standard 1.25" inset pair.
    for (const divider of labyrinthDividers) {
      const drillX = mx(divider.xRight - EDGE_INSET);
      for (const along of dividerAlignmentOffsets(divider.length)) {
        entities += dxfCircle(layer, drillX, divider.yStart + along, DRILL_HOLE_RADIUS);
      }
    }
  } else if (p1w > 0) {
    const portBase = getPortBaseOffset(bs, isBirch, isSUPB, !!opts.recessedMounting, opts.materialConfig, opts.glueTolerance);
    const port2VOffset = opts.port2VerticalOffset || 0;
    const port2Y = p1w + portBase + port2VOffset + EDGE_INSET;
    // Desktop: holes at (bw - 1.25) and (bw - port2Width + 1.25) — within baffle right area
    entities += dxfCircle(layer, mx(baffleOffset + bw - CORNER_INSET), port2Y, DRILL_HOLE_RADIUS);
    entities += dxfCircle(layer, mx(baffleOffset + bw - p2w + CORNER_INSET), port2Y, DRILL_HOLE_RADIUS);
  }

  return entities;
}

// ─── Terminal Cup Cutout ──────────────────────────────────────────────────────

const TERMINAL_WIDTH = 4.5;
const TERMINAL_HEIGHT = 2.75;
const TERMINAL_CORNER_RADIUS = 0.375;
const TERMINAL_BOTTOM_OFFSET = 2.125;
const TERMINAL_MOUNT_HOLE_DIAMETER = 0.25;

/** Generate terminal cup cutout: rounded rectangle + 2 mounting drill holes.
 *  Placed on Back (dual port default) or Side Left (single port default).
 *  xOffset shifts the cutout horizontally from the panel's center; default 0
 *  preserves today's centered placement. yOffset is the part's drawing
 *  origin offset (typically 0).
 *  rotated=true draws the cup 90° CW on the panel (W and H swapped, mounting
 *  holes above and below instead of left and right) — used for SUPP designs
 *  where the panel itself rotates 90° in the viewer, so this counter-rotation
 *  keeps the cup looking landscape in the rendered view. */
function generateTerminalCutout(entities: string, partWidth: number, partHeight: number, bs: string | undefined, yOffset: number, xOffset: number, rotated: boolean, isBirch: boolean): string {
  const cutInsideLayer = getTerminalCutInsideLayer(bs, isBirch);  // HD=thick, SD/RD=thin
  const drillLayer = getDrill25Layer(bs, isBirch);
  const cr = TERMINAL_CORNER_RADIUS;

  // Cup body footprint — swapped when rotated.
  const cupW = rotated ? TERMINAL_HEIGHT : TERMINAL_WIDTH;
  const cupH = rotated ? TERMINAL_WIDTH : TERMINAL_HEIGHT;

  const rectX = (partWidth - cupW) / 2 + xOffset;
  const rectY = TERMINAL_BOTTOM_OFFSET + yOffset;
  const left = rectX;
  const right = rectX + cupW;
  const bottom = rectY;
  const top = rectY + cupH;
  // Straight edges (shortened by corner radius)
  entities += dxfLine(cutInsideLayer, left + cr, bottom, right - cr, bottom);  // Bottom
  entities += dxfLine(cutInsideLayer, right, bottom + cr, right, top - cr);    // Right
  entities += dxfLine(cutInsideLayer, right - cr, top, left + cr, top);        // Top
  entities += dxfLine(cutInsideLayer, left, top - cr, left, bottom + cr);      // Left
  // Corner arcs
  entities += dxfArc(cutInsideLayer, left + cr, bottom + cr, cr, 180, 270);    // Bottom-Left
  entities += dxfArc(cutInsideLayer, right - cr, bottom + cr, cr, 270, 360);   // Bottom-Right
  entities += dxfArc(cutInsideLayer, right - cr, top - cr, cr, 0, 90);         // Top-Right
  entities += dxfArc(cutInsideLayer, left + cr, top - cr, cr, 90, 180);        // Top-Left

  // Mounting drill holes — orientation depends on cup rotation.
  if (rotated) {
    // Holes ABOVE and BELOW the cup body, both at the cup's horizontal centerline.
    const holeX = rectX + cupW / 2;
    entities += dxfCircle(drillLayer, holeX, top + 0.5, TERMINAL_MOUNT_HOLE_DIAMETER / 2);
    entities += dxfCircle(drillLayer, holeX, bottom - 0.5, TERMINAL_MOUNT_HOLE_DIAMETER / 2);
  } else {
    // Original behavior: holes LEFT and RIGHT of the cup body, near the top edge.
    const holeY = top - 0.5;
    entities += dxfCircle(drillLayer, rectX - 0.5, holeY, TERMINAL_MOUNT_HOLE_DIAMETER / 2);
    entities += dxfCircle(drillLayer, rectX + cupW + 0.5, holeY, TERMINAL_MOUNT_HOLE_DIAMETER / 2);
  }
  return entities;
}

// ─── Acrylic Window Cutout (V1) ──────────────────────────────────────────────
//
// Adds a rounded-rectangle cutout to the host panel + a perimeter ring of
// screw pilot holes. The acrylic plate that covers the cutout is emitted
// as a separate `Acrylic-{prefix}.dxf` file (see emitAcrylicCompanionDxf
// further down).
//
// Cutout center is panel-local: (panelW/2 + xOff, panelH/2 + yOff). The
// host panel's perimeter is the standard `dxfRect` already drawn by
// generatePartDxf; we just punch the rounded rectangle inside it.
//
// Screw pilot ring sits inboard of the plate edges by `WINDOW_SCREW_INSET`
// inches, equivalently outboard of the cutout edges by
// (WINDOW_PLATE_OVERHANG − WINDOW_SCREW_INSET). On a 12" plate with the
// template's numbers the ring lands at 10.75" (0.625" inside both
// edges) and the wood pilots match the same X/Y so screws pass through
// the plate's overhang zone directly into the wood underneath.

const WINDOW_PLATE_OVERHANG = 1.25;    // per side — 12 plate ↔ 9.5 cutout. MUST match acrylic-window.ts.
const WINDOW_SCREW_INSET    = 0.625;   // screw inset from plate edge (template ring = 10.75)
const WINDOW_SCREW_DIAMETER = 0.375;   // 3/8" — accepts an M8 T-nut / threaded insert
const WINDOW_SCREW_TARGET_SPACING = 5.0; // along each side; rounded to even count

/** Place screws around a rectangular ring (corners + auto-spaced edges).
 *  `screwInset` shrinks the ring inward from the rect; e.g. for the wood
 *  pilots `screwInset = -WINDOW_SCREW_INSET` (ring sits OUTSIDE the cutout
 *  at WINDOW_PLATE_OVERHANG - WINDOW_SCREW_INSET = 0.25" outboard). For
 *  the acrylic plate it's WINDOW_SCREW_INSET (ring sits 0.25" inside). */
function addWindowScrewRing(
  entities: string,
  layer: string,
  ringRect: { x: number; y: number; w: number; h: number },
  targetSpacing = WINDOW_SCREW_TARGET_SPACING,
): string {
  const r = WINDOW_SCREW_DIAMETER / 2;
  const corners: Array<[number, number]> = [
    [ringRect.x,            ringRect.y],
    [ringRect.x + ringRect.w, ringRect.y],
    [ringRect.x + ringRect.w, ringRect.y + ringRect.h],
    [ringRect.x,            ringRect.y + ringRect.h],
  ];
  for (const [cx, cy] of corners) {
    entities += dxfCircle(layer, cx, cy, r);
  }
  // Mid-edge screws — count chosen so spacing is ≤ targetSpacing.
  const placeAlong = (
    x1: number, y1: number, x2: number, y2: number,
  ): void => {
    const len = Math.hypot(x2 - x1, y2 - y1);
    const n = Math.max(0, Math.ceil(len / targetSpacing) - 1);
    for (let i = 1; i <= n; i++) {
      const t = i / (n + 1);
      const mx = x1 + t * (x2 - x1);
      const my = y1 + t * (y2 - y1);
      entities += dxfCircle(layer, mx, my, r);
    }
  };
  placeAlong(corners[0][0], corners[0][1], corners[1][0], corners[1][1]); // bottom
  placeAlong(corners[1][0], corners[1][1], corners[2][0], corners[2][1]); // right
  placeAlong(corners[2][0], corners[2][1], corners[3][0], corners[3][1]); // top
  placeAlong(corners[3][0], corners[3][1], corners[0][0], corners[0][1]); // left
  return entities;
}

/** Draw a rounded rectangle path as 4 lines + 4 arcs on the given layer. */
function addRoundedRect(
  entities: string,
  layer: string,
  x: number, y: number, w: number, h: number, cr: number,
): string {
  const left = x, right = x + w, bottom = y, top = y + h;
  // Clamp corner radius so it never exceeds half the smaller side.
  const r = Math.max(0, Math.min(cr, Math.min(w, h) / 2 - 0.001));

  // Emit as ONE closed POLYLINE with bulged vertices — laser/water-jet
  // vendors (and CNC routers) want a single continuous tool path, not
  // line + arc fragments that have to be stitched in CAM. Bulge for a
  // 90° CCW arc = tan(90/4) = tan(22.5°) = 0.4142.
  const ARC_90 = Math.tan(Math.PI / 8); // ≈ 0.4142

  if (r > 0.001) {
    // CCW traversal around the rect, starting at the bottom edge's
    // left-side arc-end. 8 vertices, 4 line segments + 4 arc segments.
    const verts = [
      { x: left + r,  y: bottom,    bulge: 0 },       // → line along bottom
      { x: right - r, y: bottom,    bulge: ARC_90 },  // → bottom-right arc (CCW)
      { x: right,     y: bottom + r, bulge: 0 },      // → line up right edge
      { x: right,     y: top - r,    bulge: ARC_90 }, // → top-right arc
      { x: right - r, y: top,        bulge: 0 },      // → line along top
      { x: left + r,  y: top,        bulge: ARC_90 }, // → top-left arc
      { x: left,      y: top - r,    bulge: 0 },      // → line down left edge
      { x: left,      y: bottom + r, bulge: ARC_90 }, // → bottom-left arc back to first vertex
    ];
    return entities + dxfPolylineWithBulges(layer, verts);
  }

  // Sharp corners — 4-vertex closed polyline.
  const sharp = [
    { x: left,  y: bottom, bulge: 0 },
    { x: right, y: bottom, bulge: 0 },
    { x: right, y: top,    bulge: 0 },
    { x: left,  y: top,    bulge: 0 },
  ];
  return entities + dxfPolylineWithBulges(layer, sharp);
}

/** Cut the acrylic window into the host panel and add the screw pilot
 *  ring outboard of it. Cutout dimensions + offsets must match what the
 *  acrylic-window helpers report so the wood and acrylic DXFs align. */
function generateAcrylicWindowCutout(
  entities: string,
  partWidth: number,
  partHeight: number,
  cutInsideLayer: string,
  drillLayer: string,
  windowW: number,
  windowH: number,
  xOffsetFromCenter: number,
  yOffsetFromCenter: number,
  cornerRadius: number,
  mirrorX: boolean = false,
): string {
  // X-mirror the cutout for the Top panel — the rest of the Top panel DXF
  // (drill holes, SUPB sub cutouts, guides) is rendered with chamber-side
  // up, so the saved windowXOffset (in box-world frame) needs to flip on
  // the X axis to land in the right place on the DXF. Y axis is the same
  // direction in both frames so it doesn't need flipping.
  const cx = mirrorX
    ? partWidth / 2 - xOffsetFromCenter
    : partWidth / 2 + xOffsetFromCenter;
  const cy = partHeight / 2 + yOffsetFromCenter;
  const cutoutX = cx - windowW / 2;
  const cutoutY = cy - windowH / 2;

  // 1. The cutout itself (rounded rectangle on the cut-inside layer).
  entities = addRoundedRect(entities, cutInsideLayer, cutoutX, cutoutY, windowW, windowH, cornerRadius);

  // 2. Screw pilot ring — outboard of the cutout edges by
  //    WINDOW_PLATE_OVERHANG − WINDOW_SCREW_INSET = 0.625". Screws pass
  //    THROUGH the plate's overhang (the part not over the cutout) into
  //    the wood underneath. For a 12" plate / 9.5" cutout this lands the
  //    ring at 10.75" — matches the operator's plexi template DXF.
  const ringInset = WINDOW_PLATE_OVERHANG - WINDOW_SCREW_INSET;
  entities = addWindowScrewRing(
    entities, drillLayer,
    {
      x: cutoutX - ringInset,
      y: cutoutY - ringInset,
      w: windowW + 2 * ringInset,
      h: windowH + 2 * ringInset,
    },
  );
  return entities;
}

/** Plate-to-cutout overhang per side (inches). Must match
 *  `WINDOW_PLATE_OVERHANG_PER_SIDE` in `acrylic-window.ts` — duplicated here
 *  so the DXF generator doesn't reach into the higher-level helper for a
 *  constant during the build. 12×12 plate ↔ 9.5×9.5 cutout. */
const WINDOW_PLATE_OVERHANG_PER_SIDE = 1.25;

/** Resolve PLATE width × height (inches) from size + orientation. The wood
 *  cutout is `plate − 2 × overhang` per axis (see `cutoutFromPlate` below).
 *  This is a local copy of acrylic-window's logic to keep DXF generation
 *  self-contained — barrel-export ordering would otherwise become a concern. */
function resolveWindowDxfDimensions(
  size: '12x12' | '24x12' | 'custom' | undefined,
  orientation: 'landscape' | 'portrait' | undefined,
  customW: number | undefined,
  customH: number | undefined,
): { plateW: number; plateH: number; cutoutW: number; cutoutH: number } | null {
  if (!size) return null;
  let plateW = 12, plateH = 12;
  if (size === 'custom') {
    plateW = Number.isFinite(customW) && (customW as number) > 0 ? (customW as number) : 12;
    plateH = Number.isFinite(customH) && (customH as number) > 0 ? (customH as number) : 12;
  } else if (size === '24x12') {
    if (orientation === 'portrait') { plateW = 12; plateH = 24; }
    else                            { plateW = 24; plateH = 12; }
  }
  const cutoutW = Math.max(1, plateW - 2 * WINDOW_PLATE_OVERHANG_PER_SIDE);
  const cutoutH = Math.max(1, plateH - 2 * WINDOW_PLATE_OVERHANG_PER_SIDE);
  return { plateW, plateH, cutoutW, cutoutH };
}

/** Determine which part the window cutout lands on for the given config.
 *  Centralized so generatePartDxf and the companion-DXF emitter agree. */
function resolveWindowHostPart(
  enclosureConfiguration: string | undefined,
): 'Top' | 'Baffle' | 'Bottom' {
  if (enclosureConfiguration === 'Subs Up/Port Back') return 'Baffle';
  if (enclosureConfiguration === 'Subs Up/Port Up')   return 'Bottom';
  return 'Top';  // SBPB and any unknown config
}

/** Layers for the companion `Acrylic-{prefix}.dxf` file the laser/water-jet
 *  vendor cuts. Uses generic layer names not tied to any specific CAM
 *  preset — vendor will map them to their own cut profiles. */
const ACRYLIC_LAYERS: LayerDef[] = [
  { name: 'acrylic_outline', color: COLOR_BLUE },
  { name: 'acrylic_holes',   color: COLOR_RED },
];

/**
 * Build a standalone DXF for the acrylic plate. Takes the PLATE dimensions
 * directly (matching the operator's plexi template, where the size tier
 * names the plate, not the cutout). Includes:
 *
 *   - Plate outline (rounded rectangle, corner radius matches the wood
 *     cutout's radius extended outward by the overhang)
 *   - Screw clearance holes inset `WINDOW_SCREW_INSET` from each plate
 *     edge — matches the wood pilot ring once the plate is laid over the
 *     wood (screws pass through plate THEN into wood)
 *
 * Origin is the plate's bottom-left corner. No part-of-enclosure context
 * — the laser shop only sees the plate.
 */
function buildAcrylicCompanionDxf(
  plateW: number,
  plateH: number,
  cutoutCornerRadius: number,
): string {
  // Plate's outline corner radius matches the wood cutout's radius so the
  // visible plate and the hole below share the same corner profile. The
  // operator's plexi template DXF uses a single router-bit radius for
  // both (typically 1/8" — small consistent radius, not concentric arcs).
  const plateCR = cutoutCornerRadius;
  let entities = '';
  // 1. Plate outline.
  entities = addRoundedRect(entities, 'acrylic_outline', 0, 0, plateW, plateH, plateCR);
  // 2. Screw clearance holes — sit WINDOW_SCREW_INSET inboard of the plate
  //    edge (matches the wood pilot ring once the plate is laid over the
  //    wood). Slightly larger than the wood pilot diameter so the screw
  //    has clearance through the acrylic.
  const clearanceR = (WINDOW_SCREW_DIAMETER + 0.04) / 2;  // +1mm clearance over pilot
  // Build a lightweight sub-helper specific to this drill diameter.
  const corners: Array<[number, number]> = [
    [WINDOW_SCREW_INSET,            WINDOW_SCREW_INSET],
    [plateW - WINDOW_SCREW_INSET,   WINDOW_SCREW_INSET],
    [plateW - WINDOW_SCREW_INSET,   plateH - WINDOW_SCREW_INSET],
    [WINDOW_SCREW_INSET,            plateH - WINDOW_SCREW_INSET],
  ];
  for (const [cx, cy] of corners) {
    entities += dxfCircle('acrylic_holes', cx, cy, clearanceR);
  }
  const placeAlong = (
    x1: number, y1: number, x2: number, y2: number,
  ): void => {
    const len = Math.hypot(x2 - x1, y2 - y1);
    const n = Math.max(0, Math.ceil(len / WINDOW_SCREW_TARGET_SPACING) - 1);
    for (let i = 1; i <= n; i++) {
      const t = i / (n + 1);
      const mx = x1 + t * (x2 - x1);
      const my = y1 + t * (y2 - y1);
      entities += dxfCircle('acrylic_holes', mx, my, clearanceR);
    }
  };
  placeAlong(corners[0][0], corners[0][1], corners[1][0], corners[1][1]);
  placeAlong(corners[1][0], corners[1][1], corners[2][0], corners[2][1]);
  placeAlong(corners[2][0], corners[2][1], corners[3][0], corners[3][1]);
  placeAlong(corners[3][0], corners[3][1], corners[0][0], corners[0][1]);

  return buildDxfDocument(entities, ACRYLIC_LAYERS);
}

// ─── Guide Rectangle Generation ───────────────────────────────────────────────
// Matches desktop GuideRectangleGenerator + DrillHoleGenerator guide output.
// Guide rectangles show where adjacent parts connect (assembly reference marks).

const GUIDE_RECT_LAYER = 'Guides';
const GUIDE_HOLES_LAYER = 'Guides_Holes';
const GUIDE_WIDTH = 0.375; // standard guide rectangle width

function labyrinthAnchorLayer(anchor: 'front' | 'back'): string {
  return `ASSEMBLY_${anchor.toUpperCase()}_ANCHOR`;
}

/** Non-machining chevron on the divider's anchored/mill-down edge. */
function addLabyrinthAnchorReference(
  entities: string,
  width: number,
  height: number,
  yOffset: number,
  anchor: 'front' | 'back',
): string {
  const layer = labyrinthAnchorLayer(anchor);
  const edgeX = width - 0.05;
  const tipX = Math.max(0.05, edgeX - 0.6);
  const centerY = yOffset + height / 2;
  const halfHeight = Math.min(0.4, Math.max(0.15, height / 8));
  entities += dxfLine(layer, edgeX, centerY - halfHeight, tipX, centerY);
  entities += dxfLine(layer, tipX, centerY, edgeX, centerY + halfHeight);
  entities += dxfLine(layer, edgeX, centerY - halfHeight, edgeX, centerY + halfHeight);
  return entities;
}

/** Add guide rectangles for Back or Baffle panels: left/right edge strips + 4 corner marks */
function addBackBaffleGuides(entities: string, width: number, height: number, xOffset: number, yOffset: number): string {
  const px = xOffset;
  const py = yOffset;
  // Left edge guide (full height)
  entities += dxfRect(GUIDE_RECT_LAYER, px, py, GUIDE_WIDTH, height);
  // Right edge guide (full height)
  entities += dxfRect(GUIDE_RECT_LAYER, px + width - GUIDE_WIDTH, py, GUIDE_WIDTH, height);
  // Corner marks (0.375 x 1.25)
  const ch = CORNER_INSET; // 1.25"
  entities += dxfRect(GUIDE_RECT_LAYER, px, py, GUIDE_WIDTH, ch);                           // Bottom-left
  entities += dxfRect(GUIDE_RECT_LAYER, px + width - GUIDE_WIDTH, py, GUIDE_WIDTH, ch);     // Bottom-right
  entities += dxfRect(GUIDE_RECT_LAYER, px, py + height - ch, GUIDE_WIDTH, ch);             // Top-left
  entities += dxfRect(GUIDE_RECT_LAYER, px + width - GUIDE_WIDTH, py + height - ch, GUIDE_WIDTH, ch); // Top-right
  return entities;
}

/** Add guide rectangles for Port 2: right edge strip + 2 corner marks */
function addPort2Guides(entities: string, width: number, height: number, yOffset: number): string {
  const px = 0;
  const py = yOffset;
  // Right edge guide
  entities += dxfRect(GUIDE_RECT_LAYER, px + width - GUIDE_WIDTH, py, GUIDE_WIDTH, height);
  // Right corner marks
  entities += dxfRect(GUIDE_RECT_LAYER, px + width - GUIDE_WIDTH, py, GUIDE_WIDTH, CORNER_INSET);
  entities += dxfRect(GUIDE_RECT_LAYER, px + width - GUIDE_WIDTH, py + height - CORNER_INSET, GUIDE_WIDTH, CORNER_INSET);
  return entities;
}

/** Build-specific yOffset for Bottom/Top guide rectangles (matches desktop GuideRectangleGenerator).
 *  These offsets position the Side Left and Port guides to account for the
 *  structural front baffle's thickness + mill-down joint geometry — they
 *  represent how far back from the panel's front edge the side/port walls
 *  actually start (= just past the back face of the structural baffle).
 *
 *  Flush mount (SBPB only): the structural baffle drops from 24mm → 18mm
 *  regardless of duty. The thinner baffle pushes the start position
 *  forward by ~0.24" (= B2 − B1), so we return the SD/RD-SUPB value
 *  instead of the RD-SBPB / HD value. Without this, guides land 0.24"
 *  too far back and Side Left / PP1 visibly miss the back face of the
 *  18mm structural baffle. */
function getGuideYOffset(
  bs: string | undefined,
  isBirch: boolean,
  isSUPB: boolean,
  isRecessed: boolean = false,
  config: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance?: number,
): number {
  // Guide rectangles and port drilling share the same reference face. Keep a
  // single formula so these two production outputs cannot drift apart again.
  return getPortBaseOffset(bs, isBirch, isSUPB, isRecessed, config, glueTolerance);
}

/** Add guide rectangles for Bottom/Top panels matching desktop GuideRectangleGenerator exactly.
 *  Desktop uses cut list part widths (port1PartWidth, port2PartWidth, sideLeftDepth, sideRightDepth)
 *  for guide dimensions — NOT the port opening width from design inputs.
 *  Desktop fully X-mirrors all guide positions for Top panel. */
function addBottomTopGuides(entities: string, width: number, height: number, opts: PartDxfOptions, isTop: boolean): string {
  const bw = opts.baffleWidth || 0;
  const isBirch = opts.isBirchPly !== false;
  const isSUPB = opts.enclosureConfiguration === 'Subs Up/Port Back';
  const isDualPort = opts.portQuantity === 'Dual';
  const isRecessed = !!opts.recessedMounting;
  const yOff = getGuideYOffset(
    opts.buildStrength,
    isBirch,
    isSUPB,
    isRecessed,
    opts.materialConfig,
    opts.glueTolerance,
  );
  const gw = GUIDE_WIDTH; // 0.375
  // Use cut list part widths for port guides (NOT port opening width)
  const p1w = opts.port1PartWidth || opts.portWidth || 0;
  const p2w = opts.port2PartWidth || opts.portWidth || 0;
  const port2VOffset = opts.port2VerticalOffset || 0;
  // Desktop: port2YPosition = yOffset + port1Width + port2VerticalOffset
  const port2YPos = yOff + p1w + port2VOffset;

  // Use cut list part dimensions for guide sizes (NOT computed approximations)
  const slDepth = opts.sideLeftDepth || (height - (opts.materialThickness || fallbackThinIn(isBirch)));
  const srDepth = opts.sideRightDepth || (height - (opts.materialThickness || fallbackThinIn(isBirch)));
  const bkWidth = opts.backWidth || width;
  const labyrinthDividers = labyrinthDividerPlacements(width, height, opts)
    .filter(panel => panel.partNumber >= 2);

  const addLabyrinthGuides = (mirrorX: boolean): void => {
    for (const divider of labyrinthDividers) {
      const x = mirrorX ? width - divider.xRight : divider.xRight - gw;
      entities += dxfRect(GUIDE_RECT_LAYER, x, divider.yStart, gw, divider.length);
      // A matching cyan drill-reference strip makes the two dowel locations
      // visually obvious when the _wG file is opened in VCarve.
      entities += dxfRect(GUIDE_HOLES_LAYER, x, divider.yStart, gw, divider.length);
    }
  };

  // --- BOTTOM PANEL guides (desktop AddBottomPanelGuideRectangles) ---
  if (!isTop) {
    // Baffle guide (bottom edge strip, width = baffleWidth)
    entities += dxfRect(GUIDE_RECT_LAYER, 0, 0, bw, gw);
    // Back guide (top edge strip, width = backWidth from cut list)
    entities += dxfRect(GUIDE_RECT_LAYER, 0, height - gw, bkWidth, gw);
    // Side Left (left edge, starts at yOff for single port, 0 for dual)
    // Height = sideLeftDepth from cut list (accounts for edge mill + glue tolerance)
    const leftY = isDualPort ? 0 : yOff;
    entities += dxfRect(GUIDE_RECT_LAYER, 0, leftY, gw, slDepth);
    // Side Right (right edge, full depth from 0)
    entities += dxfRect(GUIDE_RECT_LAYER, width - gw, 0, gw, srDepth);

    // Port 1 guide (single port: vertical strip at baffle right edge)
    if (p1w > 0) {
      if (!isDualPort) {
        entities += dxfRect(GUIDE_RECT_LAYER, bw - gw, yOff, gw, p1w);
      } else {
        // Dual port: two vertical strips at baffle left and right edges
        entities += dxfRect(GUIDE_RECT_LAYER, 0, yOff, gw, p1w);
        entities += dxfRect(GUIDE_RECT_LAYER, bw - gw, yOff, gw, p1w);
      }
    }
    // Port 2 guide (horizontal strip — desktop: X from bw-p2w to bw, Y at port2YPos)
    if (labyrinthDividers.length > 0) {
      addLabyrinthGuides(false);
    } else if (p2w > 0 && p1w > 0) {
      if (!isDualPort) {
        entities += dxfRect(GUIDE_RECT_LAYER, bw - p2w, port2YPos, p2w, gw);
      } else {
        // Dual port: two horizontal strips
        entities += dxfRect(GUIDE_RECT_LAYER, 0, port2YPos, p2w, gw);
        entities += dxfRect(GUIDE_RECT_LAYER, bw - p2w, port2YPos, p2w, gw);
      }
    }
  } else {
    // --- TOP PANEL guides (desktop AddTopPanelGuideRectangles — all X mirrored) ---
    // Back guide (at bottom edge on Top, width = backWidth from cut list)
    entities += dxfRect(GUIDE_RECT_LAYER, width - bkWidth, height - gw, bkWidth, gw);
    // Baffle guide (at top edge, X-mirrored: starts at width - bw)
    entities += dxfRect(GUIDE_RECT_LAYER, width - bw, 0, bw, gw);
    // Side Left (right edge on Top — mirrored from left)
    // Height = sideLeftDepth from cut list
    const leftY = isDualPort ? 0 : yOff;
    entities += dxfRect(GUIDE_RECT_LAYER, width - gw, leftY, gw, slDepth);
    // Side Right (left edge on Top — mirrored from right)
    entities += dxfRect(GUIDE_RECT_LAYER, 0, 0, gw, srDepth);

    // Port 1 guide (mirrored)
    if (p1w > 0) {
      if (!isDualPort) {
        // Single port: at width - bw (mirrored from bw - gw)
        entities += dxfRect(GUIDE_RECT_LAYER, width - bw, yOff, gw, p1w);
      } else {
        entities += dxfRect(GUIDE_RECT_LAYER, width - gw, yOff, gw, p1w);
        entities += dxfRect(GUIDE_RECT_LAYER, width - bw, yOff, gw, p1w);
      }
    }
    // Port 2 guide (mirrored — desktop: X from width-bw to width-bw+p2w)
    if (labyrinthDividers.length > 0) {
      addLabyrinthGuides(true);
    } else if (p2w > 0 && p1w > 0) {
      if (!isDualPort) {
        entities += dxfRect(GUIDE_RECT_LAYER, width - bw, port2YPos, p2w, gw);
      } else {
        entities += dxfRect(GUIDE_RECT_LAYER, width - p2w, port2YPos, p2w, gw);
        entities += dxfRect(GUIDE_RECT_LAYER, width - bw, port2YPos, p2w, gw);
      }
    }
  }

  return entities;
}

/** Add drill hole guide rectangles on Guides_Holes layer (matches desktop DrillHoleGenerator guides).
 *  Shows where adjacent panels connect — helps CNC operators identify drill areas.
 *  Desktop mirrors all X positions for Top panel. */
function addDrillHoleGuides(entities: string, width: number, height: number, opts: PartDxfOptions, isTop: boolean): string {
  const isBirch = opts.isBirchPly !== false;
  const isDualPort = opts.portQuantity === 'Dual';
  const isSUPB = opts.enclosureConfiguration === 'Subs Up/Port Back';
  const rightInsets = getRightSideInsets(opts.buildStrength, isBirch, opts.materialConfig, opts.glueTolerance);
  const leftInsets = getLeftSideInsets(
    opts.buildStrength,
    isBirch,
    isDualPort,
    !!opts.recessedMounting,
    opts.materialConfig,
    opts.glueTolerance,
  );
  const rw = GUIDE_WIDTH;
  const bw = opts.baffleWidth || width;

  if (!isTop) {
    // BOTTOM: Right side at right edge, Left side at left edge
    entities += dxfRect(GUIDE_HOLES_LAYER, width - rw, rightInsets.bottomInset, rw, height - rightInsets.bottomInset - rightInsets.topInset);
    entities += dxfRect(GUIDE_HOLES_LAYER, 0, leftInsets.bottomInset, rw, height - leftInsets.bottomInset - leftInsets.topInset);
    // Back edge at top, Front (baffle) edge at bottom
    entities += dxfRect(GUIDE_HOLES_LAYER, CORNER_INSET, height - rw, width - 2 * CORNER_INSET, rw);
    entities += dxfRect(GUIDE_HOLES_LAYER, CORNER_INSET, 0, bw - 2 * CORNER_INSET, rw);
  } else {
    // TOP: All X mirrored — Right side at LEFT edge, Left side at RIGHT edge
    entities += dxfRect(GUIDE_HOLES_LAYER, 0, rightInsets.bottomInset, rw, height - rightInsets.bottomInset - rightInsets.topInset);
    entities += dxfRect(GUIDE_HOLES_LAYER, width - rw, leftInsets.bottomInset, rw, height - leftInsets.bottomInset - leftInsets.topInset);
    // Back edge at top (mirrored X), Front (baffle) edge at bottom (mirrored X)
    entities += dxfRect(GUIDE_HOLES_LAYER, CORNER_INSET, height - rw, width - 2 * CORNER_INSET, rw);
    entities += dxfRect(GUIDE_HOLES_LAYER, width - bw + CORNER_INSET, 0, bw - 2 * CORNER_INSET, rw);
  }

  return entities;
}

// ─── Tool-path Depth Safety Check ─────────────────────────────────────────────

/**
 * Inferred cut depth from a layer name. We use the layer-name suffix as the
 * source of truth because that's what the CAM software keys off of. Returns
 * `null` for layer names that aren't through-cuts (drills, mill-downs,
 * guides, etc.) — those have their own depth specs that are intentionally
 * less than full thickness.
 */
function layerDepthInches(layerName: string): number | null {
  // Full-through cut layers: CUT_OUT_XXMM, CUT_INSIDE_XXMM. Anything else
  // (8MM_DRILL__5_DEEP_*, 25_DRILL__5_DEEP_*, MILL_DOWN__03/__034, Guides,
  // BOUNDING_FOR_NEST) is a partial pocket / drill / annotation that never
  // exceeds material thickness by design.
  if (!layerName.startsWith('CUT_OUT_') && !layerName.startsWith('CUT_INSIDE_')) {
    return null;
  }
  // MDF true-dimension suffixes (endsWith('_75INCH') also catches __75INCH).
  if (layerName.endsWith('_1INCH')) return 1.0;
  if (layerName.endsWith('_75INCH')) return 0.75;
  if (layerName.endsWith('_24MM')) return 24 / 25.4;
  if (layerName.endsWith('_18MM')) return 18 / 25.4;
  return null;
}

/** Maximum allowed overcut past material thickness, in inches. A typical
 *  CNC pass goes a hair past full thickness to ensure a clean through-cut
 *  without leaving fuzz on the bottom face. ~0.05" covers reasonable
 *  overcut while catching the 6mm (~0.236") layer-mismatch bug that put a
 *  24MM toolpath on an 18mm panel. */
const MAX_OVERCUT_TOLERANCE_IN = 0.05;

/**
 * Validate that no CUT_OUT/CUT_INSIDE layer used for this part implies a
 * depth greater than the part's actual material thickness (plus a small
 * overcut tolerance). Throws if a mismatch is found — better to fail
 * generation than ship a DXF that punches the spoilboard.
 *
 * Takes the part's effective thickness directly from the caller because
 * a handful of parts (Sub Mount Plate, Structural Baffle Flush, Sub Mount
 * Cap) override the default duty/config matrix — generatePartDxf already
 * computes the right value when it picks the cut layer, so we reuse it
 * instead of re-deriving and risking drift.
 */
function assertCutDepthsSafe(
  partName: string,
  actualThicknessIn: number,
  layers: LayerDef[],
): void {
  if (!actualThicknessIn || actualThicknessIn <= 0) return;

  for (const layer of layers) {
    const depth = layerDepthInches(layer.name);
    if (depth === null) continue;
    const overcut = depth - actualThicknessIn;
    if (overcut > MAX_OVERCUT_TOLERANCE_IN) {
      throw new Error(
        `[SAFETY] Tool-path depth mismatch on ${partName}: layer "${layer.name}" ` +
        `cuts ${depth.toFixed(3)}" but the part is only ${actualThicknessIn.toFixed(3)}" thick ` +
        `(overcut ${(overcut * 25.4).toFixed(1)}mm exceeds ${(MAX_OVERCUT_TOLERANCE_IN * 25.4).toFixed(1)}mm tolerance). ` +
        `This would damage the spoilboard. Refusing to emit DXF — investigate layer selection in dxf-generator.ts.`
      );
    }
  }
}

// ─── Collect All Layers Used ──────────────────────────────────────────────────

/** Build layer definitions from all layers actually referenced by entities */
function collectPartLayers(bs: string | undefined, partName: string, opts: {
  hasSubCutouts: boolean;
  hasMillDown: boolean;
  hasDrillHoles: boolean;
  hasTerminal: boolean;
  hasGuides: boolean;
  hasAcrylicWindow?: boolean;
  enclosureConfiguration?: string;
  isBirch: boolean;
  cutOutLayer?: string;
  cutInsideLayer?: string;
  drillLayer?: string;
}): LayerDef[] {
  // Desktop uses ACI 6 (magenta) for Guides layer when guide rectangles are drawn,
  // ACI 8 (gray) when only sheet outline is present. Since both use the same layer
  // name, guides-version gets magenta to match desktop GuideRectangleGenerator.
  const guidesColor = opts.hasGuides ? COLOR_MAGENTA_GUIDE : COLOR_GRAY;
  const layers: LayerDef[] = [
    { name: 'Guides', color: guidesColor },
    { name: opts.cutOutLayer ?? getCutOutLayer(bs, partName, opts.enclosureConfiguration, opts.isBirch), color: COLOR_WHITE },
  ];
  if (opts.hasSubCutouts || opts.hasTerminal || opts.hasAcrylicWindow) {
    const ciName = opts.cutInsideLayer ?? getCutInsideLayer(bs, partName, opts.enclosureConfiguration, opts.isBirch);
    if (!layers.find(l => l.name === ciName)) layers.push({ name: ciName, color: COLOR_RED });
  }
  if (opts.hasDrillHoles) {
    const dlName = opts.drillLayer ?? getDrillLayer(bs, partName, opts.enclosureConfiguration, opts.isBirch);
    if (!layers.find(l => l.name === dlName)) layers.push({ name: dlName, color: COLOR_WHITE });
  }
  if (opts.hasTerminal) {
    const d25Name = getDrill25Layer(bs, opts.isBirch);
    if (!layers.find(l => l.name === d25Name)) layers.push({ name: d25Name, color: COLOR_WHITE });
  }
  if (opts.hasMillDown) {
    const mdName = getMillDownLayer(bs);
    if (!layers.find(l => l.name === mdName)) layers.push({ name: mdName, color: COLOR_BLUE });
    // Bounding envelope layer for nesting software
    if (!layers.find(l => l.name === BOUNDING_FOR_NEST_LAYER)) {
      layers.push({ name: BOUNDING_FOR_NEST_LAYER, color: COLOR_GRAY });
    }
  }
  // Guides_Holes layer for drill hole guide rectangles (desktop ACI 5 = Cyan)
  if (opts.hasGuides && opts.hasDrillHoles) {
    layers.push({ name: GUIDE_HOLES_LAYER, color: COLOR_BLUE });
  }
  return layers;
}

// ─── Main Part DXF Generator ──────────────────────────────────────────────────

/**
 * Generate a DXF file for a single part positioned on a 96"×48" sheet.
 * Matches desktop DxfPartGenerator: duty-specific layers, drill holes,
 * mill-down pockets (Birch only), terminal cup cutout, SUPB sub cutouts.
 */
export function generatePartDxf(
  partName: string,
  width: number,
  height: number,
  options: PartDxfOptions = {}
): string {
  let entities = '';
  const bs = options.buildStrength;
  const isBirch = options.isBirchPly !== false; // default true
  const isSUPB = options.enclosureConfiguration === 'Subs Up/Port Back';
  const isDualPort = options.portQuantity === 'Dual';
  const subCount = options.subwooferQuantity ? getSubwooferCount(options.subwooferQuantity) : 0;
  const cutOutLayer = getCutOutLayer(bs, partName, options.enclosureConfiguration, isBirch);
  const t = options.materialThickness || fallbackThinIn(isBirch); // fallback B1 / D1
  const portPieceNumber = numberedPortPiece(partName);
  const labyrinthPanel = options.calc?.labyrinthPort?.active && portPieceNumber !== null
    ? options.calc.labyrinthPort.panels.find(panel => panel.partNumber === portPieceNumber)
    : undefined;
  const isLabyrinthDivider = !!labyrinthPanel && labyrinthPanel.partNumber >= 2;

  // ── Kerf Port: merged "Baffle + Port 1" bent panel ──────────────────────
  // A flat rectangle (developed length × internalHeight) with the sub cutout on
  // the baffle leg + the kerf groove centerlines in the bend zone. Early return:
  // the name startsWith('Baffle'), which would otherwise mis-trigger the
  // mill-down / baffle paths below. (The RD flat "Port 1" remainder is a plain
  // rectangle handled by the normal path.)
  if (partName === 'Baffle + Port 1' && options.kerf) {
    const k = options.kerf;
    const kerfCutOut = k.bentThicknessIn >= 0.9 ? 'CUT_OUT_24MM' : 'CUT_OUT_18MM';
    let e = dxfRect(kerfCutOut, 0, 0, width, height);
    const layers: LayerDef[] = [
      { name: 'Guides', color: COLOR_GRAY },
      { name: kerfCutOut, color: COLOR_WHITE },
    ];
    // Sub cutout(s) on the baffle leg, distributed across baffleRunIn.
    if (options.subCutoutDiameter && subCount > 0) {
      const tol = options.cutOutTolerance || 0;
      const r = (options.subCutoutDiameter + tol) / 2;
      const od = options.outsideDiameter || options.subCutoutDiameter;
      const ci = getCutInsideLayer(bs, 'Baffle', options.enclosureConfiguration, isBirch);
      layers.push({ name: ci, color: COLOR_RED });
      const cy = height / 2;
      for (const xp of getSubwooferXPositions(k.baffleRunIn, od, subCount)) {
        e += dxfCircle(ci, xp, cy, r);
        if (options.outsideDiameter) e += dxfCircle('Guides', xp, cy, options.outsideDiameter / 2);
      }
    }
    // Kerf groove centerlines (full panel height) — the bit cuts down each line
    // to the layer-encoded depth. Centerlines from kerf-port.ts.
    const kerfLayer = kerfGrooveLayerName(k.pattern.depthMm);
    layers.push({ name: kerfLayer, color: COLOR_BLUE });
    for (const gx of k.grooveXsIn) {
      e += dxfLine(kerfLayer, gx, 0, gx, height);
    }
    return buildDxfDocument(e, layers);
  }

  // Determine if this part gets mill-down (Birch only, specific parts)
  const millDownParts = ['Back', 'Baffle', 'Port Piece 2', 'Port Piece 2 Left', 'Port Piece 2 Right'];
  const hasMillDown = isBirch && (
    millDownParts.some(p => partName.startsWith(p) || partName === p)
    || isLabyrinthDivider
  );

  // Mill-down offsets shift the part outline when mill-down rectangles are present
  const yOffset = hasMillDown ? 0.25 : 0;
  const xOffset = (hasMillDown && (partName === 'Back' || partName === 'Baffle')) ? 0.125 : 0;

  // Determine if this part gets subwoofer cutouts
  const isBaffle = partName === 'Baffle';
  const isTopPanel = partName === 'Top';
  const isBottomPanel = partName === 'Bottom';
  const isSubMountPlate = partName === 'Sub Mount Plate';
  const isSubMountCap = partName === 'Sub Mount Cap';
  // Flush mount routing:
  //   - Structural baffle gets a flange-recess hole (OD + 0.25") instead of
  //     a sub through-hole, with layers forced to the material's thin stock.
  //   - Sub Mount Plate (NEW separate piece) gets the standard sub through-
  //     hole + outline cut only — no drill, no mill-down, no terminal.
  //   - Sub Mount Cap (SUPB flush): thin Birch/MDF slab on top of the box with
  //     flange-recess holes (OD + 0.25") matching the Top panel's cutout
  //     positions. No drill, no mill-down, no terminal.
  const isStructuralBaffleFlush = isBaffle && !!options.recessedMounting;
  const hasBaffleCutouts = isBaffle && !isSUPB && !!options.subCutoutDiameter;
  // Desktop: SUPB cutouts ONLY on Top panel (not Bottom). Guard: isTopPanel && SUPB.
  const hasSUPBCutouts = isTopPanel && isSUPB && !!options.subCutoutDiameter;
  const hasSubMountCapCutouts = isSubMountCap && isSUPB && !!options.subCutoutDiameter;
  const hasSubMountPlateCutouts = isSubMountPlate && !isSUPB && !!options.subCutoutDiameter;
  const hasSubCutouts = hasBaffleCutouts || hasSUPBCutouts || hasSubMountCapCutouts || hasSubMountPlateCutouts;

  // Determine if this part gets terminal cup. Default panel matches legacy
  // behavior — single port → Side Left, dual port → Back. SUPP uses the
  // same defaults since it's the same physical box; the panel rotates with
  // the rest of the geometry in the viewer. User override via
  // options.terminalPanel switches it; the cutout itself shifts via
  // options.terminalXOffset (handled below in generateTerminalCutout).
  // Keep this in sync with terminal-placement.ts:defaultTerminalPanel.
  const chosenTerminalPanel = options.terminalPanel ?? (isDualPort ? 'Back' : 'Side Left');
  const hasTerminal = partName === chosenTerminalPanel;

  // Determine if this part gets drill holes. The baffle's drill pattern is
  // joinery dowels (corner + extra-height edges + multi-sub gusset braces),
  // NOT sub mounting holes — sub mounting holes aren't pre-drilled anywhere
  // in this codebase. So flush mount keeps the structural baffle's drill
  // holes intact: it's still the joinery panel that aligns to the side
  // panels via dowels.
  const drillParts = ['Top', 'Bottom', 'Back', 'Baffle', 'Port Piece 2', 'Port Piece 2 Left', 'Port Piece 2 Right'];
  // Labyrinth dividers are located by the paired Top/Bottom dowels emitted on
  // those horizontal panels. Their alternating wall-anchor edge is glue/mill-
  // down only; do not copy normal transverse PP2's face holes because there is
  // no matching Baffle/Back hole pattern for that topology.
  const hasDrillHoles = isLabyrinthDivider
    ? false
    : drillParts.some(p => partName === p);

  // Desktop does NOT draw a 96x48 sheet outline on individual part DXFs.
  // Sheet outlines only appear in the logo DXF.

  // --- Part outline on CUT_OUT layer (offset for mill-down) ---
  // Desktop: parts start at (xOffset, yOffset) — no sheet-level offset
  // Flush mount overrides:
  //   - Structural baffle: forced to the material's thin stock.
  //   - Sub Mount Plate: thickness follows duty — thick for RD/HD, thin for SD.
  let effectiveCutOutLayer = cutOutLayer;
  if (isStructuralBaffleFlush) {
    effectiveCutOutLayer = `CUT_OUT_${matToken(isBirch, false)}`;
  } else if (isSubMountPlate) {
    effectiveCutOutLayer = `CUT_OUT_${matToken(isBirch, isHD(bs) || isRD(bs))}`;
  } else if (isSubMountCap) {
    effectiveCutOutLayer = `CUT_OUT_${matToken(isBirch, false)}`;
  }
  entities += dxfRect(effectiveCutOutLayer, xOffset, yOffset, width, height);

  // --- Mill-down rectangles (Birch only) ---
  // Desktop passes raw height; each mill-down function adds 0.5 internally (0.25 above + 0.25 below)
  if (hasMillDown) {
    if (partName === 'Back') {
      entities = generateBackMillDown(entities, width, height, bs, xOffset);
    } else if (partName === 'Baffle') {
      entities = generateBaffleMillDown(entities, width, height, bs, xOffset);
    } else if (partName.startsWith('Port Piece 2') || isLabyrinthDivider) {
      entities = generatePort2MillDown(entities, width, height, bs);
    }
    // Envelope rect for nesting software — avoids mill-down strips being
    // misread as separate parts outside the main outline.
    entities = generateBoundingForNest(entities, partName, width, height);
  }

  // --- Drill holes ---
  if (hasDrillHoles) {
    if (isTopPanel) {
      entities = generateBottomTopDrillHoles(entities, width, height, bs, true, options);
    } else if (isBottomPanel) {
      entities = generateBottomTopDrillHoles(entities, width, height, bs, false, options);
    } else if (partName === 'Back') {
      entities = generateBackDrillHoles(entities, width, height, bs, xOffset, yOffset, options.extraHolesHeight ?? 1, options.enclosureConfiguration, isBirch);
    } else if (isBaffle) {
      const od = options.outsideDiameter || options.subCutoutDiameter || 0;
      // For SUPB designs, subwooferXOffset shifts the sub pattern on the top
      // panel — gussets (and their brace dowel holes here) follow that shift.
      const subXOffForBrace = isSUPB ? (options.subwooferXOffset ?? 0) : 0;
      entities = generateBaffleDrillHoles(entities, width, height, bs, xOffset, yOffset, subCount, od, options.extraHolesHeight ?? 1, options.enclosureConfiguration, isStructuralBaffleFlush, subXOffForBrace, isBirch);
    } else if (partName.startsWith('Port Piece 2') || isLabyrinthDivider) {
      entities = generatePort2DrillHoles(entities, width, height, bs, yOffset, options.extraHolesHeight ?? 1, options.enclosureConfiguration, isBirch);
    }
  }

  if (isLabyrinthDivider && labyrinthPanel) {
    entities = addLabyrinthAnchorReference(
      entities,
      width,
      height,
      yOffset,
      labyrinthPanel.anchoredAt,
    );
  }
  // Sub Mount Plate (flush mount, multi-sub only): gusset brace dowels move
  // here from the baffle. Plate has no edge dowels (no joinery to side
  // panels), so this is the ONLY drill content on the plate.
  if (isSubMountPlate && subCount > 1 && !!options.recessedMounting) {
    const od = options.outsideDiameter || options.subCutoutDiameter || 0;
    const baffleW = options.baffleWidth || width;
    entities = generateSubMountPlateDrillHoles(entities, width, baffleW, height, bs, subCount, od, options.extraHolesHeight ?? 1, isBirch);
  }

  // SUPB multi-sub gusset dowels — drilled on BOTH Top and Bottom panels at
  // the chamber-frame midpoint between adjacent subs. The gusset is a
  // free-standing column dowelled to Top + Bottom only (NOT touching the
  // baffle, which is why generateBaffleDrillHoles skips its brace block when
  // isSUPB). Two dowels per panel-edge along the gusset's 5" depth (1.25"
  // CORNER_INSET from each end of that 5"), centered on subY so the gusset
  // sits directly under the subs even with the X/Y offset sliders engaged.
  if ((isTopPanel || isBottomPanel) && isSUPB && subCount > 1) {
    const od = options.outsideDiameter || options.subCutoutDiameter || 0;
    const sharedLayout = !isDualPort && options.inputs && options.calc && options.cutList
      ? resolveSupbSubLayout(options.inputs, options.calc, options.cutList)
      : null;
    if (sharedLayout && !sharedLayout.safe) {
      throw new Error(`Subwoofer placement is unsafe: ${sharedLayout.diagnostic}`);
    }
    if (sharedLayout?.safe) {
      entities = generateSupbGussetDrillHoles(
        entities,
        width,
        bs,
        isTopPanel,
        sharedLayout.gussets.map(gusset => ({ x: gusset.x, y: gusset.y })),
        options.enclosureConfiguration,
        isBirch,
      );
    } else {
    const t = options.materialThickness ?? fallbackThinIn(isBirch);
    const isDualPort = options.portQuantity === 'Dual';
    const s2w = options.s2LeftWidth || 0;
    const s1w = options.s1RightWidth || 0;
    const portW = options.portWidth || 0;
    const s2EdgeClearance = subCount > 0
      ? (s2w - od * subCount) / (subCount + 1)
      : 0;
    const useCombined = !isDualPort && s2EdgeClearance <= 0;
    const chamberW = useCombined ? (s2w + s1w) : s2w;
    const cutoutD = options.subCutoutDiameter || od;
    const s1Depth = useCombined
      ? Math.max(0, height - 2 * t - portW - t)
      : 0;
    // Resolve the same Y the Top sub cutouts use (with outer-edge bias),
    // then layer the user's Y offset on top.
    const baseCenterY = resolveSupbAutoCenterY({
      boxDepth: height,
      portWidth: portW,
      wallT: t,
      tBaffle: t,
      tBack: t,
      s1Depth,
      useCombined,
      halfOD: od / 2,
      halfCutout: cutoutD / 2,
    });
    const subYOff = options.subwooferYOffset ?? 0;
    const subY = baseCenterY + subYOff;
    // World X of each gusset = midpoint between adjacent sub centers.
    // Sub world X = t + subwooferXOffset + xPos, where xPos is the chamber-
    // frame position from getSubwooferXPositions(chamberW, od, subCount).
    const subXOff = options.subwooferXOffset ?? 0;
    const xPositions = chamberW > 0 ? getSubwooferXPositions(chamberW, od, subCount) : [];
    const worldGussets: Array<{ x: number; y: number }> = [];
    for (let i = 0; i < xPositions.length - 1; i++) {
      worldGussets.push({
        x: t + subXOff + (xPositions[i] + xPositions[i + 1]) / 2,
        y: subY,
      });
    }
    entities = generateSupbGussetDrillHoles(
      entities, width, bs, isTopPanel, worldGussets, options.enclosureConfiguration, isBirch,
    );
    }
  }

  // --- Subwoofer cutout circles ---
  if (hasSubCutouts && subCount > 0) {
    // Cutout diameter:
    //   - Structural baffle in flush mount: outsideDiameter + 0.25" (flange recess
    //     hole — sub flange sits in this larger hole, flush with the box face). No
    //     CutOutTolerance applies; the +0.25 IS the operator-spec'd clearance.
    //   - Everything else (non-flush baffle, SUPB top, Sub Mount Plate): standard
    //     sub through-hole = SubCutoutDiameter + CutOutTolerance.
    const tolerance = options.cutOutTolerance || 0;
    const standardCutoutRadius = (options.subCutoutDiameter! + tolerance) / 2;
    const recessCutoutRadius = options.outsideDiameter
      ? (options.outsideDiameter + 0.25) / 2
      : standardCutoutRadius;
    // CUT_INSIDE layer:
    //   - Structural baffle / SUPB cap: material's thin stock.
    //   - Sub Mount Plate: material's thick stock for RD/HD, thin for SD.
    //   - Everything else: existing part/duty material rule.
    let cutInsideLayer: string;
    if (isStructuralBaffleFlush || isSubMountCap) {
      cutInsideLayer = `CUT_INSIDE_${matToken(isBirch, false)}`;
    } else if (isSubMountPlate) {
      cutInsideLayer = `CUT_INSIDE_${matToken(isBirch, isHD(bs) || isRD(bs))}`;
    } else {
      cutInsideLayer = getCutInsideLayer(bs, partName, options.enclosureConfiguration, isBirch);
    }
    const od = options.outsideDiameter || options.subCutoutDiameter!;

    // Default cutout radius:
    //   - Structural baffle in flush mode: recess (OD + 0.25") for flange.
    //   - Sub Mount Cap (SUPB flush): recess (OD + 0.25") for flange.
    //   - Everything else: standard sub through-hole.
    const cutoutRadius = (isStructuralBaffleFlush || isSubMountCap) ? recessCutoutRadius : standardCutoutRadius;
    if (hasBaffleCutouts || hasSubMountPlateCutouts) {
      // SBPB structural baffle (recess hole when flush, through-hole otherwise),
      // OR Sub Mount Plate (standard through-hole). Same X/Y pattern: centered
      // vertically, evenly spaced horizontally. The plate is narrower than the
      // structural baffle and is centered behind it during assembly — for
      // cutout centers to align in the assembled enclosure, the plate's
      // cutouts must reference the BAFFLE'S width and shift left by the plate's
      // gap (otherwise multi-sub cutouts would land 1/3 of the wall thickness
      // off the baffle's centers because each part distributes evenly across
      // its own width).
      const centerY = yOffset + height / 2;
      const cutoutBaseWidth = hasSubMountPlateCutouts
        ? (options.baffleWidth || width)
        : width;
      const plateGapX = hasSubMountPlateCutouts
        ? Math.max(0, ((options.baffleWidth || width) - width) / 2)
        : 0;
      const xPositions = getSubwooferXPositions(cutoutBaseWidth, od, subCount);
      for (const xPos of xPositions) {
        const cx = xOffset + xPos - plateGapX;
        entities += dxfCircle(cutInsideLayer, cx, centerY, cutoutRadius);
      }
      // OD reference circles on Guides — useful for the structural baffle so
      // the operator can see where the visible flange edge will sit. Skip on
      // the Sub Mount Plate (no cosmetic surface) and skip when flush mount
      // baffle is rendered (the recess hole IS already the flange edge).
      if (options.outsideDiameter && hasBaffleCutouts && !isStructuralBaffleFlush) {
        const odR = options.outsideDiameter / 2;
        for (const xPos of xPositions) {
          entities += dxfCircle('Guides', xOffset + xPos, centerY, odR);
        }
      }
    } else if (hasSUPBCutouts || hasSubMountCapCutouts) {
      // SUPB Top panel cutouts (sub through-holes) AND SUPB Sub Mount Cap
      // cutouts (flange-recess holes) share identical X/Y positioning — the
      // cap sits directly above the Top panel with matching footprint, so
      // cutouts must align in world space. Only the radius differs (handled
      // upstream via cutoutRadius).
      // Single port: prefer S2 Left; if S2 is too small
      // for the sub, fall back to the combined (S2 + S1) chamber since the
      // L-shape port connects them. Dual port: stays in S2 (separate chambers).
      const sharedLayout = !isDualPort && options.inputs && options.calc && options.cutList
        ? resolveSupbSubLayout(options.inputs, options.calc, options.cutList)
        : null;
      if (sharedLayout && !sharedLayout.safe) {
        throw new Error(`Subwoofer placement is unsafe: ${sharedLayout.diagnostic}`);
      }
      if (sharedLayout?.safe) {
        for (const point of sharedLayout.points) {
          const drawX = width - point.x;
          entities += dxfCircle(cutInsideLayer, drawX, point.y, cutoutRadius);
          if (options.outsideDiameter && !isSubMountCap) {
            entities += dxfCircle('Guides', drawX, point.y, options.outsideDiameter / 2);
          }
        }
      } else {
      const s2w = options.s2LeftWidth || 0;
      const s1w = options.s1RightWidth || 0;
      const portW = options.portWidth || 0;
      const s2EdgeClearance = subCount > 0
        ? (s2w - od * subCount) / (subCount + 1)
        : 0;
      const useCombined = !isDualPort && s2EdgeClearance <= 0;
      const chamberW = useCombined ? (s2w + s1w) : s2w;
      // Depth (Y in DXF / front-to-back): biased to keep the flange ≥ 0.5"
      // from the box's outer front/back faces when geometry allows. Falls
      // back to legacy formula (boxDepth/2 for S2-only, (boxDepth − portW −
      // wallT)/2 for combined fallback) when constraints can't be met.
      // Mirrors subwoofer-placement.resolveSupbAutoCenterY so the slider's
      // auto-center, the DXF cutout, and the 3D viewer's driver all agree.
      const cutoutD = options.subCutoutDiameter || od;
      const s1Depth = useCombined
        ? Math.max(0, height - 2 * t - portW - t)
        : 0;
      const baseCenterY = resolveSupbAutoCenterY({
        boxDepth: height,
        portWidth: portW,
        wallT: t,
        tBaffle: t,
        tBack: t,
        s1Depth,
        useCombined,
        halfOD: od / 2,
        halfCutout: cutoutD / 2,
      });
      // User-supplied X/Y offsets shift the entire pattern. The DXF Top panel
      // is X-mirrored (drawX = width - physicalX), so a +X offset in box
      // coordinates becomes -X in DXF coordinates. Y axis isn't mirrored.
      const subXOff = options.subwooferXOffset ?? 0;
      const subYOff = options.subwooferYOffset ?? 0;
      const centerY = baseCenterY + subYOff;
      if (chamberW > 0) {
        // Chamber's right edge (in DXF X-mirrored coords) sits just inside Side
        // Left wall. Spans chamberW to the left from there. Apply user X
        // offset by shifting the chamber's anchor (negate to honor mirror).
        const chamberRightEdge = (width - t) - subXOff;
        const chamberLeftEdge = chamberRightEdge - chamberW;
        const xPositions = getSubwooferXPositions(chamberW, od, subCount);
        for (const xPos of xPositions) {
          const cx = chamberLeftEdge + xPos;
          entities += dxfCircle(cutInsideLayer, cx, centerY, cutoutRadius);
        }
        // OD reference circle on Guides — useful for the Top panel so the
        // operator can see where the visible flange edge will sit. Skip on
        // the Sub Mount Cap (recess hole IS the flange edge, so the guide
        // circle would overlap the cut line).
        if (options.outsideDiameter && !isSubMountCap) {
          const odR = options.outsideDiameter / 2;
          for (const xPos of xPositions) {
            entities += dxfCircle('Guides', chamberLeftEdge + xPos, centerY, odR);
          }
        }
      }
      }
    }
  }

  // --- Terminal cup cutout (rounded rectangle + mounting holes) ---
  if (hasTerminal) {
    // SUPP + Side Left: rotate the cup 90° CW on the panel so it reads
    // landscape in the rendered view. X-offset places the cup so its
    // back-of-box edge is inset by (portWidth + PP2_thickness + 2.25)
    // from the panel's back edge — clears the port slot + Port Piece 2
    // with a 2.25" safety buffer. Y position centers cup on panel
    // height (= partHeight/2). Mirrors terminal-placement.ts:
    // defaultTerminalXOffset; inlined since DXF options is leaner than
    // EnclosureInputs.
    const isSupp = options.enclosureConfiguration === 'Subs Up/Port Up';
    const rotateCup = isSupp && chosenTerminalPanel === 'Side Left';
    const portWidth = options.portWidth ?? 0;
    const pp2Thickness = options.materialThickness ?? fallbackThinIn(isBirch);
    const suppXOffset = isSupp && chosenTerminalPanel === 'Side Left'
      ? width / 2 - portWidth - pp2Thickness - 2.25 - TERMINAL_HEIGHT / 2
      : 0;
    const effectiveXOffset = options.terminalXOffset ?? suppXOffset;
    // Y offset: shifts cup BOTTOM from the default TERMINAL_BOTTOM_OFFSET
    // up to (panelHeight/2 − rotatedCupHeight/2). Math:
    //   target rectY = panelHeight/2 − cupHeight/2
    //   yOffset = target rectY − TERMINAL_BOTTOM_OFFSET
    //          = height/2 − TERMINAL_WIDTH/2 − TERMINAL_BOTTOM_OFFSET
    //          = height/2 − 2.25 − 2.125
    //          = height/2 − 4.375
    const suppYOffset = rotateCup
      ? height / 2 - TERMINAL_WIDTH / 2 - TERMINAL_BOTTOM_OFFSET
      : 0;
    const effectiveYOffset = yOffset + suppYOffset;
    entities = generateTerminalCutout(entities, width, height, bs, effectiveYOffset, effectiveXOffset, rotateCup, isBirch);
  }

  // --- Acrylic window cutout (V1) ---
  // Fires for the host panel only. Per-config rule:
  //   SBPB → Top, SUPB → Baffle, SUPU → Bottom.
  // Cutout is a rounded rectangle on the cut-inside layer; screw pilot ring
  // sits outboard of the cutout edges so screws pass through the acrylic
  // plate's overhang into the wood.
  if (options.windowEnabled && options.windowSize) {
    const hostPart = resolveWindowHostPart(options.enclosureConfiguration);
    if (partName === hostPart) {
      const dim = resolveWindowDxfDimensions(options.windowSize, options.windowOrientation, options.windowCustomWidth, options.windowCustomHeight);
      if (dim) {
        // Cut-inside layer matches whatever the host panel cuts on. Falls
        // back to the duty-driven rule for plain cases.
        const winCutLayer = isStructuralBaffleFlush
          ? `CUT_INSIDE_${matToken(isBirch, false)}`
          : getCutInsideLayer(bs, partName, options.enclosureConfiguration, isBirch);
        const winDrillLayer = getDrill25Layer(bs, isBirch);
        // Use effective offsets (saved clamped to safe range) so legacy
        // designs with stale offsets render in the right place without
        // requiring the operator to click Recenter.
        let xOff = options.windowXOffset ?? 0;
        let yOff = options.windowYOffset ?? 0;
        if (options.inputs && options.calc) {
          const eff = resolveEffectiveWindowOffsets(options.inputs, options.calc, options.cutList);
          xOff = eff.x;
          yOff = eff.y;
        }
        const cr = options.windowCornerRadius ?? 0.125;
        // Auto-shrink the plate to fit the host panel's safe area when we
        // have the design context. Wood cutout = plate − 2 × overhang/axis.
        let fittedPlateW = dim.plateW;
        let fittedPlateH = dim.plateH;
        if (options.inputs && options.calc) {
          const safe = resolveWindowSafeArea(options.inputs, options.calc, options.cutList);
          const fitted = resolveAutoFitPlateDimensions(
            { plateW: dim.plateW, plateH: dim.plateH },
            safe,
          );
          fittedPlateW = fitted.plateW;
          fittedPlateH = fitted.plateH;
        }
        const fittedCutoutW = Math.max(1, fittedPlateW - 2 * WINDOW_PLATE_OVERHANG_PER_SIDE);
        const fittedCutoutH = Math.max(1, fittedPlateH - 2 * WINDOW_PLATE_OVERHANG_PER_SIDE);
        // Wood cutout uses the (possibly shrunk) cutout dims. Plate is
        // emitted at the matching plate dims in the companion DXF.
        // Mirror X on the Top panel — the rest of the Top DXF uses
        // chamber-side-up X (drawX = width − physicalX) so the cutout
        // needs the same flip to land in the right place relative to
        // drill holes, sub cutouts, etc.
        entities = generateAcrylicWindowCutout(
          entities, width, height, winCutLayer, winDrillLayer,
          fittedCutoutW, fittedCutoutH, xOff, yOff, cr,
          isTopPanel,
        );
      }
    }
  }

  // --- Guide rectangles (with-guides version only) ---
  if (options.includeGuides) {
    if (partName === 'Back' || isBaffle) {
      entities = addBackBaffleGuides(entities, width, height, xOffset, yOffset);
    } else if (partName.startsWith('Port Piece 2') || isLabyrinthDivider) {
      entities = addPort2Guides(entities, width, height, yOffset);
    } else if (isTopPanel || isBottomPanel) {
      entities = addBottomTopGuides(entities, width, height, options, isTopPanel);
      // Drill hole guide rectangles on separate Guides_Holes layer (matches desktop DrillHoleGenerator)
      entities = addDrillHoleGuides(entities, width, height, options, isTopPanel);
    }
  }

  const hasGuides = !!options.includeGuides;
  // The window cutout uses a CUT_INSIDE layer too — register it for the
  // host panel even when there are no sub cutouts or terminal on this
  // part, otherwise the entity references a layer the DXF reader doesn't
  // know about.
  const hasAcrylicWindow = !!(options.windowEnabled && options.windowSize && partName === resolveWindowHostPart(options.enclosureConfiguration));
  const hasSubMountPlateDrillHoles = isSubMountPlate && subCount > 1 && !!options.recessedMounting;
  const effectiveCutInsideLayer = (isStructuralBaffleFlush || isSubMountCap)
    ? `CUT_INSIDE_${matToken(isBirch, false)}`
    : isSubMountPlate
      ? `CUT_INSIDE_${matToken(isBirch, isHD(bs) || isRD(bs))}`
      : getCutInsideLayer(bs, partName, options.enclosureConfiguration, isBirch);
  const effectiveDrillLayer = isStructuralBaffleFlush
    ? `8MM_DRILL__5_DEEP_${matToken(isBirch, false)}`
    : isSubMountPlate
      ? `8MM_DRILL__5_DEEP_${matToken(isBirch, isHD(bs) || isRD(bs))}`
      : getDrillLayer(bs, partName, options.enclosureConfiguration, isBirch);
  const layers = collectPartLayers(bs, partName, {
    hasSubCutouts,
    hasMillDown,
    hasDrillHoles: hasDrillHoles || hasSubMountPlateDrillHoles,
    hasTerminal,
    hasGuides,
    hasAcrylicWindow,
    enclosureConfiguration: options.enclosureConfiguration,
    isBirch,
    cutOutLayer: effectiveCutOutLayer,
    cutInsideLayer: effectiveCutInsideLayer,
    drillLayer: effectiveDrillLayer,
  });
  if (isLabyrinthDivider && labyrinthPanel) {
    layers.push({ name: labyrinthAnchorLayer(labyrinthPanel.anchoredAt), color: COLOR_MAGENTA_GUIDE });
  }

  // Defense-in-depth: confirm we never emit a cut layer deeper than the
  // host part's actual material thickness. Catches misuse of the duty-only
  // heuristic and any future regression that picks the wrong layer.
  // Effective thickness mirrors the `effectiveCutOutLayer` decision above:
  //   - Structural baffle flush / Sub Mount Cap → material's thin stock.
  //   - Sub Mount Plate → follows duty (RD/HD = heavy, SD = thin).
  //   - Everything else → isPartThick decides (RD-SBPB baffle / RD-SUPB top
  //     get heavy; rest get material; HD all heavy; SD all material).
  const mt = options.materialThickness ?? fallbackThinIn(isBirch);
  const ht = options.heavyThickness ?? fallbackHeavyIn(isBirch);
  let actualThicknessIn: number;
  if (isStructuralBaffleFlush || isSubMountCap) {
    actualThicknessIn = mt;
  } else if (isSubMountPlate) {
    actualThicknessIn = (isHD(bs) || isRD(bs)) ? ht : mt;
  } else {
    actualThicknessIn = isPartThick(bs, partName, options.enclosureConfiguration) ? ht : mt;
  }
  assertCutDepthsSafe(partName, actualThicknessIn, layers);

  return buildDxfDocument(entities, layers);
}

// ─── Box Dieline DXF Generation (Pacdora-compatible FEFCO 0201) ──────────────
// Ported from C# BoxDielineGenerator.cs and SplitBoxDielineGenerator.cs
// All geometry in millimetres to match Pacdora's coordinate system.

const BOX_LAYERS: LayerDef[] = [
  { name: 'cuts', color: COLOR_BLUE },
  { name: 'folds', color: COLOR_RED },
  // Non-cutting 96×48 sheet outline so CAM software (VCarve, etc.) auto-detects
  // the job size as a full sheet rather than fitting to the dieline bbox.
  // Operator excludes this layer from toolpath generation.
  { name: 'sheet', color: COLOR_GRAY },
];

/** Truncate mm value to 2dp to match Pacdora precision */
function truncMm(mm: number): number {
  return Math.floor(mm * 100) / 100;
}

/** Conversion factor for box dieline output. Internal math stays in mm
 *  (preserves the Pacdora-compatible Polyline2D dimensions exactly), then
 *  every coordinate is multiplied by this at the output boundary so the
 *  emitted DXF declares $INSUNITS=1 (inches). */
const MM_TO_IN = 1 / 25.4;

/** Cardboard sheet layout for the box dieline. The dieline is positioned
 *  with its leftmost point at SHEET_LEFT_MARGIN_IN inches from the sheet's
 *  left edge and centered vertically on a SHEET_HEIGHT_IN-tall sheet.
 *  A non-cutting "sheet" rectangle is also drawn at (0,0)→(96,48) so VCarve
 *  auto-detects the job size as 96×48 instead of fitting to the dieline bbox
 *  (otherwise the operator has to manually set Job Size + datum offset). */
const SHEET_WIDTH_IN = 96;
const SHEET_HEIGHT_IN = 48;
const SHEET_LEFT_MARGIN_IN = 1.5;

/**
 * Calculate overall dieline dimensions in inches.
 * Used by needsSplitDieline() to check if it fits on a 48"×96" sheet.
 */
export function getDielineDimensions(
  lengthIn: number, widthIn: number, heightIn: number, thicknessIn: number
): { widthInches: number; heightInches: number } {
  const lengthMm = truncMm(lengthIn * 25.4);
  const widthMm = truncMm(widthIn * 25.4);
  const heightMm = truncMm(heightIn * 25.4);
  const thicknessMm = truncMm(thicknessIn * 25.4);

  const fudgeConstantMm = 2.0;
  const fudgeOffsetMm = thicknessMm + fudgeConstantMm;
  const shortDimMm = Math.min(lengthMm, widthMm);
  const longDimMm = Math.max(lengthMm, widthMm);
  const glueTabMm = 45.0;

  const longPanelMm = longDimMm + fudgeOffsetMm;
  const shortPanelMm = shortDimMm + fudgeOffsetMm;
  const lastShortPanelMm = shortDimMm + thicknessMm;
  const totalWidthMm = glueTabMm + longPanelMm + shortPanelMm + longPanelMm + lastShortPanelMm;

  let extraHeightMm = Math.round((2 / 3) * thicknessMm);
  if (extraHeightMm < 1) extraHeightMm = 1;
  const marginInterior = 3.0;
  const flapRatioK = 0.506;

  let bottomMinorHeightMm = fudgeOffsetMm + flapRatioK * shortDimMm - (fudgeConstantMm + marginInterior);
  if (bottomMinorHeightMm < 0) bottomMinorHeightMm = 0;
  bottomMinorHeightMm = Math.round(bottomMinorHeightMm);
  const bottomMajorHeightMm = bottomMinorHeightMm + extraHeightMm;

  const yBase = extraHeightMm;
  const bodyHeightMm = heightMm + fudgeOffsetMm;
  const bottomMajorFold = yBase + bottomMajorHeightMm;
  const topMajorFold = bottomMajorFold + bodyHeightMm;
  const topMinorFold = topMajorFold + extraHeightMm;
  const topBaselineY = Math.max(
    topMajorFold + bottomMajorHeightMm,
    topMinorFold + bottomMinorHeightMm
  );
  const totalHeightMm = topBaselineY - yBase;

  return { widthInches: totalWidthMm / 25.4, heightInches: totalHeightMm / 25.4 };
}

/**
 * Check if a box requires a split (two-piece) dieline because the
 * single-piece dieline would exceed the 48"×96" sheet.
 */
export function needsSplitDieline(
  lengthIn: number, widthIn: number, heightIn: number, thicknessIn: number
): boolean {
  const { widthInches: w, heightInches: h } = getDielineDimensions(lengthIn, widthIn, heightIn, thicknessIn);
  const fitsH = w <= 96 && h <= 48;
  const fitsV = w <= 48 && h <= 96;
  return !(fitsH || fitsV);
}

/**
 * Generate a box dieline DXF (FEFCO 0201 four-panel wrap-around).
 * Ported from C# BoxDielineGenerator.cs — exact Pacdora match.
 * Input: internal dimensions in inches. Output: DXF in mm.
 * Layers: "cuts" (blue) for cut lines, "folds" (red) for fold lines.
 */
export function generateBoxDielineDxf(
  lengthIn: number, widthIn: number, heightIn: number,
  thicknessIn: number = 0.25
): string {
  const lengthMm = truncMm(lengthIn * 25.4);
  const widthMm = truncMm(widthIn * 25.4);
  const heightMm = truncMm(heightIn * 25.4);
  const thicknessMm = truncMm(thicknessIn * 25.4);

  const fudgeConstantMm = 2.0;
  const fudgeOffsetMm = thicknessMm + fudgeConstantMm;
  const shortDimMm = Math.min(lengthMm, widthMm);
  const longDimMm = Math.max(lengthMm, widthMm);
  const glueTabMm = 45.0;
  const marginFirst = 3.0;
  const marginInterior = 3.0;
  const flapRatioK = 0.506;

  // Panel widths
  const longPanelMm = longDimMm + fudgeOffsetMm;
  const shortPanelMm = shortDimMm + fudgeOffsetMm;
  const lastLongPanelMm = longDimMm + thicknessMm;
  const lastShortPanelMm = shortDimMm + thicknessMm;
  const panelTypes = [0, 1, 0, 1]; // 0=minor(long), 1=major(short)

  // X coordinates
  const x: number[] = [0, glueTabMm];
  for (let i = 0; i < 4; i++) {
    let pw: number;
    if (i === 3) pw = panelTypes[i] === 0 ? lastLongPanelMm : lastShortPanelMm;
    else pw = panelTypes[i] === 0 ? longPanelMm : shortPanelMm;
    x.push(x[x.length - 1] + pw);
  }

  // Flap heights
  let extraHeightMm = Math.round((2 / 3) * thicknessMm);
  if (extraHeightMm < 1) extraHeightMm = 1;
  let bottomMinorHeightMm = fudgeOffsetMm + flapRatioK * shortDimMm - (fudgeConstantMm + marginInterior);
  if (bottomMinorHeightMm < 0) bottomMinorHeightMm = 0;
  bottomMinorHeightMm = Math.round(bottomMinorHeightMm);
  const bottomMajorHeightMm = bottomMinorHeightMm + extraHeightMm;

  const yBase = extraHeightMm;
  const bodyHeightMm = heightMm + fudgeOffsetMm;
  const bottomMinorFold = yBase + bottomMinorHeightMm;
  const bottomMajorFold = yBase + bottomMajorHeightMm;
  const topMajorFold = bottomMajorFold + bodyHeightMm;
  const topMinorFold = topMajorFold + extraHeightMm;
  const topBaselineY = Math.max(
    topMajorFold + bottomMajorHeightMm,
    topMinorFold + bottomMinorHeightMm
  );

  const diagonalOffsetMm = glueTabMm * Math.tan(Math.PI / 12);

  const bottomFoldY: number[] = [];
  const topFoldY: number[] = [];
  for (let i = 0; i < 4; i++) {
    bottomFoldY.push(panelTypes[i] === 0 ? bottomMinorFold : bottomMajorFold);
    topFoldY.push(panelTypes[i] === 0 ? topMinorFold : topMajorFold);
  }

  let entities = '';
  // Sheet layout: dieline sits 1.5" from the left edge of a 96"×48" sheet
  // and is centered vertically. Computed in inches, applied as an additive
  // offset at the output boundary (after the mm→in conversion).
  const dielineCenterYIn = ((yBase + topBaselineY) / 2) * MM_TO_IN;
  const xOffsetIn = SHEET_LEFT_MARGIN_IN; // leftmost dieline point sits here
  const yOffsetIn = SHEET_HEIGHT_IN / 2 - dielineCenterYIn;

  // Cuts are collected into a flat segment list and stitched into ONE closed
  // polyline at the end, so VCarve sees a single continuous tool path instead
  // of ~30 individual lines + arcs the operator has to join by hand.
  // All math here stays in mm (Pacdora units); the conversion to inches +
  // sheet-positioning offset happens only at the output boundary (fold
  // callback + cutVerts mapping below).
  const cuts: CutSegment[] = [];
  const cut = (x1: number, y1: number, x2: number, y2: number) => {
    cuts.push({ x1, y1, x2, y2, bulge: 0 });
  };
  const arcCut = (cx: number, cy: number, r: number, sa: number, ea: number) => {
    cuts.push(arcToSegment(cx, cy, r, sa, ea));
  };
  const fold = (x1: number, y1: number, x2: number, y2: number) => {
    entities += dxfLine('folds',
      x1 * MM_TO_IN + xOffsetIn, y1 * MM_TO_IN + yOffsetIn,
      x2 * MM_TO_IN + xOffsetIn, y2 * MM_TO_IN + yOffsetIn);
  };

  // Bridging segments at interior panel boundaries
  const bridgingPositions = [
    x[2] - marginInterior,
    x[3] + marginInterior,
    x[4] - marginInterior,
  ];
  for (const bx of bridgingPositions) {
    cut(bx, bottomMajorFold - marginInterior, bx, bottomMinorFold);
    cut(bx, topMinorFold, bx, topMajorFold + marginInterior);
  }

  // Slot arcs at interior panel boundaries
  for (let k = 2; k <= 4; k++) {
    const r = marginInterior;
    arcCut(x[k], bottomMajorFold - r, r, 0, 180);
    arcCut(x[k], topMajorFold + r, r, 180, 360);
  }

  // Glue tab
  cut(glueTabMm, bottomMajorFold, 0, bottomMajorFold + diagonalOffsetMm);
  cut(0, bottomMajorFold + diagonalOffsetMm, 0, topMajorFold - diagonalOffsetMm);
  cut(0, topMajorFold - diagonalOffsetMm, glueTabMm, topMajorFold);
  fold(glueTabMm, bottomMajorFold, glueTabMm, topMajorFold);

  // Glue tab bridging arcs
  const bridgeX = glueTabMm + marginFirst;
  cut(bridgeX, bottomMinorFold, bridgeX, bottomMajorFold - marginFirst);
  arcCut(glueTabMm, bottomMajorFold - marginFirst, marginFirst, 0, 90);
  cut(bridgeX, topMinorFold, bridgeX, topMajorFold + marginFirst);
  arcCut(glueTabMm, topMajorFold + marginFirst, marginFirst, 270, 360);

  // Vertical fold lines between panels
  for (let i = 1; i < 4; i++) {
    fold(x[i + 1], bottomMajorFold, x[i + 1], topMajorFold);
  }

  // Rightmost edge quarter-circle arcs
  arcCut(x[5], bottomMajorFold - marginFirst, marginFirst, 90, 180);
  cut(x[5], bottomMajorFold, x[5], topMajorFold);
  arcCut(x[5], topMajorFold + marginFirst, marginFirst, 180, 270);

  // Horizontal fold lines per panel
  for (let i = 0; i < 4; i++) {
    let foldStart: number, foldEnd: number;
    if (panelTypes[i] === 0) {
      const leftM = i === 0 ? marginFirst : marginInterior;
      const rightM = i === 3 ? marginFirst : marginInterior;
      foldStart = x[i + 1] + leftM;
      foldEnd = x[i + 2] - rightM;
    } else {
      foldStart = x[i + 1];
      foldEnd = x[i + 2];
    }
    fold(foldStart, bottomFoldY[i], foldEnd, bottomFoldY[i]);
    fold(foldStart, topFoldY[i], foldEnd, topFoldY[i]);
  }

  // Bottom flaps
  for (let i = 0; i < 4; i++) {
    const leftM = i === 0 ? marginFirst : marginInterior;
    const rightM = i === 3 ? marginFirst : marginInterior;
    const xStart = x[i + 1] + leftM;
    const xEnd = x[i + 2] - rightM;
    const flapTermY = panelTypes[i] === 0 ? bottomMinorFold : (bottomMajorFold - marginInterior);
    cut(xStart, yBase, xEnd, yBase);
    cut(xStart, yBase, xStart, flapTermY);
    cut(xEnd, yBase, xEnd, flapTermY);
  }

  // Top flaps
  for (let i = 0; i < 4; i++) {
    const leftM = i === 0 ? marginFirst : marginInterior;
    const rightM = i === 3 ? marginFirst : marginInterior;
    const xStart = x[i + 1] + leftM;
    const xEnd = x[i + 2] - rightM;
    const topFlapTermY = panelTypes[i] === 0 ? topMinorFold : (topMajorFold + marginInterior);
    cut(xStart, topBaselineY, xEnd, topBaselineY);
    cut(xStart, topFlapTermY, xStart, topBaselineY);
    cut(xEnd, topFlapTermY, xEnd, topBaselineY);
  }

  const cutVerts = stitchClosedPath(cuts, `box ${lengthIn}x${widthIn}x${heightIn}`);
  const cutVertsIn = cutVerts.map(v => ({
    x: v.x * MM_TO_IN + xOffsetIn,
    y: v.y * MM_TO_IN + yOffsetIn,
    bulge: v.bulge,
  }));
  entities += dxfPolylineWithBulges('cuts', cutVertsIn);

  // Sheet outline so VCarve auto-sizes the job to 96×48 on import
  entities += dxfRect('sheet', 0, 0, SHEET_WIDTH_IN, SHEET_HEIGHT_IN);

  return buildDxfDocument(entities, BOX_LAYERS, false);
}

// ─── Split Box Dieline DXF (Single-Piece, both halves identical) ───────────
// Ported from C# SplitBoxDielineGenerator.cs
// For boxes too large to fit on a single 48"×96" cardboard sheet.

/**
 * Generate a split box dieline. The original two-piece format had identical
 * halves stacked vertically in one DXF — we now emit only ONE piece (the
 * operator runs it twice), rotated 90° CCW so the long axis lays along the
 * sheet's 96" axis, and positioned with the same 1.5"-from-left + vertically
 * centered placement as `generateBoxDielineDxf` for layout consistency.
 *
 * Each piece contains a glue tab and two panels (long + short).
 * Internal math stays in mm (Pacdora format); rotation, mm→in conversion,
 * and sheet positioning are all applied at the output boundary.
 */
export function generateSplitBoxDielineDxf(
  lengthIn: number, widthIn: number, heightIn: number,
  thicknessIn: number = 0.25
): string {
  const lengthMm = truncMm(lengthIn * 25.4);
  const widthMm = truncMm(widthIn * 25.4);
  const heightMm = truncMm(heightIn * 25.4);
  const thicknessMm = truncMm(thicknessIn * 25.4);

  const fudgeConstantMm = 2.0;
  const fudgeOffsetMm = thicknessMm + fudgeConstantMm;
  const shortDimMm = Math.min(lengthMm, widthMm);
  const longDimMm = Math.max(lengthMm, widthMm);
  const glueTabMm = 45.0;
  const marginFirst = 3.0;
  const marginInterior = 3.0;
  const flapRatioK = 0.506;

  // Panel widths (all use full fudgeOffset — no narrow last panel in split)
  const longPanelMm = longDimMm + fudgeOffsetMm;
  const shortPanelMm = shortDimMm + fudgeOffsetMm;
  const panelTypes = [0, 1]; // 0=minor(long), 1=major(short)

  // X coordinates: glue tab + 2 panels
  const x = [0, glueTabMm, glueTabMm + longPanelMm, glueTabMm + longPanelMm + shortPanelMm];

  // Flap heights
  let extraHeightMm = Math.round((2 / 3) * thicknessMm);
  if (extraHeightMm < 1) extraHeightMm = 1;
  let bottomMinorHeightMm = fudgeOffsetMm + flapRatioK * shortDimMm - (fudgeConstantMm + marginInterior);
  if (bottomMinorHeightMm < 0) bottomMinorHeightMm = 0;
  bottomMinorHeightMm = Math.round(bottomMinorHeightMm);
  const flapCapMm = Math.round(shortDimMm / 2 + fudgeOffsetMm - marginInterior);
  if (bottomMinorHeightMm > flapCapMm) bottomMinorHeightMm = flapCapMm;
  const bottomMajorHeightMm = bottomMinorHeightMm + extraHeightMm;
  const bodyHeightMm = heightMm + fudgeOffsetMm;

  const yBase = extraHeightMm;
  const bottomMinorFold = yBase + bottomMinorHeightMm;
  const bottomMajorFold = yBase + bottomMajorHeightMm;
  const topMajorFold = bottomMajorFold + bodyHeightMm;
  const topMinorFold = topMajorFold + extraHeightMm;
  const topBaselineY = Math.max(
    topMajorFold + bottomMajorHeightMm,
    topMinorFold + bottomMinorHeightMm
  );

  const diagonalOffsetMm = glueTabMm * Math.tan(Math.PI / 12);

  const bottomFoldYArr = panelTypes.map(t => t === 0 ? bottomMinorFold : bottomMajorFold);
  const topFoldYArr = panelTypes.map(t => t === 0 ? topMinorFold : topMajorFold);

  // Cuts go through the segment list and stitcher; folds are collected into a
  // parallel list so the rotation transform below applies to both. Math stays
  // in mm; rotation + mm→in + sheet positioning happens in `tx()` after.
  const pieceCuts: CutSegment[] = [];
  const foldLines: Array<{ x1: number; y1: number; x2: number; y2: number }> = [];
  const cut = (x1: number, y1: number, x2: number, y2: number) => {
    pieceCuts.push({ x1, y1, x2, y2, bulge: 0 });
  };
  const arcCut = (cx: number, cy: number, r: number, sa: number, ea: number) => {
    pieceCuts.push(arcToSegment(cx, cy, r, sa, ea));
  };
  const fold = (x1: number, y1: number, x2: number, y2: number) => {
    foldLines.push({ x1, y1, x2, y2 });
  };

  // Bridging segment at x[2]
  const bx = x[2] - marginInterior;
  cut(bx, bottomMajorFold - marginInterior, bx, bottomMinorFold);
  cut(bx, topMinorFold, bx, topMajorFold + marginInterior);

  // Slot arcs at x[2]
  const r = marginInterior;
  arcCut(x[2], bottomMajorFold - r, r, 0, 180);
  arcCut(x[2], topMajorFold + r, r, 180, 360);

  // Glue tab
  cut(glueTabMm, bottomMajorFold, 0, bottomMajorFold + diagonalOffsetMm);
  cut(0, bottomMajorFold + diagonalOffsetMm, 0, topMajorFold - diagonalOffsetMm);
  cut(0, topMajorFold - diagonalOffsetMm, glueTabMm, topMajorFold);
  fold(glueTabMm, bottomMajorFold, glueTabMm, topMajorFold);

  // Glue tab bridging arcs
  const bxG = glueTabMm + marginFirst;
  cut(bxG, bottomMinorFold, bxG, bottomMajorFold - marginFirst);
  arcCut(glueTabMm, bottomMajorFold - marginFirst, marginFirst, 0, 90);
  cut(bxG, topMinorFold, bxG, topMajorFold + marginFirst);
  arcCut(glueTabMm, topMajorFold + marginFirst, marginFirst, 270, 360);

  // Vertical fold line at x[2]
  fold(x[2], bottomMajorFold, x[2], topMajorFold);

  // Rightmost edge (x[3])
  arcCut(x[3], bottomMajorFold - marginFirst, marginFirst, 90, 180);
  cut(x[3], bottomMajorFold, x[3], topMajorFold);
  arcCut(x[3], topMajorFold + marginFirst, marginFirst, 180, 270);

  // Horizontal fold lines
  for (let i = 0; i < 2; i++) {
    let foldStart: number, foldEnd: number;
    if (panelTypes[i] === 0) {
      const leftM = i === 0 ? marginFirst : marginInterior;
      const rightM = i === 1 ? marginFirst : marginInterior;
      foldStart = x[i + 1] + leftM;
      foldEnd = x[i + 2] - rightM;
    } else {
      foldStart = x[i + 1];
      foldEnd = x[i + 2];
    }
    fold(foldStart, bottomFoldYArr[i], foldEnd, bottomFoldYArr[i]);
    fold(foldStart, topFoldYArr[i], foldEnd, topFoldYArr[i]);
  }

  // Bottom flaps
  for (let i = 0; i < 2; i++) {
    const leftM = i === 0 ? marginFirst : marginInterior;
    const rightM = i === 1 ? marginFirst : marginInterior;
    const xStart = x[i + 1] + leftM;
    const xEnd = x[i + 2] - rightM;
    const flapTermY = panelTypes[i] === 0 ? bottomMinorFold : (bottomMajorFold - marginInterior);
    cut(xStart, yBase, xEnd, yBase);
    cut(xStart, yBase, xStart, flapTermY);
    cut(xEnd, yBase, xEnd, flapTermY);
  }

  // Top flaps
  for (let i = 0; i < 2; i++) {
    const leftM = i === 0 ? marginFirst : marginInterior;
    const rightM = i === 1 ? marginFirst : marginInterior;
    const xStart = x[i + 1] + leftM;
    const xEnd = x[i + 2] - rightM;
    const topFlapTermY = panelTypes[i] === 0 ? topMinorFold : (topMajorFold + marginInterior);
    cut(xStart, topBaselineY, xEnd, topBaselineY);
    cut(xStart, topFlapTermY, xStart, topBaselineY);
    cut(xEnd, topFlapTermY, xEnd, topBaselineY);
  }

  // ── Transform: rotate 90° CCW, normalize to non-negative coords, convert
  //    mm→in, then position on sheet (1.5" left margin, vertically centered).
  //
  //    Original bbox in mm: x ∈ [0, x[3]], y ∈ [yBase, topBaselineY]
  //    After CCW rotation (x, y) → (-y, x):
  //                        x ∈ [-topBaselineY, -yBase], y ∈ [0, x[3]]
  //    After normalization (shift x by +topBaselineY):
  //                        x ∈ [0, topBaselineY - yBase], y ∈ [0, x[3]]
  //
  //    90° rotation preserves arc orientation, so bulge signs stay as-is.
  const rotatedHeightIn = x[3] * MM_TO_IN;
  const xOffsetIn = SHEET_LEFT_MARGIN_IN;
  const yOffsetIn = SHEET_HEIGHT_IN / 2 - rotatedHeightIn / 2;
  const tx = (xMm: number, yMm: number) => ({
    x: (topBaselineY - yMm) * MM_TO_IN + xOffsetIn,
    y: xMm * MM_TO_IN + yOffsetIn,
  });

  let entities = '';
  // Folds first (order doesn't matter for the DXF, but groups same-layer)
  for (const f of foldLines) {
    const p1 = tx(f.x1, f.y1);
    const p2 = tx(f.x2, f.y2);
    entities += dxfLine('folds', p1.x, p1.y, p2.x, p2.y);
  }

  const cutVerts = stitchClosedPath(
    pieceCuts,
    `splitBox ${lengthIn}x${widthIn}x${heightIn}`,
  );
  const cutVertsOut = cutVerts.map(v => {
    const p = tx(v.x, v.y);
    return { x: p.x, y: p.y, bulge: v.bulge };
  });
  entities += dxfPolylineWithBulges('cuts', cutVertsOut);

  // Sheet outline so VCarve auto-sizes the job to 96×48 on import
  entities += dxfRect('sheet', 0, 0, SHEET_WIDTH_IN, SHEET_HEIGHT_IN);

  return buildDxfDocument(entities, BOX_LAYERS, false);
}

// ─── Logo DXF Generation (from EPS) ───────────────────────────────────────────

const LOGO_LAYERS: LayerDef[] = [
  { name: 'Guides', color: COLOR_GRAY },
  { name: 'ENGRAVE_LOGO_ON_LINE_0625', color: COLOR_WHITE },
];

/**
 * Generate a Logo DXF from EPS file content.
 * Parses EPS paths, scales/centers within the panel area (with 0.75" border),
 * and outputs as DXF polylines on ENGRAVE_LOGO_ON_LINE_0625 layer.
 *
 * Panel is positioned on a 96"×48" sheet matching desktop's DxfPartGenerator.
 */
export function generateLogoDxf(
  epsContent: string,
  panelWidth: number,
  panelHeight: number,
): string | null {
  // Parse EPS paths
  const paths = parseEpsPaths(epsContent);
  appendDebug('Logo', paths.length === 0 ? 'error' : 'info',
    `parseEpsPaths → ${paths.length} path(s)`,
    { epsBytes: epsContent.length, epsPreview: epsContent.slice(0, 200).replace(/\s+/g, ' ') });
  if (paths.length === 0) return null;

  // Calculate bounds
  const bounds = calculatePathsBounds(paths);
  if (!bounds || bounds.width <= 0 || bounds.height <= 0) {
    appendDebug('Logo', 'error', 'calculatePathsBounds returned invalid bounds', { bounds });
    return null;
  }
  appendDebug('Logo', 'info', 'EPS bounds', bounds);

  // Filter out bounding box / clipping paths
  const filteredPaths = filterBoundingBoxPaths(paths, bounds);
  appendDebug('Logo', filteredPaths.length === 0 ? 'error' : 'info',
    `filterBoundingBoxPaths → ${filteredPaths.length} path(s) (from ${paths.length})`);
  if (filteredPaths.length === 0) return null;

  // Panel position on sheet (matches desktop: flush left, offset from bottom)
  const topPanelOffsetX = 0;
  const topPanelOffsetY = SHEET_HEIGHT - panelHeight - LOGO_PANEL_OFFSET_Y;

  // Logo area = panel minus 0.75" border on all sides
  const border = 0.75;
  const logoAreaWidth = panelWidth - 2 * border;
  const logoAreaHeight = panelHeight - 2 * border;
  if (logoAreaWidth <= 0 || logoAreaHeight <= 0) {
    appendDebug('Logo', 'error', 'Logo area is zero or negative — panel too small', {
      panelWidth, panelHeight, logoAreaWidth, logoAreaHeight,
    });
    return null;
  }

  // Scale to fit (maintain aspect ratio)
  const scaleX = logoAreaWidth / bounds.width;
  const scaleY = logoAreaHeight / bounds.height;
  const scale = Math.min(scaleX, scaleY);

  const scaledWidth = bounds.width * scale;
  const scaledHeight = bounds.height * scale;

  // Center within logo area
  const offsetX = topPanelOffsetX + border + (logoAreaWidth - scaledWidth) / 2 - bounds.minX * scale;
  const offsetY = topPanelOffsetY + border + (logoAreaHeight - scaledHeight) / 2 - bounds.minY * scale;

  let entities = '';

  // Sheet outline on GUIDES
  entities += dxfRect('Guides', 0, 0, SHEET_WIDTH, SHEET_HEIGHT);

  // Panel outline on GUIDES
  entities += dxfRect('Guides', topPanelOffsetX, topPanelOffsetY, panelWidth, panelHeight);

  // Logo polylines on ENGRAVE layer
  entities += epsPathsToDxfEntities(filteredPaths, 'ENGRAVE_LOGO_ON_LINE_0625', scale, offsetX, offsetY);

  return buildDxfDocument(entities, LOGO_LAYERS);
}

// ─── On-Line Logo Toolpath Generation (.xxl) ─────────────────────────────────
// Traces logo outlines with G1/G2/G3 commands (surface engrave, not pocket clearing).
// Matches desktop LogoToolpathGenerator.cs

/**
 * SCM router-friendly logo XXL filename. Logo programs do not vary by sales
 * tier (BHSP/BHSF/BHSS) or duty code, so those tokens are omitted. Mixed case
 * keeps the compact, separator-free result readable within the router's
 * 14-character basename limit:
 *
 *   BHSP-SUN-SAV3-D12-RD      → LsunSAV3d12
 *   BHSF-SUN-SAV3-D12-RD-MDF  → LsunSAV3d12mdf
 *
 * MDF is deliberately retained because its logo program uses 3/4-inch stock.
 */
export function logoXxlFilename(prefix: string): string {
  const raw = (prefix || '').trim();
  if (!raw) return 'L_ENCLOSURE.xxl';

  const tokens = raw
    .replace(/^(?:BHSP|BHSF|BHSS)-/i, '')
    .split('-')
    .filter(Boolean);
  const isMdf = tokens.some(token => token.toUpperCase() === 'MDF');
  const ignored = /^(?:SD|RD|HD|MDF|SUPB|FP|FM|KP|C\d+)$/i;
  const meaningful = tokens.filter(token => !ignored.test(token));
  if (meaningful.length === 0) return isMdf ? 'L_ENCLOSUmdf.xxl' : 'L_ENCLOSURE.xxl';

  const clean = (token: string): string => token.replace(/[^A-Za-z0-9]/g, '');
  const brand = clean(meaningful[0]).toLowerCase();
  const rest = meaningful.slice(1);
  const sizeIndex = rest.findIndex(token => /^[SDTQ]\d+(?:\.\d+)?$/i.test(token));
  const sizeToken = sizeIndex >= 0 ? rest[sizeIndex] : '';
  const modelTokens = sizeIndex >= 0
    ? rest.filter((_, index) => index !== sizeIndex)
    : rest;
  const model = modelTokens.map(clean).join('').toUpperCase();
  const size = clean(sizeToken).toLowerCase();
  const mdfSuffix = isMdf ? 'mdf' : '';
  const readable = `L${brand}${model}${size}`;

  // Keep the material suffix visible even when an unusual model exceeds the
  // router limit; it is operationally more important than the truncated tail.
  const available = 14 - mdfSuffix.length;
  return `${readable.slice(0, available)}${mdfSuffix}.xxl`;
}

/**
 * Cardboard plotter box XXL filename. Same rule set as the logo XXL — drop
 * build strength + SUPB suffixes, swap separators, 14-char cap — but with a
 * `B_` prefix instead of `L_`. Both single-piece (Box) and split-piece
 * (SplitBox) outputs share this name (only one of the two is ever generated
 * per design, so no collision).
 *
 *   JL-W7-S13.5-RD          → B_JL_W7_S13_5.xxl
 *   SUN-SAv3-D10-HD         → B_SUN_SAv3_D10.xxl
 *   BHSP-AMB-GO-D12-HD      → B_BHSP_AMB_GO_.xxl  (truncated at 14)
 */
export function boxXxlFilename(prefix: string): string {
  return shortenedXxlFilename(prefix, 'B');
}

/** Shared 14-char-capped, separator-stripped XXL filename builder. */
function shortenedXxlFilename(prefix: string, letter: 'L' | 'B'): string {
  let body = (prefix || 'ENCLOSURE').trim();
  body = body.replace(/-(?:SD|RD|HD)$/i, '');
  body = body.replace(/-SUPB$/i, '');
  body = body.replace(/-/g, '_').replace(/\./g, '_');
  let name = `${letter}_${body}`;
  if (name.length > 14) name = name.slice(0, 14);
  return `${name}.xxl`;
}

const LOGO_TOOL = 104;
const LOGO_RPM = 18000;
const LOGO_FEED = 1524;        // mm/min cutting
const LOGO_PLUNGE = 1842;      // mm/min plunge/ramp
const LOGO_SAFE_Z = -38.1;     // 1.5" above surface
const LOGO_APPROACH_Z = -5.08; // 0.2" above surface
const LOGO_CUT_Z = 1.5875;     // 0.0625" into material
const LOGO_RAMP_MM = 6.35;     // 0.25" ramp distance
const IN_TO_MM = 25.4;

interface LogoVertex { x: number; y: number; bulge: number; }
interface LogoPolyline { vertices: LogoVertex[]; closed: boolean; }

/** Parse logo DXF for POLYLINE/LWPOLYLINE/LINE entities on ENGRAVE_LOGO_ON_LINE_0625 layer */
function parseLogoDxfForToolpath(dxfContent: string): LogoPolyline[] {
  const lines = dxfContent.split('\n').map(l => l.trim());
  const polylines: LogoPolyline[] = [];
  const targetLayer = 'ENGRAVE_LOGO_ON_LINE_0625';

  for (let i = 0; i < lines.length - 1; i++) {
    if (lines[i] === '0' && lines[i + 1] === 'LWPOLYLINE') {
      // Parse LWPOLYLINE
      let layer = '';
      let closed = false;
      const verts: LogoVertex[] = [];
      let cx = 0, cy = 0, cb = 0, hasVert = false;
      let j = i + 2;
      while (j < lines.length - 1) {
        const code = lines[j], val = lines[j + 1];
        if (code === '0') { if (hasVert) verts.push({ x: cx, y: cy, bulge: cb }); break; }
        if (code === '8') { layer = val; j += 2; }
        else if (code === '70') { closed = (parseInt(val) & 1) === 1; j += 2; }
        else if (code === '10') { if (hasVert) verts.push({ x: cx, y: cy, bulge: cb }); hasVert = true; cx = parseFloat(val) || 0; cb = 0; j += 2; }
        else if (code === '20') { cy = parseFloat(val) || 0; j += 2; }
        else if (code === '42') { cb = parseFloat(val) || 0; j += 2; }
        else { j += 2; }
      }
      if (layer === targetLayer && verts.length >= 2) polylines.push({ vertices: verts, closed });
    } else if (lines[i] === '0' && lines[i + 1] === 'LINE') {
      // Parse LINE entity
      let layer = '';
      let x1 = 0, y1 = 0, x2 = 0, y2 = 0;
      let j = i + 2;
      while (j < lines.length - 1) {
        const code = lines[j], val = lines[j + 1];
        if (code === '0') break;
        if (code === '8') { layer = val; j += 2; }
        else if (code === '10') { x1 = parseFloat(val) || 0; j += 2; }
        else if (code === '20') { y1 = parseFloat(val) || 0; j += 2; }
        else if (code === '11') { x2 = parseFloat(val) || 0; j += 2; }
        else if (code === '21') { y2 = parseFloat(val) || 0; j += 2; }
        else { j += 2; }
      }
      if (layer === targetLayer) {
        polylines.push({ vertices: [{ x: x1, y: y1, bulge: 0 }, { x: x2, y: y2, bulge: 0 }], closed: false });
      }
    }
  }
  return polylines;
}

/** Calculate arc center from two points and bulge value (DXF convention) */
function arcCenterFromBulge(p1x: number, p1y: number, p2x: number, p2y: number, bulge: number): { cx: number; cy: number } {
  const mx = (p1x + p2x) / 2, my = (p1y + p2y) / 2;
  const dx = p2x - p1x, dy = p2y - p1y;
  const chord = Math.sqrt(dx * dx + dy * dy);
  if (chord < 1e-10) return { cx: mx, cy: my };
  const sagitta = Math.abs(bulge) * chord / 2;
  const radius = chord * (1 + bulge * bulge) / (4 * Math.abs(bulge));
  const dist = radius - sagitta;
  const px = -dy / chord, py = dx / chord; // perpendicular unit vector
  if (bulge > 0) return { cx: mx + px * dist, cy: my + py * dist };
  return { cx: mx - px * dist, cy: my - py * dist };
}

/** Return the point reached after travelling `distance` along a DXF bulge arc. */
function pointAlongBulgeArc(
  start: { x: number; y: number },
  end: { x: number; y: number },
  bulge: number,
  distance: number,
): { point: { x: number; y: number }; center: { cx: number; cy: number } } | null {
  if (!Number.isFinite(bulge) || Math.abs(bulge) < 1e-12) return null;
  const center = arcCenterFromBulge(start.x, start.y, end.x, end.y, bulge);
  const radius = Math.hypot(start.x - center.cx, start.y - center.cy);
  const sweep = 4 * Math.atan(bulge);
  const arcLength = radius * Math.abs(sweep);
  if (!Number.isFinite(arcLength) || arcLength < 1e-9) return null;

  const fraction = Math.max(0, Math.min(1, distance / arcLength));
  const angle = Math.atan2(start.y - center.cy, start.x - center.cx) + sweep * fraction;
  return {
    point: {
      x: center.cx + radius * Math.cos(angle),
      y: center.cy + radius * Math.sin(angle),
    },
    center,
  };
}

/** Format a coordinate value for XXL output (mm, 3 decimal places) */
function xxlF(v: number): string { return v.toFixed(3); }

/**
 * Generate "On Line" logo toolpath XXL from a logo DXF.
 * Traces each polyline outline with G1 (straight) and G2/G3 (arc) commands.
 * Matches desktop LogoToolpathGenerator.cs
 */
export function generateOnLineLogoToolpath(
  logoDxfContent: string,
  buildStrength: string,
  materialThicknessMm?: number,
): string | null {
  const polylines = parseLogoDxfForToolpath(logoDxfContent);
  if (polylines.length === 0) return null;

  const matThick = materialThicknessMm
    ?? (buildStrength.toUpperCase().includes('HEAVY') ? 24.0 : 18.0);
  const xxl: string[] = [];

  // Header
  xxl.push(`H DX=2438.4 DY=1219.2 DZ=${matThick.toFixed(3)} BX=0 BY=0 BZ=0 -AB V=10 T=0 R=0 *MM /"def" `);
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Program Info vvv');
  xxl.push(';================================');
  xxl.push(';');
  xxl.push(';Name: Logo On');
  xxl.push(';');
  xxl.push(';Tools Used:');
  xxl.push(';104 = End Mill (0.125 inch) - Down Spiral');
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Setup Commands vvv');
  xxl.push(';================================');
  xxl.push(';');
  xxl.push('SY=0 M=1');
  xxl.push('C=0');
  xxl.push('SET ZFAST=38.100');
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Begin Operations vvv');
  xxl.push(';================================');
  xxl.push(';');
  xxl.push(`;================================================================`);
  xxl.push(`;Operation   : Logo On`);
  xxl.push(`;Tool used   : End Mill (0.125 inch) - Down Spiral`);
  xxl.push(`;Feed Rate   : V=${LOGO_FEED} mm/min`);
  xxl.push(`;Plunge Rate : V=${LOGO_PLUNGE} mm/min`);
  xxl.push(`;Spindle RPM : S=${LOGO_RPM} RPM`);
  xxl.push(`;================================================================`);
  xxl.push(';');

  for (const poly of polylines) {
    const rawPtsRaw = poly.vertices.map(v => ({ x: v.x * IN_TO_MM, y: v.y * IN_TO_MM, bulge: v.bulge }));
    if (rawPtsRaw.length < 2) continue;

    // Some EPS-to-DXF converters emit closed shapes as OPEN LWPOLYLINEs that
    // close themselves by duplicating the start vertex at the end (bit 0 of
    // code 70 stays clear). Treat these as closed: strip the duplicate and
    // flip the local closed flag so the rotation, close-back, and overcut
    // blocks all fire.
    let isClosed = poly.closed;
    let rawPts = rawPtsRaw;
    if (!isClosed && rawPtsRaw.length >= 3) {
      const f = rawPtsRaw[0], l = rawPtsRaw[rawPtsRaw.length - 1];
      if (Math.abs(f.x - l.x) < 1e-4 && Math.abs(f.y - l.y) < 1e-4) {
        isClosed = true;
        rawPts = rawPtsRaw.slice(0, -1);
      }
    }

    // SCM Xilog Plus rejects G2/G3 commands whose implicit start point is off
    // the arc. The G1 chord ramp on the first segment lands the bit ~1mm
    // inside the arc when the first segment is curved, then the next G2/G3
    // (still using the original arc center) has a mismatched start radius
    // and SCM bails with "Value of radius of arc not valid".
    //
    // Closed polylines have an arbitrary start vertex — rotating the vertex
    // order so the chord ramp lands on a STRAIGHT segment fixes the issue
    // without changing the cut path. Bulge[i] describes segment i→i+1, so
    // rotating preserves the per-segment bulge association cyclically.
    //
    // If every segment is curved, the ramp block below follows the first arc
    // instead of using a chord, so its following G2/G3 remains radius-valid.
    let pts = rawPts;
    if (isClosed && rawPts.length >= 3 && rawPts[0].bulge !== 0) {
      let straightIdx = -1;
      for (let i = 0; i < rawPts.length; i++) {
        if (rawPts[i].bulge === 0) { straightIdx = i; break; }
      }
      if (straightIdx > 0) {
        pts = [...rawPts.slice(straightIdx), ...rawPts.slice(0, straightIdx)];
      }
    }

    const start = pts[0];

    // Rapid to safe height above start
    xxl.push(`G0 X=${xxlF(start.x)} Y=${xxlF(start.y)} Z=${xxlF(LOGO_SAFE_Z)} T=${LOGO_TOOL} V=${LOGO_PLUNGE} S=${LOGO_RPM} E=0`);
    // Rapid to approach height
    xxl.push(`G0 X=${xxlF(start.x)} Y=${xxlF(start.y)} Z=${xxlF(LOGO_APPROACH_Z)} T=${LOGO_TOOL} V=${LOGO_PLUNGE} S=${LOGO_RPM} E=0`);
    // Plunge to surface
    xxl.push(`G1 X=${xxlF(start.x)} Y=${xxlF(start.y)} Z=0.000 V=${LOGO_PLUNGE}`);

    // Ramp into cut depth along first segment
    const second = pts[1];
    const dx = second.x - start.x, dy = second.y - start.y;
    const segLen = Math.sqrt(dx * dx + dy * dy);
    let rampedToSecond = false;

    if (pts[0].bulge !== 0) {
      const arcRamp = pointAlongBulgeArc(start, second, pts[0].bulge, LOGO_RAMP_MM);
      if (arcRamp) {
        const cmd = pts[0].bulge > 0 ? 'G3' : 'G2';
        const rampEnd = arcRamp.point;
        const reachesSecond = Math.hypot(rampEnd.x - second.x, rampEnd.y - second.y) < 1e-6;
        xxl.push(`${cmd} X=${xxlF(rampEnd.x)} Y=${xxlF(rampEnd.y)} Z=${xxlF(LOGO_CUT_Z)} I=${xxlF(arcRamp.center.cx)} J=${xxlF(arcRamp.center.cy)} V=${LOGO_PLUNGE}`);
        if (!reachesSecond) {
          xxl.push(`${cmd} X=${xxlF(second.x)} Y=${xxlF(second.y)} Z=${xxlF(LOGO_CUT_Z)} I=${xxlF(arcRamp.center.cx)} J=${xxlF(arcRamp.center.cy)} V=${LOGO_FEED}`);
        }
        rampedToSecond = true;
      } else {
        // Degenerate curved metadata cannot form a valid arc. Preserve a safe
        // linear move rather than emitting a controller-invalid G2/G3.
        xxl.push(`G1 X=${xxlF(second.x)} Y=${xxlF(second.y)} Z=${xxlF(LOGO_CUT_Z)} V=${LOGO_PLUNGE}`);
        rampedToSecond = true;
      }
    } else if (segLen >= LOGO_RAMP_MM && segLen > 1e-6) {
      // Ramp over 6.35mm along direction to second point
      const nx = dx / segLen, ny = dy / segLen;
      const rx = start.x + nx * LOGO_RAMP_MM, ry = start.y + ny * LOGO_RAMP_MM;
      xxl.push(`G1 X=${xxlF(rx)} Y=${xxlF(ry)} Z=${xxlF(LOGO_CUT_Z)} V=${LOGO_PLUNGE}`);
    } else {
      // Segment shorter than ramp — ramp directly to second point
      xxl.push(`G1 X=${xxlF(second.x)} Y=${xxlF(second.y)} Z=${xxlF(LOGO_CUT_Z)} V=${LOGO_PLUNGE}`);
      rampedToSecond = true;
    }

    // Feed through remaining points at cut depth
    const startIdx = rampedToSecond ? 2 : 1;
    for (let k = startIdx; k < pts.length; k++) {
      const prev = pts[k - 1];
      const pt = pts[k];
      if (prev.bulge !== 0) {
        const ac = arcCenterFromBulge(prev.x, prev.y, pt.x, pt.y, prev.bulge);
        const cmd = prev.bulge > 0 ? 'G3' : 'G2';
        xxl.push(`${cmd} X=${xxlF(pt.x)} Y=${xxlF(pt.y)} Z=${xxlF(LOGO_CUT_Z)} I=${xxlF(ac.cx)} J=${xxlF(ac.cy)} V=${LOGO_FEED}`);
      } else {
        xxl.push(`G1 X=${xxlF(pt.x)} Y=${xxlF(pt.y)} Z=${xxlF(LOGO_CUT_Z)} V=${LOGO_FEED}`);
      }
    }

    // If closed polyline, feed back to start
    if (isClosed && pts.length >= 3) {
      const lastPt = pts[pts.length - 1];
      if (lastPt.bulge !== 0) {
        const ac = arcCenterFromBulge(lastPt.x, lastPt.y, start.x, start.y, lastPt.bulge);
        const cmd = lastPt.bulge > 0 ? 'G3' : 'G2';
        xxl.push(`${cmd} X=${xxlF(start.x)} Y=${xxlF(start.y)} Z=${xxlF(LOGO_CUT_Z)} I=${xxlF(ac.cx)} J=${xxlF(ac.cy)} V=${LOGO_FEED}`);
      } else {
        xxl.push(`G1 X=${xxlF(start.x)} Y=${xxlF(start.y)} Z=${xxlF(LOGO_CUT_Z)} V=${LOGO_FEED}`);
      }

      // Overcut past the start point along the first segment at full cut depth.
      // The ramp-in (plunge to surface, then ramp down over LOGO_RAMP_MM) cuts
      // the first ~6.35mm of the polyline at partial depth, leaving residual
      // material right at start that never gets re-cut. Without this overcut,
      // sharp corners near the EPS-chosen start point show visible tabs of
      // uncut fibers. Matches the overcut pattern in NestedSheet CutOut/
      // CutInside profiles and the desktop LogoToolpathGenerator.cs fix
      // applied 2026-04-23.
      const osDx = second.x - start.x;
      const osDy = second.y - start.y;
      const osSegLen = Math.sqrt(osDx * osDx + osDy * osDy);
      if (osSegLen > 0.001) {
        const osDirX = osDx / osSegLen;
        const osDirY = osDy / osSegLen;
        const osDist = Math.min(LOGO_RAMP_MM, osSegLen);
        const osX = start.x + osDirX * osDist;
        const osY = start.y + osDirY * osDist;
        xxl.push(`G1 X=${xxlF(osX)} Y=${xxlF(osY)} Z=${xxlF(LOGO_CUT_Z)} V=${LOGO_FEED}`);
      }
    }
  }

  // Footer
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Closing Commands vvv');
  xxl.push(';================================');
  xxl.push(';');
  xxl.push('N X=0 Y=0');

  return xxl.join('\n') + '\n';
}

// ─── Box Dieline Toolpath Generation (.xxl) ──────────────────────────────────
// Auto-generates the cardboard plotter XXL alongside the box dieline DXF, so
// the operator doesn't have to open VCarve and run the toolpath wizard by hand.
// Modeled on the reference XXL at:
//   CNC Files/0000 - Adire Enclosures/DC-LVL3-D12-RD/Box-DC-LVL3-D12-RD.xxl
// Two operations: scoring (folds — half-thickness, ramp/reverse pattern) +
// perimeter (cuts — full-thickness, lead-in along the longest straight edge).

const BOX_TOOL = 103;
const BOX_RPM = 18000;
const BOX_FEED = 2540;            // mm/min cutting + scoring
const BOX_PLUNGE = 1842;          // mm/min plunge + ramp
const BOX_SAFE_Z = -38.1;         // 1.5" above material
const BOX_APPROACH_Z = -5.08;     // 0.2" above material
const BOX_FULL_DEPTH_Z = 6.35;    // 0.25" — full thickness through-cut
const BOX_SCORE_Z = 3.175;        // 0.125" — half thickness for fold creases
const BOX_RAMP_HALFWAY_Z = 1.587; // 0.0625" — quarter thickness, mid-ramp on score
const BOX_RAMP_MM = 50.8;         // 2" ramp distance for both score and cut lead-in
const BOX_THICKNESS_MM = 6.35;    // 0.25" cardboard

interface BoxFoldLine { x1: number; y1: number; x2: number; y2: number; }
interface BoxCutVertex { x: number; y: number; bulge: number; }

/** Parse a box dieline DXF for the closed cuts polyline + fold LINE entities.
 *  The dieline uses old-style POLYLINE+VERTEX+SEQEND (AC1009), so the loop
 *  walks group codes manually. Returns coords in DXF units (inches). */
function parseBoxDxfForToolpath(dxfContent: string): {
  cuts: BoxCutVertex[] | null;
  folds: BoxFoldLine[];
} {
  const lines = dxfContent.split('\n').map(l => l.trim());
  let cuts: BoxCutVertex[] | null = null;
  const folds: BoxFoldLine[] = [];

  for (let i = 0; i < lines.length - 1; i++) {
    if (lines[i] !== '0') continue;
    const entity = lines[i + 1];

    if (entity === 'POLYLINE') {
      // Walk the POLYLINE header until we hit the first VERTEX or SEQEND
      let layer = '';
      let j = i + 2;
      while (j < lines.length - 1) {
        const code = lines[j], val = lines[j + 1];
        if (code === '0') break;
        if (code === '8') layer = val;
        j += 2;
      }
      // Then accumulate VERTEX entries until SEQEND
      const verts: BoxCutVertex[] = [];
      while (j < lines.length - 1) {
        if (lines[j] === '0' && lines[j + 1] === 'VERTEX') {
          let vx = 0, vy = 0, vb = 0;
          let k = j + 2;
          while (k < lines.length - 1) {
            const c = lines[k], v = lines[k + 1];
            if (c === '0') break;
            if (c === '10') vx = parseFloat(v) || 0;
            else if (c === '20') vy = parseFloat(v) || 0;
            else if (c === '42') vb = parseFloat(v) || 0;
            k += 2;
          }
          verts.push({ x: vx, y: vy, bulge: vb });
          j = k;
        } else if (lines[j] === '0' && lines[j + 1] === 'SEQEND') {
          break;
        } else {
          j += 2;
        }
      }
      // Only the cuts-layer polyline matters — the sheet outline is on its own layer
      // but we want to skip it (it would also parse as a POLYLINE). The cuts layer
      // is the only closed polyline we want to toolpath.
      if (layer === 'cuts' && verts.length >= 3) cuts = verts;
    } else if (entity === 'LINE') {
      let layer = '';
      let x1 = 0, y1 = 0, x2 = 0, y2 = 0;
      let j = i + 2;
      while (j < lines.length - 1) {
        const code = lines[j], val = lines[j + 1];
        if (code === '0') break;
        if (code === '8') layer = val;
        else if (code === '10') x1 = parseFloat(val) || 0;
        else if (code === '20') y1 = parseFloat(val) || 0;
        else if (code === '11') x2 = parseFloat(val) || 0;
        else if (code === '21') y2 = parseFloat(val) || 0;
        j += 2;
      }
      if (layer === 'folds') folds.push({ x1, y1, x2, y2 });
    }
  }

  return { cuts, folds };
}

/** Find the index of the vertex where the longest straight (zero-bulge) segment
 *  starts. We rotate the polyline so the cut lead-in/lead-out lands on a long
 *  straight edge — much safer for the bit than starting at a corner. */
function findLongestStraightStartIdx(verts: BoxCutVertex[]): number {
  let bestIdx = 0;
  let bestLen = -1;
  const n = verts.length;
  for (let i = 0; i < n; i++) {
    const a = verts[i], b = verts[(i + 1) % n];
    if (a.bulge !== 0) continue; // skip arcs
    const dx = b.x - a.x, dy = b.y - a.y;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len > bestLen) { bestLen = len; bestIdx = i; }
  }
  return bestIdx;
}

/**
 * Generate cardboard plotter XXL for a box dieline DXF. The DXF must be the
 * one produced by `generateBoxDielineDxf` / `generateSplitBoxDielineDxf` (AC1009
 * POLYLINE on layer "cuts" + LINE entities on layer "folds", coordinates in
 * inches with a "sheet" outline rectangle for VCarve auto-sizing).
 *
 * Returns the XXL text, or `null` if the DXF didn't contain a parseable cuts
 * polyline (shouldn't happen with our generator, but guards a malformed input).
 */
export function generateBoxToolpath(boxDxfContent: string, name: string): string | null {
  const { cuts, folds } = parseBoxDxfForToolpath(boxDxfContent);
  if (!cuts || cuts.length < 3) return null;

  // DXF coords are inches → mm for XXL output
  const cutsMm = cuts.map(v => ({ x: v.x * IN_TO_MM, y: v.y * IN_TO_MM, bulge: v.bulge }));
  const foldsMm = folds.map(f => ({
    x1: f.x1 * IN_TO_MM, y1: f.y1 * IN_TO_MM,
    x2: f.x2 * IN_TO_MM, y2: f.y2 * IN_TO_MM,
  }));

  // Rotate the cuts polyline so it starts at the longest straight edge — the
  // lead-in ramp and lead-out overcut both ride along that edge, and starting
  // at a corner would put the bit through a 90° turn at full depth.
  const startIdx = findLongestStraightStartIdx(cutsMm);
  const rotatedCuts = startIdx === 0
    ? cutsMm
    : [...cutsMm.slice(startIdx), ...cutsMm.slice(0, startIdx)];
  // Bulge[i] describes segment i→i+1 cyclically, so rotation preserves the
  // per-segment association (same logic the logo XXL uses).

  const xxl: string[] = [];

  // ── Header
  xxl.push(`H DX=2438.4 DY=1219.2 DZ=${BOX_THICKNESS_MM.toFixed(2)} BX=0 BY=0 BZ=0 -AB V=10 T=0 R=0 *MM /"def" `);
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Program Info vvv');
  xxl.push(';================================');
  xxl.push(';');
  xxl.push(`;Name: ${name}`);
  xxl.push(';');
  xxl.push(';Tools Used:');
  xxl.push(`;${BOX_TOOL} = End Mill (0.125 inch) - Cardboard Spiral`);
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Setup Commands vvv');
  xxl.push(';================================');
  xxl.push(';');
  xxl.push('SY=0 M=1');
  xxl.push('C=0');
  xxl.push('SET ZFAST=38.100');
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Begin Operations vvv');
  xxl.push(';================================');
  xxl.push(';');

  // ── Operation 1: Score the folds (half-thickness, ramp/reverse pattern)
  xxl.push(';================================================================');
  xxl.push(';Operation   : CUT_ON_FOLDS_350_DW__125_BIT');
  xxl.push(`;Tool used   : End Mill (0.125 inch) - Cardboard Spiral`);
  xxl.push(`;Feed Rate   : V=${BOX_FEED} mm/min`);
  xxl.push(`;Plunge Rate : V=${BOX_PLUNGE} mm/min`);
  xxl.push(`;Spindle RPM : S=${BOX_RPM} RPM`);
  xxl.push(';================================================================');
  xxl.push(';');

  for (const f of foldsMm) {
    const dx = f.x2 - f.x1, dy = f.y2 - f.y1;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len < 1e-3) continue;

    // Approach / plunge at start
    xxl.push(`G0 X=${xxlF(f.x1)} Y=${xxlF(f.y1)} Z=${xxlF(BOX_SAFE_Z)} T=${BOX_TOOL} V=${BOX_PLUNGE} S=${BOX_RPM} E=0 `);
    xxl.push(`G0 X=${xxlF(f.x1)} Y=${xxlF(f.y1)} Z=${xxlF(BOX_APPROACH_Z)} T=${BOX_TOOL} V=${BOX_PLUNGE} S=${BOX_RPM} E=0 `);
    xxl.push(`G1 X=${xxlF(f.x1)} Y=${xxlF(f.y1)} Z=0.000 V=${BOX_PLUNGE} `);

    if (len >= BOX_RAMP_MM) {
      // Ramp/reverse: the example gets the start point to full half-depth by
      // ramping forward 50.8mm to quarter-depth, then reversing back to start
      // at half-depth (so the bit is at the right depth right at the start).
      const nx = dx / len, ny = dy / len;
      const rx = f.x1 + nx * BOX_RAMP_MM, ry = f.y1 + ny * BOX_RAMP_MM;
      xxl.push(`G1 X=${xxlF(rx)} Y=${xxlF(ry)} Z=${xxlF(BOX_RAMP_HALFWAY_Z)} V=${BOX_PLUNGE} `);
      xxl.push(`G1 X=${xxlF(f.x1)} Y=${xxlF(f.y1)} Z=${xxlF(BOX_SCORE_Z)} V=${BOX_PLUNGE} `);
      xxl.push(`G1 X=${xxlF(f.x2)} Y=${xxlF(f.y2)} Z=${xxlF(BOX_SCORE_Z)} V=${BOX_FEED}`);
    } else {
      // Fold shorter than ramp distance — plunge directly to half-depth and cut.
      // Rare (would only happen for very small boxes) but guards the math.
      xxl.push(`G1 X=${xxlF(f.x1)} Y=${xxlF(f.y1)} Z=${xxlF(BOX_SCORE_Z)} V=${BOX_PLUNGE} `);
      xxl.push(`G1 X=${xxlF(f.x2)} Y=${xxlF(f.y2)} Z=${xxlF(BOX_SCORE_Z)} V=${BOX_FEED}`);
    }
  }

  // ── Operation 2: Cut out the perimeter (full thickness, lead-in/lead-out)
  xxl.push(';');
  xxl.push(';================================================================');
  xxl.push(';Operation   : CUT_OUT_350_DW');
  xxl.push(`;Tool used   : End Mill (0.125 inch) - Cardboard Spiral`);
  xxl.push(`;Feed Rate   : V=${BOX_FEED} mm/min`);
  xxl.push(`;Plunge Rate : V=${BOX_PLUNGE} mm/min`);
  xxl.push(`;Spindle RPM : S=${BOX_RPM} RPM`);
  xxl.push(';================================================================');
  xxl.push(';');

  // Lead-in: pick a point along the first straight segment, ramp to full depth.
  // The first segment after rotation IS the longest straight edge, so this is
  // safe even if the ramp distance is large.
  const v0 = rotatedCuts[0];
  const v1 = rotatedCuts[1 % rotatedCuts.length];
  const fdx = v1.x - v0.x, fdy = v1.y - v0.y;
  const fLen = Math.sqrt(fdx * fdx + fdy * fdy);

  // Approach point sits 50.8mm INTO the first segment (so the ramp lands at v0+50.8mm,
  // then the cut continues through v0... wait, that's wrong direction).
  // Re-read the example: approach is BEFORE the polyline start, ramping TOWARD the
  // start. So the approach is OUTSIDE the polyline — but the cut needs to follow
  // the polyline path, which means the approach must be on the closing edge
  // (from last vertex back to first). Since we rotated to start on the longest
  // straight edge, the first segment IS that edge — and the approach point sits
  // 50.8mm INTO that segment, ramping to full depth at the segment's midpoint.
  //
  // Simpler: approach AT v0, ramp 50.8mm forward (toward v1) to full depth.
  // The remainder of the segment + the rest of the polyline is at full depth.
  // After closing back to v0, overcut another 50.8mm in the same direction.
  // This re-cuts the ramped section at full depth (cleans up the partial-depth
  // entry) — same idea as the logo XXL overcut.

  xxl.push(`G0 X=${xxlF(v0.x)} Y=${xxlF(v0.y)} Z=${xxlF(BOX_SAFE_Z)} T=${BOX_TOOL} V=${BOX_PLUNGE} S=${BOX_RPM} E=0 `);
  xxl.push(`G0 X=${xxlF(v0.x)} Y=${xxlF(v0.y)} Z=${xxlF(BOX_APPROACH_Z)} T=${BOX_TOOL} V=${BOX_PLUNGE} S=${BOX_RPM} E=0 `);
  xxl.push(`G1 X=${xxlF(v0.x)} Y=${xxlF(v0.y)} Z=0.000 V=${BOX_PLUNGE} `);

  let rampedToV1 = false;
  if (fLen >= BOX_RAMP_MM) {
    const nx = fdx / fLen, ny = fdy / fLen;
    const rx = v0.x + nx * BOX_RAMP_MM, ry = v0.y + ny * BOX_RAMP_MM;
    xxl.push(`G1 X=${xxlF(rx)} Y=${xxlF(ry)} Z=${xxlF(BOX_FULL_DEPTH_Z)} V=${BOX_PLUNGE} `);
    // Continue at full depth to v1
    xxl.push(`G1 X=${xxlF(v1.x)} Y=${xxlF(v1.y)} Z=${xxlF(BOX_FULL_DEPTH_Z)} V=${BOX_FEED}`);
    rampedToV1 = true;
  } else {
    // Rare: first segment shorter than 50.8mm (only happens when polyline has
    // no straight segment ≥ 50.8mm, e.g. a tiny box). Ramp directly to v1.
    if (v0.bulge !== 0) {
      const ac = arcCenterFromBulge(v0.x, v0.y, v1.x, v1.y, v0.bulge);
      const cmd = v0.bulge > 0 ? 'G3' : 'G2';
      xxl.push(`${cmd} X=${xxlF(v1.x)} Y=${xxlF(v1.y)} Z=${xxlF(BOX_FULL_DEPTH_Z)} I=${xxlF(ac.cx)} J=${xxlF(ac.cy)} V=${BOX_PLUNGE}`);
    } else {
      xxl.push(`G1 X=${xxlF(v1.x)} Y=${xxlF(v1.y)} Z=${xxlF(BOX_FULL_DEPTH_Z)} V=${BOX_PLUNGE}`);
    }
    rampedToV1 = true;
  }

  // Walk the rest of the polyline at full depth
  const startK = rampedToV1 ? 2 : 1;
  for (let k = startK; k < rotatedCuts.length; k++) {
    const prev = rotatedCuts[k - 1];
    const pt = rotatedCuts[k];
    if (prev.bulge !== 0) {
      const ac = arcCenterFromBulge(prev.x, prev.y, pt.x, pt.y, prev.bulge);
      const cmd = prev.bulge > 0 ? 'G3' : 'G2';
      xxl.push(`${cmd} X=${xxlF(pt.x)} Y=${xxlF(pt.y)} Z=${xxlF(BOX_FULL_DEPTH_Z)} I=${xxlF(ac.cx)} J=${xxlF(ac.cy)} V=${BOX_FEED}`);
    } else {
      xxl.push(`G1 X=${xxlF(pt.x)} Y=${xxlF(pt.y)} Z=${xxlF(BOX_FULL_DEPTH_Z)} V=${BOX_FEED}`);
    }
  }

  // Close back to the start vertex
  const lastPt = rotatedCuts[rotatedCuts.length - 1];
  if (lastPt.bulge !== 0) {
    const ac = arcCenterFromBulge(lastPt.x, lastPt.y, v0.x, v0.y, lastPt.bulge);
    const cmd = lastPt.bulge > 0 ? 'G3' : 'G2';
    xxl.push(`${cmd} X=${xxlF(v0.x)} Y=${xxlF(v0.y)} Z=${xxlF(BOX_FULL_DEPTH_Z)} I=${xxlF(ac.cx)} J=${xxlF(ac.cy)} V=${BOX_FEED}`);
  } else {
    xxl.push(`G1 X=${xxlF(v0.x)} Y=${xxlF(v0.y)} Z=${xxlF(BOX_FULL_DEPTH_Z)} V=${BOX_FEED}`);
  }

  // Overcut: continue 50.8mm past v0 along the first segment to re-cut the
  // partial-depth ramp section at full depth. Caps at first-segment length so
  // the overcut doesn't shoot past v1.
  if (fLen > 1e-3) {
    const nx = fdx / fLen, ny = fdy / fLen;
    const od = Math.min(BOX_RAMP_MM, fLen);
    const ox = v0.x + nx * od, oy = v0.y + ny * od;
    xxl.push(`G1 X=${xxlF(ox)} Y=${xxlF(oy)} Z=${xxlF(BOX_FULL_DEPTH_Z)} V=${BOX_FEED}`);
  }

  // ── Footer
  xxl.push(';');
  xxl.push(';================================');
  xxl.push(';vvv Closing Commands vvv');
  xxl.push(';================================');
  xxl.push(';');
  xxl.push('N X=0 Y=0');

  return xxl.join('\n') + '\n';
}

// ─── ACC File Generation ──────────────────────────────────────────────────────
// ACC files contain drill/dowel coordinates for CNC machines.
// Baseline 7 files per design, numbered 01-07, matching desktop
// AccFileGenerator.cs. Optional SUPB gusset is 08; labyrinth PP3+ use 09+.

/** Format a coordinate value: 6 decimal places, max 8 chars, left-padded with spaces */
function formatAccValue(value: number): string {
  if (!isFinite(value)) value = 0;
  value = Math.round(value * 1000000) / 1000000; // round to 6dp
  let s = value.toFixed(6);
  if (s.length < 8) s = s.padStart(8, ' ');
  else if (s.length > 8) s = s.substring(0, 8);
  return s;
}

/** Generate a single ACC file's text content */
function generateAccFileContent(values: number[]): string {
  // Distinct + sorted ascending
  const unique = [...new Set(values.map(v => Math.round(v * 1000000) / 1000000))].sort((a, b) => a - b);
  const lines: string[] = [];
  lines.push('HPJ Program File');
  lines.push('Version Number');
  lines.push('66049');
  lines.push('Zones');
  lines.push('1');
  lines.push('Glue Time');
  lines.push('30');
  lines.push('Num Items');
  lines.push(String(unique.length));
  lines.push('Num\tX\t\tDrill\tDowel  Drill3');
  for (let i = 0; i < unique.length; i++) {
    lines.push(`${i + 1}\t${formatAccValue(unique[i])}\tYes\tNo    No`);
  }
  return lines.join('\r\n') + '\r\n';
}

interface AccCoordinateSets {
  backY: number[];       // 01: Back panel Y drill positions (part-relative)
  baffleX: number[];     // 02: Baffle hole X positions on bottom panel
  sideLeftY: number[];   // 03: Side Left hole Y positions
  sideRightY: number[];  // 04: Side Right hole Y positions
  bottomBackX: number[]; // 05: Back edge hole X positions on bottom panel
  port1Y: number[];      // 06: Port 1 hole Y positions
  port2X: number[];      // 07: Port 2 hole X positions
  /** 08 (SUPB multi-sub only): Gusset dowel positions on Top + Bottom panels.
   *  Empty array for SBPB / single-sub / non-SUPB designs. When non-empty,
   *  contains [gussetX_1, gussetX_2, ..., depthInsetFromSubY] — the X
   *  positions of each gusset dowel column (panel-local, world coords),
   *  followed by the symmetric Y inset from subY at which the two dowels
   *  per gusset are drilled (always 1.25"). */
  supbGussetXY: number[];
  /** Labyrinth PP3+ alignment programs. PP2 retains established file 07;
   *  PP3 begins at 09 so optional SUPB gusset file 08 never changes meaning. */
  labyrinthDividers: Array<{ partNumber: number; values: number[] }>;
  /** True when the design is a kerf port (merged 'Baffle + Port 1' bent piece).
   *  File 06 (Port 1) is dropped and the ACC numbering intentionally jumps
   *  05 → 07, since the baffle + port-1 are one piece with no separate port-1
   *  dowel pass. File 02 (Baffle) is drilled across the bent piece's baffle leg. */
  isKerf: boolean;
}

/**
 * Collect ACC coordinate sets from the design parameters.
 * Matches desktop DxfPartGenerator + DrillHoleGenerator coordinate collection.
 */
function collectAccCoordinates(opts: GenerateAllOptions, cutList: CutListItem[]): AccCoordinateSets {
  const bs = opts.buildStrength || '';
  const isBirch = opts.isBirchPly !== false;
  const isDualPort = opts.portQuantity === 'Dual';
  // Exact match — NOT `.includes('Subs Up')`, since 'Subs Up/Port Up'
  // would falsely trigger SUPB-specific ACC handling. SUPB has top-firing
  // subs with their own panel positioning; 'Subs Up/Port Up' is logically
  // 'Subs Back/Port Back' just rotated for visualization, so it should
  // take the default branch.
  const isSUPB = opts.enclosureConfiguration === 'Subs Up/Port Back';

  const backPart = cutList.find(p => p.partName === 'Back');
  const bafflePart = cutList.find(p => p.partName === 'Baffle');
  const port1Part = cutList.find(p => p.partName === 'Port Piece 1' || p.partName === 'Port Piece 1 Left');
  const port2Part = cutList.find(p => p.partName === 'Port Piece 2' || p.partName === 'Port Piece 2 Left');
  const topPart = cutList.find(p => p.partName === 'Top');

  // Kerf port: the baffle + Port 1 are built as ONE kerf-bent piece, emitted in
  // the cut list as 'Baffle + Port 1' (no standalone 'Baffle' or 'Port Piece 1').
  // File 02 (Baffle) drills across the bent piece's flat baffle LEG; file 06
  // (Port 1) is dropped entirely (see generateAccFiles). Per operator decision.
  const kerfMergedPart = cutList.find(p => p.partName === 'Baffle + Port 1');
  const kerfGeo = kerfMergedPart?.kerf;
  const isKerf = !!kerfGeo;

  const extraBack = opts.extraHolesBack ?? 2;
  const extraFront = opts.extraHolesFront ?? 2;
  const extraRight = opts.extraHolesRight ?? 1;
  const extraLeft = opts.extraHolesLeft ?? 1;
  const extraHeight = opts.extraHolesHeight ?? 0;

  // 01: backY — Y positions of holes on Back panel (part-relative)
  // Desktop: 1.25, height - 1.25, extras based on HeightExtraHoles
  const backY: number[] = [];
  if (backPart) {
    backY.push(CORNER_INSET);
    backY.push(backPart.height - CORNER_INSET);
    if (extraHeight > 0) {
      const span = backPart.height - 2 * CORNER_INSET;
      for (let i = 1; i <= extraHeight; i++) {
        backY.push(CORNER_INSET + span * i / (extraHeight + 1));
      }
    }
  }

  // 02: baffleX — rectangle WIDTHS of baffle guide rects on bottom panel
  // Desktop: rectangleWidth = drawX - baffleOffset = x (baffle-relative), so [1.25, baffleWidth - 1.25, extras]
  // Kerf port: drill across the bent piece's flat baffle LEG (kerf.baffleRunIn),
  // not the full developed length — the bend zone + PP1 leg are past the holes.
  const baffleDrillWidth = kerfGeo ? kerfGeo.baffleRunIn : bafflePart?.width;
  const baffleX: number[] = [];
  if (baffleDrillWidth !== undefined) {
    baffleX.push(CORNER_INSET);
    baffleX.push(baffleDrillWidth - CORNER_INSET);
    const frontSpan = baffleDrillWidth - 2 * CORNER_INSET;
    for (let i = 1; i <= extraFront; i++) {
      baffleX.push(CORNER_INSET + frontSpan * i / (extraFront + 1));
    }
  }

  // Bottom panel height = enclosure DEPTH = topPart.height (NOT backPart.height which is enclosure HEIGHT)
  // Desktop DrillHoleGenerator uses the Bottom panel's height parameter = enclosure depth
  const bottomH = topPart?.height ?? 0;

  // yOffset = port base offset (where port guide rects start on the bottom panel Y axis)
  const yOffset = getPortBaseOffset(
    bs,
    isBirch,
    isSUPB,
    !!opts.recessedMounting,
    opts.materialConfig,
    opts.glueTolerance,
  );

  // 03: sideLeftY — rectangle HEIGHTS of left-side guide rects on bottom panel
  // Desktop: rectangleHeight = y - leftSideStartY
  //   leftSideStartY = isDualPort ? 0 : yOffset
  //   y positions come from GetSideHoleYPositions("Left")
  const leftInsets = getLeftSideInsets(
    bs,
    isBirch,
    isDualPort,
    !!opts.recessedMounting,
    opts.materialConfig,
    opts.glueTolerance,
  );
  const leftSideStartY = isDualPort ? 0 : yOffset;
  const sideLeftY: number[] = [];
  if (bottomH > 0) {
    sideLeftY.push(leftInsets.bottomInset - leftSideStartY);
    sideLeftY.push(bottomH - leftInsets.topInset - leftSideStartY);
    const leftSpan = (bottomH - leftInsets.topInset) - leftInsets.bottomInset;
    for (let i = 1; i <= extraLeft; i++) {
      sideLeftY.push(leftInsets.bottomInset - leftSideStartY + leftSpan * i / (extraLeft + 1));
    }
  }

  // 04: sideRightY — rectangle HEIGHTS of right-side guide rects on bottom panel
  // Desktop: rectangleHeight = y - 0 = y (guide rect starts at Y=0), so values = hole Y positions
  const rightInsets = getRightSideInsets(bs, isBirch, opts.materialConfig, opts.glueTolerance);
  const sideRightY: number[] = [];
  if (bottomH > 0) {
    sideRightY.push(rightInsets.bottomInset);
    sideRightY.push(bottomH - rightInsets.topInset);
    const rightSpan = (bottomH - rightInsets.topInset) - rightInsets.bottomInset;
    for (let i = 1; i <= extraRight; i++) {
      sideRightY.push(rightInsets.bottomInset + rightSpan * i / (extraRight + 1));
    }
  }

  // 05: bottomBackX — rectangle WIDTHS of back-edge guide rects on bottom panel
  // Desktop: rectangleWidth = drawX = x (hole X position), so [1.25, width - 1.25, extras]
  const bottomBackX: number[] = [];
  if (topPart) {
    bottomBackX.push(CORNER_INSET);
    bottomBackX.push(topPart.width - CORNER_INSET);
    const backSpan = topPart.width - 2 * CORNER_INSET;
    for (let i = 1; i <= extraBack; i++) {
      bottomBackX.push(CORNER_INSET + backSpan * i / (extraBack + 1));
    }
  }

  // 06: port1Y — rectangle HEIGHT of port 1 guide rect on bottom panel
  // Desktop: port1HoleY = (Port1Width / 2) + yOffset, rectangleHeight = port1HoleY - yOffset = Port1Width / 2
  // Port1Width = GetDimension("Port1Width") = Port Piece 1 cut list width (NOT the port opening width)
  const port1Y: number[] = [];
  if (port1Part) {
    port1Y.push(port1Part.width / 2);
  }

  // 07: port2X — rectangle WIDTHS of port 2 guide rects on bottom panel
  // Desktop: |x - refX| where x = baffleEdge - 1.25 or baffleEdge - port2Width + 1.25, refX = baffleEdge
  // So port2X = [1.25, port2Width - 1.25]
  const port2X: number[] = [];
  if (port2Part) {
    port2X.push(...dividerAlignmentOffsets(port2Part.width));
  }

  const labyrinthDividers = opts.calc?.labyrinthPort?.active
    ? opts.calc.labyrinthPort.panels
      .filter(panel => panel.partNumber >= 3)
      .map(panel => {
        const part = cutList.find(item => item.partName === `Port Piece ${panel.partNumber}`);
        return {
          partNumber: panel.partNumber,
          values: dividerAlignmentOffsets(part?.width ?? 0),
        };
      })
      .filter(group => group.values.length > 0)
    : [];

  // 08: supbGussetXY — SUPB multi-sub gusset dowel positions on Top/Bottom.
  // Same dowel pattern drills both panels (one barcode = two passes), so the
  // operator only sees this 8th ACC file when isSUPB && subCount > 1. The
  // gusset's two dowels per panel-edge are always at subY ± 1.25".
  const supbGussetXY: number[] = [];
  const subCountForGusset = (() => {
    switch (opts.subwooferQuantity) {
      case 'Dual': return 2;
      case 'Triple': return 3;
      case 'Quad': return 4;
      default: return 1;
    }
  })();
  if (isSUPB && subCountForGusset > 1 && topPart) {
    const sharedLayout = !isDualPort && opts.inputs && opts.calc
      ? resolveSupbSubLayout(opts.inputs, opts.calc, cutList)
      : null;
    if (sharedLayout && !sharedLayout.safe) {
      throw new Error(`Subwoofer placement is unsafe: ${sharedLayout.diagnostic}`);
    }
    if (sharedLayout?.safe) {
      for (const gusset of sharedLayout.gussets) supbGussetXY.push(gusset.x);
    } else {
    const od = opts.outsideDiameter || opts.subCutoutDiameter || 0;
    const t = opts.materialThickness ?? fallbackThinIn(opts.isBirchPly !== false);
    const s2w = opts.s2LeftWidth || 0;
    const s1w = opts.s1RightWidth || 0;
    const s2EdgeClearance = (s2w - od * subCountForGusset) / (subCountForGusset + 1);
    const useCombined = !isDualPort && s2EdgeClearance <= 0;
    const chamberW = useCombined ? (s2w + s1w) : s2w;
    const subXOff = opts.subwooferXOffset ?? 0;
    const xPositions = chamberW > 0 && od > 0
      ? Array.from({ length: subCountForGusset }, (_, i) => {
          const gap = (chamberW - od * subCountForGusset) / (subCountForGusset + 1);
          return gap * (i + 1) + od * i + od / 2;
        })
      : [];
    for (let i = 0; i < xPositions.length - 1; i++) {
      supbGussetXY.push(t + subXOff + (xPositions[i] + xPositions[i + 1]) / 2);
    }
    }
    if (supbGussetXY.length > 0) {
      // Trailing value: the depth inset (1.25") from subY at which the two
      // dowels per gusset are drilled. Lets the drill machine derive both Y
      // positions from this single value + the operator-known subY.
      supbGussetXY.push(1.25);
    }
  }

  return {
    backY,
    baffleX,
    sideLeftY,
    sideRightY,
    bottomBackX,
    port1Y,
    port2X,
    supbGussetXY,
    labyrinthDividers,
    isKerf,
  };
}

/**
 * Generate the baseline ACC set plus optional gusset/labyrinth programs.
 * Returns array of GeneratedFile objects with .acc extension.
 */
function generateAccFiles(prefix: string, opts: GenerateAllOptions, cutList: CutListItem[]): Array<{ filename: string; content: string; type: 'acc' }> {
  const coords = collectAccCoordinates(opts, cutList);
  // Filename and barcode naming are centralized in acc-naming.ts. Do not
  // duplicate even part of the compact-name rule in this generator.

  // Fixed file numbers (NOT a running index) so dropping a file leaves a
  // deliberate numbering gap rather than renumbering everything after it.
  const groups: { num: number; values: number[]; name: string }[] = [
    { num: 1, values: coords.backY, name: 'Back (Y)' },
    { num: 2, values: coords.baffleX, name: 'Baffle Holes (X)' },
    { num: 3, values: coords.sideLeftY, name: 'Side Left Holes (Y)' },
    { num: 4, values: coords.sideRightY, name: 'Side Right Holes (Y)' },
    { num: 5, values: coords.bottomBackX, name: 'Back Holes (X)' },
  ];

  // 06 — Port 1. DROPPED for kerf-port designs: the baffle + port-1 are one
  // kerf-bent piece with no separate port-1 dowel pass, so the numbering jumps
  // 05 → 07 on purpose and Port 2 keeps its 07 barcode. Per operator decision.
  if (!coords.isKerf) {
    groups.push({ num: 6, values: coords.port1Y, name: 'Port1 Holes (Y)' });
  }
  groups.push({ num: 7, values: coords.port2X, name: 'Port2 Holes (X)' });

  // 08 — SUPB multi-sub gusset dowels. Conditionally emitted: only present
  // when the design is SUPB with ≥2 subs (never a kerf design — kerf is SBPB).
  // SBPB / single-sub designs keep the standard files; only SUPB multi-sub
  // jobs ever see this 8th file.
  if (coords.supbGussetXY.length > 0) {
    groups.push({ num: 8, values: coords.supbGussetXY, name: 'Top/Bottom Gusset' });
  }

  for (const divider of coords.labyrinthDividers) {
    groups.push({
      num: divider.partNumber + 6,
      values: divider.values,
      name: `Port${divider.partNumber} Holes (Y)`,
    });
  }

  return groups.map((group) => ({
    filename: accFilename(prefix, group.num),
    content: generateAccFileContent(group.values),
    type: 'acc' as const,
  }));
}

// ─── Barcode PDF Generation ──────────────────────────────────────────────────

/**
 * Generate a PDF page with CODE_128 barcodes for the design's ACC files.
 * Matches desktop PdfBarcodeGenerator: 8.5×11", 2-column grid (4 left, 3-4
 * right depending on barcode count). Must be called in a browser context
 * (uses DOM canvas + dynamic imports).
 *
 * `includeGusset` adds an 8th barcode for the SUPB multi-sub gusset dowel
 * file (file 08). Only pass true for SUPB designs with ≥2 subs — otherwise
 * the 8th file is never written by generateAccFiles and the barcode would
 * scan to nothing.
 */
export async function generateAccBarcodesPdf(
  prefix: string,
  backHeight: number,
  includeGusset: boolean = false,
  kerfPort: boolean = false,
  labyrinthPortPieceCount: number = 0,
): Promise<{ filename: string; blob: Blob }> {
  if (typeof document === 'undefined') throw new Error('generateAccBarcodesPdf requires a browser environment');

  const { jsPDF } = await import('jspdf');
  const JsBarcode = (await import('jsbarcode')).default;

  // Ordered (file number, display name) entries. MUST stay in lockstep with
  // generateAccFiles: same files, same FIXED numbers, so each printed barcode
  // resolves to a real .acc on disk. Display names match desktop
  // PdfBarcodeGenerator.GetDisplayNames(). For kerf-port designs, file 06
  // (Port 1) is dropped and the numbering jumps 05 → 07 (Port 2 keeps 07).
  const backHeightStr = backHeight > 0
    ? parseFloat(backHeight.toFixed(4)).toString()  // strip trailing zeros like C# "0.####"
    : '';
  const entries: { num: number; name: string }[] = [
    { num: 1, name: backHeightStr ? `${backHeightStr} Side` : 'Side' },
    { num: 2, name: 'Front' },
    { num: 3, name: 'Side 1 - Left' },
    { num: 4, name: 'Side 2 - Right' },
    { num: 5, name: 'Back' },
  ];
  if (!kerfPort) entries.push({ num: 6, name: 'Port 1' });
  entries.push({ num: 7, name: 'Port 2' });
  if (includeGusset) entries.push({ num: 8, name: 'Top/Bottom Gusset' });
  for (let partNumber = 3; partNumber <= labyrinthPortPieceCount; partNumber++) {
    entries.push({ num: partNumber + 6, name: `Port ${partNumber}` });
  }

  const pdf = new jsPDF({ orientation: 'portrait', unit: 'in', format: 'letter' });
  const pageWidth = 8.5;
  const pageHeight = 11.0;
  const margin = 0.5;
  const usableWidth = pageWidth - 2 * margin;

  const contentStartY = margin + 0.75;
  const colWidth = usableWidth / 2;
  const rowHeight = (pageHeight - contentStartY - margin) / 4;

  const drawTitle = (): void => {
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    pdf.text(prefix || 'ACC File Barcodes', pageWidth / 2, margin + 0.35, { align: 'center' });
  };
  drawTitle();

  // Eight entries fit per page (4 per column). Labyrinth sets continue onto
  // as many additional pages as required.
  for (let i = 0; i < entries.length; i++) {
    const localIndex = i % 8;
    if (i > 0 && localIndex === 0) {
      pdf.addPage('letter', 'portrait');
      drawTitle();
    }
    const col = localIndex < 4 ? 0 : 1;
    const row = localIndex < 4 ? localIndex : localIndex - 4;
    const cellX = margin + col * colWidth;
    const cellY = contentStartY + row * rowHeight;

    const barcodeContent = accBarcodeValue(prefix, entries[i].num);

    // Render barcode to an offscreen canvas then embed in PDF
    const canvas = document.createElement('canvas');
    try {
      JsBarcode(canvas, barcodeContent, {
        format: 'CODE128',
        width: 2,
        height: 80,
        displayValue: false,
        margin: 5,
      });
      const imgData = canvas.toDataURL('image/png');
      const barcodeW = colWidth - 0.4;
      const barcodeH = 0.8;
      pdf.addImage(imgData, 'PNG', cellX + 0.2, cellY + 0.1, barcodeW, barcodeH);
    } catch (e) {
      console.warn(`Barcode render failed for ${barcodeContent}:`, e);
    }

    // Barcode filename label (small, monospace-style)
    pdf.setFontSize(8);
    pdf.setFont('courier', 'normal');
    pdf.text(barcodeContent, cellX + colWidth / 2, cellY + 0.1 + 0.8 + 0.15, { align: 'center' });

    // Part display name (larger, bold)
    const partName = entries[i].name;
    pdf.setFontSize(13);
    pdf.setFont('helvetica', 'bold');
    pdf.text(partName, cellX + colWidth / 2, cellY + 0.1 + 0.8 + 0.38, { align: 'center' });
  }

  const blob = pdf.output('blob');
  return { filename: `${prefix}_ACC_Barcodes.pdf`, blob };
}

function labyrinthPlacementOptions(
  options: GenerateAllOptions,
  cutList: CutListItem[],
): PartDxfOptions {
  const baffle = cutList.find(part => part.partName === 'Baffle');
  return {
    buildStrength: options.buildStrength,
    isBirchPly: options.isBirchPly,
    enclosureConfiguration: options.enclosureConfiguration,
    portQuantity: options.portQuantity,
    portWidth: options.portWidth,
    baffleWidth: baffle?.width ?? 0,
    materialThickness: options.materialThickness,
    heavyThickness: options.heavyThickness,
    materialConfig: options.materialConfig,
    glueTolerance: options.glueTolerance,
    recessedMounting: options.recessedMounting,
    calc: options.calc,
    cutList,
  };
}

/** Bottom-view plan DXF used to audit the complete serpentine layout in CAM. */
function generateLabyrinthAssemblyReferenceDxf(
  options: GenerateAllOptions,
  cutList: CutListItem[],
): string | null {
  const layout = options.calc?.labyrinthPort;
  const top = cutList.find(part => part.partName === 'Top');
  if (!layout?.active || !top) return null;

  const placements = labyrinthDividerPlacements(
    top.width,
    top.height,
    labyrinthPlacementOptions(options, cutList),
  );
  if (placements.length !== layout.panels.length) return null;

  const outlineLayer = 'REFERENCE_ONLY_BOX_OUTLINE';
  let entities = dxfRect(outlineLayer, 0, 0, top.width, top.height);
  const layers: LayerDef[] = [{ name: outlineLayer, color: COLOR_GRAY }];
  for (const placement of placements) {
    const layer = `REFERENCE_PP${placement.partNumber}_${placement.anchoredAt.toUpperCase()}_ANCHOR`;
    entities += dxfRect(
      layer,
      placement.xRight - layout.dividerThickness,
      placement.yStart,
      layout.dividerThickness,
      placement.length,
    );
    layers.push({ name: layer, color: COLOR_MAGENTA_GUIDE });
  }
  return buildDxfDocument(entities, layers);
}

function generateLabyrinthReviewManifest(
  prefix: string,
  options: GenerateAllOptions,
  cutList: CutListItem[],
): string | null {
  const layout = options.calc?.labyrinthPort;
  const top = cutList.find(part => part.partName === 'Top');
  if (!layout?.active || !top) return null;
  const placements = labyrinthDividerPlacements(
    top.width,
    top.height,
    labyrinthPlacementOptions(options, cutList),
  );
  if (placements.length !== layout.panels.length) return null;

  const lines = [
    `Labyrinth Manufacturing Review — ${prefix}`,
    '='.repeat(72),
    'MANUAL REVIEW REQUIRED BEFORE PRODUCTION CUTTING.',
    '',
    `Activation: ${layout.reason}`,
    `Acoustic centerline length: ${layout.acousticLength.toFixed(4)} in`,
    `Port width: ${layout.portWidth.toFixed(4)} in`,
    `Divider thickness: ${layout.dividerThickness.toFixed(4)} in`,
    `Lane pitch: ${layout.lanePitch.toFixed(4)} in`,
    `Top/Bottom panel: ${top.width.toFixed(4)} x ${top.height.toFixed(4)} in`,
    '',
    'Coordinate convention:',
    '- Bottom DXF is the direct plan view (X left-to-right, Y front-to-back).',
    '- Top DXF mirrors X; Top drill X = panel width - Bottom drill X.',
    '- The right edge in every PP2+ part DXF is the machined anchor edge.',
    '- ASSEMBLY_FRONT_ANCHOR / ASSEMBLY_BACK_ANCHOR are reference-only layers.',
    '- Standard dividers use two Top/Bottom dowels 1.25 in from their ends;',
    '  a final divider 2.50 in or shorter uses one centered alignment dowel.',
    '',
    'Divider schedule:',
  ];

  for (const placement of placements) {
    const part = cutList.find(item => item.partName === `Port Piece ${placement.partNumber}`);
    const drillBottomX = placement.xRight - EDGE_INSET;
    const drillTopX = top.width - drillBottomX;
    const drillY = dividerAlignmentOffsets(placement.length)
      .map(offset => placement.yStart + offset);
    const accNumber = placement.partNumber === 1
      ? 6
      : placement.partNumber === 2
        ? 7
        : placement.partNumber + 6;
    lines.push(
      `PP${placement.partNumber}: cut ${part?.width.toFixed(4) ?? 'missing'} x ${part?.height.toFixed(4) ?? 'missing'} in; `
      + `${placement.anchoredAt.toUpperCase()} anchor; lane ${placement.partNumber}; ACC ${accNumber}`,
      `  guide: X ${(placement.xRight - GUIDE_WIDTH).toFixed(4)}..${placement.xRight.toFixed(4)}, `
      + `Y ${placement.yStart.toFixed(4)}..${(placement.yStart + placement.length).toFixed(4)}`,
      `  drill: Bottom X ${drillBottomX.toFixed(4)}, Top X ${drillTopX.toFixed(4)}, `
      + `Y ${drillY.map(value => value.toFixed(4)).join(', ') || 'none'}`,
    );
  }

  lines.push(
    '',
    'ACC numbering:',
    '- Existing programs remain fixed: 01..07; optional SUPB gusset remains 08.',
    '- Labyrinth Port 3 begins at 09; later pieces use ACC = port number + 6.',
    '',
  );
  return lines.join('\r\n');
}

// ─── Generate All Files ───────────────────────────────────────────────────────

export interface GeneratedFile {
  filename: string;
  content: string;
  type: 'dxf' | 'acc' | 'txt' | 'xxl';
}

export interface GenerateAllOptions {
  filenamePrefix: string;
  /** Canonical saved design name used only for ACC filenames. This must match
   *  the name Track prints on nesting labels; omit to use filenamePrefix. */
  accFilenamePrefix?: string;
  cutList: CutListItem[];
  subCutoutDiameter: number;
  outsideDiameter: number;
  subwooferQuantity: string;
  cartonLength: number;
  cartonWidth: number;
  cartonHeight: number;
  cardboardThickness: number;
  // Logo (optional) - EPS file content as string
  epsLogoContent?: string;
  logoMode?: 'On Line' | 'Pocket';
  enclosureConfiguration?: string; // 'Subs Back/Port Back' | 'Subs Up/Port Back'
  buildStrength?: string;          // 'Standard Duty' | 'Regular Duty' | 'Heavy Duty'
  isBirchPly?: boolean;            // true = Birch (mill-down), false = MDF
  portQuantity?: string;           // 'Single' | 'Dual'
  portWidth?: number;              // port opening width
  s2LeftWidth?: number;            // S2 Left chamber width (SUPB positioning)
  s1RightWidth?: number;           // S1 Right chamber width
  materialThickness?: number;      // primary wall thickness (B1/D1)
  heavyThickness?: number;         // heavy thickness (B2/D2)
  materialConfig?: MaterialConfig; // configured B/C/D dimensions for joinery placement
  glueTolerance?: number;          // clearance per mating edge (default 0.01")
  cutOutTolerance?: number;        // added to subwoofer cutout diameter (inches)
  // Extra hole counts (desktop BuildTabViewModel properties)
  extraHolesBack?: number;
  extraHolesFront?: number;
  extraHolesRight?: number;
  extraHolesLeft?: number;
  extraHolesHeight?: number;   // extra holes along height of Back/Baffle/Port2
  port2VerticalOffset?: number; // user-configurable Port 2 offset from Build tab
  // Terminal cup placement (mirrors PartDxfOptions; both undefined = legacy
  // hardcoded behavior of single→Side Left, dual→Back, centered).
  terminalPanel?: 'Side Left' | 'Back' | 'None';
  terminalXOffset?: number;
  // Subwoofer cutout placement override (SUPB only; both undefined = auto).
  subwooferXOffset?: number;
  subwooferYOffset?: number;
  /** Optional EnclosureInputs + EnclosureCalculations for engine-side
   *  defense-in-depth checks. When both are present, generateAllFiles resolves
   *  the shared SUPB layout before emitting DXF or ACC output, including
   *  default (non-customized) placements and invalid port geometry. */
  inputs?: EnclosureInputs;
  calc?: EnclosureCalculations;
  // Recessed (flush) sub mounting. Threads through to generatePartDxf to:
  //   - Override the structural baffle's hole to OD + 0.25" (recess)
  //   - Keep edge-joinery holes on the structural baffle using thin-stock layers
  //   - Force the material's thin-stock cut layers on the structural baffle
  //   - Generate a per-part DXF for the new 'Sub Mount Plate' cut list entry
  //     (outline + standard sub through-cutout, layer per plate thickness)
  recessedMounting?: boolean;
  // Acrylic window (V1) — see PartDxfOptions for field semantics. When
  // `windowEnabled` is true, generateAllFiles will:
  //   - Add the cutout + screw pilot ring to the host panel's DXF
  //     (panel auto-determined by enclosureConfiguration)
  //   - Emit a companion `Acrylic-{prefix}.dxf` — solid plate outline +
  //     screw clearance holes, ready for the laser/water-jet vendor
  windowEnabled?: boolean;
  windowSize?: '12x12' | '24x12' | 'custom';
  windowOrientation?: 'landscape' | 'portrait';
  windowXOffset?: number;
  windowYOffset?: number;
  windowCornerRadius?: number;
  windowCustomWidth?: number;
  windowCustomHeight?: number;
  /** Limit generation to the fast machine-file subsets used by Pricing batch
   *  exports. Omitted/'all' preserves the complete legacy output. */
  outputMode?: 'all' | 'acc' | 'logo';
}

/**
 * Generate all files for an enclosure design.
 * Returns an array of generated files (DXF content as strings).
 */
export function generateAllFiles(options: GenerateAllOptions): GeneratedFile[] {
  const {
    filenamePrefix,
    cutList,
    subCutoutDiameter,
    outsideDiameter,
    subwooferQuantity,
    cartonLength,
    cartonWidth,
    cartonHeight,
    cardboardThickness,
  } = options;

  const prefix = filenamePrefix || 'ENCLOSURE';
  const accPrefix = options.accFilenamePrefix || prefix;
  const files: GeneratedFile[] = [];
  const outputMode = options.outputMode ?? 'all';
  const includeFull = outputMode === 'all';
  const includeAcc = includeFull || outputMode === 'acc';
  const includeLogo = includeFull || outputMode === 'logo';

  // ── Terminal placement defense-in-depth check ────────────────────────────
  // Only enforce when the user opted into customization (either field set).
  // Legacy designs with both undefined keep today's hardcoded behavior even
  // if it would technically conflict — we don't want to retroactively block
  // saves that have always worked. UI-driven placements are gated by the
  // Design tab + handleSaveDesign before getting here, so this is the
  // last-line check for direct API callers, batch jobs with stale data, etc.
  // Skipped entirely when terminalPanel === 'None' (no cup, no conflicts to
  // check).
  if (includeFull &&
    (options.terminalPanel !== undefined || options.terminalXOffset !== undefined) &&
    options.terminalPanel !== 'None'
  ) {
    const isDualPort = options.portQuantity === 'Dual';
    const panel = options.terminalPanel ?? (isDualPort ? 'Back' : 'Side Left');
    const topPart = cutList.find(p => p.partName === 'Top');
    const boxWidthIn = topPart?.width ?? 0;
    const boxDepthIn = topPart?.height ?? 0;
    const pp1Part =
      cutList.find(p => p.partName === 'Port Piece 1') ??
      cutList.find(p => p.partName === 'Port Piece 1 Left');
    const pp1DepthIn = pp1Part?.width ?? 0;
    const pp2Part =
      cutList.find(p => p.partName === 'Port Piece 2') ??
      cutList.find(p => p.partName === 'Port Piece 2 Left');
    const pp2WidthIn = pp2Part?.width ?? 0;
    const bafflePart = cutList.find(p => p.partName === 'Baffle');
    const baffleTIn = bafflePart?.thickness ?? options.materialThickness ?? fallbackThinIn(options.isBirchPly !== false);
    const wallT = options.materialThickness ?? fallbackThinIn(options.isBirchPly !== false);
    const panelWidth = panel === 'Side Left' ? boxDepthIn : boxWidthIn - 2 * wallT;
    const check = checkTerminalPlacementFlat({
      panel,
      panelWidth,
      xOffset: options.terminalXOffset ?? 0,
      ctx: {
        isDualPort,
        portWidth: options.portWidth ?? 0,
        pp1Depth: pp1DepthIn,
        pp2Width: pp2WidthIn,
        boxWidth: boxWidthIn,
        boxDepth: boxDepthIn,
        baffleThickness: baffleTIn,
        panelThicknessIn: wallT,
      },
    });
    if (!check.safe && check.conflict) {
      throw new Error(
        `Terminal cup placement is unsafe on the ${panel} panel: ${check.conflict.label}. ` +
        `Adjust the X offset or change panel in the Design tab.`,
      );
    }
  }

  // ── Subwoofer placement defense-in-depth check ───────────────────────────
  // Validate the default or translated SUPB layout before generating any
  // physical file. This also catches negative PP1/PP2 geometry; staggering
  // must never disguise an impossible port.
  if ((includeFull || includeAcc) &&
    options.enclosureConfiguration === 'Subs Up/Port Back' &&
    options.portQuantity !== 'Dual' &&
    options.inputs && options.calc
  ) {
    const layout = resolveSupbSubLayout(options.inputs, options.calc, cutList);
    if (!layout.safe) {
      throw new Error(
        `Subwoofer placement is unsafe: ${layout.diagnostic || 'no safe layout exists'}. ` +
        `Adjust the enclosure geometry or X/Y offset in the Design tab.`,
      );
    }
  }

  // Get part widths from cut list for positioning on Bottom/Top panels
  const bafflePart = cutList.find(p => p.partName === 'Baffle');
  const baffleWidth = bafflePart?.width || 0;
  const port1Part = cutList.find(p => p.partName === 'Port Piece 1' || p.partName === 'Port Piece 1 Left');
  const port2Part = cutList.find(p => p.partName === 'Port Piece 2' || p.partName === 'Port Piece 2 Left');
  const port1PartWidth = port1Part?.width || 0;
  const port2PartWidth = port2Part?.width || 0;
  // Side panel depths and back width from cut list (for guide rectangle positioning)
  const sideLeftPart = cutList.find(p => p.partName === 'Side Left');
  const sideRightPart = cutList.find(p => p.partName === 'Side Right');
  const backPart = cutList.find(p => p.partName === 'Back');
  const sideLeftDepth = sideLeftPart?.width || 0;  // "width" in cut list = depth dimension
  const sideRightDepth = sideRightPart?.width || 0;
  const backWidth = backPart?.width || 0;

  // Generate DXF for each part — both WITHOUT guides and WITH guides (_wG suffix)
  if (includeFull) for (const part of cutList) {
    // Skip Acrylic Window cut-list entries — the generic part DXF would
    // just be a rectangle outline (no rounded corners, no screw holes).
    // The Acrylic-{prefix}.dxf companion file handles the real plate.
    if (part.partName.startsWith('Acrylic Window')) continue;
    const baseOptions: PartDxfOptions = {
      buildStrength: options.buildStrength,
      isBirchPly: options.isBirchPly,
      enclosureConfiguration: options.enclosureConfiguration,
      portQuantity: options.portQuantity,
      portWidth: options.portWidth,
      s2LeftWidth: options.s2LeftWidth,
      s1RightWidth: options.s1RightWidth,
      materialThickness: options.materialThickness,
      heavyThickness: options.heavyThickness,
      materialConfig: options.materialConfig,
      glueTolerance: options.glueTolerance,
      subCutoutDiameter: subCutoutDiameter,
      subwooferQuantity: subwooferQuantity,
      outsideDiameter: outsideDiameter,
      baffleWidth,
      port1PartWidth,
      port2PartWidth,
      cutOutTolerance: options.cutOutTolerance,
      extraHolesBack: options.extraHolesBack,
      extraHolesFront: options.extraHolesFront,
      extraHolesRight: options.extraHolesRight,
      extraHolesLeft: options.extraHolesLeft,
      extraHolesHeight: options.extraHolesHeight,
      port2VerticalOffset: options.port2VerticalOffset,
      sideLeftDepth,
      sideRightDepth,
      backWidth,
      terminalPanel: options.terminalPanel,
      terminalXOffset: options.terminalXOffset,
      subwooferXOffset: options.subwooferXOffset,
      subwooferYOffset: options.subwooferYOffset,
      recessedMounting: options.recessedMounting,
      windowEnabled: options.windowEnabled,
      windowSize: options.windowSize,
      windowOrientation: options.windowOrientation,
      windowXOffset: options.windowXOffset,
      windowYOffset: options.windowYOffset,
      windowCornerRadius: options.windowCornerRadius,
      windowCustomWidth: options.windowCustomWidth,
      windowCustomHeight: options.windowCustomHeight,
      // Window auto-shrink context. Pass inputs/calc/cutList through so
      // generatePartDxf can compute the host panel's safe area and shrink
      // the plate to fit (1" clearance from baffle, PP1, PP2, sides).
      kerf: part.kerf,
      inputs: options.inputs,
      calc: options.calc,
      cutList,
    };

    // Map web cut list names to desktop DXF filenames:
    // "Port Piece 1" → "Port 1", "Port Piece 2" → "Port 2", etc.
    // Desktop uses spaces in filenames, not hyphens.
    const dxfName = part.partName
      .replace('Baffle + Port 1', 'Baffle-Port1')
      .replace(/Port Piece (\d+)/, 'Port $1');

    // Without guides (main output — matches desktop root directory files)
    const dxfContent = generatePartDxf(part.partName, part.width, part.height, { ...baseOptions, includeGuides: false });
    files.push({ filename: `${prefix}-${dxfName}.dxf`, content: dxfContent, type: 'dxf' });

    // With guides (matches desktop "DXF With Guides" subfolder, _wG suffix)
    const dxfContentWG = generatePartDxf(part.partName, part.width, part.height, { ...baseOptions, includeGuides: true });
    files.push({ filename: `${prefix}-${dxfName}_wG.dxf`, content: dxfContentWG, type: 'dxf' });
  }

  if (includeFull && options.calc?.labyrinthPort?.active) {
    const referenceDxf = generateLabyrinthAssemblyReferenceDxf(options, cutList);
    const reviewManifest = generateLabyrinthReviewManifest(prefix, options, cutList);
    if (!referenceDxf || !reviewManifest) {
      throw new Error(
        'Labyrinth manufacturing placement could not be resolved consistently from the cut list. Export stopped before emitting an incomplete package.',
      );
    }
    files.push({
      filename: `${prefix}-Labyrinth-Assembly-REFERENCE-ONLY.dxf`,
      content: referenceDxf,
      type: 'dxf',
    });
    files.push({
      filename: `${prefix}-Labyrinth-Assembly-Review.txt`,
      content: reviewManifest,
      type: 'txt',
    });
  }

  // Generate box dieline DXF (auto-detect split if needed)
  if (includeFull && cartonLength > 0 && cartonWidth > 0 && cartonHeight > 0) {
    const isSplit = needsSplitDieline(cartonLength, cartonWidth, cartonHeight, cardboardThickness);
    const boxDxf = isSplit
      ? generateSplitBoxDielineDxf(cartonLength, cartonWidth, cartonHeight, cardboardThickness)
      : generateBoxDielineDxf(cartonLength, cartonWidth, cartonHeight, cardboardThickness);
    const boxDxfName = isSplit ? `SplitBox-${prefix}` : `Box-${prefix}`;
    files.push({
      filename: `${boxDxfName}.dxf`,
      content: boxDxf,
      type: 'dxf',
    });

    // Generate matching XXL toolpath so the operator doesn't have to run
    // VCarve's toolpath wizard by hand. Same auto-pairing pattern as the logo.
    // XXL uses the router-friendly `B_<prefix>` naming (mirrors logo `L_...`),
    // not the descriptive `Box-<prefix>` / `SplitBox-<prefix>` of the DXF.
    const boxXxl = generateBoxToolpath(boxDxf, boxDxfName);
    if (boxXxl) {
      files.push({
        filename: boxXxlFilename(prefix),
        content: boxXxl,
        type: 'xxl',
      });
    }
  }

  // Generate logo DXF from EPS (if provided)
  if (includeLogo && options.epsLogoContent) {
    // Logo goes on Top panel (standard) or Baffle (Subs Up/Port Back)
    const isSubsUp = options.enclosureConfiguration === 'Subs Up/Port Back';
    const logoPart = isSubsUp
      ? cutList.find(p => p.partName === 'Baffle')
      : cutList.find(p => p.partName === 'Top');

    appendDebug('Logo', 'info', `EPS provided — targeting ${isSubsUp ? 'Baffle' : 'Top'} panel`, {
      isSubsUp,
      logoPartFound: !!logoPart,
      logoPartSize: logoPart ? { width: logoPart.width, height: logoPart.height } : null,
      epsBytes: options.epsLogoContent.length,
    });

    if (logoPart) {
      const logoDxf = generateLogoDxf(options.epsLogoContent, logoPart.width, logoPart.height);
      if (logoDxf) {
        appendDebug('Logo', 'info', `Logo DXF generated for ${prefix}`, { dxfBytes: logoDxf.length });
        files.push({
          filename: `Logo-${prefix}.dxf`,
          content: logoDxf,
          type: 'dxf',
        });

        // Generate logo CNC toolpath (.xxl) for both On Line and Pocket modes.
        // The cut list is the source of truth for the actual target panel:
        // Top for SBPB, Baffle for SUPB. Do not infer DZ from duty or material
        // family because operator-configured B1/B2/D1/D2 values may differ
        // from nominal stock thicknesses.
        const logoMaterialThicknessMm = logoPart.thickness * IN_TO_MM;
        if (!Number.isFinite(logoMaterialThicknessMm) || logoMaterialThicknessMm <= 0) {
          appendDebug('Logo', 'error', 'Logo XXL skipped because target panel thickness is invalid', {
            prefix,
            logoPart: logoPart.partName,
            thicknessInches: logoPart.thickness,
          });
        } else if (options.buildStrength) {
          let xxlContent: string | null = null;
          if (options.logoMode === 'Pocket') {
            xxlContent = generatePocketLogoToolpath(
              logoDxf,
              options.buildStrength,
              logoMaterialThicknessMm,
            );
          } else {
            // Default to On Line mode (surface engrave along outlines)
            xxlContent = generateOnLineLogoToolpath(
              logoDxf,
              options.buildStrength,
              logoMaterialThicknessMm,
            );
          }
          if (xxlContent) {
            files.push({
              filename: logoXxlFilename(prefix),
              content: xxlContent,
              type: 'xxl',
            });
          }
        }
      } else {
        appendDebug('Logo', 'error', `generateLogoDxf returned null — EPS failed to produce DXF`, {
          prefix, logoPartWidth: logoPart.width, logoPartHeight: logoPart.height,
          epsPreview: options.epsLogoContent.slice(0, 300).replace(/\s+/g, ' '),
        });
      }
    } else {
      appendDebug('Logo', 'warn', `No logo panel in cut list — skipping logo generation`, {
        isSubsUp, targetPartName: isSubsUp ? 'Baffle' : 'Top',
        availableParts: cutList.map(p => p.partName),
      });
    }
  }

  // Generate companion Acrylic DXF for the laser/water-jet vendor (V1).
  // This is the SOLID acrylic plate cut from a separate sheet (1/4" or
  // 3/8" depending on duty). Wood-side cutout + screw pilot ring is
  // already emitted on the host part DXF — this file is just the
  // acrylic plate outline + screw clearance holes for the vendor.
  if (includeFull && options.windowEnabled && options.windowSize) {
    const dim = resolveWindowDxfDimensions(options.windowSize, options.windowOrientation, options.windowCustomWidth, options.windowCustomHeight);
    if (dim) {
      const cr = options.windowCornerRadius ?? 0.125;
      // Auto-shrink the plate to fit the host panel's safe area so the
      // laser-cut plate matches the wood cutout that landed on the part DXF.
      let fittedPlateW = dim.plateW;
      let fittedPlateH = dim.plateH;
      if (options.inputs && options.calc) {
        const safe = resolveWindowSafeArea(options.inputs, options.calc, cutList);
        const fitted = resolveAutoFitPlateDimensions(
          { plateW: dim.plateW, plateH: dim.plateH },
          safe,
        );
        fittedPlateW = fitted.plateW;
        fittedPlateH = fitted.plateH;
      }
      const acrylicDxf = buildAcrylicCompanionDxf(fittedPlateW, fittedPlateH, cr);
      files.push({
        filename: `Acrylic-${prefix}.dxf`,
        content: acrylicDxf,
        type: 'dxf',
      });
    }
  }

  // Generate ACC files (7 coordinate files for CNC machine)
  if (includeAcc) {
    const accFiles = generateAccFiles(accPrefix, options, cutList);
    files.push(...accFiles);
  }

  // Generate cut list summary (text file)
  if (includeFull) {
    let cutListText = `Cut List for ${prefix}\n`;
    cutListText += `${'='.repeat(60)}\n\n`;
    cutListText += `${'Part Name'.padEnd(20)} ${'Width'.padEnd(10)} ${'Height'.padEnd(10)} ${'Qty'.padEnd(5)} ${'Material'.padEnd(20)}\n`;
    cutListText += `${'-'.repeat(65)}\n`;
    for (const part of cutList) {
      cutListText += `${part.partName.padEnd(20)} ${part.width.toFixed(3).padEnd(10)} ${part.height.toFixed(3).padEnd(10)} ${String(part.quantity).padEnd(5)} ${part.material.padEnd(20)}\n`;
    }
    cutListText += `${'-'.repeat(65)}\n`;
    const totalArea = cutList.reduce((sum, p) => sum + p.width * p.height * p.quantity, 0);
    cutListText += `Total Build Area: ${totalArea.toFixed(2)} sq in (${(totalArea / 144).toFixed(2)} sq ft)\n`;
    cutListText += `\nCarton Dimensions: ${cartonLength.toFixed(3)}" L × ${cartonWidth.toFixed(3)}" W × ${cartonHeight.toFixed(3)}" H\n`;

    files.push({
      filename: `${prefix}-CutList.txt`,
      content: cutListText,
      type: 'txt',
    });
  }

  return files;
}
