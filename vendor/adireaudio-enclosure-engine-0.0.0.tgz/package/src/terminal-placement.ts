/**
 * Terminal cup placement helpers — pure functions only.
 *
 * The terminal cup is a 4.5" × 2.75" rounded-rectangle cutout (with two
 * mounting drill holes 0.5" outside its left/right edges) that sits 2.125"
 * up from a panel's bottom edge. Today the panel is hardcoded by config
 * (Side Left for single port, Back for dual port) and centered horizontally.
 *
 * V1 lets the user opt into picking Side Left | Back and shifting the X
 * position. Y stays locked at 2.125". We must HARD-BLOCK any placement that
 * would put the cutout — or the binding posts that protrude from it — into
 * Port Piece 1 / Port Piece 2 / the port opening on the chosen panel.
 *
 * This module computes the no-go bands per panel/config and exposes a
 * single safety check + a "snap to nearest safe X" helper.
 *
 * NB: panel coordinates have origin at the panel's bottom-left, X = the
 * panel's width axis (running along the panel's longer dimension as drawn).
 * For Side Left, X = front-to-back of the box (panel width = boxDepth).
 * For Back, X = left-to-right of the box (panel width = baffleW).
 */

import type {
  CutListItem,
  EnclosureCalculations,
  EnclosureInputs,
} from './types/enclosure';

// ── Geometry constants ──────────────────────────────────────────────────────

/** Terminal cutout footprint width (matches dxf-generator.ts:528). */
export const TERMINAL_WIDTH = 4.5;
/** Terminal cutout footprint height (matches dxf-generator.ts:529). */
export const TERMINAL_HEIGHT = 2.75;
/** Vertical position of the cutout's bottom edge from panel bottom. */
export const TERMINAL_BOTTOM_OFFSET = 2.125;
/** Horizontal half-width of the cutout — used for X-band intersection math. */
export const TERMINAL_HALF_WIDTH = TERMINAL_WIDTH / 2;
/**
 * Approximate depth that brass binding posts (recessed cup style) protrude
 * from the panel's interior face into the chamber. Used to validate that the
 * Side Left wall has enough room before the nearest PP1/PP2. Conservative;
 * real hardware varies between ~1.25" and ~2".
 */
export const BINDING_POST_DEPTH = 2.0;
/** Required clearance between the cutout/post envelope and any obstruction. */
export const SAFETY_BORDER = 0.5;

// ── Panel kinds ─────────────────────────────────────────────────────────────

/**
 * The resolved terminal placement. 'Side Left' / 'Back' name the panel
 * hosting the cup; 'None' means no terminal cup at all — DXF skips the
 * cutout, 3D viewer skips the hardware overlay, validation skips the
 * port-piece interference check.
 */
export type TerminalPanel = 'Side Left' | 'Back' | 'None';

/**
 * Default panel when the user hasn't picked one — single port → Side Left,
 * dual port → Back. 'None' is never the default; only an explicit opt-in.
 *
 * 'Subs Up/Port Up' uses the same defaults as 'Subs Back/Port Back' since
 * it's the same physical box; the only difference is the viewer rotation.
 * The original Side Left / Back panels stay attached to the box and rotate
 * along with it — terminal cup ends up on the same panel, just shown in
 * its new orientation.
 */
export function defaultTerminalPanel(inputs: EnclosureInputs): 'Side Left' | 'Back' {
  return inputs.portQuantity === 'Dual' ? 'Back' : 'Side Left';
}

/**
 * Resolve the panel that should host the terminal — explicit override wins,
 * otherwise the config-driven default. May return 'None' if the user
 * explicitly opted out of a terminal cup on this design.
 */
export function resolveTerminalPanel(inputs: EnclosureInputs): TerminalPanel {
  return inputs.terminalPanel ?? defaultTerminalPanel(inputs);
}

/** True when this design includes a terminal cup at all. */
export function hasTerminalCup(inputs: EnclosureInputs): boolean {
  return resolveTerminalPanel(inputs) !== 'None';
}

/**
 * Default horizontal offset for the terminal cutout, in inches.
 *
 * For SUPP on Side Left: positions the cup so its back-of-box edge sits
 * a known clearance from the panel's back edge. The clearance is:
 *
 *   portWidth + PP2_thickness + 2.25" safety
 *
 * — this keeps the cup clear of the port slot + Port Piece 2 panel that
 * sit near the back of the original box (= bottom of the rendered SUPP
 * view), with a 2.25" buffer for binding-post clearance.
 *
 * Other configs: 0 (centered on panel).
 */
export function defaultTerminalXOffset(
  inputs: EnclosureInputs,
  panel: TerminalPanel,
  panelWidth: number,
  pp2Thickness: number = 0.709, // default 18mm
): number {
  if (
    inputs.enclosureConfiguration === 'Subs Up/Port Up' &&
    panel === 'Side Left'
  ) {
    const port = Number(inputs.portWidth) || 0;
    // Cup right edge inset = port + pp2 + 2.25.
    // Cup center X = panelWidth - inset - cupHalfWidth.
    // xOffset = cup center X - panelWidth/2 = panelWidth/2 - inset - cupHalfWidth.
    return panelWidth / 2 - port - pp2Thickness - 2.25 - TERMINAL_HEIGHT / 2;
  }
  return 0;
}

/**
 * Resolve the effective X offset — explicit override wins, otherwise the
 * config-driven default.
 */
export function resolveTerminalXOffset(
  inputs: EnclosureInputs,
  panel: TerminalPanel,
  panelWidth: number,
  pp2Thickness?: number,
): number {
  return inputs.terminalXOffset ?? defaultTerminalXOffset(inputs, panel, panelWidth, pp2Thickness);
}

/**
 * Whether the terminal cup itself should be rotated 90° CW on the panel.
 * SUPP on Side Left: the panel rotates 90° in the viewer, so the cup that
 * would otherwise appear portrait on screen needs a counter-rotation on
 * the panel to read landscape in the rendered view. SBPB / SUPB / SUPP-on-
 * Back render the cup unrotated.
 */
export function isTerminalRotated(
  inputs: EnclosureInputs,
  panel: TerminalPanel,
): boolean {
  return inputs.enclosureConfiguration === 'Subs Up/Port Up' && panel === 'Side Left';
}

// ── No-go bands ─────────────────────────────────────────────────────────────

export type NoGoReason = 'PP1' | 'PP2' | 'PortOpening' | 'BindingPostClearance';

export interface NoGoBand {
  /** Inclusive lower X (panel coordinates, 0 = panel left edge as drawn). */
  xMin: number;
  /** Inclusive upper X. */
  xMax: number;
  /** Why this band is unsafe — surfaced to the operator. */
  reason: NoGoReason;
  /** Human-readable label for tooltips / error messages. */
  label: string;
}

/**
 * Look up panel thickness (the wall thickness used for the chosen panel).
 * Side panels and Back use the standard wall thickness (B1/D1) regardless
 * of build strength variations on the Baffle. Matches the conventions used
 * elsewhere in dxf-generator's `materialThickness` parameter.
 */
function panelThicknessInches(inputs: EnclosureInputs): number {
  // Birch 18mm = 0.709, MDF 3/4" = 0.75. Use the calculator's defaults; the
  // exact value is only used for derivation of port-relative X positions and
  // doesn't need to match the user's MaterialConfig override (a difference
  // of a few thousandths is negligible relative to the safety border).
  return inputs.enclosureType.includes('MDF') ? 0.75 : 0.709;
}

/**
 * Read Port Piece 2's drawn width from the cut list. Returns 0 if neither
 * the single-port "Port Piece 2" nor the dual-port "Port Piece 2 Left" row
 * is present; the caller must then fall back to a calc-based derivation.
 */
function getPp2WidthFromCutList(cutList: CutListItem[]): number {
  // Cut list names PP2 differently for single vs dual port:
  //   single: "Port Piece 2"
  //   dual:   "Port Piece 2 Left" + "Port Piece 2 Right" (same dimensions)
  const fromCut =
    cutList.find(p => p.partName === 'Port Piece 2')?.width ??
    cutList.find(p => p.partName === 'Port Piece 2 Left')?.width;
  return fromCut && fromCut > 0 ? fromCut : 0;
}

/**
 * Read Port Piece 1's drawn width (= depth/run when assembled — PP1 is a
 * wall whose "width" cut-list dimension is the front-to-back length).
 */
function getPp1DepthFromCutList(cutList: CutListItem[]): number {
  const fromCut =
    cutList.find(p => p.partName === 'Port Piece 1')?.width ??
    cutList.find(p => p.partName === 'Port Piece 1 Left')?.width;
  return fromCut && fromCut > 0 ? fromCut : 0;
}

/** Read baffle thickness from cut list (used to anchor PP1's front-Z position). */
function getBaffleThicknessFromCutList(cutList: CutListItem[]): number {
  const baffle = cutList.find(p => p.partName === 'Baffle');
  return baffle?.thickness && baffle.thickness > 0 ? baffle.thickness : 0;
}

/**
 * Flat geometry inputs for the band computation. The high-level overload
 * (computeNoGoBands) builds this from EnclosureInputs/Calculations; the DXF
 * generator builds it inline from its options + cut list. Same band math
 * either way.
 */
export interface BandContext {
  isDualPort: boolean;
  portWidth: number;       // inches
  pp1Depth: number;        // PP1 panel depth/run (inches) — front-to-back length of the port channel wall
  pp2Width: number;        // PP2 panel width (inches), 0 if no PP2
  boxWidth: number;        // calc.boxWidth — used for Back panel
  boxDepth: number;        // inputs.boxDepth — used for Side Left
  baffleThickness: number; // baffle thickness (inches) — front offset where PP1's Z range starts
  panelThicknessIn: number; // wall thickness for chosen panel (B1 or D1)
}

/** Build a BandContext from the high-level inputs/calc/cutList trio. */
function bandContextFromInputs(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): BandContext {
  const pp2FromCut = getPp2WidthFromCutList(cutList);
  const pp2Width = pp2FromCut > 0 ? pp2FromCut : Math.max(0, calc.portLength2 - inputs.portWidth);
  const pp1FromCut = getPp1DepthFromCutList(cutList);
  // Calc fallback for PP1: portLength1 (front-to-back depth of the port channel
  // wall — matches calculations.ts:338 portLength1 = boxDepth - (thickness + portWidth/2)).
  const pp1Depth = pp1FromCut > 0 ? pp1FromCut : Math.max(0, calc.portLength1);
  const baffleT = getBaffleThicknessFromCutList(cutList) || panelThicknessInches(inputs);
  return {
    isDualPort: inputs.portQuantity === 'Dual',
    portWidth: inputs.portWidth || 0,
    pp1Depth,
    pp2Width,
    boxWidth: calc.boxWidth,
    boxDepth: inputs.boxDepth,
    baffleThickness: baffleT,
    panelThicknessIn: panelThicknessInches(inputs),
  };
}

/**
 * Compute every no-go band on the given panel for this design — flat-args
 * variant. Returns an empty array when the panel has no PP1/PP2 face
 * conflicts AND the binding post clearance check passes.
 */
export function computeNoGoBandsFlat(
  panel: TerminalPanel,
  ctx: BandContext,
): NoGoBand[] {
  const {
    isDualPort: isDual, portWidth: pW, pp1Depth, pp2Width: pp2W,
    boxWidth, baffleThickness, panelThicknessIn: t,
  } = ctx;

  if (panel === 'Side Left') {
    // Side Left's panel-X axis = front-to-back of box (panel coord X = 0 is
    // the front edge as drawn). PP1 left runs along Z = [tBaffle, tBaffle +
    // pp1Depth] in box coordinates, which maps directly to panel X for
    // Side Left (the panel and box share the same X-as-depth axis here).
    //
    // Binding posts protrude from the inside Side Left face by
    // BINDING_POST_DEPTH along the wall-normal. Their footprint on PP1 only
    // matters when the post depth exceeds the chamber width between Side
    // Left and PP1 — i.e., when port width < BINDING_POST_DEPTH + safety.
    // For dual port that gap is pW (Side Left → PP1 left). For single port
    // PP1 lives on the right wall and never matters here.
    const bands: NoGoBand[] = [];
    if (isDual && pW > 0 && pp1Depth > 0) {
      const gap = pW;
      if (gap < BINDING_POST_DEPTH + SAFETY_BORDER) {
        bands.push({
          xMin: baffleThickness - SAFETY_BORDER,
          xMax: baffleThickness + pp1Depth + SAFETY_BORDER,
          reason: 'PP1',
          label: `Port Piece 1 (left) — only ${gap.toFixed(2)}″ chamber on Side Left wall, ` +
                 `binding posts (${BINDING_POST_DEPTH.toFixed(2)}″) would collide`,
        });
      }
    }
    return bands;
  }
  // Suppress the "ctx.boxDepth declared but unused" hint for the Back path.
  void ctx.boxDepth;

  // Back panel — PP2 X-bands. Single = one band on the right; dual = two
  // bands. boxWidth from ctx; baffleW = boxWidth - 2t when needed.
  if (isDual) {
    const leftMin = t + pW;
    const leftMax = leftMin + pp2W;
    const rightMax = boxWidth - t - pW;
    const rightMin = rightMax - pp2W;
    const out: NoGoBand[] = [];
    if (pp2W > 0) {
      out.push({
        xMin: leftMin, xMax: leftMax,
        reason: 'PP2',
        label: 'Port Piece 2 (left chamber)',
      });
      out.push({
        xMin: rightMin, xMax: rightMax,
        reason: 'PP2',
        label: 'Port Piece 2 (right chamber)',
      });
    }
    return out;
  }

  // Single port: PP2 sits flush against baffleW (right edge of interior),
  // extending leftward by pp2W.
  if (pp2W <= 0) return [];
  const baffleW = boxWidth - 2 * t;
  return [{
    xMin: baffleW - pp2W, xMax: baffleW,
    reason: 'PP2',
    label: 'Port Piece 2',
  }];
}

/**
 * High-level overload — accepts the standard inputs/calc/cutList trio and
 * delegates to computeNoGoBandsFlat. Used by the Design tab UI.
 */
export function computeNoGoBands(
  panel: TerminalPanel,
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): NoGoBand[] {
  return computeNoGoBandsFlat(panel, bandContextFromInputs(inputs, calc, cutList));
}

// ── Safety checks ───────────────────────────────────────────────────────────

/**
 * Resolve the X coordinate of the cutout's CENTER on the chosen panel,
 * given the user's offset (or 0 if unset). The cutout is centered on the
 * panel's width by default; xOffset shifts that center.
 */
export function resolveTerminalCenterX(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  panel: 'Side Left' | 'Back',
): number {
  const panelWidth = panelWidthInches(panel, inputs, calc);
  const offset = inputs.terminalXOffset ?? 0;
  return panelWidth / 2 + offset;
}

/** The chosen panel's width — used everywhere the cutout's bounds matter.
 *  Excludes 'None' deliberately: callers must narrow before asking for a
 *  width. There's no panel for skip-cup designs. */
export function panelWidthInches(
  panel: 'Side Left' | 'Back',
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
): number {
  if (panel === 'Side Left') return inputs.boxDepth;
  // Back panel width = interior baffleW (drawn between two side wall
  // thicknesses). Matches dxf-generator's expected partWidth for "Back".
  const t = panelThicknessInches(inputs);
  return calc.boxWidth - 2 * t;
}

export interface PlacementCheck {
  /** True when the requested placement is safe (or no fields set → defaults). */
  safe: boolean;
  /** Set when unsafe — the band that's blocking. */
  conflict?: NoGoBand;
  /** The cutout footprint that was checked. */
  footprint: { xMin: number; xMax: number };
}

/**
 * Validate a terminal placement against the no-go bands — flat-args variant.
 * Used by the DXF generator (which doesn't have a full inputs+calc bundle)
 * and as the underlying implementation for the high-level overload below.
 */
export function checkTerminalPlacementFlat(args: {
  panel: 'Side Left' | 'Back';
  panelWidth: number;
  xOffset: number;
  ctx: BandContext;
}): PlacementCheck {
  const { panel, panelWidth, xOffset, ctx } = args;
  const cx = panelWidth / 2 + xOffset;
  const xMin = cx - TERMINAL_HALF_WIDTH - SAFETY_BORDER;
  const xMax = cx + TERMINAL_HALF_WIDTH + SAFETY_BORDER;
  const footprint = { xMin, xMax };

  // Hard panel-edge check — cutout must fit with at least SAFETY_BORDER
  // on either side.
  if (xMin < 0 || xMax > panelWidth) {
    return {
      safe: false,
      conflict: {
        xMin: Math.min(xMin, 0),
        xMax: Math.max(xMax, panelWidth),
        reason: 'PP2',
        label: `Cutout extends past the panel edge (panel width ${panelWidth.toFixed(2)}″)`,
      },
      footprint,
    };
  }

  const bands = computeNoGoBandsFlat(panel, ctx);
  for (const band of bands) {
    // Interval-overlap [xMin, xMax] vs [band.xMin, band.xMax]. Also catches
    // the all-X BindingPostClearance band (±Infinity bounds).
    if (xMin < band.xMax && band.xMin < xMax) {
      return { safe: false, conflict: band, footprint };
    }
  }
  return { safe: true, footprint };
}

/**
 * Validate a terminal placement against the no-go bands. Used by the UI for
 * live feedback and by `handleSaveDesign` as a save-time gate. Wrapper over
 * the flat variant.
 */
export function checkTerminalPlacement(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  panel: 'Side Left' | 'Back' = defaultTerminalPanel(inputs),
  xOffsetOverride?: number,
): PlacementCheck {
  return checkTerminalPlacementFlat({
    panel,
    panelWidth: panelWidthInches(panel, inputs, calc),
    xOffset: xOffsetOverride ?? inputs.terminalXOffset ?? 0,
    ctx: bandContextFromInputs(inputs, calc, cutList),
  });
}

/**
 * Find the nearest X offset that places the terminal in a safe zone. Used
 * by the UI as a "snap" affordance and by tests. Returns null when no safe
 * X exists on the chosen panel (the operator must change panels).
 */
export function findNearestSafeXOffset(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  panel: 'Side Left' | 'Back' = defaultTerminalPanel(inputs),
  desiredOffset: number = inputs.terminalXOffset ?? 0,
): number | null {
  // Quick path: requested position is already safe.
  const initial = checkTerminalPlacement(inputs, calc, cutList, panel, desiredOffset);
  if (initial.safe) return desiredOffset;

  const panelWidth = panelWidthInches(panel, inputs, calc);
  const minOffset = -(panelWidth / 2 - TERMINAL_HALF_WIDTH - SAFETY_BORDER);
  const maxOffset = -minOffset;
  // Sweep outward from desiredOffset in 1/8" steps until safe or out of range.
  const step = 0.125;
  for (let delta = step; delta <= panelWidth; delta += step) {
    const cands = [desiredOffset - delta, desiredOffset + delta];
    for (const c of cands) {
      if (c < minOffset || c > maxOffset) continue;
      if (checkTerminalPlacement(inputs, calc, cutList, panel, c).safe) return c;
    }
  }
  return null;
}
