import { DEFAULT_GLUE_TOLERANCE, DEFAULT_MATERIAL_CONFIG, type EnclosureInputs, type MaterialConfig } from './types/enclosure';

/** Inches. Keep the existing router's exact 0.864 mm SD/RD depth. */
export const DEFAULT_MILL_DOWN_DEPTHS = { standardRegular: 0.864 / 25.4, heavy: 0.03 };
export type MillDownDepths = typeof DEFAULT_MILL_DOWN_DEPTHS;
export interface ManufacturingProfile {
  version: 1;
  materials: MaterialConfig;
  millDownDepths: MillDownDepths;
  glueTolerance: number;
}

export function createManufacturingProfile(
  materials: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  millDownDepths: MillDownDepths = DEFAULT_MILL_DOWN_DEPTHS,
  glueTolerance: number = DEFAULT_GLUE_TOLERANCE,
): ManufacturingProfile {
  for (const key of ['B1', 'B2', 'D1', 'D2'] as const) {
    if (!Number.isFinite(materials[key]) || materials[key] <= 0) throw new Error(`Invalid stock thickness: ${key}`);
  }
  for (const [duty, depth] of (['standardRegular', 'heavy'] as const).map(key => [key, millDownDepths[key]] as const)) {
    // HD flush baffles are thin stock, too.
    if (!Number.isFinite(depth) || depth < 0 || depth >= Math.min(materials.B1, materials.B2)) {
      throw new Error(`Mill-down depth for ${duty} must be nonnegative and less than the stock thickness.`);
    }
  }
  if (!Number.isFinite(glueTolerance) || glueTolerance < 0) throw new Error('Glue tolerance must be a nonnegative number.');
  return { version: 1, materials: { ...materials }, millDownDepths: { ...millDownDepths }, glueTolerance };
}

/** Saved profiles are self-contained. Legacy C1/C2 and manual Port 2 offsets
 * are never manufacturing inputs to the new calculation. */
export function resolveManufacturingProfile(
  inputs: Partial<EnclosureInputs>,
  materials = DEFAULT_MATERIAL_CONFIG,
  glueTolerance = DEFAULT_GLUE_TOLERANCE,
): ManufacturingProfile {
  const saved = inputs.manufacturingProfile;
  if (saved && saved.version !== 1) throw new Error('Unsupported manufacturing profile version.');
  if (saved && (!saved.materials || !saved.millDownDepths || typeof saved.glueTolerance !== 'number')) throw new Error('Incomplete saved manufacturing profile.');
  return saved
    ? createManufacturingProfile(saved.materials, saved.millDownDepths, saved.glueTolerance)
    : createManufacturingProfile(materials, DEFAULT_MILL_DOWN_DEPTHS, glueTolerance);
}

export function resolveJoinery(inputs: Partial<EnclosureInputs>, materials = DEFAULT_MATERIAL_CONFIG, glueTolerance = DEFAULT_GLUE_TOLERANCE) {
  const profile = resolveManufacturingProfile(inputs, materials, glueTolerance);
  const mdf = inputs.enclosureType?.includes('MDF') === true;
  const heavy = inputs.enclosureType?.includes('Heavy') === true;
  const regular = inputs.enclosureType?.includes('Regular') === true;
  const supb = inputs.enclosureConfiguration === 'Subs Up/Port Back';
  const flush = !!inputs.recessedMounting && !supb;
  const kerf = !!inputs.kerfPortEnabled && !mdf && !supb && !flush && inputs.portQuantity !== 'Dual';
  const depth = mdf ? 0 : profile.millDownDepths[heavy ? 'heavy' : 'standardRegular'];
  const stock = profile.materials;
  const thin = mdf ? stock.D1 : stock.B1, thick = mdf ? stock.D2 : stock.B2;
  const frontStock = flush || (!heavy && (!regular || supb)) ? thin : thick;
  const backStock = heavy ? thick : thin;
  const frontFinished = frontStock - (kerf ? 0 : depth);
  const backFinished = backStock - depth;
  const glue = profile.glueTolerance;
  return {
    profile, depth, frontFinished, backFinished,
    frontMate: frontFinished + glue, backMate: backFinished + glue,
    // PP2 remains full stock across the port channel; only its mating edge is relieved.
    port2Stock: backStock,
    port2VerticalOffset: glue - depth,
    // Compatibility for internal helpers: derive C values for THIS duty, including HD thin flush faces.
    materialConfig: { ...stock, C1: stock.B1 - depth, C2: stock.B2 - depth },
  };
}

const MARKER = 'BHS_JOINERY_V1 ';
export interface MillDownRequirement { layer: string; depthIn: number }
export function millDownRequirement(inputs: Partial<EnclosureInputs>, materials?: MaterialConfig, glueTolerance?: number): MillDownRequirement | null {
  if (inputs.enclosureType?.includes('MDF')) return null;
  const joint = resolveJoinery(inputs, materials, glueTolerance);
  return { layer: inputs.enclosureType?.includes('Heavy') ? 'MILL_DOWN__03' : 'MILL_DOWN__034', depthIn: joint.depth };
}
export function readMillDownRequirements(dxf: string): MillDownRequirement[] {
  const lines = dxf.split(/\r?\n/);
  const results: MillDownRequirement[] = [];
  for (let i = 0; i + 1 < lines.length; i += 2) {
    if (lines[i].trim() !== '999' || !lines[i + 1].startsWith(MARKER)) continue;
    const value = JSON.parse(lines[i + 1].slice(MARKER.length)) as MillDownRequirement;
    if (!/^MILL_DOWN__(03|034)$/.test(value.layer) || !Number.isFinite(value.depthIn) || value.depthIn < 0) throw new Error('Invalid milling requirement in DXF.');
    results.push(value);
  }
  return results;
}
export function stampMillDownRequirements(dxf: string, requirements: MillDownRequirement[]): string {
  const comments = [...new Set(requirements.map(r => JSON.stringify(r)))].map(r => `999\n${MARKER}${r}\n`).join('');
  return dxf.replace('0\nENDSEC', comments + '0\nENDSEC');
}
