// How close subwoofer frames may come on a baffle (Andrew, 2026-11-16).
import type { EnclosureInputs } from './types/enclosure';

/**
 * How far an outside frame may run past the baffle's top and bottom edges: "1/8 in. on the top
 * and 1/8 in. on the bottom". The top and bottom panels sit flush around the baffle, so the frame
 * rests on them there, and its screws, nearer the cutout, stay in the baffle. Not for flush
 * (recessed) mounting, whose recess still needs wood all round, nor for the side edges.
 */
export const BAFFLE_FRAME_OVERHANG_IN = 0.125;

/**
 * The gap two outside frames need with a baffle brace between them: "1.25 inches for heavy duty
 * and 1 in. for regular duty or standard duty". The frames then clear a 24 mm or 18 mm brace by
 * about 0.15 in a side; their screws sit nearer the cutout. Never less than the brace itself plus
 * 1/8 in a side, so an unusually thick brace still clears the frames. Flush recesses add their
 * 1/8 in a side on top of this.
 */
export function braceGapIn(inputs: Pick<EnclosureInputs, 'enclosureType'>, braceThickness: number): number {
  const rule = String(inputs.enclosureType ?? '').includes('Heavy Duty') ? 1.25 : 1.0;
  return Math.max(rule, braceThickness + 0.25);
}

/** The smallest room from the frames to the baffle's side edges, and to its top and bottom. */
export function baffleFrameClearances(points: Array<{ x: number; y: number }>, width: number, height: number,
  frameWidth: number, frameHeight: number): { side: number; vertical: number } {
  const hw = frameWidth / 2, hh = frameHeight / 2;
  return {
    side: Math.min(...points.flatMap(p => [p.x - hw, width - p.x - hw])),
    vertical: Math.min(...points.flatMap(p => [p.y - hh, height - p.y - hh])),
  };
}
