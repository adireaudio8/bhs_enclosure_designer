/**
 * Lightweight app-wide debug log. Any part of the app can call
 * `appendDebug(category, level, message, data?)` to record an event.
 * The Manage tab's Debug Console subscribes via `subscribeDebugLog`
 * and displays the ring buffer.
 *
 * Also mirrors to `console.log / console.warn / console.error` so
 * DevTools still shows everything.
 */

import { useEffect, useState } from 'react';

export type DebugLevel = 'info' | 'warn' | 'error';

export interface DebugEntry {
  id: number;
  ts: number;          // epoch ms
  category: string;    // e.g. 'Logo', 'Nest', 'Planning', 'Storage'
  level: DebugLevel;
  message: string;
  data?: unknown;      // optional structured payload
}

const MAX_ENTRIES = 500;
const STORAGE_KEY = 'debug_log';
const PERSIST_DEBOUNCE_MS = 250;

let nextId = 1;
const buffer: DebugEntry[] = [];
const listeners = new Set<(entries: DebugEntry[]) => void>();

// Hydrate from localStorage on module load (client-only). Survives page refreshes.
if (typeof window !== 'undefined') {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DebugEntry[];
      if (Array.isArray(parsed)) {
        buffer.push(...parsed.slice(-MAX_ENTRIES));
        nextId = (parsed[parsed.length - 1]?.id ?? 0) + 1;
      }
    }
  } catch { /* corrupt cache — ignore and start fresh */ }
}

let persistTimer: ReturnType<typeof setTimeout> | null = null;
function schedulePersist() {
  if (typeof window === 'undefined') return;
  if (persistTimer) return; // coalesce bursts
  persistTimer = setTimeout(() => {
    persistTimer = null;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(buffer)); } catch { /* quota etc. */ }
  }, PERSIST_DEBOUNCE_MS);
}

function emit() {
  // Clone so subscribers get a new array reference (React rerender)
  const snapshot = buffer.slice();
  for (const fn of listeners) fn(snapshot);
}

export function appendDebug(
  category: string,
  level: DebugLevel,
  message: string,
  data?: unknown,
): void {
  const entry: DebugEntry = { id: nextId++, ts: Date.now(), category, level, message, data };
  buffer.push(entry);
  if (buffer.length > MAX_ENTRIES) buffer.splice(0, buffer.length - MAX_ENTRIES);

  // Mirror to console so DevTools sees it too
  const tag = `[${category}]`;
  if (level === 'error') console.error(tag, message, data ?? '');
  else if (level === 'warn') console.warn(tag, message, data ?? '');
  else console.log(tag, message, data ?? '');

  schedulePersist();
  emit();
}

export function clearDebugLog(): void {
  buffer.length = 0;
  if (typeof window !== 'undefined') {
    try { localStorage.removeItem(STORAGE_KEY); } catch { /* noop */ }
  }
  emit();
}

export function getDebugLog(): DebugEntry[] {
  return buffer.slice();
}

export function subscribeDebugLog(fn: (entries: DebugEntry[]) => void): () => void {
  listeners.add(fn);
  // Fire once so subscribers get the current state immediately
  fn(buffer.slice());
  return () => { listeners.delete(fn); };
}

/** React hook — returns the current entries (array ref changes on every append). */
export function useDebugLog(): DebugEntry[] {
  const [entries, setEntries] = useState<DebugEntry[]>(() => buffer.slice());
  useEffect(() => subscribeDebugLog(setEntries), []);
  return entries;
}
