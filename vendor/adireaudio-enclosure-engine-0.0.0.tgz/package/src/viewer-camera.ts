import { PerspectiveCamera, Vector3 } from 'three';

export type ViewerPoint = [number, number, number];
export const VIEWER_FOV = 35;

/** World-space box after the viewer's optional Subs Up/Port Up rotation. */
export function viewerCameraFrame(width: number, height: number, depth: number, rotated: boolean) {
  const size: ViewerPoint = rotated ? [width, depth, height] : [width, height, depth];
  const target: ViewerPoint = rotated ? [0, depth / 2, -height / 2] : [0, height / 2, 0];
  return { size, target };
}

/** Fit every box corner in the actual viewport, with room for the driver flange.
 * The narrower lens reduces perspective exaggeration without changing geometry. */
export function viewerCameraPose(frame: ReturnType<typeof viewerCameraFrame>, aspect: number) {
  const direction = new Vector3(-0.6, 0.5, 0.8).normalize();
  const right = new Vector3().crossVectors(new Vector3(0, 1, 0), direction).normalize();
  const up = new Vector3().crossVectors(direction, right);
  const tanV = Math.tan(VIEWER_FOV * Math.PI / 360);
  const tanH = tanV * Math.max(0.1, aspect);
  let distance = 1;
  for (const x of [-1, 1]) for (const y of [-1, 1]) for (const z of [-1, 1]) {
    const corner = new Vector3(x * (frame.size[0] / 2 + .05), y * (frame.size[1] / 2 + .05), z * (frame.size[2] / 2 + .05));
    distance = Math.max(distance, corner.dot(direction) + 1.28 * Math.max(Math.abs(corner.dot(right)) / tanH, Math.abs(corner.dot(up)) / tanV));
  }
  const position = direction.multiplyScalar(distance).add(new Vector3(...frame.target)).toArray() as ViewerPoint;
  return { target: frame.target, position, distance };
}

interface ViewerControls {
  target: Vector3;
  enableDamping: boolean;
  update: () => unknown;
  saveState: () => void;
}

/** OrbitControls.reset() omits camera.up and retains pending damping motion.
 * Restore all camera state explicitly, even after a view-cube animation. */
export function resetViewerCamera(camera: PerspectiveCamera, controls: ViewerControls, pose: ReturnType<typeof viewerCameraPose>) {
  const damping = controls.enableDamping;
  controls.enableDamping = false;
  controls.update(); // Consume and clear pending orbit/pan deltas before restoring.
  camera.up.set(0, 1, 0);
  camera.zoom = 1;
  camera.fov = VIEWER_FOV;
  camera.position.set(...pose.position);
  controls.target.set(...pose.target);
  camera.lookAt(controls.target);
  camera.updateProjectionMatrix();
  controls.update();
  controls.saveState();
  controls.enableDamping = damping;
}
