/**
 * Auto-calculate edge-screw "extra holes" counts from cut-list panel dimensions.
 *
 * Mirrors desktop BuildTabViewModel.DataProcessing.AutoCalculateExtraHoles
 * (see Software Dev/Enclosure Calculator - Desktop/View Models/
 * BuildTabViewModel.DataProcessing.cs). The same logic was inline in
 * BuildTab.tsx; lifted here so usePricingGeneration's batch path can apply
 * it too — previously Pricing tab "Gen All Files (Synced)" only read these
 * counts from `buildSettings`, falling back to 0 for designs never saved
 * with explicit values, which produced bottom panels with no edge holes.
 */
import type { CutListItem } from './types/enclosure';

export interface ExtraHoles {
  /** Side Left & Right (extra) — derived from Bottom panel depth */
  bottomExtraHoles: number;
  bottomRightExtraHoles: number;
  /** Back (extra) — derived from Bottom panel width */
  bottomBackExtraHoles: number;
  /** Front (extra) — derived from Baffle width */
  bottomFrontExtraHoles: number;
  /** Side panels' vertical edge holes — derived from tallest of Back/Baffle/Port2 */
  heightExtraHoles: number;
}

/**
 * Desktop CalculateExtraHolesFromWidth: <11"=0, 11–18.5"=1, 18.5–34"=2, ≥34"=3.
 * Returns 0 for non-positive widths.
 */
export function extraHolesFromWidth(width: number): number {
  if (!Number.isFinite(width) || width <= 0) return 0;
  if (width < 11) return 0;
  if (width <= 18.5) return 1;
  if (width < 34) return 2;
  return 3;
}

/**
 * Desktop AutoCalculateHeightExtraHoles: <8"=0, 8–16"=1, >16"=2.
 * Returns 0 for non-positive heights.
 */
export function heightExtraHolesFromMaxPanelHeight(maxHeight: number): number {
  if (!Number.isFinite(maxHeight) || maxHeight <= 0) return 0;
  if (maxHeight < 8) return 0;
  if (maxHeight <= 16) return 1;
  return 2;
}

/**
 * Run the full auto-calc against a freshly generated cut list. Caller is
 * expected to have already produced the cut list via generateCutList.
 */
export function autoCalculateExtraHoles(cutList: CutListItem[]): ExtraHoles {
  const find = (name: string) => cutList.find(p => p.partName === name);
  const back = find('Back');
  const baffle = find('Baffle');
  const port2 = find('Port Piece 2');
  const bottom = find('Bottom');

  // Cut-list "height" on the Bottom row stores depth (panel is laid flat),
  // matching the desktop convention.
  const bottomDepth = bottom?.height ?? 0;
  const bottomWidth = bottom?.width ?? 0;
  const baffleWidth = baffle?.width ?? 0;

  const maxPanelHeight = Math.max(
    back?.height ?? 0,
    baffle?.height ?? 0,
    port2?.height ?? 0,
  );

  return {
    bottomExtraHoles: extraHolesFromWidth(bottomDepth),
    bottomRightExtraHoles: extraHolesFromWidth(bottomDepth),
    bottomBackExtraHoles: extraHolesFromWidth(bottomWidth),
    bottomFrontExtraHoles: extraHolesFromWidth(baffleWidth),
    heightExtraHoles: heightExtraHolesFromMaxPanelHeight(maxPanelHeight),
  };
}
