import type { CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';

export type RenderGeometry = { inputs: EnclosureInputs; calculations: EnclosureCalculations; cutList: CutListItem[] };

export function snapshotRenderGeometry({ inputs, calculations, cutList }: RenderGeometry): RenderGeometry {
  // labyrinthPort is intentionally non-enumerable on calculated results. A
  // generic JSON/structured clone loses it and breaks every exported scene.
  return structuredClone({ inputs, cutList, calculations: {
    ...calculations, labyrinthPort: calculations.labyrinthPort,
    ...(calculations.roundPort ? { roundPort: calculations.roundPort } : {}),
  } });
}
