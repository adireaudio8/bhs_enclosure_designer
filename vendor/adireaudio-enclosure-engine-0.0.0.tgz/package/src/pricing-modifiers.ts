/**
 * Unified pricing modifier resolution.
 *
 * Performance series (BHSP-) MAPs are the source of truth in the `pricing`
 * table. All other variants (Flat Pack, Foundation, Select, Flush Mount, …)
 * derive their MAP by applying one or more *modifiers* on top of the base.
 *
 * The modifier config lives as a single JSON blob in `app_settings`
 * (key: `pricing_modifiers`) so it can be edited through one settings
 * window without touching code, and so the calc + storefront read the
 * same source of truth via this helper.
 *
 * Resolution rule (deterministic):
 *
 *   final_map = base_map × Π(1 + percent_modifier_value/100)
 *                 + Σ(absolute_modifier_delta)
 *
 * Percent modifiers compound multiplicatively (matches the legacy FP-then-FN
 * sequential math so existing combo prices don't move); absolute modifiers
 * add on top of the discounted base (so the FM cost-recovery upcharge is the
 * same dollar amount whether or not the design is also a Foundation/FP).
 *
 * Dealer price is always `final_map × 0.6` per the BHS pricing rule.
 */

// ─── Types ────────────────────────────────────────────────────────────────

export type PricingModifierKind = 'percent' | 'absolute_by_size' | 'absolute_by_window_size';

export type PricingModifierDetector =
  | { type: 'name_starts'; pattern: string }
  | { type: 'name_ends';   pattern: string }
  | { type: 'name_contains'; pattern: string }
  /** Match when a boolean field on the design's parsed inputs is truthy.
   *  Used for design options that aren't encoded in the design name —
   *  e.g. acrylic window (`windowEnabled`). */
  | { type: 'input_flag'; field: string }
  /** Match when the design's resolved material matches the configured value.
   *  Optionally:
   *   - `nameStartsWith` — require the design name to start with this prefix
   *     (case-insensitive). Only useful if Performance designs ever get a
   *     consistent prefix; today they don't (raw stored names start with
   *     the brand code like SUN-, JL-, AMB-).
   *   - `nameExcludeStartsWith` — REJECT designs whose name starts with any
   *     of these prefixes. Used to scope an MDF discount to Performance only
   *     by excluding BHSF- (Foundation) and BHSS- (Select) which have their
   *     own per-series discount math. */
  | { type: 'material_is'; material: 'birch' | 'mdf'; nameStartsWith?: string; nameExcludeStartsWith?: string[] };

export interface PricingModifierBase {
  id: string;
  label: string;
  /** Operator-facing description shown in the settings UI. */
  description?: string;
  detector: PricingModifierDetector;
  /** When false the modifier exists in config but is skipped at lookup time.
   *  Useful for sketching "Select" before the value is decided. */
  enabled?: boolean;
}

/** Discriminator for material-aware modifier overrides. Derived from the
 *  design's `enclosureType` field — "Birch Ply - Heavy Duty" → 'birch',
 *  "MDF - Heavy Duty" → 'mdf'. Defaults to 'birch' when not specified. */
export type EnclosureMaterial = 'birch' | 'mdf';

export interface PercentModifier extends PricingModifierBase {
  kind: 'percent';
  /** Default percentage. Negative for discount (e.g. -25 = 25% off), positive for upcharge. */
  value: number | null;
  /** Optional per-material override. When the design's material matches a key
   *  here AND the value is non-null, this overrides `value`. Use to model
   *  different discount levels for MDF vs Birch (e.g. Foundation MDF discounted
   *  more than Foundation Birch to account for lower material cost).
   *
   *  Currently only `mdf` is supported — Birch falls through to the default `value`. */
  materialOverrides?: {
    mdf?: number | null;
  };
}

export interface AbsoluteBySizeModifier extends PricingModifierBase {
  kind: 'absolute_by_size';
  /** Map of size string ("6.5", "8", "10", "12", "13.5", "15", "18") → dollar delta. */
  tiers: Record<string, number>;
}

/** Like `absolute_by_size` but the tier key is the design's `windowSize`
 *  ("12x12" / "24x12") instead of the subwoofer size. */
export interface AbsoluteByWindowSizeModifier extends PricingModifierBase {
  kind: 'absolute_by_window_size';
  /** Map of window size string ("12x12" / "24x12") → dollar delta. */
  tiers: Record<string, number>;
}

export type PricingModifier = PercentModifier | AbsoluteBySizeModifier | AbsoluteByWindowSizeModifier;

export interface PricingModifiersConfig {
  version: number;
  modifiers: PricingModifier[];
}

// ─── Defaults ─────────────────────────────────────────────────────────────

/**
 * Default modifier config — used when `app_settings.pricing_modifiers` is
 * missing. Mirrors the legacy FP/FN discount behavior so existing prices
 * don't change on first load. Flush Mount upcharge tiers are populated
 * with the May 6, 2026 recommendation; Select is null until decided.
 */
export const DEFAULT_PRICING_MODIFIERS: PricingModifiersConfig = {
  version: 1,
  modifiers: [
    {
      id: 'flushMount',
      label: 'Flush Mount',
      description:
        'Adds an 18mm Birch Sub Mount Cap (SUPB) or Sub Mount Plate ' +
        '(SBPB/SUPP) so the sub flange sits recessed/flush with the box ' +
        'face. Extra material + slight assembly time — upcharge varies ' +
        'by sub size.',
      detector: { type: 'name_contains', pattern: '-FM-' },
      kind: 'absolute_by_size',
      tiers: { '6.5': 25, '8': 25, '10': 25, '12': 50, '13.5': 50, '15': 50, '18': 100 },
      enabled: true,
    },
    {
      id: 'flatPack',
      label: 'Flat Pack',
      description:
        'Ships unassembled — pre-cut and pre-drilled panels packaged ' +
        'flat for the customer to glue/screw together. Saves labor and ' +
        'shipping volume; sold at a discount off the assembled MAP.',
      detector: { type: 'name_ends', pattern: '-FP' },
      kind: 'percent',
      value: -25,
      enabled: true,
    },
    {
      id: 'foundation',
      label: 'Foundation',
      description:
        'Unfinished / bare enclosures — no stain, lacquer, engraving, ' +
        'or finishing labor. Customer applies their own finish. Sold ' +
        'at a discount off the fully-finished Performance MAP.',
      detector: { type: 'name_starts', pattern: 'BHSF-' },
      kind: 'percent',
      value: -30,
      enabled: true,
    },
    {
      id: 'select',
      label: 'Select',
      description:
        'Curated mid-tier line — discount and exact scope to be decided. ' +
        'Disabled by default until the value is set.',
      detector: { type: 'name_starts', pattern: 'BHSS-' },
      kind: 'percent',
      value: null,
      enabled: false,
    },
    {
      id: 'mdfDiscount',
      label: 'MDF Discount from Birch (Performance only)',
      description:
        'Discount applied to Performance MDF enclosures (material is MDF ' +
        'AND name does NOT start with BHSF- or BHSS-). MDF material is ' +
        'cheaper than Birch but the volume-based MAP table only stores ' +
        'Birch prices — this modifier discounts the looked-up Birch MAP. ' +
        'Foundation (BHSF-) and Select (BHSS-) are excluded because those ' +
        'series have their own per-material discount tuning. Performance ' +
        'designs have no consistent name prefix (they start with the brand ' +
        'code like SUN-, JL-, AMB-) so we exclude the two series prefixes ' +
        'rather than match a Performance prefix.',
      detector: {
        type: 'material_is',
        material: 'mdf',
        nameExcludeStartsWith: ['BHSF-', 'BHSS-'],
      },
      kind: 'percent',
      value: null,
      enabled: false,
    },
    {
      id: 'acrylicWindow',
      label: 'Acrylic Window',
      description:
        'Per-order upcharge added when a design has a clear acrylic window ' +
        'cutout enabled. Tier picked by window size (12x12 vs 24x12) — no ' +
        '"-PW" SKU variant; same design row, plexi is an add-on like a finish ' +
        'option. Detected via the design\'s parsed inputs (windowEnabled flag), ' +
        'not the design name.',
      detector: { type: 'input_flag', field: 'windowEnabled' },
      kind: 'absolute_by_window_size',
      tiers: { '12x12': 75, '24x12': 150, custom: 150 },
      enabled: true,
    },
  ],
};

// ─── Detection ────────────────────────────────────────────────────────────

function matches(
  detector: PricingModifierDetector,
  designName: string,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  inputs?: Record<string, any> | null,
  material?: EnclosureMaterial,
): boolean {
  switch (detector.type) {
    case 'name_starts':
      if (!designName) return false;
      return designName.toUpperCase().startsWith(detector.pattern.toUpperCase());
    case 'name_ends':
      if (!designName) return false;
      return designName.toUpperCase().endsWith(detector.pattern.toUpperCase());
    case 'name_contains':
      if (!designName) return false;
      return designName.toUpperCase().includes(detector.pattern.toUpperCase());
    case 'input_flag':
      if (!inputs) return false;
      return !!inputs[detector.field];
    case 'material_is': {
      if ((material ?? 'birch') !== detector.material) return false;
      // Optional positive name-prefix filter.
      if (detector.nameStartsWith && designName) {
        if (!designName.toUpperCase().startsWith(detector.nameStartsWith.toUpperCase())) return false;
      }
      // Optional negative name-prefix filter — reject when name starts with
      // any of these prefixes. Used by the MDF Discount modifier to exclude
      // Foundation BHSF- + Select BHSS- which have their own per-series
      // discount math.
      if (detector.nameExcludeStartsWith && designName) {
        const upper = designName.toUpperCase();
        for (const ex of detector.nameExcludeStartsWith) {
          if (upper.startsWith(ex.toUpperCase())) return false;
        }
      }
      return true;
    }
  }
}

// ─── Resolution ───────────────────────────────────────────────────────────

export interface ResolveModifiedMAPArgs {
  designName: string;
  /** Numeric size string ("6.5", "8", "10", "12", "13.5", "15", "18"). */
  size: string;
  /** Base MAP from the `pricing` table (BHSP- pricing for this size/duty/volume). */
  baseMap: number;
  /** Modifier config — pass DEFAULT_PRICING_MODIFIERS or a parsed JSON. */
  modifiers: PricingModifiersConfig;
  /** Optional parsed inputs from the design. Required for `input_flag`
   *  detectors and `absolute_by_window_size` tier lookups (acrylic window
   *  upcharge etc.). Plain object — typically `parseDesignDataInputs(dd)`. */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  inputs?: Record<string, any> | null;
  /** Material the design is built from. Drives `materialOverrides` lookup on
   *  percent modifiers. Caller should pass `detectMaterial(inputs.enclosureType)`.
   *  Defaults to 'birch' if omitted. */
  material?: EnclosureMaterial;
}

/** Detect material from an EnclosureInputs.enclosureType string.
 *  Returns 'birch' as the safe default for ambiguous / missing values. */
export function detectMaterial(enclosureType: string | undefined | null): EnclosureMaterial {
  if (!enclosureType) return 'birch';
  const s = enclosureType.toLowerCase();
  if (s.includes('mdf')) return 'mdf';
  return 'birch';
}

export interface ResolveModifiedMAPResult {
  /** MAP after all matching modifiers applied. */
  finalMap: number;
  /** Final MAP × 0.6, the standard BHS dealer rule. */
  dealerPrice: number;
  /** IDs of modifiers that fired, in order applied. */
  applied: string[];
  /** Per-modifier breakdown for tooltip / debug display. */
  breakdown: { id: string; label: string; deltaDollars: number }[];
}

export function resolveModifiedMAP({
  designName, size, baseMap, modifiers, inputs, material,
}: ResolveModifiedMAPArgs): ResolveModifiedMAPResult {
  if (!Number.isFinite(baseMap) || baseMap <= 0) {
    return { finalMap: 0, dealerPrice: 0, applied: [], breakdown: [] };
  }

  const mat: EnclosureMaterial = material ?? 'birch';

  // Phase 1: compound all matching enabled percent modifiers on the base.
  let percentMultiplier = 1;
  const applied: string[] = [];
  const breakdown: ResolveModifiedMAPResult['breakdown'] = [];

  for (const mod of modifiers.modifiers) {
    if (mod.enabled === false) continue;
    if (!matches(mod.detector, designName, inputs, mat)) continue;

    if (mod.kind === 'percent') {
      // Prefer the material-specific override when present and non-null,
      // else fall back to the default `value`. Only 'mdf' currently supports
      // an override; Birch always uses the default.
      //
      // EXCEPTION: when the modifier's detector is material_is, the detector
      // itself already pins one material — a separate materialOverrides entry
      // is logically redundant and historically caused confusion when stale
      // values shadowed the active `value`. For material_is detectors,
      // always use `value`.
      let v: number | null = mod.value;
      if (mat === 'mdf' && mod.detector.type !== 'material_is') {
        const override = mod.materialOverrides?.mdf;
        if (override !== undefined && override !== null && Number.isFinite(override)) {
          v = override;
        }
      }
      if (v === null || !Number.isFinite(v) || v === 0) {
        continue;
      }
      const before = baseMap * percentMultiplier;
      percentMultiplier *= (1 + v / 100);
      const after = baseMap * percentMultiplier;
      applied.push(mod.id);
      // Cent-round the display delta like the final prices (raw float noise
      // like -225.0000000000001 otherwise leaks into tooltips).
      breakdown.push({ id: mod.id, label: mod.label, deltaDollars: Math.round((after - before) * 100) / 100 });
    }
  }

  let result = baseMap * percentMultiplier;

  // Phase 2: add absolute_by_size and absolute_by_window_size deltas.
  // Two kinds, same shape — the only difference is the tier-key source
  // (sub size string vs. design's windowSize string).
  for (const mod of modifiers.modifiers) {
    if (mod.enabled === false) continue;
    if (!matches(mod.detector, designName, inputs, mat)) continue;

    let delta: number | undefined;
    if (mod.kind === 'absolute_by_size') {
      delta = mod.tiers[size];
    } else if (mod.kind === 'absolute_by_window_size') {
      const winSize = inputs?.windowSize as string | undefined;
      if (winSize) delta = mod.tiers[winSize];
    } else {
      continue;
    }

    if (typeof delta !== 'number' || !Number.isFinite(delta) || delta === 0) continue;
    result += delta;
    applied.push(mod.id);
    breakdown.push({ id: mod.id, label: mod.label, deltaDollars: delta });
  }

  // Round to cents for display consistency with the legacy code path.
  const finalMap = Math.round(result * 100) / 100;
  const dealerPrice = Math.round(finalMap * 0.6 * 100) / 100;

  return { finalMap, dealerPrice, applied, breakdown };
}

// ─── Parsing / migration ──────────────────────────────────────────────────

/**
 * Parse a stored `pricing_modifiers` JSON string into a typed config.
 * Returns the default config if the input is missing or unparseable.
 */
export function parsePricingModifiers(raw: string | null | undefined): PricingModifiersConfig {
  if (!raw) return DEFAULT_PRICING_MODIFIERS;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.modifiers)) {
      return DEFAULT_PRICING_MODIFIERS;
    }
    return parsed as PricingModifiersConfig;
  } catch {
    return DEFAULT_PRICING_MODIFIERS;
  }
}

/**
 * Build a `PricingModifiersConfig` from the legacy split settings keys
 * (`flat_pack_discount_percent`, `foundation_discount_percent`). Used during
 * the one-shot migration when no `pricing_modifiers` key exists yet.
 *
 * The legacy keys store discount as POSITIVE percents (e.g. "30" = 30% off),
 * but the modifier config uses NEGATIVE for discounts. So we negate.
 */
export function migrateFromLegacyDiscounts(
  flatPackDiscountPercent: number | undefined,
  foundationDiscountPercent: number | undefined,
): PricingModifiersConfig {
  const out = JSON.parse(JSON.stringify(DEFAULT_PRICING_MODIFIERS)) as PricingModifiersConfig;
  for (const mod of out.modifiers) {
    if (mod.id === 'flatPack' && mod.kind === 'percent' && Number.isFinite(flatPackDiscountPercent)) {
      // `|| 0` normalizes the -0 that -Math.abs(0) produces.
      mod.value = -Math.abs(flatPackDiscountPercent as number) || 0;
    }
    if (mod.id === 'foundation' && mod.kind === 'percent' && Number.isFinite(foundationDiscountPercent)) {
      mod.value = -Math.abs(foundationDiscountPercent as number) || 0;
    }
  }
  return out;
}
