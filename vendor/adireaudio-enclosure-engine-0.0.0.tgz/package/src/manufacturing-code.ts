/** Opaque machine identifiers. Allocation/persistence belongs to the server. */
export const MANUFACTURING_CODE_PATTERN = /^[2-9A-HJKMNP-Z]{8}$/;

export function validateManufacturingCode(code: string): string {
  if (!MANUFACTURING_CODE_PATTERN.test(code)) throw new Error('Invalid manufacturing code');
  return code;
}

export interface ManufacturingOperation {
  key: string;
  legacyBarcode: string;
  material: string;
  thicknessInches: number;
}

/** Rename only; program bytes and machining instructions must never change. */
export function applyManufacturingCodes<T extends {
  filename: string; content: string; type: string; manufacturing?: ManufacturingOperation;
}>(files: T[], codes: Readonly<Record<string, string>>): T[] {
  const used = new Set<string>();
  return files.map(file => {
    if (!file.manufacturing) return file;
    const code = validateManufacturingCode(codes[file.manufacturing.key] || '');
    if (used.has(code)) throw new Error(`Duplicate manufacturing code: ${code}`);
    used.add(code);
    return { ...file, filename: `${code}.${file.type}` };
  });
}
