import type { SupbSubPosition } from './subwoofer-placement';

/** Measurements of the displayed circles only; never a port/brace fit verdict. */
export function measureSubwooferLayout(points: SupbSubPosition[], panelWidth: number,
  panelDepth: number, outsideDiameter: number) {
  if (!points.length || ![panelWidth, panelDepth, outsideDiameter].every(n => Number.isFinite(n) && n > 0)
    || points.some(p => !Number.isFinite(p.x) || !Number.isFinite(p.y))) return null;
  const radius = outsideDiameter / 2;
  const edgeClearance = Math.min(...points.flatMap(p => [
    p.x - radius, panelWidth - p.x - radius, p.y - radius, panelDepth - p.y - radius,
  ]));
  let subToSubGap = Infinity;
  points.forEach((p, i) => points.slice(i + 1).forEach(q => {
    subToSubGap = Math.min(subToSubGap, Math.hypot(p.x - q.x, p.y - q.y) - outsideDiameter);
  }));
  return { edgeClearance, subToSubGap: Number.isFinite(subToSubGap) ? subToSubGap : 0 };
}
