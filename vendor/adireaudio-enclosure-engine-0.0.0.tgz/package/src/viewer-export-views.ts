import type { EnclosureInputs } from './types/enclosure';

export type ExportView = {
  suffix: string;
  vector: [number, number, number];
};

type ExportViewInputs = Pick<EnclosureInputs, 'enclosureConfiguration' | 'windowEnabled' | 'windowSize'>;

/** Product photography convention: +Z is the assembled front, +Y is up.
 * Match the three whole-box photos on the American Bass Dual 12 King listing.
 * Keep the former preset vector length so angle changes do not change zoom.
 * These are export-only presets; interactive Reset has its own camera pose. */
function productView(suffix: string, azimuth: number, elevation: number): ExportView {
  const yaw = azimuth * Math.PI / 180;
  const pitch = elevation * Math.PI / 180;
  const distance = Math.sqrt(1.25);
  return { suffix, vector: [
    distance * Math.sin(yaw) * Math.cos(pitch),
    distance * Math.sin(pitch),
    distance * Math.cos(yaw) * Math.cos(pitch),
  ] };
}

/** Camera directions are in assembled world space, including Subs Up/Port Up.
 * The scene bounds supply the target after any enclosure rotation. */
export function getExportViews(inputs: ExportViewInputs): ExportView[] {
  const views = [
    productView('Front-Left', -34, 21),
    productView('Front-Right', 41, 22),
    productView('Front', 0, 25),
  ];
  // Retain the additional window feature view, independently of the three
  // product angles. No terminal-cup or wire close-ups are exported.
  if (!inputs.windowEnabled || !inputs.windowSize) return views;
  if (inputs.enclosureConfiguration === 'Subs Up/Port Back') {
    views.push({ suffix: 'Front-Hero', vector: [0.05, 0.25, 1.20] });
  } else if (inputs.enclosureConfiguration === 'Subs Up/Port Up') {
    views.push({ suffix: 'Bottom-Up', vector: [0.30, -0.90, 0.45] });
  } else {
    views.push({ suffix: 'Top-Down', vector: [0.30, 1.00, 0.45] });
  }
  return views;
}
