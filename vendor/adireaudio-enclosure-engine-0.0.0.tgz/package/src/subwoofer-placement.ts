/**
 * Subwoofer cutout placement helpers — SUPB only.
 *
 * For Subs Up / Port Back configurations, the sub cutout sits on the Top
 * panel. By default the auto-positioner picks an X (along box width) and
 * Y (along box depth) based on the L-shape chamber geometry: chamber center
 * for the X axis (S2 alone if it fits, combined S1+S2 if S2 is too narrow),
 * and box depth center / forward-shifted for the Y axis (forward shift in
 * the combined fallback so the sub clears the L-shape port leg at the back).
 *
 * V1 lets the user override that auto position by typing X/Y offsets in the
 * Design tab. The offsets shift the entire multi-sub pattern by the same
 * amount so subs stay evenly spaced. Validation uses the subwoofer's
 * outside diameter (OD) — not the through-hole cutout — so the visible
 * flange must clear the safe zone with `SUB_SAFETY_BORDER` to spare.
 *
 * Panel coords: X = box width axis (X=0 at Side Left outer face, X=boxW at
 * Side Right outer face); Y = box depth axis (Y=0 at front face, Y=boxD at
 * back face).
 */

import type {
  CutListItem,
  EnclosureCalculations,
  EnclosureInputs,
} from './types/enclosure';

/**
 * Required clearance between the sub CUTOUT (through-hole) and any chamber
 * wall (Side Left, PP1/PP2, baffle, back). The cutout is what physically
 * collides with internal structure — the flange sits on the OUTSIDE of the
 * top panel and just laps over the chamber wall's top edge harmlessly.
 */
export const SUB_SAFETY_BORDER = 0.25;

/**
 * Required clearance between the sub flange OD and the box's outer panel
 * edges (front/back/left/right faces). Acts as a hard limit on the slider:
 * the flange must keep this much clear of the box's outer rectangle even
 * when the operator drags the pattern toward an outer face.
 *
 * Set to 0.5" so the cutout always has at least a half-inch of wood
 * surrounding it on the outer side. (The chamber-wall safety border
 * `SUB_SAFETY_BORDER` handles the interior side via the cutout, allowing
 * the flange to harmlessly lap over an interior wall's top edge.)
 */
export const OUTER_EDGE_SAFETY_BORDER = 0.5;

// ─── Auto-center Y resolution with outer-edge bias ──────────────────────────

/**
 * Resolve the SUPB sub Y center on the top panel, with a default bias toward
 * keeping the flange OD at least OUTER_EDGE_SAFETY_BORDER inches from
 * the box's outer front/back faces — when geometry permits. Falls back to
 * the legacy formula (boxDepth/2 for S2-only, (boxDepth − portW − wallT)/2
 * for combined fallback) when the constraints can't all be satisfied.
 *
 * Used by the slider's auto-center, the DXF generator's SUPB top cutout
 * pattern, and the 3D viewer's SUPB driver position so all three render
 * the same default location and the user's "+0 offset" lands consistently.
 */
export function resolveSupbAutoCenterY(args: {
  boxDepth: number;
  portWidth: number;
  wallT: number;
  tBaffle: number;
  tBack: number;
  s1Depth: number; // 0 if S2-only (not in combined fallback)
  useCombined: boolean;
  halfOD: number;
  halfCutout: number;
}): number {
  const {
    boxDepth, portWidth, wallT, tBaffle, tBack, s1Depth,
    useCombined, halfOD, halfCutout,
  } = args;

  // Legacy default — preserved when bias can't be satisfied.
  const legacyCy = useCombined
    ? (boxDepth - portWidth - wallT) / 2
    : boxDepth / 2;

  // Outer-edge constraint: flange ≥ default clearance from box outer faces.
  const outerMin = halfOD + OUTER_EDGE_SAFETY_BORDER;
  const outerMax = boxDepth - halfOD - OUTER_EDGE_SAFETY_BORDER;

  // Chamber-wall constraint: cutout doesn't punch baffle / PP2 / back wall.
  const chamberYBack = useCombined ? tBaffle + s1Depth : boxDepth - tBack;
  const chamberMin = tBaffle + halfCutout + SUB_SAFETY_BORDER;
  const chamberMax = chamberYBack - halfCutout - SUB_SAFETY_BORDER;

  const validMin = Math.max(outerMin, chamberMin);
  const validMax = Math.min(outerMax, chamberMax);

  if (validMax >= validMin) {
    // Range is non-empty — clamp legacy cy into it so the auto position
    // sits ≥ OUTER_EDGE_SAFETY_BORDER from the nearest outer face.
    if (legacyCy < validMin) return validMin;
    if (legacyCy > validMax) return validMax;
    return legacyCy;
  }
  // Bias range is empty — geometry is too tight for both constraints; fall
  // back to legacy. Slider can still reach a valid placement using the
  // smaller (cutout/0.25") chamber border + 0" outer overhang allowance.
  return legacyCy;
}

// ─── Default-position resolution (mirrors dxf-generator.ts SUPB cutout logic) ─

/**
 * For SUPB single port, decide whether the sub fits in S2 alone or needs
 * the combined (S2 + S1) chamber as fallback. Mirrors the same decision
 * the DXF generator and 3D viewer make so the override math stays
 * consistent.
 */
function resolveCombinedChamber(
  s2LeftWidth: number, s1RightWidth: number, outsideDiameter: number, subCount: number,
): boolean {
  void s1RightWidth; // only used by callers that read combined width
  if (subCount <= 0 || outsideDiameter <= 0) return false;
  const s2EdgeClearance = (s2LeftWidth - outsideDiameter * subCount) / (subCount + 1);
  return s2EdgeClearance <= 0;
}

/**
 * Resolve the auto-computed cutout pattern center on the Top panel for
 * SUPB. Returns coordinates in box-axis inches (X: 0..boxW, Y: 0..boxD).
 *
 * Single port single sub: cx = chamber X center, cy = chamber Y center.
 * Single port multi sub: cx = chamber X center (subs spread by gap rule);
 *   cy = chamber Y center (all subs share the same Y).
 * Dual port: see comments on resolveAutoCenters for per-chamber handling.
 */
export function resolveAutoCenter(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
): { cx: number; cy: number; chamberWidth: number; useCombined: boolean } {
  const isDualPort = inputs.portQuantity === 'Dual';
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const subCount = subCountOf(inputs);
  const t = wallThickness(inputs);
  const s2 = calc.s2LeftWidth;
  const s1 = calc.s1RightWidth;
  const portW = inputs.portWidth || 0;
  const boxD = inputs.boxDepth;

  if (isDualPort) {
    // Dual port: chambers are separate; XOverride here only applies meaningfully
    // when subCount === 1 (sub centered on box). For 2 subs, the legacy logic
    // places one in each chamber and the override shifts both by the same
    // amount. We still expose a single (cx, cy) — for 2 subs it's the
    // midpoint of both chambers (= boxW/2). cy is always boxD/2.
    return { cx: calc.boxWidth / 2, cy: boxD / 2, chamberWidth: 0, useCombined: false };
  }
  // Single port: the chamber spans width-wise from Side Left to PP1 (S2),
  // and the L-shape connects S2 with S1 acoustically. If sub fits in S2,
  // use S2 alone; else fall back to combined chamber and shift cy forward
  // by (portW + wallThickness)/2 so the sub clears port leg 1 at the back.
  // Y center is biased to keep the flange ≥ OUTER_EDGE_SAFETY_BORDER
  // from the box's outer front/back faces when geometry allows.
  const useCombined = resolveCombinedChamber(s2, s1, od, subCount);
  const chamberWidth = useCombined ? (s2 + s1) : s2;
  const cx = t + chamberWidth / 2;
  const cutoutD = inputs.subCutoutDiameter || od;
  const s1Depth = useCombined
    ? (calc.s1RightDepth > 0 ? calc.s1RightDepth : (boxD - 2 * t - portW - t))
    : 0;
  const cy = resolveSupbAutoCenterY({
    boxDepth: boxD,
    portWidth: portW,
    wallT: t,
    tBaffle: t,
    tBack: t,
    s1Depth,
    useCombined,
    halfOD: od / 2,
    halfCutout: cutoutD / 2,
  });
  return { cx, cy, chamberWidth, useCombined };
}

/** Apply user-supplied offsets to the auto-computed center. */
export function applyOffsets(
  center: { cx: number; cy: number },
  inputs: EnclosureInputs,
): { cx: number; cy: number } {
  return {
    cx: center.cx + (inputs.subwooferXOffset ?? 0),
    cy: center.cy + (inputs.subwooferYOffset ?? 0),
  };
}

// ─── Shared SUPB multi-sub layout ───────────────────────────────────────────

export interface SupbSubPosition {
  /** Physical Top-panel X coordinate, measured from the Side Left outer face. */
  x: number;
  /** Physical Top-panel Y coordinate, measured from the front outer face. */
  y: number;
}

export interface SupbGussetPosition {
  /** Center of the free-standing 5" gusset between an adjacent sub pair. */
  x: number;
  y: number;
  /** The two Top/Bottom dowel locations for the existing front-to-back gusset. */
  dowels: [SupbSubPosition, SupbSubPosition];
}

export type SupbLayoutMode = 'single' | 'straight' | 'staggered';

export interface SupbLayoutResult {
  safe: boolean;
  mode: SupbLayoutMode;
  /** Final physical coordinates after the shared X/Y pattern offset is applied. */
  points: SupbSubPosition[];
  /** Arithmetic center of the final pattern (the anchor used by the offset UI). */
  center: { cx: number; cy: number };
  gussets: SupbGussetPosition[];
  /** Human-readable reason when geometry or the requested translation is unsafe. */
  diagnostic?: string;
}

interface SupbCenterRegion {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
  label: string;
}

interface SupbPortGeometry {
  regions: SupbCenterRegion[];
  /** Raw chamber bounds used to keep the 5" gusset out of PP1/PP2. */
  chamberLeft: number;
  pp1Left: number;
  pp2Left: number;
  pp2Front: number;
  chamberBack: number;
  gussetThickness: number;
  diagnostic?: string;
}

interface SupbBaseLayout extends SupbLayoutResult {
  /** Region assignment is deliberately sticky while the operator translates the pattern. */
  regionIndexes: number[];
  geometry: SupbPortGeometry;
}

const POSITION_EPSILON = 1e-7;
const GUSSET_DEPTH = 5;
const GUSSET_DOWEL_HALF_SPACING = 1.25;

/**
 * Resolve the physical SUPB Top-panel cutout coordinates once for every
 * consumer (DXF, 3D, validation, gussets, and ACC). Existing straight rows
 * remain byte-for-byte stable when they are physically valid. A dual-sub row
 * that is too wide falls back to the operator-approved diagonal arrangement:
 * one driver moves forward and the other backward just far enough for the
 * two flange circles to clear.
 *
 * The current X/Y override still translates the entire resolved pattern. It
 * never changes the stagger or the sub-to-sub relationship.
 */
export function resolveSupbSubLayout(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  xOffsetOverride?: number,
  yOffsetOverride?: number,
): SupbLayoutResult {
  const base = resolveSupbBaseLayout(inputs, calc, cutList);
  if (!base.safe) return base;

  const xOff = xOffsetOverride ?? inputs.subwooferXOffset ?? 0;
  const yOff = yOffsetOverride ?? inputs.subwooferYOffset ?? 0;
  const points = base.points.map(point => ({ x: point.x + xOff, y: point.y + yOff }));
  const regionIndexes = base.regionIndexes;

  for (let i = 0; i < points.length; i++) {
    const region = base.geometry.regions[regionIndexes[i]];
    if (!region || !pointInRegion(points[i], region)) {
      return {
        safe: false,
        mode: base.mode,
        points,
        center: { cx: base.center.cx + xOff, cy: base.center.cy + yOff },
        gussets: buildSupbGussets(points),
        diagnostic: 'Subwoofer pattern would overlap an outer edge, PP1, or the PP2 return leg.',
      };
    }
  }

  const gussets = buildSupbGussets(points);
  if (!gussetsFit(points, gussets, inputs, base.geometry)) {
    return {
      safe: false,
      mode: base.mode,
      points,
      center: { cx: base.center.cx + xOff, cy: base.center.cy + yOff },
      gussets,
      diagnostic: 'The translated gusset would overlap a subwoofer cutout or the PP1/PP2 port walls.',
    };
  }

  return {
    safe: true,
    mode: base.mode,
    points,
    center: { cx: base.center.cx + xOff, cy: base.center.cy + yOff },
    gussets,
  };
}

function resolveSupbBaseLayout(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SupbBaseLayout {
  const emptyGeometry: SupbPortGeometry = {
    regions: [], chamberLeft: 0, pp1Left: 0, pp2Left: 0, pp2Front: 0,
    chamberBack: 0, gussetThickness: 0,
  };
  const fail = (diagnostic: string): SupbBaseLayout => ({
    safe: false,
    mode: subCountOf(inputs) > 1 ? 'straight' : 'single',
    points: [],
    center: { cx: 0, cy: 0 },
    gussets: [],
    diagnostic,
    regionIndexes: [],
    geometry: emptyGeometry,
  });

  if (inputs.enclosureConfiguration !== 'Subs Up/Port Back') {
    return fail('Diagonal Top-panel placement is available only for Subs Up / Port Back designs.');
  }
  if (inputs.portQuantity === 'Dual') {
    return fail('Dual-port SUPB placement uses separate chambers and is not part of the staggered-row solver.');
  }

  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  if (!(od > 0) || !(cutoutD > 0) || subCount <= 0) {
    return fail('A positive subwoofer outside diameter and cutout diameter are required.');
  }

  const geometry = buildSupbPortGeometry(inputs, calc, cutList, od, cutoutD);
  if (geometry.diagnostic) {
    return { ...fail(geometry.diagnostic), geometry };
  }
  if (geometry.regions.length === 0) {
    return { ...fail('No usable Top-panel area remains after outer-edge and port-wall clearances.'), geometry };
  }

  const wallT = wallThicknessFromCutList(inputs, cutList);
  const useCombined = resolveCombinedChamber(calc.s2LeftWidth, calc.s1RightWidth, od, subCount);
  const chamberWidth = useCombined ? calc.s2LeftWidth + calc.s1RightWidth : calc.s2LeftWidth;
  const baseY = resolveSupbAutoCenterY({
    boxDepth: inputs.boxDepth,
    portWidth: inputs.portWidth || 0,
    wallT,
    tBaffle: baffleThickness(inputs, cutList),
    tBack: backThicknessFromCutList(inputs, cutList),
    s1Depth: useCombined ? calc.s1RightDepth : 0,
    useCombined,
    halfOD: od / 2,
    halfCutout: cutoutD / 2,
  });

  // First choice: the exact historical row. This is what keeps valid designs
  // unchanged even though the new solver uses geometric PP1/PP2 boundaries.
  if (chamberWidth > 0) {
    const legacyPoints = legacyXPositions(chamberWidth, od, subCount)
      .map(x => ({ x: wallT + x, y: baseY }));
    const legacyAssignments = assignRegions(legacyPoints, geometry.regions);
    if (legacyAssignments && subFlangesClear(legacyPoints, od)) {
      const gussets = buildSupbGussets(legacyPoints);
      if (gussetsFit(legacyPoints, gussets, inputs, geometry)) {
        return makeBaseLayout(subCount === 1 ? 'single' : 'straight', legacyPoints, legacyAssignments, gussets, geometry);
      }
    }
  }

  // Second choice: keep a straight row, but derive it from the real geometric
  // center region instead of the volume-derived S2 width. This repairs stale
  // volume/chamber disagreement without changing depth placement.
  const regionsByWidth = geometry.regions
    .map((region, index) => ({ region, index }))
    .sort((a, b) => (b.region.xMax - b.region.xMin) - (a.region.xMax - a.region.xMin));
  for (const { region, index } of regionsByWidth) {
    const span = region.xMax - region.xMin;
    const newLayoutSpacing = od + SUB_SAFETY_BORDER;
    if (subCount === 1 || span + POSITION_EPSILON >= newLayoutSpacing * (subCount - 1)) {
      const y = clampNumber(baseY, region.yMin, region.yMax);
      const points = subCount === 1
        ? [{ x: clampNumber(wallT + chamberWidth / 2, region.xMin, region.xMax), y }]
        : Array.from({ length: subCount }, (_, i) => ({
            x: region.xMin + span * i / (subCount - 1),
            y,
          }));
      const gussets = buildSupbGussets(points);
      if (subFlangesClear(points, newLayoutSpacing) && gussetsFit(points, gussets, inputs, geometry)) {
        return makeBaseLayout(subCount === 1 ? 'single' : 'straight', points, points.map(() => index), gussets, geometry);
      }
    }
  }

  // Approved diagonal fallback. Restrict the new behavior to dual-sub boxes;
  // triple/quad arrangements keep their established row unless a future
  // physical construction decision defines multiple staggered gussets.
  if (subCount === 2) {
    const staggeredCenterDistance = od + SUB_SAFETY_BORDER;
    const staggerCandidates: Array<{ points: SupbSubPosition[]; assignments: number[] }> = [];
    for (let leftIndex = 0; leftIndex < geometry.regions.length; leftIndex++) {
      for (let rightIndex = 0; rightIndex < geometry.regions.length; rightIndex++) {
        const leftRegion = geometry.regions[leftIndex];
        const rightRegion = geometry.regions[rightIndex];
        const xLeft = leftRegion.xMin;
        const xRight = rightRegion.xMax;
        const dx = xRight - xLeft;
        if (dx < 0 || dx >= staggeredCenterDistance) continue;
        const dy = Math.sqrt(Math.max(0, staggeredCenterDistance * staggeredCenterDistance - dx * dx)) + POSITION_EPSILON;

        // Try both diagonals. The first matches the requested photo: left sub
        // forward, right sub backward. The mirrored depth arrangement is an
        // equally safe deterministic fallback when PP2 blocks that direction.
        for (const direction of [-1, 1] as const) {
          const leftSign = direction;
          const rightSign = -direction;
          const midMin = Math.max(
            leftRegion.yMin - leftSign * dy / 2,
            rightRegion.yMin - rightSign * dy / 2,
          );
          const midMax = Math.min(
            leftRegion.yMax - leftSign * dy / 2,
            rightRegion.yMax - rightSign * dy / 2,
          );
          if (midMax + POSITION_EPSILON < midMin) continue;
          const midY = clampNumber(baseY, midMin, midMax);
          staggerCandidates.push({
            points: [
              { x: xLeft, y: midY + leftSign * dy / 2 },
              { x: xRight, y: midY + rightSign * dy / 2 },
            ],
            assignments: [leftIndex, rightIndex],
          });
        }
      }
    }

    staggerCandidates.sort((a, b) => {
      const aDy = Math.abs(a.points[1].y - a.points[0].y);
      const bDy = Math.abs(b.points[1].y - b.points[0].y);
      if (Math.abs(aDy - bDy) > POSITION_EPSILON) return aDy - bDy;
      const aCenter = averagePoint(a.points);
      const bCenter = averagePoint(b.points);
      return Math.abs(aCenter.cy - baseY) - Math.abs(bCenter.cy - baseY);
    });

    for (const candidate of staggerCandidates) {
      if (!subFlangesClear(candidate.points, staggeredCenterDistance)) continue;
      const gussets = buildSupbGussets(candidate.points);
      if (!gussetsFit(candidate.points, gussets, inputs, geometry)) continue;
      return makeBaseLayout('staggered', candidate.points, candidate.assignments, gussets, geometry);
    }
  }

  return {
    ...fail(
      subCount === 2
        ? 'The two subwoofers do not fit safely in either a straight or diagonally staggered layout.'
        : 'The subwoofers do not fit safely in the established straight-row layout.',
    ),
    geometry,
  };
}

function makeBaseLayout(
  mode: SupbLayoutMode,
  points: SupbSubPosition[],
  regionIndexes: number[],
  gussets: SupbGussetPosition[],
  geometry: SupbPortGeometry,
): SupbBaseLayout {
  return {
    safe: true,
    mode,
    points,
    center: averagePoint(points),
    gussets,
    regionIndexes,
    geometry,
  };
}

function buildSupbPortGeometry(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  od: number,
  cutoutD: number,
): SupbPortGeometry {
  const wallT = wallThicknessFromCutList(inputs, cutList);
  const tBaffle = baffleThickness(inputs, cutList);
  const tBack = backThicknessFromCutList(inputs, cutList);
  const baffleW = baffleWidthFromCutList(cutList);
  const topW = cutList.find(part => part.partName === 'Top')?.width || calc.boxWidth;
  const pp1 = portPiece1FromCutList(cutList);
  const pp2 = portPiece2FromCutList(cutList);
  const pp1Thick = pp1?.thickness || wallT;
  const gussetThickness = gussetThicknessFromCutList(inputs, cutList);
  const base: SupbPortGeometry = {
    regions: [],
    chamberLeft: wallT,
    pp1Left: baffleW - pp1Thick,
    pp2Left: baffleW - (pp2?.width ?? 0),
    pp2Front: tBaffle + (pp1?.width ?? 0),
    chamberBack: inputs.boxDepth - tBack,
    gussetThickness,
  };

  const invalid = (message: string): SupbPortGeometry => ({ ...base, diagnostic: message });
  if (!Number.isFinite(calc.portLength2) || calc.portLength2 <= 0) {
    return invalid('Port geometry is invalid: Port Length 2 must be greater than zero before subwoofer placement can be resolved.');
  }
  if (!pp1 || !Number.isFinite(pp1.width) || pp1.width <= 0) {
    return invalid('Port geometry is invalid: Port Piece 1 has no positive physical depth.');
  }
  if (calc.labyrinthPort.active) {
    const panelCount = calc.labyrinthPort.panels.length;
    if (panelCount < 2 || !Number.isFinite(calc.labyrinthPort.lanePitch)) {
      return invalid('Labyrinth port geometry is invalid: no return divider was resolved.');
    }
    const mazeLeft = baffleW
      - pp1Thick
      - (panelCount - 1) * calc.labyrinthPort.lanePitch;
    base.pp2Left = mazeLeft;
    base.pp2Front = base.chamberBack;
    if (!(baffleW > 0) || !(mazeLeft > base.chamberLeft)) {
      return invalid('Labyrinth port geometry is invalid: the divider maze consumes the full subwoofer chamber width.');
    }

    // The serpentine occupies the full-depth band at the right of the box.
    // Keep top-firing cutouts in the unobstructed rectangle to its left.
    const halfOD = od / 2;
    const halfCutout = cutoutD / 2;
    const region: SupbCenterRegion = {
      xMin: Math.max(
        halfOD + OUTER_EDGE_SAFETY_BORDER,
        base.chamberLeft + halfCutout + SUB_SAFETY_BORDER,
      ),
      xMax: Math.min(
        topW - halfOD - OUTER_EDGE_SAFETY_BORDER,
        mazeLeft - halfCutout - SUB_SAFETY_BORDER,
      ),
      yMin: Math.max(
        halfOD + OUTER_EDGE_SAFETY_BORDER,
        tBaffle + halfCutout + SUB_SAFETY_BORDER,
      ),
      yMax: Math.min(
        inputs.boxDepth - halfOD - OUTER_EDGE_SAFETY_BORDER,
        base.chamberBack - halfCutout - SUB_SAFETY_BORDER,
      ),
      label: 'Labyrinth-free chamber',
    };
    base.regions = region.xMax + POSITION_EPSILON >= region.xMin
      && region.yMax + POSITION_EPSILON >= region.yMin
      ? [region]
      : [];
    return base;
  }
  if (!pp2 || !Number.isFinite(pp2.width) || pp2.width <= 0) {
    return invalid('Port geometry is invalid: Port Piece 2 has no positive physical width. Adjust tuning, port width, or box depth.');
  }
  if (!(baffleW > 0) || !(base.pp1Left > base.chamberLeft) || !(base.pp2Left > base.chamberLeft)) {
    return invalid('Port geometry is invalid: PP1/PP2 extends through the usable subwoofer chamber.');
  }
  if (!(base.pp2Front > tBaffle) || !(base.pp2Front < base.chamberBack)) {
    return invalid('Port geometry is invalid: the PP1/PP2 corner lies outside the enclosure depth.');
  }

  const halfOD = od / 2;
  const halfCutout = cutoutD / 2;
  const xMin = Math.max(
    halfOD + OUTER_EDGE_SAFETY_BORDER,
    base.chamberLeft + halfCutout + SUB_SAFETY_BORDER,
  );
  const outerXMax = topW - halfOD - OUTER_EDGE_SAFETY_BORDER;
  const yMin = Math.max(
    halfOD + OUTER_EDGE_SAFETY_BORDER,
    tBaffle + halfCutout + SUB_SAFETY_BORDER,
  );
  const outerYMax = inputs.boxDepth - halfOD - OUTER_EDGE_SAFETY_BORDER;
  const chamberYMax = base.chamberBack - halfCutout - SUB_SAFETY_BORDER;

  // The cutout-center region is an L: a narrow left leg can use full depth,
  // while the wider right/front leg must stop before the PP2 return wall.
  const fullDepthLeft: SupbCenterRegion = {
    xMin,
    xMax: Math.min(outerXMax, base.pp2Left - halfCutout - SUB_SAFETY_BORDER),
    yMin,
    yMax: Math.min(outerYMax, chamberYMax),
    label: 'S2 left leg (full depth)',
  };
  const frontStrip: SupbCenterRegion = {
    xMin,
    xMax: Math.min(outerXMax, base.pp1Left - halfCutout - SUB_SAFETY_BORDER),
    yMin,
    yMax: Math.min(outerYMax, base.pp2Front - halfCutout - SUB_SAFETY_BORDER),
    label: 'S1 + S2 front leg (ahead of PP2)',
  };
  base.regions = [fullDepthLeft, frontStrip]
    .filter(region => region.xMax + POSITION_EPSILON >= region.xMin && region.yMax + POSITION_EPSILON >= region.yMin);
  return base;
}

function buildSupbGussets(points: SupbSubPosition[]): SupbGussetPosition[] {
  if (points.length <= 1) return [];
  const sorted = [...points].sort((a, b) => a.x - b.x);
  const gussets: SupbGussetPosition[] = [];
  for (let i = 0; i < sorted.length - 1; i++) {
    const x = (sorted[i].x + sorted[i + 1].x) / 2;
    const y = (sorted[i].y + sorted[i + 1].y) / 2;
    gussets.push({
      x,
      y,
      dowels: [
        { x, y: y - GUSSET_DOWEL_HALF_SPACING },
        { x, y: y + GUSSET_DOWEL_HALF_SPACING },
      ],
    });
  }
  return gussets;
}

function gussetsFit(
  points: SupbSubPosition[],
  gussets: SupbGussetPosition[],
  inputs: EnclosureInputs,
  geometry: SupbPortGeometry,
): boolean {
  if (gussets.length === 0) return true;
  const cutoutR = (inputs.subCutoutDiameter || inputs.outsideDiameter || 0) / 2;
  const halfT = geometry.gussetThickness / 2;
  const halfD = GUSSET_DEPTH / 2;

  for (const gusset of gussets) {
    const xMin = gusset.x - halfT;
    const xMax = gusset.x + halfT;
    const yMin = gusset.y - halfD;
    const yMax = gusset.y + halfD;
    const insideFullDepthLeg = xMin >= geometry.chamberLeft && xMax <= geometry.pp2Left;
    const insideFrontLeg = xMin >= geometry.chamberLeft && xMax <= geometry.pp1Left && yMax <= geometry.pp2Front;
    if ((!insideFullDepthLeg && !insideFrontLeg) || yMin < 0 || yMax > geometry.chamberBack) return false;

    // A gusset may sit below the flange, but it cannot project into the actual
    // through-hole/basket opening on the Top panel.
    for (const point of points) {
      const nearestX = clampNumber(point.x, xMin, xMax);
      const nearestY = clampNumber(point.y, yMin, yMax);
      if (Math.hypot(point.x - nearestX, point.y - nearestY) + POSITION_EPSILON < cutoutR) {
        return false;
      }
    }
  }
  return true;
}

function subFlangesClear(points: SupbSubPosition[], od: number): boolean {
  for (let i = 0; i < points.length; i++) {
    for (let j = i + 1; j < points.length; j++) {
      if (Math.hypot(points[i].x - points[j].x, points[i].y - points[j].y) + POSITION_EPSILON < od) {
        return false;
      }
    }
  }
  return true;
}

function assignRegions(points: SupbSubPosition[], regions: SupbCenterRegion[]): number[] | null {
  const assignments: number[] = [];
  for (const point of points) {
    // Prefer the full-depth left leg when both rectangles contain a point;
    // that leaves the widest safe Y translation range for the operator.
    const index = regions.findIndex(region => pointInRegion(point, region));
    if (index < 0) return null;
    assignments.push(index);
  }
  return assignments;
}

function pointInRegion(point: SupbSubPosition, region: SupbCenterRegion): boolean {
  return point.x + POSITION_EPSILON >= region.xMin && point.x - POSITION_EPSILON <= region.xMax &&
    point.y + POSITION_EPSILON >= region.yMin && point.y - POSITION_EPSILON <= region.yMax;
}

function legacyXPositions(width: number, od: number, count: number): number[] {
  if (!(width > 0) || !(od > 0) || count <= 0) return [];
  const gap = (width - od * count) / (count + 1);
  return Array.from({ length: count }, (_, i) => gap * (i + 1) + od * i + od / 2);
}

function averagePoint(points: SupbSubPosition[]): { cx: number; cy: number } {
  if (points.length === 0) return { cx: 0, cy: 0 };
  return {
    cx: points.reduce((sum, point) => sum + point.x, 0) / points.length,
    cy: points.reduce((sum, point) => sum + point.y, 0) / points.length,
  };
}

function clampNumber(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

// ─── Safe-zone bounds ────────────────────────────────────────────────────────

export interface SafeZone {
  /** Inclusive panel-X range the cutout center must keep its OD inside (with safety border). */
  xMin: number; xMax: number;
  /** Inclusive panel-Y range the cutout center must keep its OD inside. */
  yMin: number; yMax: number;
  /** Human-readable description of the active zone (for tooltips / debug). */
  label: string;
}

/**
 * Compute the safe rectangle the entire pattern's bounding extent must fit
 * inside. We treat the pattern as a single "envelope" (multi-sub stretches
 * X-wise via gap spacing) so the validity check below subtracts the
 * pattern's half-width from xMin/xMax instead of restating it per-sub.
 *
 * SUPB single port:
 *  - S2-only: chamber is a clean rectangle, X = [t, t+s2], Y = [tBaffle, boxD-tBack].
 *  - Combined: simplified to the front part of the interior that's NOT
 *    inside the L-shape port leg. X = [t, boxW-t], Y = [tBaffle, tBaffle+s1RightDepth].
 *    This is conservative — the back-left corner (over S2 width) is
 *    actually deeper, but treating the safe zone as the front rectangle
 *    avoids the user putting a sub partly over port leg 1.
 *
 * SUPB dual port: the safe zone is whichever chamber is currently hosting
 *  the cutout (left or right). We default to the left chamber for offset
 *  purposes; the offset shifts both subs symmetrically. xMin/xMax for the
 *  left chamber: [t + portW + pp1Thick, t + portW + pp1Thick + s2].
 */
export function computeSafeZone(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SafeZone {
  const isDualPort = inputs.portQuantity === 'Dual';
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const subCount = subCountOf(inputs);
  const t = wallThickness(inputs);
  const tBaffle = baffleThickness(inputs, cutList);
  const tBack = wallThickness(inputs);
  const boxD = inputs.boxDepth;
  const boxW = calc.boxWidth;
  const s2 = calc.s2LeftWidth;
  const s1 = calc.s1RightWidth;
  const portW = inputs.portWidth || 0;

  if (isDualPort) {
    // Dual port: pick the left chamber's bounds. PP1 thickness from cut list
    // (or fall back to wall thickness).
    const pp1Thick = portPiece1ThicknessFromCutList(cutList) || t;
    const leftMin = t + portW + pp1Thick;
    const leftMax = leftMin + s2;
    return {
      xMin: leftMin, xMax: leftMax,
      yMin: tBaffle, yMax: boxD - tBack,
      label: 'Dual-port left chamber (S2 Left)',
    };
  }
  // Single port:
  // PP1 runs depth-wise on the right side of the chamber (its right face = baffleWidth).
  // Right of PP1 is the port channel — cutouts there would dump into the port,
  // so the safe X zone must cap at PP1's LEFT face for both S2-only and
  // combined-fallback paths.
  const baffleW_in = baffleWidthFromCutList(cutList);
  const pp1Thick_in = portPiece1ThicknessFromCutList(cutList) || t;
  const pp1LeftFace = baffleW_in > 0 ? baffleW_in - pp1Thick_in : (boxW - t);

  const useCombined = resolveCombinedChamber(s2, s1, od, subCount);
  if (!useCombined) {
    // S2-only: chamber spans Side Left interior to PP1 left face for the
    // full box depth. (s2LeftWidth from calc is volume-derived, not geometric;
    // use the actual geometric bound from PP1 instead.)
    return {
      xMin: t, xMax: pp1LeftFace,
      yMin: tBaffle, yMax: boxD - tBack,
      label: 'S2 Left chamber (sub fits)',
    };
  }
  // Combined fallback — front strip of the interior that doesn't include the
  // L-shape port leg's back-side intrusion. PP1 cuts through the front strip
  // at baffleW − tPP1, so cap xMax there to keep cutouts clear of the port
  // channel (which sits between PP1's right face and Side Right interior).
  const s1Depth = calc.s1RightDepth > 0 ? calc.s1RightDepth : (boxD - tBaffle - tBack - portW - t);
  return {
    xMin: t, xMax: pp1LeftFace,
    yMin: tBaffle, yMax: tBaffle + s1Depth,
    label: 'Combined S1+S2 chamber (front strip, left of PP1 / port channel)',
  };
}

// ─── Pattern bounding extent (multi-sub spread) ─────────────────────────────

/**
 * Compute the half-width of the cutout pattern's X extent (from cx to the
 * outer edge of the leftmost / rightmost sub). For a single sub this is
 * just od/2. For multi-sub, the leftmost sub's center is offset from the
 * pattern center by (chamber/2 - od/2 - safetyMargin) — but here we just
 * want the X extent of the pattern itself, so it's:
 *
 *   halfWidth = (subCount-1) * (od + gap)/2 + od/2
 *
 * where gap is computed by the existing getSubwooferXPositions formula.
 * For the half-EXTENT (= pattern half-width PLUS sub radius) we add od/2
 * on top.
 */
function patternHalfExtentX(subCount: number, od: number, chamberWidth: number): number {
  if (subCount <= 0 || od <= 0) return 0;
  if (subCount === 1) return od / 2;
  // gap = (chamberWidth - od*subCount) / (subCount+1). Pattern endpoints sit
  // halfway between the outer subs and the chamber edge, so the pattern's
  // half-width from the pattern center is (chamberWidth - 2*gap) / 2 - od/2.
  // For the extent (center → outer edge of outer sub), we add od/2 back:
  // halfExtent = (chamberWidth - 2*gap) / 2.
  const gap = (chamberWidth - od * subCount) / (subCount + 1);
  return (chamberWidth - 2 * gap) / 2;
}

// ─── Safe offset range (for slider min/max) ─────────────────────────────────

export interface SafeOffsetRange {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
}

/**
 * Convert the safe zone (absolute panel coords) into safe-offset-from-auto-center
 * bounds, after subtracting the pattern's half-extent and the safety borders.
 * Used by the Design tab UI to clamp slider min/max so the operator can't
 * drag the pattern into an unsafe region.
 *
 * Two independent constraints combined per axis:
 *  - Chamber walls: the through-hole CUTOUT must clear interior walls
 *    (Side Left, PP1, baffle, back, PP2 / L-port leg) by SUB_SAFETY_BORDER.
 *  - Box outer faces: the visible flange OD must not overhang the box's
 *    outer rectangle (front/back/sides), bounded by OUTER_EDGE_SAFETY_BORDER.
 *
 * The CUTOUT-based chamber check is what allows the user to push a sub
 * inward past the OD's footprint of the chamber wall — the flange harmlessly
 * laps over the wall's top edge while the through-hole stays inside.
 *
 * If the chamber is too small for the sub at any offset (rare but possible
 * when the math has produced a chamber narrower than `cutout + 2*SAFETY`),
 * the returned range collapses (xMax < xMin); the UI should treat that as
 * "no safe placement on this axis" and surface it as an error.
 */
export function getSafeOffsetRange(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SafeOffsetRange {
  if (
    inputs.enclosureConfiguration === 'Subs Up/Port Back' &&
    inputs.portQuantity !== 'Dual' &&
    subCountOf(inputs) > 1
  ) {
    const base = resolveSupbBaseLayout(inputs, calc, cutList);
    if (!base.safe || base.points.length === 0) {
      return { xMin: 1, xMax: -1, yMin: 1, yMax: -1 };
    }
    let xMin = -Infinity;
    let xMax = Infinity;
    let yMin = -Infinity;
    let yMax = Infinity;
    for (let i = 0; i < base.points.length; i++) {
      const point = base.points[i];
      const region = base.geometry.regions[base.regionIndexes[i]];
      xMin = Math.max(xMin, region.xMin - point.x);
      xMax = Math.min(xMax, region.xMax - point.x);
      yMin = Math.max(yMin, region.yMin - point.y);
      yMax = Math.min(yMax, region.yMax - point.y);
    }
    const halfT = base.geometry.gussetThickness / 2;
    const halfD = GUSSET_DEPTH / 2;
    for (const gusset of base.gussets) {
      const usesFullDepthLeg = gusset.x + halfT <= base.geometry.pp2Left + POSITION_EPSILON;
      xMin = Math.max(xMin, base.geometry.chamberLeft + halfT - gusset.x);
      xMax = Math.min(
        xMax,
        (usesFullDepthLeg ? base.geometry.pp2Left : base.geometry.pp1Left) - halfT - gusset.x,
      );
      yMin = Math.max(yMin, halfD - gusset.y);
      yMax = Math.min(
        yMax,
        (usesFullDepthLeg ? base.geometry.chamberBack : base.geometry.pp2Front) - halfD - gusset.y,
      );
    }
    return { xMin, xMax, yMin, yMax };
  }

  const auto = resolveAutoCenter(inputs, calc);
  const chamber = computeSafeZone(inputs, calc, cutList);
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  const chamberWidth = auto.chamberWidth || (chamber.xMax - chamber.xMin);

  // Pattern half-extents — same X spread (gap-spaced flanges) for both
  // checks; only the radius portion differs (cutout vs OD).
  const patternHalfX_OD = patternHalfExtentX(subCount, od, chamberWidth);
  const patternHalfX_cutout = patternHalfX_OD - od / 2 + cutoutD / 2;

  // Outer panel bounds = box outer rectangle for SUPB
  const boxW = calc.boxWidth;
  const boxD = inputs.boxDepth;

  // Required absolute-coord min/max from each constraint
  const xMinChamber = chamber.xMin + patternHalfX_cutout + SUB_SAFETY_BORDER;
  const xMaxChamber = chamber.xMax - patternHalfX_cutout - SUB_SAFETY_BORDER;
  const xMinOuter = 0 + patternHalfX_OD + OUTER_EDGE_SAFETY_BORDER;
  const xMaxOuter = boxW - patternHalfX_OD - OUTER_EDGE_SAFETY_BORDER;

  const yMinChamber = chamber.yMin + cutoutD / 2 + SUB_SAFETY_BORDER;
  const yMaxChamber = chamber.yMax - cutoutD / 2 - SUB_SAFETY_BORDER;
  const yMinOuter = 0 + od / 2 + OUTER_EDGE_SAFETY_BORDER;
  const yMaxOuter = boxD - od / 2 - OUTER_EDGE_SAFETY_BORDER;

  return {
    xMin: Math.max(xMinChamber, xMinOuter) - auto.cx,
    xMax: Math.min(xMaxChamber, xMaxOuter) - auto.cx,
    yMin: Math.max(yMinChamber, yMinOuter) - auto.cy,
    yMax: Math.min(yMaxChamber, yMaxOuter) - auto.cy,
  };
}

/**
 * Absolute safe-center rectangle for the sub cutout on the Top panel.
 * Same constraints as `getSafeOffsetRange`, but returned in panel-local
 * inches (X = box width axis, Y = box depth axis) instead of as relative
 * offsets from the auto-center. The 3D viewer's no-go overlay reads this
 * to render a translucent outline showing where the cutout center can
 * sit.
 */
export interface SubSafeCenterRect {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
  /** True if at least one axis collapsed (xMax < xMin || yMax < yMin) —
   *  i.e. the geometry has no valid placement. UI should surface this. */
  collapsed: boolean;
}

export function computeSubSafeCenterRect(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SubSafeCenterRect {
  const multiBase = inputs.enclosureConfiguration === 'Subs Up/Port Back' &&
    inputs.portQuantity !== 'Dual' && subCountOf(inputs) > 1
    ? resolveSupbBaseLayout(inputs, calc, cutList)
    : null;
  const auto = multiBase?.safe ? multiBase.center : resolveAutoCenter(inputs, calc);
  const range = getSafeOffsetRange(inputs, calc, cutList);
  const xMin = auto.cx + range.xMin;
  const xMax = auto.cx + range.xMax;
  const yMin = auto.cy + range.yMin;
  const yMax = auto.cy + range.yMax;
  return { xMin, xMax, yMin, yMax, collapsed: xMax < xMin || yMax < yMin };
}

// ─── Placement check ────────────────────────────────────────────────────────

export interface SubPlacementCheck {
  safe: boolean;
  conflict?: { axis: 'x' | 'y'; side: 'min' | 'max'; overrun: number; label: string };
  /** The pattern's resolved center after applying offsets. */
  center: { cx: number; cy: number };
  /** The safe zone the placement was validated against. */
  zone: SafeZone;
}

export function checkSubwooferPlacement(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  xOffsetOverride?: number,
  yOffsetOverride?: number,
): SubPlacementCheck {
  if (
    inputs.enclosureConfiguration === 'Subs Up/Port Back' &&
    inputs.portQuantity !== 'Dual' &&
    subCountOf(inputs) > 1
  ) {
    const layout = resolveSupbSubLayout(inputs, calc, cutList, xOffsetOverride, yOffsetOverride);
    const computedZone = computeSafeZone(inputs, calc, cutList);
    const zone = {
      ...computedZone,
      label: layout.mode === 'staggered'
        ? 'Top panel — automatic diagonal stagger'
        : 'Top panel — geometric straight row',
    };
    if (layout.safe) return { safe: true, center: layout.center, zone };
    return {
      safe: false,
      center: layout.center,
      zone,
      conflict: {
        axis: 'x',
        side: 'min',
        overrun: 0,
        label: layout.diagnostic || 'No safe straight or diagonally staggered subwoofer layout exists.',
      },
    };
  }

  const auto = resolveAutoCenter(inputs, calc);
  const xOff = xOffsetOverride ?? inputs.subwooferXOffset ?? 0;
  const yOff = yOffsetOverride ?? inputs.subwooferYOffset ?? 0;
  const center = { cx: auto.cx + xOff, cy: auto.cy + yOff };
  const zone = computeSafeZone(inputs, calc, cutList);

  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  const chamberWidth = auto.chamberWidth || (zone.xMax - zone.xMin);
  const patternHalfX_OD = patternHalfExtentX(subCount, od, chamberWidth);
  const patternHalfX_cutout = patternHalfX_OD - od / 2 + cutoutD / 2;
  const halfCutout = cutoutD / 2;
  const halfOD = od / 2;
  const boxW = calc.boxWidth;
  const boxD = inputs.boxDepth;

  // Chamber-wall constraints: cutout must clear interior structure
  const xMinChamber = zone.xMin + patternHalfX_cutout + SUB_SAFETY_BORDER;
  const xMaxChamber = zone.xMax - patternHalfX_cutout - SUB_SAFETY_BORDER;
  const yMinChamber = zone.yMin + halfCutout + SUB_SAFETY_BORDER;
  const yMaxChamber = zone.yMax - halfCutout - SUB_SAFETY_BORDER;
  // Outer-panel constraints: flange OD must not overhang the box's outer faces
  const xMinOuter = 0 + patternHalfX_OD + OUTER_EDGE_SAFETY_BORDER;
  const xMaxOuter = boxW - patternHalfX_OD - OUTER_EDGE_SAFETY_BORDER;
  const yMinOuter = 0 + halfOD + OUTER_EDGE_SAFETY_BORDER;
  const yMaxOuter = boxD - halfOD - OUTER_EDGE_SAFETY_BORDER;

  // Check chamber-wall constraints first (they're the more nuanced ones).
  if (center.cx < xMinChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'min', overrun: xMinChamber - center.cx,
        label: 'Sub cutout would overlap the Side Left wall (or the chamber edge)',
      },
    };
  }
  if (center.cx > xMaxChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'max', overrun: center.cx - xMaxChamber,
        label: 'Sub cutout would overlap PP1 / port channel / Side Right wall',
      },
    };
  }
  if (center.cy < yMinChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'min', overrun: yMinChamber - center.cy,
        label: 'Sub cutout would overlap the front baffle/PP1 boundary',
      },
    };
  }
  if (center.cy > yMaxChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'max', overrun: center.cy - yMaxChamber,
        label: 'Sub cutout would overlap PP2 / L-shape port leg at the back',
      },
    };
  }
  // Then outer-panel overhang checks.
  if (center.cx < xMinOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'min', overrun: xMinOuter - center.cx,
        label: 'Sub flange would overhang the box’s left face',
      },
    };
  }
  if (center.cx > xMaxOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'max', overrun: center.cx - xMaxOuter,
        label: 'Sub flange would overhang the box’s right face',
      },
    };
  }
  if (center.cy < yMinOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'min', overrun: yMinOuter - center.cy,
        label: 'Sub flange would overhang the box’s front face',
      },
    };
  }
  if (center.cy > yMaxOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'max', overrun: center.cy - yMaxOuter,
        label: 'Sub flange would overhang the box’s back face',
      },
    };
  }
  return { safe: true, center, zone };
}

/** Find the nearest (xOffset, yOffset) pair that places the sub safely. */
export function findNearestSafeOffsets(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  desired: { x: number; y: number } = {
    x: inputs.subwooferXOffset ?? 0,
    y: inputs.subwooferYOffset ?? 0,
  },
): { x: number; y: number } | null {
  const initial = checkSubwooferPlacement(inputs, calc, cutList, desired.x, desired.y);
  if (initial.safe) return desired;

  // Sweep outward in 1/8" rings around the desired offset.
  const step = 0.125;
  const maxR = 12; // generous range; sweeps well past any sane offset.
  for (let r = step; r <= maxR; r += step) {
    // Check 8 points around a ring at this radius, in cardinal + diagonal order.
    for (const [dx, dy] of [
      [-r, 0], [r, 0], [0, -r], [0, r],
      [-r, -r], [r, -r], [-r, r], [r, r],
    ]) {
      const cand = { x: desired.x + dx, y: desired.y + dy };
      if (checkSubwooferPlacement(inputs, calc, cutList, cand.x, cand.y).safe) {
        return cand;
      }
    }
  }
  return null;
}

// ─── Internal helpers ───────────────────────────────────────────────────────

function subCountOf(inputs: EnclosureInputs): number {
  switch (inputs.subwooferQuantity) {
    case 'Dual': return 2;
    case 'Triple': return 3;
    case 'Quad': return 4;
    default: return 1;
  }
}

function wallThickness(inputs: EnclosureInputs): number {
  // Wall thickness for SUPB-RD/SD = B1/D1 (thin); HD = B2/D2 (thick).
  const isMDF = inputs.enclosureType.includes('MDF');
  const isHeavy = inputs.enclosureType.includes('Heavy');
  if (isMDF) return isHeavy ? 1.0 : 0.75;
  return isHeavy ? 0.945 : 0.709;
}

function baffleThickness(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const baffle = cutList.find(p => p.partName === 'Baffle');
  if (baffle?.thickness && baffle.thickness > 0) return baffle.thickness;
  return wallThickness(inputs);
}

function portPiece1ThicknessFromCutList(cutList: CutListItem[]): number {
  const pp1 =
    cutList.find(p => p.partName === 'Port Piece 1') ??
    cutList.find(p => p.partName === 'Port Piece 1 Left');
  return pp1?.thickness ?? 0;
}

function baffleWidthFromCutList(cutList: CutListItem[]): number {
  const baffle = cutList.find(p => p.partName === 'Baffle');
  return baffle?.width ?? 0;
}

function portPiece1FromCutList(cutList: CutListItem[]): CutListItem | undefined {
  return cutList.find(p => p.partName === 'Port Piece 1') ??
    cutList.find(p => p.partName === 'Port Piece 1 Left');
}

function portPiece2FromCutList(cutList: CutListItem[]): CutListItem | undefined {
  return cutList.find(p => p.partName === 'Port Piece 2') ??
    cutList.find(p => p.partName === 'Port Piece 2 Left');
}

function wallThicknessFromCutList(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const side = cutList.find(p => p.partName === 'Side Left');
  return side?.thickness && side.thickness > 0 ? side.thickness : wallThickness(inputs);
}

function backThicknessFromCutList(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const back = cutList.find(p => p.partName === 'Back');
  return back?.thickness && back.thickness > 0 ? back.thickness : wallThickness(inputs);
}

function gussetThicknessFromCutList(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const gusset = cutList.find(p => p.partName.startsWith('Gusset'));
  return gusset?.thickness && gusset.thickness > 0 ? gusset.thickness : wallThickness(inputs);
}
