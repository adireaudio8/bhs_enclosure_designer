import { resolveManufacturingProfile } from './manufacturing-profile';
/**
 * Subwoofer cutout placement helpers — SUPB only.
 *
 * For Subs Up / Port Back configurations, the sub cutout sits on the Top
 * panel. By default the auto-positioner picks an X (along box width) and
 * Y (along box depth) based on the L-shape chamber geometry: chamber center
 * for the X axis (S2 alone if it fits, combined S1+S2 if S2 is too narrow),
 * and box depth center / forward-shifted for the Y axis (forward shift in
 * the combined fallback so the sub clears the L-shape port leg at the back).
 *
 * One through four drivers accept independent absolute centers.
 * Older shared X/Y offsets remain supported when those centers are absent.
 * The flange clears the outer panel; the circular cutout plus its wood
 * border clears the chamber walls and the inside corner of the port.
 *
 * Panel coords: X = box width axis (X=0 at Side Left outer face, X=boxW at
 * Side Right outer face); Y = box depth axis (Y=0 at front face, Y=boxD at
 * back face).
 */

import type {
  CutListItem,
  EnclosureCalculations,
  EnclosureInputs,
} from './types/enclosure';
import { validateCutoutProfile, profileBounds, frameProfile, profileGap, moveProfile, rectProfile, offsetProfile } from './subwoofer-profile';

/**
 * Required clearance between the sub CUTOUT (through-hole) and any chamber
 * wall (Side Left, PP1/PP2, baffle, back). The cutout is what physically
 * collides with internal structure — the flange sits on the OUTSIDE of the
 * top panel and just laps over the chamber wall's top edge harmlessly.
 */
export const SUB_SAFETY_BORDER = 0.25;

/**
 * Required clearance between the sub flange OD and the box's outer panel
 * edges (front/back/left/right faces). Acts as a hard limit on the slider:
 * the flange must keep this much clear of the box's outer rectangle even
 * when the operator drags the pattern toward an outer face.
 *
 * Set to 0.5" so the cutout always has at least a half-inch of wood
 * surrounding it on the outer side. (The chamber-wall safety border
 * `SUB_SAFETY_BORDER` handles the interior side via the cutout, allowing
 * the flange to harmlessly lap over an interior wall's top edge.)
 */
export const OUTER_EDGE_SAFETY_BORDER = 0.5;

// ─── Auto-center Y resolution with outer-edge bias ──────────────────────────

/**
 * Resolve the SUPB sub Y center on the top panel, with a default bias toward
 * keeping the flange OD at least OUTER_EDGE_SAFETY_BORDER inches from
 * the box's outer front/back faces — when geometry permits. Falls back to
 * the legacy formula (boxDepth/2 for S2-only, (boxDepth − portW − wallT)/2
 * for combined fallback) when the constraints can't all be satisfied.
 *
 * Used by the slider's auto-center, the DXF generator's SUPB top cutout
 * pattern, and the 3D viewer's SUPB driver position so all three render
 * the same default location and the user's "+0 offset" lands consistently.
 */
export function resolveSupbAutoCenterY(args: {
  boxDepth: number;
  portWidth: number;
  wallT: number;
  tBaffle: number;
  tBack: number;
  s1Depth: number; // 0 if S2-only (not in combined fallback)
  useCombined: boolean;
  halfOD: number;
  halfCutout: number;
}): number {
  const {
    boxDepth, portWidth, wallT, tBaffle, tBack, s1Depth,
    useCombined, halfOD, halfCutout,
  } = args;

  // Legacy default — preserved when bias can't be satisfied.
  const legacyCy = useCombined
    ? (boxDepth - portWidth - wallT) / 2
    : boxDepth / 2;

  // Outer-edge constraint: flange ≥ default clearance from box outer faces.
  const outerMin = halfOD + OUTER_EDGE_SAFETY_BORDER;
  const outerMax = boxDepth - halfOD - OUTER_EDGE_SAFETY_BORDER;

  // Chamber-wall constraint: cutout doesn't punch baffle / PP2 / back wall.
  const chamberYBack = useCombined ? tBaffle + s1Depth : boxDepth - tBack;
  const chamberMin = tBaffle + halfCutout + SUB_SAFETY_BORDER;
  const chamberMax = chamberYBack - halfCutout - SUB_SAFETY_BORDER;

  const validMin = Math.max(outerMin, chamberMin);
  const validMax = Math.min(outerMax, chamberMax);

  if (validMax >= validMin) {
    // Range is non-empty — clamp legacy cy into it so the auto position
    // sits ≥ OUTER_EDGE_SAFETY_BORDER from the nearest outer face.
    if (legacyCy < validMin) return validMin;
    if (legacyCy > validMax) return validMax;
    return legacyCy;
  }
  // Bias range is empty — geometry is too tight for both constraints; fall
  // back to legacy. Slider can still reach a valid placement using the
  // smaller (cutout/0.25") chamber border + 0" outer overhang allowance.
  return legacyCy;
}

// ─── Default-position resolution (mirrors dxf-generator.ts SUPB cutout logic) ─

/**
 * For SUPB single port, decide whether the sub fits in S2 alone or needs
 * the combined (S2 + S1) chamber as fallback. Mirrors the same decision
 * the DXF generator and 3D viewer make so the override math stays
 * consistent.
 */
function resolveCombinedChamber(
  s2LeftWidth: number, s1RightWidth: number, outsideDiameter: number, subCount: number,
): boolean {
  void s1RightWidth; // only used by callers that read combined width
  if (subCount <= 0 || outsideDiameter <= 0) return false;
  const s2EdgeClearance = (s2LeftWidth - outsideDiameter * subCount) / (subCount + 1);
  return s2EdgeClearance <= 0;
}

/**
 * Resolve the auto-computed cutout pattern center on the Top panel for
 * SUPB. Returns coordinates in box-axis inches (X: 0..boxW, Y: 0..boxD).
 *
 * Single port single sub: cx = chamber X center, cy = chamber Y center.
 * Single port multi sub: cx = chamber X center (subs spread by gap rule);
 *   cy = chamber Y center (all subs share the same Y).
 * Dual port: see comments on resolveAutoCenters for per-chamber handling.
 */
export function resolveAutoCenter(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
): { cx: number; cy: number; chamberWidth: number; useCombined: boolean } {
  const isDualPort = inputs.portQuantity === 'Dual';
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const subCount = subCountOf(inputs);
  const t = wallThickness(inputs);
  const s2 = calc.s2LeftWidth;
  const s1 = calc.s1RightWidth;
  const portW = inputs.portWidth || 0;
  const boxD = inputs.boxDepth;

  if (isDualPort) {
    // Dual port: chambers are separate; XOverride here only applies meaningfully
    // when subCount === 1 (sub centered on box). For 2 subs, the legacy logic
    // places one in each chamber and the override shifts both by the same
    // amount. We still expose a single (cx, cy) — for 2 subs it's the
    // midpoint of both chambers (= boxW/2). cy is always boxD/2.
    return { cx: calc.boxWidth / 2, cy: boxD / 2, chamberWidth: 0, useCombined: false };
  }
  // Single port: the chamber spans width-wise from Side Left to PP1 (S2),
  // and the L-shape connects S2 with S1 acoustically. If sub fits in S2,
  // use S2 alone; else fall back to combined chamber and shift cy forward
  // by (portW + wallThickness)/2 so the sub clears port leg 1 at the back.
  // Y center is biased to keep the flange ≥ OUTER_EDGE_SAFETY_BORDER
  // from the box's outer front/back faces when geometry allows.
  const useCombined = resolveCombinedChamber(s2, s1, od, subCount);
  const chamberWidth = useCombined ? (s2 + s1) : s2;
  const cx = t + chamberWidth / 2;
  const cutoutD = inputs.subCutoutDiameter || od;
  const s1Depth = useCombined
    ? (calc.s1RightDepth > 0 ? calc.s1RightDepth : (boxD - 2 * t - portW - t))
    : 0;
  const cy = resolveSupbAutoCenterY({
    boxDepth: boxD,
    portWidth: portW,
    wallT: t,
    tBaffle: t,
    tBack: t,
    s1Depth,
    useCombined,
    halfOD: od / 2,
    halfCutout: cutoutD / 2,
  });
  return { cx, cy, chamberWidth, useCombined };
}

/** Apply user-supplied offsets to the auto-computed center. */
export function applyOffsets(
  center: { cx: number; cy: number },
  inputs: EnclosureInputs,
): { cx: number; cy: number } {
  return {
    cx: center.cx + (inputs.subwooferXOffset ?? 0),
    cy: center.cy + (inputs.subwooferYOffset ?? 0),
  };
}

// ─── Shared SUPB multi-sub layout ───────────────────────────────────────────

export interface SupbSubPosition {
  /** Physical Top-panel X coordinate, measured from the Side Left outer face. */
  x: number;
  /** Physical Top-panel Y coordinate, measured from the front outer face. */
  y: number;
}

export interface SupbGussetPosition {
  /** Center of a free-standing 5" brace in solid wood between/around cutouts. */
  x: number;
  y: number;
  /** The two Top/Bottom dowel locations for the existing front-to-back gusset. */
  dowels: [SupbSubPosition, SupbSubPosition];
}

export type SupbLayoutMode = 'single' | 'straight' | 'staggered' | 'grid' | 'manual';

export interface SupbLayoutResult {
  safe: boolean;
  mode: SupbLayoutMode;
  /** Final physical coordinates, including independent centers or shared offsets. */
  points: SupbSubPosition[];
  /** Arithmetic center of the final pattern (the anchor used by the offset UI). */
  center: { cx: number; cy: number };
  gussets: SupbGussetPosition[];
  /** Full-height baffle brace X centers; Top braces use gussets instead. */
  baffleBraces?: number[];
  /** Human-readable reason when geometry or the requested translation is unsafe. */
  diagnostic?: string;
}

interface SupbCenterRegion {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
  label: string;
}

interface SupbPortGeometry {
  regions: SupbCenterRegion[];
  centerBounds?: SupbCenterRegion;
  cornerRadius?: number;
  /** Raw chamber bounds used to keep the 5" gusset out of PP1/PP2. */
  chamberLeft: number;
  chamberFront: number;
  pp1Left: number;
  pp2Left: number;
  pp2Front: number;
  chamberBack: number;
  gussetThickness: number;
  diagnostic?: string;
}

interface SupbBaseLayout extends SupbLayoutResult {
  /** Conservative rectangular assignments for legacy shared-offset slider bounds. */
  regionIndexes: number[];
  geometry: SupbPortGeometry;
}

const POSITION_EPSILON = 1e-7;
const GUSSET_DEPTH = 5;
const GUSSET_DOWEL_HALF_SPACING = 1.25;

/**
 * Resolve the physical SUPB Top-panel cutout coordinates once for every
 * consumer (DXF, 3D, validation, gussets, and ACC). Existing straight rows
 * remain byte-for-byte stable when they are physically valid. Dual layouts
 * fall back to a diagonal; triple/quad layouts try grids and staggered rows.
 *
 * Independent one-through-four-sub centers take precedence over legacy shared offsets.
 * Every requested arrangement is rechecked, including its midpoint gusset.
 */
export function resolveSupbSubLayout(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  xOffsetOverride?: number,
  yOffsetOverride?: number,
  cutoutClearance = 0,
  positionsOverride?: SupbSubPosition[],
): SupbLayoutResult {
  // Machining allowance validates the displayed centers and brace row; it must
  // never silently find a different automatic layout that the DXF does not use.
  if(cutoutClearance>0 && positionsOverride===undefined) {
    const raw=resolveSupbSubLayout(inputs,calc,cutList,xOffsetOverride,yOffsetOverride);
    if(!raw.safe) return raw;
    const checked=resolveSupbSubLayout(inputs,calc,cutList,xOffsetOverride,yOffsetOverride,cutoutClearance,raw.points);
    if(checked.safe && (checked.gussets.length!==raw.gussets.length || checked.gussets.some((g,i)=>
      Math.abs(g.x-raw.gussets[i].x)>1e-7 || Math.abs(g.y-raw.gussets[i].y)>1e-7)))
      return {...raw,safe:false,diagnostic:'The cutting allowance does not clear the displayed brace positions. Adjust the sub positions before exporting.'};
    return checked;
  }
  if (inputs.subwooferCutoutProfile) return resolveProfileSupbLayout(inputs, calc, cutList, xOffsetOverride, yOffsetOverride, cutoutClearance, positionsOverride);
  const requested = positionsOverride ?? inputs.subwooferPositions;
  const checkedInputs = { ...inputs, subCutoutDiameter: inputs.subCutoutDiameter + 2*cutoutClearance };
  const dual = inputs.portQuantity === 'Dual';
  // Manual moves need only geometry, not an expensive search for a different layout.
  const base = requested !== undefined && !dual
    ? {...resolveEmptyLayout(),geometry:buildSupbPortGeometry(checkedInputs,calc,cutList,inputs.outsideDiameter||inputs.subCutoutDiameter,checkedInputs.subCutoutDiameter)}
    : dual ? resolveDualPortLayout(checkedInputs, calc, cutList) : resolveSupbBaseLayout(checkedInputs, calc, cutList);
  if (requested !== undefined) {
    const count = subCountOf(inputs);
    if (!Array.isArray(requested) || requested.length !== count
      || requested.some(p => !p || !Number.isFinite(p.x) || !Number.isFinite(p.y))) {
      return { ...base, safe: false, mode: 'manual', points: [], gussets: [],
        diagnostic: `Enter finite X and Y centers for all ${count} subwoofers.` };
    }
    return checkSupbPoints(requested, 'manual', checkedInputs, base.geometry);
  }
  if (!base.safe) return base;

  const xOff = xOffsetOverride ?? inputs.subwooferXOffset ?? 0;
  const yOff = yOffsetOverride ?? inputs.subwooferYOffset ?? 0;
  const points = base.points.map(point => ({ x: point.x + xOff, y: point.y + yOff }));
  const gussets = base.gussets.map(g => ({ x: g.x + xOff, y: g.y + yOff,
    dowels: g.dowels.map(p => ({ x: p.x + xOff, y: p.y + yOff })) as SupbGussetPosition['dowels'] }));
  return checkSupbPoints(points, base.mode, checkedInputs, base.geometry, gussets);
}

function resolveEmptyLayout(): SupbLayoutResult {
  return {safe:false,mode:'manual',points:[],center:{cx:0,cy:0},gussets:[]};
}

/** Uploaded outlines use their actual boundary at the port corner, not an inscribed circle. */
function resolveProfileSupbLayout(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[], xo?: number, yo?: number, clearance=0, positionsOverride?: SupbSubPosition[]): SupbLayoutResult {
  const original = inputs.subwooferCutoutProfile!;
  const fail = (diagnostic: string, points: SupbSubPosition[] = []): SupbLayoutResult => ({safe:false,mode:'manual',points,center:points.length?averagePoint(points):{cx:0,cy:0},gussets:[],diagnostic});
  let p=original;
  try { validateCutoutProfile(original); p={...original,version:1,sourcePath:undefined,opening:offsetProfile(original.opening,clearance)}; validateCutoutProfile(p); } catch(e) { return fail((e as Error).message); }
  const g = buildSupbPortGeometry(inputs,calc,parts,p.frame.width,profileBounds(p.opening).width);
  if(g.diagnostic) return fail(g.diagnostic);
  const width=parts.find(v=>v.partName==='Top')?.width || calc.boxWidth, depth=inputs.boxDepth;
  if(inputs.portQuantity==='Dual') {
    // Keep custom openings and their braces in the central rectangle ahead of
    // both return walls. This conservative region clears both mirrored ports.
    const wall=wallThicknessFromCutList(inputs,parts), pp1=portPiece1FromCutList(parts)!;
    const pp2=portPiece2FromCutList(parts)!;
    if(2*pp2.width >= width-2*(wall+inputs.portWidth)) return fail('The two port return pieces overlap. Adjust the port geometry before placing custom cutouts.');
    g.chamberLeft=wall+inputs.portWidth+pp1.thickness;
    g.pp1Left=width-g.chamberLeft;
    g.pp2Left=g.pp1Left;
    g.chamberBack=Math.min(g.chamberBack,g.pp2Front);
  }
  const recess=inputs.recessedMounting ? .125 : 0;
  const b=profileBounds(p.opening), f=frameProfile(p,recess), count=subCountOf(inputs), border=.25+p.maxError;
  const x0=Math.max(p.frame.width/2+.5+recess,g.chamberLeft-b.minX+border), x1=Math.min(width-p.frame.width/2-.5-recess,g.pp1Left-b.maxX-border);
  const y0=Math.max(p.frame.height/2+.5+recess,g.chamberFront-b.minY+border), y1=Math.min(depth-p.frame.height/2-.5-recess,g.chamberBack-b.maxY-border);
  const obstacle=rectProfile(g.pp2Left,g.pp2Front,width,depth);
  const check=(points:SupbSubPosition[],mode:SupbLayoutMode):SupbLayoutResult => {
    if(points.some(v=>!Number.isFinite(v.x)||!Number.isFinite(v.y)||v.x<x0-1e-7||v.x>x1+1e-7||v.y<y0-1e-7||v.y>y1+1e-7
      || profileGap(moveProfile(p.opening,v.x,v.y),obstacle)<.25+p.maxError-1e-7)) return fail('Custom cutout would overlap an edge, chamber wall, or port clearance.',points);
    for(let i=0;i<points.length;i++)for(let j=i+1;j<points.length;j++)if(profileGap(moveProfile(f,points[i].x,points[i].y),moveProfile(f,points[j].x,points[j].y))<.25-1e-7) return fail('Keep at least 0.25 inch between the outside frames.',points);
    let gussets=buildSupbGussets(points);
    const fits=(gs:SupbGussetPosition[]) => gussetsFit(points,gs,inputs,g,.25) && gs.every(v=>points.every(q=>profileGap(moveProfile(p.opening,q.x,q.y),rectProfile(v.x-g.gussetThickness/2,v.y-2.5,v.x+g.gussetThickness/2,v.y+2.5))>=.25+p.maxError && profileGap(moveProfile(f,q.x,q.y),rectProfile(v.x-g.gussetThickness/2,v.y-2.5,v.x+g.gussetThickness/2,v.y+2.5))>=.25));
    if(!fits(gussets) || (points.length>=3 && mode==='manual' && gussets.some(v=>Math.abs(v.y-gussets[0].y)>1e-7))) { const found=findMultiRowGussets(points,{...inputs,subCutoutDiameter:Math.max(Math.hypot(b.width,b.height),Math.hypot(p.frame.width+2*recess,p.frame.height+2*recess))},g); if(!found||!fits(found))return fail('The braces need 0.25 inch clear of the outside frames and must clear the cutouts and port walls.',points); gussets=found; }
    return {safe:true,mode,points,center:averagePoint(points),gussets};
  };
  if(positionsOverride) return positionsOverride.length===count && positionsOverride.every(p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y)) ? check(positionsOverride,'manual') : fail(`Enter finite X and Y centers for all ${count} subwoofers.`);
  if(inputs.subwooferPositions !== undefined) {
    if(!Array.isArray(inputs.subwooferPositions)||inputs.subwooferPositions.length!==count || inputs.subwooferPositions.some(p=>!p||!Number.isFinite(p.x)||!Number.isFinite(p.y))) return fail(`Enter finite X and Y centers for all ${count} subwoofers.`);
    return check(inputs.subwooferPositions,'manual');
  }
  if(x1<x0 || y1<y0) return fail('The custom cutout and outside frame need more panel space.');
  const candidates:{points:SupbSubPosition[];mode:SupbLayoutMode}[]=[];
  for(let rows=1;rows<=Math.min(2,count);rows++) {
    const cols=Math.ceil(count/rows), stepX=p.frame.width+g.gussetThickness+.5+2*recess,stepY=p.frame.height+5.5+2*recess,spanX=(cols-1)*stepX, spanY=(rows-1)*stepY;
    if(spanX>x1-x0+1e-7||spanY>y1-y0+1e-7)continue;
    for(const tx of [.5,0,1,.25,.75])for(const ty of [.5,0,1,.25,.75]) {
      const points=Array.from({length:count},(_,i)=>({x:x0+(x1-x0-spanX)*tx+(i%cols)*stepX,y:y0+(y1-y0-spanY)*ty+Math.floor(i/cols)*stepY}));
      candidates.push({points,mode:count===1?'single':rows===1?'straight':'grid'});
    }
  }
  for(const c of candidates) {
    const result=check(c.points.map(v=>({x:v.x+(xo??inputs.subwooferXOffset??0),y:v.y+(yo??inputs.subwooferYOffset??0)})),c.mode);
    if(result.safe)return result;
  }
  return fail('No arrangement clears the custom frames, cutouts, port walls and braces. Increase the panel size or adjust the design.');
}

/** Exact circle clearance around the inside corner of the L-shaped port.
 * The flange stays outside the box; the cutout plus its wood border must
 * clear the port chamber. The old union of rectangles excluded this arc. */
function pointClearsPort(point: SupbSubPosition, geometry: SupbPortGeometry): boolean {
  if (!Number.isFinite(point.x) || !Number.isFinite(point.y)
    || !geometry.centerBounds || !pointInRegion(point, geometry.centerBounds)) return false;
  return geometry.cornerRadius === undefined || Math.hypot(
    Math.max(0, geometry.pp2Left - point.x), Math.max(0, geometry.pp2Front - point.y),
  ) + POSITION_EPSILON >= geometry.cornerRadius;
}

function checkSupbPoints(points: SupbSubPosition[], mode: SupbLayoutMode,
  inputs: EnclosureInputs, geometry: SupbPortGeometry,
  gussets = buildSupbGussets(points)): SupbLayoutResult {
  // All multi-row uprights share one depth datum for the ACC08 drilling jig.
  // Preserve sub indices; only brace assignment may be optimized.
  if (points.length >= 3 && mode === 'manual') {
    const found = findMultiRowGussets(points, inputs, geometry);
    if (found) gussets = found;
    else return {safe:false,mode,points,center:averagePoint(points),gussets:[],diagnostic:'No common brace row clears the cutouts and port walls.'};
  }
  const invalidIndex = points.findIndex(point => !pointClearsPort(point, geometry));
  const diagnostic = geometry.diagnostic || (invalidIndex >= 0
    ? `Sub ${invalidIndex + 1} would overlap an outer edge, chamber wall, or PP1/PP2 port clearance.`
    : !subFlangesClear(points, (inputs.outsideDiameter || inputs.subCutoutDiameter || 0)
        + SUB_SAFETY_BORDER + (inputs.recessedMounting ? .25 : 0))
      ? 'The subwoofer flanges are too close or overlap; keep at least 0.25 inch between them.'
      : !gussetsFit(points, gussets, inputs, geometry,
          SUB_SAFETY_BORDER)
        ? 'The brace needs 0.25 inch clear of each outside frame and must clear the port walls.' : undefined);
  return { safe: !diagnostic, mode, points, center: averagePoint(points), gussets, diagnostic };
}

/** Broad editing bounds; the live fit check also checks the port corner,
 * the other driver and gusset. These are not a promise of a safe position. */
export function getSupbPositionBounds(inputs: EnclosureInputs, calc: EnclosureCalculations,
  cutList: CutListItem[]): SafeOffsetRange | null {
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  if (!(od > 0) || inputs.enclosureConfiguration !== 'Subs Up/Port Back' || inputs.portQuantity === 'Dual') return null;
  const g = buildSupbPortGeometry(inputs, calc, cutList, od, inputs.subCutoutDiameter || od);
  return g.diagnostic || !g.centerBounds ? null : g.centerBounds;
}

/** Seed manual controls from the displayed layout, even when auto cannot fit. */
export function getSupbEditablePositions(inputs: EnclosureInputs, calc: EnclosureCalculations,
  cutList: CutListItem[]): SupbSubPosition[] {
  const layout = resolveSupbSubLayout(inputs, calc, cutList);
  const count = subCountOf(inputs);
  if (layout.points.length === count) return layout.points.map(p => ({ ...p }));
  const auto = resolveAutoCenter(inputs, calc);
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  return legacyXPositions(auto.chamberWidth, od, count)
    .map(x => ({ x: wallThicknessFromCutList(inputs, cutList) + x + (inputs.subwooferXOffset ?? 0),
      y: auto.cy + (inputs.subwooferYOffset ?? 0) }));
}

function resolveDualPortLayout(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[]): SupbBaseLayout {
  const od=inputs.outsideDiameter||inputs.subCutoutDiameter, cutout=inputs.subCutoutDiameter||od;
  const g=buildSupbPortGeometry(inputs,calc,parts,od,cutout);
  const width=parts.find(p=>p.partName==='Top')?.width||calc.boxWidth;
  const wall=wallThicknessFromCutList(inputs,parts), pp1=portPiece1FromCutList(parts), pp2=portPiece2FromCutList(parts);
  g.chamberLeft=wall+inputs.portWidth+(pp1?.thickness||wall);
  g.pp1Left=width-g.chamberLeft;
  g.pp2Left=g.pp1Left;
  g.chamberBack=Math.min(g.chamberBack,g.pp2Front);
  g.cornerRadius=undefined;
  const recess=inputs.recessedMounting ? .125 : 0;
  const region={xMin:Math.max(od/2+.5+recess,g.chamberLeft+cutout/2+.25),xMax:Math.min(width-od/2-.5-recess,g.pp1Left-cutout/2-.25),
    yMin:Math.max(od/2+.5+recess,g.chamberFront+cutout/2+.25),yMax:Math.min(inputs.boxDepth-od/2-.5-recess,g.chamberBack-cutout/2-.25),label:'Between both ports'};
  g.centerBounds=region; g.regions=[region];
  if(pp2 && 2*pp2.width>=width-2*(wall+inputs.portWidth)) g.diagnostic='The two port return pieces overlap. Adjust the port geometry first.';
  const count=subCountOf(inputs);
  let fallback:SupbLayoutResult={safe:false,mode:'straight',points:[],center:{cx:width/2,cy:inputs.boxDepth/2},gussets:[],diagnostic:g.diagnostic||'No safe arrangement fits between both ports.'};
  for(let rows=1;rows<=Math.min(2,count);rows++) {
    const cols=Math.ceil(count/rows),step=od+g.gussetThickness+.5+(inputs.recessedMounting ? .25 : 0);
    if((cols-1)*step>region.xMax-region.xMin || (rows-1)*step>region.yMax-region.yMin) continue;
    for(const ty of [.5,0,1]) {
      const points=Array.from({length:count},(_,i)=>({x:(region.xMin+region.xMax-(cols-1)*step)/2+(i%cols)*step,
        y:region.yMin+(region.yMax-region.yMin-(rows-1)*step)*ty+Math.floor(i/cols)*step}));
      const checked=checkSupbPoints(points,'manual',inputs,g);
      if(checked.safe) return {...checked,mode:rows===1?'straight':'grid',geometry:g,regionIndexes:[]};
      fallback=checked;
    }
  }
  return {...fallback,geometry:g,regionIndexes:[]};
}

function resolveSupbBaseLayout(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SupbBaseLayout {
  const emptyGeometry: SupbPortGeometry = {
    regions: [], chamberLeft: 0, chamberFront: 0, pp1Left: 0, pp2Left: 0, pp2Front: 0,
    chamberBack: 0, gussetThickness: 0,
  };
  const fail = (diagnostic: string): SupbBaseLayout => ({
    safe: false,
    mode: subCountOf(inputs) > 1 ? 'straight' : 'single',
    points: [],
    center: { cx: 0, cy: 0 },
    gussets: [],
    diagnostic,
    regionIndexes: [],
    geometry: emptyGeometry,
  });

  if (inputs.enclosureConfiguration !== 'Subs Up/Port Back') {
    return fail('Diagonal Top-panel placement is available only for Subs Up / Port Back designs.');
  }
  if (inputs.portQuantity === 'Dual') {
    return fail('Dual-port SUPB placement uses separate chambers and is not part of the staggered-row solver.');
  }

  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  if (!(od > 0) || !(cutoutD > 0) || subCount <= 0) {
    return fail('A positive subwoofer outside diameter and cutout diameter are required.');
  }

  const geometry = buildSupbPortGeometry(inputs, calc, cutList, od, cutoutD);
  if (geometry.diagnostic) {
    return { ...fail(geometry.diagnostic), geometry };
  }
  if (geometry.regions.length === 0) {
    if (!geometry.centerBounds || geometry.centerBounds.xMax < geometry.centerBounds.xMin
      || geometry.centerBounds.yMax < geometry.centerBounds.yMin) {
      return { ...fail('No usable Top-panel area remains after outer-edge and port-wall clearances.'), geometry };
    }
  }

  const wallT = wallThicknessFromCutList(inputs, cutList);
  const useCombined = resolveCombinedChamber(calc.s2LeftWidth, calc.s1RightWidth, od, subCount);
  const chamberWidth = useCombined ? calc.s2LeftWidth + calc.s1RightWidth : calc.s2LeftWidth;
  const baseY = resolveSupbAutoCenterY({
    boxDepth: inputs.boxDepth,
    portWidth: inputs.portWidth || 0,
    wallT,
    tBaffle: baffleThickness(inputs, cutList),
    tBack: backThicknessFromCutList(inputs, cutList),
    s1Depth: useCombined ? calc.s1RightDepth : 0,
    useCombined,
    halfOD: od / 2,
    halfCutout: cutoutD / 2,
  });

  // First choice: the exact historical row. This is what keeps valid designs
  // unchanged even though the new solver uses geometric PP1/PP2 boundaries.
  if (chamberWidth > 0) {
    const legacyPoints = legacyXPositions(chamberWidth, od, subCount)
      .map(x => ({ x: wallT + x, y: baseY }));
    const legacyAssignments = assignRegions(legacyPoints, geometry.regions);
    if (legacyAssignments && subFlangesClear(legacyPoints, od+SUB_SAFETY_BORDER+(inputs.recessedMounting ? .25 : 0))) {
      const gussets = buildSupbGussets(legacyPoints);
      if (gussetsFit(legacyPoints, gussets, inputs, geometry)) {
        return makeBaseLayout(subCount === 1 ? 'single' : 'straight', legacyPoints, legacyAssignments, gussets, geometry);
      }
    }
  }

  // Second choice: keep a straight row, but derive it from the real geometric
  // center region instead of the volume-derived S2 width. This repairs stale
  // volume/chamber disagreement without changing depth placement.
  const regionsByWidth = geometry.regions
    .map((region, index) => ({ region, index }))
    .sort((a, b) => (b.region.xMax - b.region.xMin) - (a.region.xMax - a.region.xMin));
  for (const { region, index } of regionsByWidth) {
    const span = region.xMax - region.xMin;
    const newLayoutSpacing = od + geometry.gussetThickness + 2*SUB_SAFETY_BORDER + (inputs.recessedMounting ? .25 : 0);
    if (subCount === 1 || span + POSITION_EPSILON >= newLayoutSpacing * (subCount - 1)) {
      const y = clampNumber(baseY, region.yMin, region.yMax);
      const points = subCount === 1
        ? [{ x: clampNumber(wallT + chamberWidth / 2, region.xMin, region.xMax), y }]
        : Array.from({ length: subCount }, (_, i) => ({
            x: region.xMin + span * i / (subCount - 1),
            y,
          }));
      const gussets = buildSupbGussets(points);
      if (subFlangesClear(points, newLayoutSpacing) && gussetsFit(points, gussets, inputs, geometry)) {
        return makeBaseLayout(subCount === 1 ? 'single' : 'straight', points, points.map(() => index), gussets, geometry);
      }
    }
  }

  // Keep the established dual-sub solver (and its midpoint brace) unchanged.
  if (subCount === 2) {
    const staggeredCenterDistance = od + SUB_SAFETY_BORDER + (inputs.recessedMounting ? .25 : 0);
    const staggerCandidates: Array<{ points: SupbSubPosition[]; assignments: number[] }> = [];
    for (let leftIndex = 0; leftIndex < geometry.regions.length; leftIndex++) {
      for (let rightIndex = 0; rightIndex < geometry.regions.length; rightIndex++) {
        const leftRegion = geometry.regions[leftIndex];
        const rightRegion = geometry.regions[rightIndex];
        const xLeft = leftRegion.xMin;
        const xRight = rightRegion.xMax;
        const dx = xRight - xLeft;
        if (dx < 0 || dx >= staggeredCenterDistance) continue;
        const dy = Math.sqrt(Math.max(0, staggeredCenterDistance * staggeredCenterDistance - dx * dx)) + POSITION_EPSILON;

        // Try both diagonals. The first matches the requested photo: left sub
        // forward, right sub backward. The mirrored depth arrangement is an
        // equally safe deterministic fallback when PP2 blocks that direction.
        for (const direction of [-1, 1] as const) {
          const leftSign = direction;
          const rightSign = -direction;
          const midMin = Math.max(
            leftRegion.yMin - leftSign * dy / 2,
            rightRegion.yMin - rightSign * dy / 2,
          );
          const midMax = Math.min(
            leftRegion.yMax - leftSign * dy / 2,
            rightRegion.yMax - rightSign * dy / 2,
          );
          if (midMax + POSITION_EPSILON < midMin) continue;
          const midY = clampNumber(baseY, midMin, midMax);
          staggerCandidates.push({
            points: [
              { x: xLeft, y: midY + leftSign * dy / 2 },
              { x: xRight, y: midY + rightSign * dy / 2 },
            ],
            assignments: [leftIndex, rightIndex],
          });
        }
      }
    }

    staggerCandidates.sort((a, b) => {
      const aDy = Math.abs(a.points[1].y - a.points[0].y);
      const bDy = Math.abs(b.points[1].y - b.points[0].y);
      if (Math.abs(aDy - bDy) > POSITION_EPSILON) return aDy - bDy;
      const aCenter = averagePoint(a.points);
      const bCenter = averagePoint(b.points);
      return Math.abs(aCenter.cy - baseY) - Math.abs(bCenter.cy - baseY);
    });

    for (const candidate of staggerCandidates) {
      if (!subFlangesClear(candidate.points, staggeredCenterDistance)) continue;
      const gussets = buildSupbGussets(candidate.points);
      if (!gussetsFit(candidate.points, gussets, inputs, geometry)) continue;
      return makeBaseLayout('staggered', candidate.points, candidate.assignments, gussets, geometry);
    }

    // Circle-aware boundary search adds the usable curved area around PP2.
    // Preserve every previously safe row/stagger by running this only last.
    const bounds = geometry.centerBounds;
    if (bounds) {
      const ys = new Set([bounds.yMin, bounds.yMax, clampNumber(baseY, bounds.yMin, bounds.yMax)]);
      const steps = Math.min(256, Math.max(1, Math.ceil((bounds.yMax - bounds.yMin) / 0.0625)));
      for (let k = 0; k <= steps; k++) ys.add(bounds.yMin + (bounds.yMax - bounds.yMin) * k / steps);
      const candidates: SupbSubPosition[] = [];
      for (const y of ys) {
        const cornerDy = Math.max(0, geometry.pp2Front - y);
        const radius = geometry.cornerRadius;
        const xMax = radius !== undefined && cornerDy < radius
          ? Math.min(bounds.xMax, geometry.pp2Left - Math.sqrt(radius * radius - cornerDy * cornerDy))
          : bounds.xMax;
        for (const x of [bounds.xMin, xMax]) {
          const point = { x, y };
          if (pointClearsPort(point, geometry)) candidates.push(point);
        }
      }
      let best: SupbSubPosition[] | null = null;
      let bestScore = Infinity;
      for (const left of candidates) for (const right of candidates) {
        if (left.x >= right.x || !subFlangesClear([left, right], staggeredCenterDistance)) continue;
        const points = [left, right];
        const score = Math.abs(left.y - right.y) + Math.abs((left.y + right.y) / 2 - baseY) * 0.01;
        if (score >= bestScore || !gussetsFit(points, buildSupbGussets(points), inputs, geometry)) continue;
        best = points; bestScore = score;
      }
      if (best) return makeBaseLayout('staggered', best, [-1, -1], buildSupbGussets(best), geometry);
    }
  }

  if (subCount === 3 || subCount === 4) {
    const multiRow = findMultiRowLayout(subCount, od + SUB_SAFETY_BORDER + (inputs.recessedMounting ? .25 : 0), baseY, inputs, geometry);
    if (multiRow) return multiRow;
  }

  return {
    ...fail(
      subCount === 2
        ? 'The two subwoofers do not fit safely in either a straight or diagonally staggered layout.'
        : 'No safe row, two-row grid, or staggered layout fits the subwoofers and their braces. Increase the usable panel area or use smaller drivers.',
    ),
    geometry,
  };
}

function makeBaseLayout(
  mode: SupbLayoutMode,
  points: SupbSubPosition[],
  regionIndexes: number[],
  gussets: SupbGussetPosition[],
  geometry: SupbPortGeometry,
): SupbBaseLayout {
  return {
    safe: true,
    mode,
    points,
    center: averagePoint(points),
    gussets,
    regionIndexes,
    geometry,
  };
}

/** Search two rows in both panel orientations. All candidates keep the same
 * enclosure/port dimensions; only cutout and free-standing brace centers move.
 * The finite search is deterministic so saved designs and every export agree. */
function findMultiRowLayout(count: number, spacing: number, baseY: number,
  inputs: EnclosureInputs, geometry: SupbPortGeometry): SupbBaseLayout | null {
  const bounds = geometry.centerBounds;
  if (!bounds) return null;
  const candidates: Array<{ points: SupbSubPosition[]; mode: SupbLayoutMode; score: number }> = [];
  const spanX = bounds.xMax - bounds.xMin;
  const spanY = bounds.yMax - bounds.yMin;
  const samples = (min: number, max: number, steps: number) =>
    max < min - POSITION_EPSILON ? [] : Array.from({ length: max <= min ? 1 : steps + 1 },
      (_, i) => min + Math.max(0, max - min) * i / steps);
  for (const rotated of [false, true]) {
    const width = rotated ? spanY : spanX;
    const depth = rotated ? spanX : spanY;
    // Above one full diameter a grid is possible; otherwise stagger the rows
    // just enough to preserve the flange gap. Include exact grid spacing.
    const depths = new Set([...samples(0, Math.min(depth, spacing * 1.5), 24), Math.min(depth, spacing)]);
    for (const dy of depths) {
      if (!(dy > 0)) continue;
      const minShift = Math.sqrt(Math.max(0, spacing ** 2 - dy ** 2));
      const minPitch = Math.max(spacing, 2 * minShift);
      const maxPitch = count === 4 ? width - minShift : width;
      for (const pitch of samples(minPitch, maxPitch, 4)) {
        const shifts = count === 3 ? [pitch / 2]
          : samples(minShift, Math.min(pitch / 2, width - pitch), 3);
        for (const shift of shifts) for (const mirror of [false, true]) {
          const shape = count === 3
            ? [{ x: 0, y: 0 }, { x: pitch, y: 0 }, { x: shift, y: dy }]
            : [{ x: 0, y: 0 }, { x: pitch, y: 0 }, { x: shift, y: dy }, { x: shift + pitch, y: dy }];
          const pattern = shape.map(p => {
            const y = mirror ? dy - p.y : p.y;
            return rotated ? { x: y, y: p.x } : { x: p.x, y };
          });
          const w = Math.max(...pattern.map(p => p.x));
          const h = Math.max(...pattern.map(p => p.y));
          const preferredY = clampNumber(baseY - averagePoint(pattern).cy, bounds.yMin, bounds.yMax - h);
          for (const y of new Set([preferredY, ...samples(bounds.yMin, bounds.yMax - h, 8)])) {
            // Intersect the exact curved PP2 boundary for all drivers at once.
            const right = Math.min(...pattern.map(p => {
              const cornerDy = Math.max(0, geometry.pp2Front - (p.y + y));
              const radius = geometry.cornerRadius;
              const xMax = radius !== undefined && cornerDy < radius
                ? Math.min(bounds.xMax, geometry.pp2Left - Math.sqrt(radius ** 2 - cornerDy ** 2)) : bounds.xMax;
              return xMax - p.x;
            }));
            if (right < bounds.xMin - POSITION_EPSILON) continue;
            for (const x of new Set([(bounds.xMin + right) / 2, bounds.xMin, right])) {
              const points = pattern.map(p => ({ x: p.x + x, y: p.y + y }))
                .sort((a, b) => a.x - b.x || a.y - b.y);
              if (!points.every(p => pointClearsPort(p, geometry)) || !subFlangesClear(points, spacing)) continue;
              const mode = count === 4 && shift < POSITION_EPSILON ? 'grid' : 'staggered';
              // Prefer an uncomplicated grid if it fits, then the most compact
              // stagger near the panel center. Braces are verified before use.
              const center = averagePoint(points);
              const score = (mode === 'grid' ? 0 : 1e6) + w * h
                + Math.abs(center.cx - (bounds.xMin + bounds.xMax) / 2)
                + Math.abs(center.cy - (bounds.yMin + bounds.yMax) / 2);
              candidates.push({ points, mode, score });
            }
          }
        }
      }
    }
  }
  candidates.sort((a, b) => a.score - b.score);
  for (const { points, mode } of candidates) {
    const gussets = findMultiRowGussets(points, inputs, geometry);
    if (gussets) return makeBaseLayout(mode, points,
      assignRegions(points, geometry.regions) ?? points.map(() => -1), gussets, geometry);
  }
  return null;
}

/** Multi-row cutouts can occupy the old midpoint brace locations. Find the
 * same n-1 upright 5-inch braces in the remaining solid wood, with a quarter
 * inch of wood at cutouts/walls and between braces. They stay front-to-back
 * and share a Y center, preserving the existing ACC 08 drill convention. */
function findMultiRowGussets(points: SupbSubPosition[], inputs: EnclosureInputs,
  g: SupbPortGeometry): SupbGussetPosition[] | null {
  const targets = buildSupbGussets(points);
  const halfT = g.gussetThickness / 2;
  const halfD = GUSSET_DEPTH / 2;
  const border = SUB_SAFETY_BORDER;
  const radius = Math.max((inputs.subCutoutDiameter || inputs.outsideDiameter)/2, (inputs.outsideDiameter || inputs.subCutoutDiameter)/2+(inputs.recessedMounting ? .125 : 0)) + border;
  const centerY = averagePoint(points).cy;
  const yMin = g.chamberFront + halfD + border;
  const yMax = g.chamberBack - halfD - border;
  if (yMin > yMax) return null;
  const ys = new Set([clampNumber(centerY, yMin, yMax),
    ...Array.from({ length: 33 }, (_, i) => yMin + (yMax - yMin) * i / 32)]);
  let bestGussets: SupbGussetPosition[] | null = null;
  let bestOverallScore = Infinity;
  for (const y of ys) {
    const right = (y + halfD <= g.pp2Front - border ? g.pp1Left : g.pp2Left) - halfT - border;
    let intervals = [[g.chamberLeft + halfT + border, right]];
    for (const p of points) {
      const dy = Math.max(0, Math.abs(p.y - y) - halfD);
      if (dy >= radius) continue;
      const dx = halfT + Math.sqrt(radius ** 2 - dy ** 2);
      intervals = intervals.flatMap(([lo, hi]) => [
        [lo, Math.min(hi, p.x - dx)], [Math.max(lo, p.x + dx), hi],
      ].filter(([a, b]) => b >= a - POSITION_EPSILON));
    }
    // Spread the supports across the panel rather than bunching redundant
    // braces into one leftover sliver at an edge.
    const separation = Math.max(g.gussetThickness + border, GUSSET_DEPTH);
    const xs = [...new Set(intervals.flatMap(([lo, hi]) => [lo, hi, (lo + hi) / 2,
      ...targets.map(t => clampNumber(t.x, lo, hi)),
      ...Array.from({ length: points.length - 1 }, (_, i) => lo + separation * i).filter(x => x <= hi),
      ...Array.from({ length: points.length - 1 }, (_, i) => hi - separation * i).filter(x => x >= lo),
    ]))].sort((a, b) => a - b);
    let best: number[] | null = null;
    let bestScore = bestOverallScore - targets.length * (y - centerY) ** 2;
    const visit = (chosen: number[], start: number, score: number) => {
      if (score >= bestScore) return;
      if (chosen.length === targets.length) { best = [...chosen]; bestScore = score; return; }
      for (let i = start; i < xs.length; i++) {
        if (chosen.length && xs[i] - chosen[chosen.length - 1] < separation - POSITION_EPSILON) continue;
        visit([...chosen, xs[i]], i + 1, score + (xs[i] - targets[chosen.length].x) ** 2);
      }
    };
    visit([], 0, 0);
    if (!best) continue;
    const gussets = (best as number[]).map(x => ({ x, y,
      dowels: [{ x, y: y - GUSSET_DOWEL_HALF_SPACING }, { x, y: y + GUSSET_DOWEL_HALF_SPACING }] as SupbGussetPosition['dowels'] }));
    if (gussetsFit(points, gussets, inputs, g)) {
      bestGussets = gussets;
      bestOverallScore = bestScore + targets.length * (y - centerY) ** 2;
    }
  }
  return bestGussets;
}

function buildSupbPortGeometry(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  od: number,
  cutoutD: number,
): SupbPortGeometry {
  od += inputs.recessedMounting ? .25 : 0;
  const wallT = wallThicknessFromCutList(inputs, cutList);
  const tBaffle = baffleThickness(inputs, cutList);
  const tBack = backThicknessFromCutList(inputs, cutList);
  const baffleW = baffleWidthFromCutList(cutList);
  const topW = cutList.find(part => part.partName === 'Top')?.width || calc.boxWidth;
  const pp1 = portPiece1FromCutList(cutList);
  const pp2 = portPiece2FromCutList(cutList);
  const pp1Thick = pp1?.thickness || wallT;
  const gussetThickness = gussetThicknessFromCutList(inputs, cutList);
  const base: SupbPortGeometry = {
    regions: [],
    chamberLeft: wallT,
    chamberFront: tBaffle,
    pp1Left: baffleW - pp1Thick,
    pp2Left: baffleW - (pp2?.width ?? 0),
    pp2Front: tBaffle + (pp1?.width ?? 0),
    chamberBack: inputs.boxDepth - tBack,
    gussetThickness,
  };

  const invalid = (message: string): SupbPortGeometry => ({ ...base, diagnostic: message });
  if (!Number.isFinite(calc.portLength2) || calc.portLength2 <= 0) {
    return invalid('Port geometry is invalid: Port Length 2 must be greater than zero before subwoofer placement can be resolved.');
  }
  if (!pp1 || !Number.isFinite(pp1.width) || pp1.width <= 0) {
    return invalid('Port geometry is invalid: Port Piece 1 has no positive physical depth.');
  }
  if (calc.labyrinthPort.active) {
    const panelCount = calc.labyrinthPort.panels.length;
    if (panelCount < 2 || !Number.isFinite(calc.labyrinthPort.lanePitch)) {
      return invalid('Labyrinth port geometry is invalid: no return divider was resolved.');
    }
    const mazeLeft = baffleW
      - pp1Thick
      - (panelCount - 1) * calc.labyrinthPort.lanePitch;
    base.pp2Left = mazeLeft;
    // There is no free front strip inside the maze band. Braces must stay
    // on the same unobstructed side as the drivers.
    base.pp1Left = mazeLeft;
    base.pp2Front = base.chamberBack;
    if (!(baffleW > 0) || !(mazeLeft > base.chamberLeft)) {
      return invalid('Labyrinth port geometry is invalid: the divider maze consumes the full subwoofer chamber width.');
    }

    // The serpentine occupies the full-depth band at the right of the box.
    // Keep top-firing cutouts in the unobstructed rectangle to its left.
    const halfOD = od / 2;
    const halfCutout = cutoutD / 2;
    const region: SupbCenterRegion = {
      xMin: Math.max(
        halfOD + OUTER_EDGE_SAFETY_BORDER,
        base.chamberLeft + halfCutout + SUB_SAFETY_BORDER,
      ),
      xMax: Math.min(
        topW - halfOD - OUTER_EDGE_SAFETY_BORDER,
        mazeLeft - halfCutout - SUB_SAFETY_BORDER,
      ),
      yMin: Math.max(
        halfOD + OUTER_EDGE_SAFETY_BORDER,
        tBaffle + halfCutout + SUB_SAFETY_BORDER,
      ),
      yMax: Math.min(
        inputs.boxDepth - halfOD - OUTER_EDGE_SAFETY_BORDER,
        base.chamberBack - halfCutout - SUB_SAFETY_BORDER,
      ),
      label: 'Labyrinth-free chamber',
    };
    base.regions = region.xMax + POSITION_EPSILON >= region.xMin
      && region.yMax + POSITION_EPSILON >= region.yMin
      ? [region]
      : [];
    base.centerBounds = region;
    return base;
  }
  if (!pp2 || !Number.isFinite(pp2.width) || pp2.width <= 0) {
    return invalid('Port geometry is invalid: Port Piece 2 has no positive physical width. Adjust tuning, port width, or box depth.');
  }
  if (!(baffleW > 0) || !(base.pp1Left > base.chamberLeft) || !(base.pp2Left > base.chamberLeft)) {
    return invalid('Port geometry is invalid: PP1/PP2 extends through the usable subwoofer chamber.');
  }
  if (!(base.pp2Front > tBaffle) || !(base.pp2Front < base.chamberBack)) {
    return invalid('Port geometry is invalid: the PP1/PP2 corner lies outside the enclosure depth.');
  }

  const halfOD = od / 2;
  const halfCutout = cutoutD / 2;
  const xMin = Math.max(
    halfOD + OUTER_EDGE_SAFETY_BORDER,
    base.chamberLeft + halfCutout + SUB_SAFETY_BORDER,
  );
  const outerXMax = topW - halfOD - OUTER_EDGE_SAFETY_BORDER;
  const yMin = Math.max(
    halfOD + OUTER_EDGE_SAFETY_BORDER,
    tBaffle + halfCutout + SUB_SAFETY_BORDER,
  );
  const outerYMax = inputs.boxDepth - halfOD - OUTER_EDGE_SAFETY_BORDER;
  const chamberYMax = base.chamberBack - halfCutout - SUB_SAFETY_BORDER;
  base.centerBounds = {
    xMin, xMax: Math.min(outerXMax, base.pp1Left - halfCutout - SUB_SAFETY_BORDER),
    yMin, yMax: Math.min(outerYMax, chamberYMax), label: 'Top panel center limits',
  };
  base.cornerRadius = halfCutout + SUB_SAFETY_BORDER;

  // The cutout-center region is an L: a narrow left leg can use full depth,
  // while the wider right/front leg must stop before the PP2 return wall.
  const fullDepthLeft: SupbCenterRegion = {
    xMin,
    xMax: Math.min(outerXMax, base.pp2Left - halfCutout - SUB_SAFETY_BORDER),
    yMin,
    yMax: Math.min(outerYMax, chamberYMax),
    label: 'S2 left leg (full depth)',
  };
  const frontStrip: SupbCenterRegion = {
    xMin,
    xMax: Math.min(outerXMax, base.pp1Left - halfCutout - SUB_SAFETY_BORDER),
    yMin,
    yMax: Math.min(outerYMax, base.pp2Front - halfCutout - SUB_SAFETY_BORDER),
    label: 'S1 + S2 front leg (ahead of PP2)',
  };
  base.regions = [fullDepthLeft, frontStrip]
    .filter(region => region.xMax + POSITION_EPSILON >= region.xMin && region.yMax + POSITION_EPSILON >= region.yMin);
  return base;
}

function buildSupbGussets(points: SupbSubPosition[]): SupbGussetPosition[] {
  if (points.length <= 1) return [];
  const sorted = [...points].sort((a, b) => a.x - b.x);
  const gussets: SupbGussetPosition[] = [];
  for (let i = 0; i < sorted.length - 1; i++) {
    const x = (sorted[i].x + sorted[i + 1].x) / 2;
    const y = (sorted[i].y + sorted[i + 1].y) / 2;
    gussets.push({
      x,
      y,
      dowels: [
        { x, y: y - GUSSET_DOWEL_HALF_SPACING },
        { x, y: y + GUSSET_DOWEL_HALF_SPACING },
      ],
    });
  }
  return gussets;
}

function gussetsFit(
  points: SupbSubPosition[],
  gussets: SupbGussetPosition[],
  inputs: EnclosureInputs,
  geometry: SupbPortGeometry,
  clearance = SUB_SAFETY_BORDER,
): boolean {
  if (gussets.length === 0) return true;
  const cutoutR = Math.max((inputs.subCutoutDiameter || inputs.outsideDiameter || 0)/2, (inputs.outsideDiameter || inputs.subCutoutDiameter || 0)/2+(inputs.recessedMounting ? .125 : 0)) + Math.max(clearance,SUB_SAFETY_BORDER);
  const halfT = geometry.gussetThickness / 2;
  const halfD = GUSSET_DEPTH / 2;

  for (const gusset of gussets) {
    const xMin = gusset.x - halfT;
    const xMax = gusset.x + halfT;
    const yMin = gusset.y - halfD;
    const yMax = gusset.y + halfD;
    const insideFullDepthLeg = xMin + POSITION_EPSILON >= geometry.chamberLeft + clearance
      && xMax <= geometry.pp2Left - clearance + POSITION_EPSILON;
    const insideFrontLeg = xMin + POSITION_EPSILON >= geometry.chamberLeft + clearance
      && xMax <= geometry.pp1Left - clearance + POSITION_EPSILON && yMax <= geometry.pp2Front - clearance + POSITION_EPSILON;
    const front = clearance ? geometry.chamberFront + clearance : 0;
    if ((!insideFullDepthLeg && !insideFrontLeg) || yMin < front - POSITION_EPSILON
      || yMax > geometry.chamberBack - clearance + POSITION_EPSILON) return false;

    // Keep the entire brace clear of the outside frame and mounting screws.
    for (const point of points) {
      const nearestX = clampNumber(point.x, xMin, xMax);
      const nearestY = clampNumber(point.y, yMin, yMax);
      if (Math.hypot(point.x - nearestX, point.y - nearestY) + POSITION_EPSILON < cutoutR) {
        return false;
      }
    }
  }
  return true;
}

function subFlangesClear(points: SupbSubPosition[], od: number): boolean {
  for (let i = 0; i < points.length; i++) {
    for (let j = i + 1; j < points.length; j++) {
      if (Math.hypot(points[i].x - points[j].x, points[i].y - points[j].y) + POSITION_EPSILON < od) {
        return false;
      }
    }
  }
  return true;
}

function assignRegions(points: SupbSubPosition[], regions: SupbCenterRegion[]): number[] | null {
  const assignments: number[] = [];
  for (const point of points) {
    // Prefer the full-depth left leg when both rectangles contain a point;
    // that leaves the widest safe Y translation range for the operator.
    const index = regions.findIndex(region => pointInRegion(point, region));
    if (index < 0) return null;
    assignments.push(index);
  }
  return assignments;
}

function pointInRegion(point: SupbSubPosition, region: SupbCenterRegion): boolean {
  return point.x + POSITION_EPSILON >= region.xMin && point.x - POSITION_EPSILON <= region.xMax &&
    point.y + POSITION_EPSILON >= region.yMin && point.y - POSITION_EPSILON <= region.yMax;
}

function legacyXPositions(width: number, od: number, count: number): number[] {
  if (!(width > 0) || !(od > 0) || count <= 0) return [];
  const gap = (width - od * count) / (count + 1);
  return Array.from({ length: count }, (_, i) => gap * (i + 1) + od * i + od / 2);
}

function averagePoint(points: SupbSubPosition[]): { cx: number; cy: number } {
  if (points.length === 0) return { cx: 0, cy: 0 };
  return {
    cx: points.reduce((sum, point) => sum + point.x, 0) / points.length,
    cy: points.reduce((sum, point) => sum + point.y, 0) / points.length,
  };
}

function clampNumber(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

// ─── Safe-zone bounds ────────────────────────────────────────────────────────

export interface SafeZone {
  /** Inclusive panel-X range the cutout center must keep its OD inside (with safety border). */
  xMin: number; xMax: number;
  /** Inclusive panel-Y range the cutout center must keep its OD inside. */
  yMin: number; yMax: number;
  /** Human-readable description of the active zone (for tooltips / debug). */
  label: string;
}

/**
 * Compute the safe rectangle the entire pattern's bounding extent must fit
 * inside. We treat the pattern as a single "envelope" (multi-sub stretches
 * X-wise via gap spacing) so the validity check below subtracts the
 * pattern's half-width from xMin/xMax instead of restating it per-sub.
 *
 * SUPB single port:
 *  - S2-only: chamber is a clean rectangle, X = [t, t+s2], Y = [tBaffle, boxD-tBack].
 *  - Combined: simplified to the front part of the interior that's NOT
 *    inside the L-shape port leg. X = [t, boxW-t], Y = [tBaffle, tBaffle+s1RightDepth].
 *    This is conservative — the back-left corner (over S2 width) is
 *    actually deeper, but treating the safe zone as the front rectangle
 *    avoids the user putting a sub partly over port leg 1.
 *
 * SUPB dual port: the safe zone is whichever chamber is currently hosting
 *  the cutout (left or right). We default to the left chamber for offset
 *  purposes; the offset shifts both subs symmetrically. xMin/xMax for the
 *  left chamber: [t + portW + pp1Thick, t + portW + pp1Thick + s2].
 */
export function computeSafeZone(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SafeZone {
  const isDualPort = inputs.portQuantity === 'Dual';
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const subCount = subCountOf(inputs);
  const t = wallThickness(inputs);
  const tBaffle = baffleThickness(inputs, cutList);
  const tBack = wallThickness(inputs);
  const boxD = inputs.boxDepth;
  const boxW = calc.boxWidth;
  const s2 = calc.s2LeftWidth;
  const s1 = calc.s1RightWidth;
  const portW = inputs.portWidth || 0;

  if (isDualPort) {
    // Dual port: pick the left chamber's bounds. PP1 thickness from cut list
    // (or fall back to wall thickness).
    const pp1Thick = portPiece1ThicknessFromCutList(cutList) || t;
    const leftMin = t + portW + pp1Thick;
    const leftMax = leftMin + s2;
    return {
      xMin: leftMin, xMax: leftMax,
      yMin: tBaffle, yMax: boxD - tBack,
      label: 'Dual-port left chamber (S2 Left)',
    };
  }
  // Single port:
  // PP1 runs depth-wise on the right side of the chamber (its right face = baffleWidth).
  // Right of PP1 is the port channel — cutouts there would dump into the port,
  // so the safe X zone must cap at PP1's LEFT face for both S2-only and
  // combined-fallback paths.
  const baffleW_in = baffleWidthFromCutList(cutList);
  const pp1Thick_in = portPiece1ThicknessFromCutList(cutList) || t;
  const pp1LeftFace = baffleW_in > 0 ? baffleW_in - pp1Thick_in : (boxW - t);

  const useCombined = resolveCombinedChamber(s2, s1, od, subCount);
  if (!useCombined) {
    // S2-only: chamber spans Side Left interior to PP1 left face for the
    // full box depth. (s2LeftWidth from calc is volume-derived, not geometric;
    // use the actual geometric bound from PP1 instead.)
    return {
      xMin: t, xMax: pp1LeftFace,
      yMin: tBaffle, yMax: boxD - tBack,
      label: 'S2 Left chamber (sub fits)',
    };
  }
  // Combined fallback — front strip of the interior that doesn't include the
  // L-shape port leg's back-side intrusion. PP1 cuts through the front strip
  // at baffleW − tPP1, so cap xMax there to keep cutouts clear of the port
  // channel (which sits between PP1's right face and Side Right interior).
  const s1Depth = calc.s1RightDepth > 0 ? calc.s1RightDepth : (boxD - tBaffle - tBack - portW - t);
  return {
    xMin: t, xMax: pp1LeftFace,
    yMin: tBaffle, yMax: tBaffle + s1Depth,
    label: 'Combined S1+S2 chamber (front strip, left of PP1 / port channel)',
  };
}

// ─── Pattern bounding extent (multi-sub spread) ─────────────────────────────

/**
 * Compute the half-width of the cutout pattern's X extent (from cx to the
 * outer edge of the leftmost / rightmost sub). For a single sub this is
 * just od/2. For multi-sub, the leftmost sub's center is offset from the
 * pattern center by (chamber/2 - od/2 - safetyMargin) — but here we just
 * want the X extent of the pattern itself, so it's:
 *
 *   halfWidth = (subCount-1) * (od + gap)/2 + od/2
 *
 * where gap is computed by the existing getSubwooferXPositions formula.
 * For the half-EXTENT (= pattern half-width PLUS sub radius) we add od/2
 * on top.
 */
function patternHalfExtentX(subCount: number, od: number, chamberWidth: number): number {
  if (subCount <= 0 || od <= 0) return 0;
  if (subCount === 1) return od / 2;
  // gap = (chamberWidth - od*subCount) / (subCount+1). Pattern endpoints sit
  // halfway between the outer subs and the chamber edge, so the pattern's
  // half-width from the pattern center is (chamberWidth - 2*gap) / 2 - od/2.
  // For the extent (center → outer edge of outer sub), we add od/2 back:
  // halfExtent = (chamberWidth - 2*gap) / 2.
  const gap = (chamberWidth - od * subCount) / (subCount + 1);
  return (chamberWidth - 2 * gap) / 2;
}

// ─── Safe offset range (for slider min/max) ─────────────────────────────────

export interface SafeOffsetRange {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
}

/**
 * Convert the safe zone (absolute panel coords) into safe-offset-from-auto-center
 * bounds, after subtracting the pattern's half-extent and the safety borders.
 * Used by the Design tab UI to clamp slider min/max so the operator can't
 * drag the pattern into an unsafe region.
 *
 * Two independent constraints combined per axis:
 *  - Chamber walls: the through-hole CUTOUT must clear interior walls
 *    (Side Left, PP1, baffle, back, PP2 / L-port leg) by SUB_SAFETY_BORDER.
 *  - Box outer faces: the visible flange OD must not overhang the box's
 *    outer rectangle (front/back/sides), bounded by OUTER_EDGE_SAFETY_BORDER.
 *
 * The CUTOUT-based chamber check is what allows the user to push a sub
 * inward past the OD's footprint of the chamber wall — the flange harmlessly
 * laps over the wall's top edge while the through-hole stays inside.
 *
 * If the chamber is too small for the sub at any offset (rare but possible
 * when the math has produced a chamber narrower than `cutout + 2*SAFETY`),
 * the returned range collapses (xMax < xMin); the UI should treat that as
 * "no safe placement on this axis" and surface it as an error.
 */
export function getSafeOffsetRange(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SafeOffsetRange {
  if (
    inputs.enclosureConfiguration === 'Subs Up/Port Back' &&
    inputs.portQuantity !== 'Dual' &&
    subCountOf(inputs) > 1
  ) {
    const base = resolveSupbBaseLayout(inputs, calc, cutList);
    if (!base.safe || base.points.length === 0) {
      return { xMin: 1, xMax: -1, yMin: 1, yMax: -1 };
    }
    let xMin = -Infinity;
    let xMax = Infinity;
    let yMin = -Infinity;
    let yMax = Infinity;
    for (let i = 0; i < base.points.length; i++) {
      const point = base.points[i];
      const region = base.geometry.regions[base.regionIndexes[i]];
      if (!region) {
        // Circle-aware layouts can sit outside the old rectangular regions.
        // Keep shared-offset controls conservative; independent controls can
        // explore the full panel with the exact live fit check.
        return { xMin: 0, xMax: 0, yMin: 0, yMax: 0 };
      }
      xMin = Math.max(xMin, region.xMin - point.x);
      xMax = Math.min(xMax, region.xMax - point.x);
      yMin = Math.max(yMin, region.yMin - point.y);
      yMax = Math.min(yMax, region.yMax - point.y);
    }
    const halfT = base.geometry.gussetThickness / 2;
    const halfD = GUSSET_DEPTH / 2;
    for (const gusset of base.gussets) {
      const usesFullDepthLeg = gusset.x + halfT <= base.geometry.pp2Left + POSITION_EPSILON;
      xMin = Math.max(xMin, base.geometry.chamberLeft + halfT - gusset.x);
      xMax = Math.min(
        xMax,
        (usesFullDepthLeg ? base.geometry.pp2Left : base.geometry.pp1Left) - halfT - gusset.x,
      );
      yMin = Math.max(yMin, halfD - gusset.y);
      yMax = Math.min(
        yMax,
        (usesFullDepthLeg ? base.geometry.chamberBack : base.geometry.pp2Front) - halfD - gusset.y,
      );
    }
    return { xMin, xMax, yMin, yMax };
  }

  const auto = resolveAutoCenter(inputs, calc);
  const chamber = computeSafeZone(inputs, calc, cutList);
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  const chamberWidth = auto.chamberWidth || (chamber.xMax - chamber.xMin);

  // Pattern half-extents — same X spread (gap-spaced flanges) for both
  // checks; only the radius portion differs (cutout vs OD).
  const patternHalfX_OD = patternHalfExtentX(subCount, od, chamberWidth);
  const patternHalfX_cutout = patternHalfX_OD - od / 2 + cutoutD / 2;

  // Outer panel bounds = box outer rectangle for SUPB
  const boxW = calc.boxWidth;
  const boxD = inputs.boxDepth;

  // Required absolute-coord min/max from each constraint
  const xMinChamber = chamber.xMin + patternHalfX_cutout + SUB_SAFETY_BORDER;
  const xMaxChamber = chamber.xMax - patternHalfX_cutout - SUB_SAFETY_BORDER;
  const xMinOuter = 0 + patternHalfX_OD + OUTER_EDGE_SAFETY_BORDER;
  const xMaxOuter = boxW - patternHalfX_OD - OUTER_EDGE_SAFETY_BORDER;

  const yMinChamber = chamber.yMin + cutoutD / 2 + SUB_SAFETY_BORDER;
  const yMaxChamber = chamber.yMax - cutoutD / 2 - SUB_SAFETY_BORDER;
  const yMinOuter = 0 + od / 2 + OUTER_EDGE_SAFETY_BORDER;
  const yMaxOuter = boxD - od / 2 - OUTER_EDGE_SAFETY_BORDER;

  return {
    xMin: Math.max(xMinChamber, xMinOuter) - auto.cx,
    xMax: Math.min(xMaxChamber, xMaxOuter) - auto.cx,
    yMin: Math.max(yMinChamber, yMinOuter) - auto.cy,
    yMax: Math.min(yMaxChamber, yMaxOuter) - auto.cy,
  };
}

/**
 * Absolute safe-center rectangle for the sub cutout on the Top panel.
 * Same constraints as `getSafeOffsetRange`, but returned in panel-local
 * inches (X = box width axis, Y = box depth axis) instead of as relative
 * offsets from the auto-center. The 3D viewer's no-go overlay reads this
 * to render a translucent outline showing where the cutout center can
 * sit.
 */
export interface SubSafeCenterRect {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
  /** True if at least one axis collapsed (xMax < xMin || yMax < yMin) —
   *  i.e. the geometry has no valid placement. UI should surface this. */
  collapsed: boolean;
}

export function computeSubSafeCenterRect(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SubSafeCenterRect {
  const multiBase = inputs.enclosureConfiguration === 'Subs Up/Port Back' &&
    inputs.portQuantity !== 'Dual' && subCountOf(inputs) > 1
    ? resolveSupbBaseLayout(inputs, calc, cutList)
    : null;
  const auto = multiBase?.safe ? multiBase.center : resolveAutoCenter(inputs, calc);
  const range = getSafeOffsetRange(inputs, calc, cutList);
  const xMin = auto.cx + range.xMin;
  const xMax = auto.cx + range.xMax;
  const yMin = auto.cy + range.yMin;
  const yMax = auto.cy + range.yMax;
  return { xMin, xMax, yMin, yMax, collapsed: xMax < xMin || yMax < yMin };
}

// ─── Placement check ────────────────────────────────────────────────────────

export interface SubPlacementCheck {
  safe: boolean;
  conflict?: { axis: 'x' | 'y'; side: 'min' | 'max'; overrun: number; label: string };
  /** The pattern's resolved center after applying offsets. */
  center: { cx: number; cy: number };
  /** The safe zone the placement was validated against. */
  zone: SafeZone;
}

export function checkSubwooferPlacement(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  xOffsetOverride?: number,
  yOffsetOverride?: number,
): SubPlacementCheck {
  if (
    inputs.enclosureConfiguration === 'Subs Up/Port Back' &&
    (inputs.portQuantity !== 'Dual' || inputs.subwooferCutoutProfile || inputs.subwooferPositions !== undefined) &&
    (subCountOf(inputs) > 1 || inputs.subwooferCutoutProfile || inputs.subwooferPositions !== undefined)
  ) {
    const layout = resolveSupbSubLayout(inputs, calc, cutList, xOffsetOverride, yOffsetOverride);
    const computedZone = computeSafeZone(inputs, calc, cutList);
    const zone = {
      ...computedZone,
      label: layout.mode === 'manual' ? 'Top panel — independent subwoofer centers' : layout.mode === 'staggered'
        ? 'Top panel — automatic diagonal stagger'
        : 'Top panel — geometric straight row',
    };
    if (layout.safe) return { safe: true, center: layout.center, zone };
    return {
      safe: false,
      center: layout.center,
      zone,
      conflict: {
        axis: 'x',
        side: 'min',
        overrun: 0,
        label: layout.diagnostic || 'No safe straight or diagonally staggered subwoofer layout exists.',
      },
    };
  }

  const auto = resolveAutoCenter(inputs, calc);
  const xOff = xOffsetOverride ?? inputs.subwooferXOffset ?? 0;
  const yOff = yOffsetOverride ?? inputs.subwooferYOffset ?? 0;
  const center = { cx: auto.cx + xOff, cy: auto.cy + yOff };
  const zone = computeSafeZone(inputs, calc, cutList);

  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  const chamberWidth = auto.chamberWidth || (zone.xMax - zone.xMin);
  const patternHalfX_OD = patternHalfExtentX(subCount, od, chamberWidth);
  const patternHalfX_cutout = patternHalfX_OD - od / 2 + cutoutD / 2;
  const halfCutout = cutoutD / 2;
  const halfOD = od / 2;
  const boxW = calc.boxWidth;
  const boxD = inputs.boxDepth;

  // Chamber-wall constraints: cutout must clear interior structure
  const xMinChamber = zone.xMin + patternHalfX_cutout + SUB_SAFETY_BORDER;
  const xMaxChamber = zone.xMax - patternHalfX_cutout - SUB_SAFETY_BORDER;
  const yMinChamber = zone.yMin + halfCutout + SUB_SAFETY_BORDER;
  const yMaxChamber = zone.yMax - halfCutout - SUB_SAFETY_BORDER;
  // Outer-panel constraints: flange OD must not overhang the box's outer faces
  const xMinOuter = 0 + patternHalfX_OD + OUTER_EDGE_SAFETY_BORDER;
  const xMaxOuter = boxW - patternHalfX_OD - OUTER_EDGE_SAFETY_BORDER;
  const yMinOuter = 0 + halfOD + OUTER_EDGE_SAFETY_BORDER;
  const yMaxOuter = boxD - halfOD - OUTER_EDGE_SAFETY_BORDER;

  // Check chamber-wall constraints first (they're the more nuanced ones).
  if (center.cx < xMinChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'min', overrun: xMinChamber - center.cx,
        label: 'Sub cutout would overlap the Side Left wall (or the chamber edge)',
      },
    };
  }
  if (center.cx > xMaxChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'max', overrun: center.cx - xMaxChamber,
        label: 'Sub cutout would overlap PP1 / port channel / Side Right wall',
      },
    };
  }
  if (center.cy < yMinChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'min', overrun: yMinChamber - center.cy,
        label: 'Sub cutout would overlap the front baffle/PP1 boundary',
      },
    };
  }
  if (center.cy > yMaxChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'max', overrun: center.cy - yMaxChamber,
        label: 'Sub cutout would overlap PP2 / L-shape port leg at the back',
      },
    };
  }
  // Then outer-panel overhang checks.
  if (center.cx < xMinOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'min', overrun: xMinOuter - center.cx,
        label: 'Sub flange would overhang the box’s left face',
      },
    };
  }
  if (center.cx > xMaxOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'max', overrun: center.cx - xMaxOuter,
        label: 'Sub flange would overhang the box’s right face',
      },
    };
  }
  if (center.cy < yMinOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'min', overrun: yMinOuter - center.cy,
        label: 'Sub flange would overhang the box’s front face',
      },
    };
  }
  if (center.cy > yMaxOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'max', overrun: center.cy - yMaxOuter,
        label: 'Sub flange would overhang the box’s back face',
      },
    };
  }
  return { safe: true, center, zone };
}

/** Find the nearest (xOffset, yOffset) pair that places the sub safely. */
export function findNearestSafeOffsets(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  desired: { x: number; y: number } = {
    x: inputs.subwooferXOffset ?? 0,
    y: inputs.subwooferYOffset ?? 0,
  },
): { x: number; y: number } | null {
  const initial = checkSubwooferPlacement(inputs, calc, cutList, desired.x, desired.y);
  if (initial.safe) return desired;

  // Sweep outward in 1/8" rings around the desired offset.
  const step = 0.125;
  const maxR = 12; // generous range; sweeps well past any sane offset.
  for (let r = step; r <= maxR; r += step) {
    // Check 8 points around a ring at this radius, in cardinal + diagonal order.
    for (const [dx, dy] of [
      [-r, 0], [r, 0], [0, -r], [0, r],
      [-r, -r], [r, -r], [-r, r], [r, r],
    ]) {
      const cand = { x: desired.x + dx, y: desired.y + dy };
      if (checkSubwooferPlacement(inputs, calc, cutList, cand.x, cand.y).safe) {
        return cand;
      }
    }
  }
  return null;
}

// ─── Internal helpers ───────────────────────────────────────────────────────

function subCountOf(inputs: EnclosureInputs): number {
  switch (inputs.subwooferQuantity) {
    case 'Dual': return 2;
    case 'Triple': return 3;
    case 'Quad': return 4;
    default: return 1;
  }
}

function wallThickness(inputs: EnclosureInputs): number {
  // Wall thickness for SUPB-RD/SD = B1/D1 (thin); HD = B2/D2 (thick).
  const isMDF = inputs.enclosureType.includes('MDF');
  const isHeavy = inputs.enclosureType.includes('Heavy');
  const material = resolveManufacturingProfile(inputs).materials;
  if (isMDF) return isHeavy ? material.D2 : material.D1;
  return isHeavy ? material.B2 : material.B1;
}

function baffleThickness(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const baffle = cutList.find(p => p.partName === 'Baffle');
  if (baffle?.thickness && baffle.thickness > 0) return baffle.thickness;
  return wallThickness(inputs);
}

function portPiece1ThicknessFromCutList(cutList: CutListItem[]): number {
  const pp1 =
    cutList.find(p => p.partName === 'Port Piece 1') ??
    cutList.find(p => p.partName === 'Port Piece 1 Left');
  return pp1?.thickness ?? 0;
}

function baffleWidthFromCutList(cutList: CutListItem[]): number {
  const baffle = cutList.find(p => p.partName === 'Baffle');
  return baffle?.width ?? 0;
}

function portPiece1FromCutList(cutList: CutListItem[]): CutListItem | undefined {
  return cutList.find(p => p.partName === 'Port Piece 1') ??
    cutList.find(p => p.partName === 'Port Piece 1 Left');
}

function portPiece2FromCutList(cutList: CutListItem[]): CutListItem | undefined {
  return cutList.find(p => p.partName === 'Port Piece 2') ??
    cutList.find(p => p.partName === 'Port Piece 2 Left');
}

function wallThicknessFromCutList(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const side = cutList.find(p => p.partName === 'Side Left');
  return side?.thickness && side.thickness > 0 ? side.thickness : wallThickness(inputs);
}

function backThicknessFromCutList(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const back = cutList.find(p => p.partName === 'Back');
  return back?.thickness && back.thickness > 0 ? back.thickness : wallThickness(inputs);
}

function gussetThicknessFromCutList(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const gusset = cutList.find(p => p.partName.startsWith('Gusset'));
  return gusset?.thickness && gusset.thickness > 0 ? gusset.thickness : wallThickness(inputs);
}
