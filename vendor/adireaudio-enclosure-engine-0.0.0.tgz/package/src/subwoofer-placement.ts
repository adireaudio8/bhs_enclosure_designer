/**
 * Subwoofer cutout placement helpers — SUPB only.
 *
 * For Subs Up / Port Back configurations, the sub cutout sits on the Top
 * panel. By default the auto-positioner picks an X (along box width) and
 * Y (along box depth) based on the L-shape chamber geometry: chamber center
 * for the X axis (S2 alone if it fits, combined S1+S2 if S2 is too narrow),
 * and box depth center / forward-shifted for the Y axis (forward shift in
 * the combined fallback so the sub clears the L-shape port leg at the back).
 *
 * V1 lets the user override that auto position by typing X/Y offsets in the
 * Design tab. The offsets shift the entire multi-sub pattern by the same
 * amount so subs stay evenly spaced. Validation uses the subwoofer's
 * outside diameter (OD) — not the through-hole cutout — so the visible
 * flange must clear the safe zone with `SUB_SAFETY_BORDER` to spare.
 *
 * Panel coords: X = box width axis (X=0 at Side Left outer face, X=boxW at
 * Side Right outer face); Y = box depth axis (Y=0 at front face, Y=boxD at
 * back face).
 */

import type {
  CutListItem,
  EnclosureCalculations,
  EnclosureInputs,
} from './types/enclosure';

/**
 * Required clearance between the sub CUTOUT (through-hole) and any chamber
 * wall (Side Left, PP1/PP2, baffle, back). The cutout is what physically
 * collides with internal structure — the flange sits on the OUTSIDE of the
 * top panel and just laps over the chamber wall's top edge harmlessly.
 */
export const SUB_SAFETY_BORDER = 0.25;

/**
 * Required clearance between the sub flange OD and the box's outer panel
 * edges (front/back/left/right faces). Acts as a hard limit on the slider:
 * the flange must keep this much clear of the box's outer rectangle even
 * when the operator drags the pattern toward an outer face.
 *
 * Set to 0.5" so the cutout always has at least a half-inch of wood
 * surrounding it on the outer side. (The chamber-wall safety border
 * `SUB_SAFETY_BORDER` handles the interior side via the cutout, allowing
 * the flange to harmlessly lap over an interior wall's top edge.)
 */
export const OUTER_EDGE_SAFETY_BORDER = 0.5;

// ─── Auto-center Y resolution with outer-edge bias ──────────────────────────

/**
 * Resolve the SUPB sub Y center on the top panel, with a default bias toward
 * keeping the flange OD at least OUTER_EDGE_SAFETY_BORDER inches from
 * the box's outer front/back faces — when geometry permits. Falls back to
 * the legacy formula (boxDepth/2 for S2-only, (boxDepth − portW − wallT)/2
 * for combined fallback) when the constraints can't all be satisfied.
 *
 * Used by the slider's auto-center, the DXF generator's SUPB top cutout
 * pattern, and the 3D viewer's SUPB driver position so all three render
 * the same default location and the user's "+0 offset" lands consistently.
 */
export function resolveSupbAutoCenterY(args: {
  boxDepth: number;
  portWidth: number;
  wallT: number;
  tBaffle: number;
  tBack: number;
  s1Depth: number; // 0 if S2-only (not in combined fallback)
  useCombined: boolean;
  halfOD: number;
  halfCutout: number;
}): number {
  const {
    boxDepth, portWidth, wallT, tBaffle, tBack, s1Depth,
    useCombined, halfOD, halfCutout,
  } = args;

  // Legacy default — preserved when bias can't be satisfied.
  const legacyCy = useCombined
    ? (boxDepth - portWidth - wallT) / 2
    : boxDepth / 2;

  // Outer-edge constraint: flange ≥ default clearance from box outer faces.
  const outerMin = halfOD + OUTER_EDGE_SAFETY_BORDER;
  const outerMax = boxDepth - halfOD - OUTER_EDGE_SAFETY_BORDER;

  // Chamber-wall constraint: cutout doesn't punch baffle / PP2 / back wall.
  const chamberYBack = useCombined ? tBaffle + s1Depth : boxDepth - tBack;
  const chamberMin = tBaffle + halfCutout + SUB_SAFETY_BORDER;
  const chamberMax = chamberYBack - halfCutout - SUB_SAFETY_BORDER;

  const validMin = Math.max(outerMin, chamberMin);
  const validMax = Math.min(outerMax, chamberMax);

  if (validMax >= validMin) {
    // Range is non-empty — clamp legacy cy into it so the auto position
    // sits ≥ OUTER_EDGE_SAFETY_BORDER from the nearest outer face.
    if (legacyCy < validMin) return validMin;
    if (legacyCy > validMax) return validMax;
    return legacyCy;
  }
  // Bias range is empty — geometry is too tight for both constraints; fall
  // back to legacy. Slider can still reach a valid placement using the
  // smaller (cutout/0.25") chamber border + 0" outer overhang allowance.
  return legacyCy;
}

// ─── Default-position resolution (mirrors dxf-generator.ts SUPB cutout logic) ─

/**
 * For SUPB single port, decide whether the sub fits in S2 alone or needs
 * the combined (S2 + S1) chamber as fallback. Mirrors the same decision
 * the DXF generator and 3D viewer make so the override math stays
 * consistent.
 */
function useCombinedChamber(
  s2LeftWidth: number, s1RightWidth: number, outsideDiameter: number, subCount: number,
): boolean {
  void s1RightWidth; // only used by callers that read combined width
  if (subCount <= 0 || outsideDiameter <= 0) return false;
  const s2EdgeClearance = (s2LeftWidth - outsideDiameter * subCount) / (subCount + 1);
  return s2EdgeClearance <= 0;
}

/**
 * Resolve the auto-computed cutout pattern center on the Top panel for
 * SUPB. Returns coordinates in box-axis inches (X: 0..boxW, Y: 0..boxD).
 *
 * Single port single sub: cx = chamber X center, cy = chamber Y center.
 * Single port multi sub: cx = chamber X center (subs spread by gap rule);
 *   cy = chamber Y center (all subs share the same Y).
 * Dual port: see comments on resolveAutoCenters for per-chamber handling.
 */
export function resolveAutoCenter(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
): { cx: number; cy: number; chamberWidth: number; useCombined: boolean } {
  const isDualPort = inputs.portQuantity === 'Dual';
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const subCount = subCountOf(inputs);
  const t = wallThickness(inputs);
  const s2 = calc.s2LeftWidth;
  const s1 = calc.s1RightWidth;
  const portW = inputs.portWidth || 0;
  const boxD = inputs.boxDepth;

  if (isDualPort) {
    // Dual port: chambers are separate; XOverride here only applies meaningfully
    // when subCount === 1 (sub centered on box). For 2 subs, the legacy logic
    // places one in each chamber and the override shifts both by the same
    // amount. We still expose a single (cx, cy) — for 2 subs it's the
    // midpoint of both chambers (= boxW/2). cy is always boxD/2.
    return { cx: calc.boxWidth / 2, cy: boxD / 2, chamberWidth: 0, useCombined: false };
  }
  // Single port: the chamber spans width-wise from Side Left to PP1 (S2),
  // and the L-shape connects S2 with S1 acoustically. If sub fits in S2,
  // use S2 alone; else fall back to combined chamber and shift cy forward
  // by (portW + wallThickness)/2 so the sub clears port leg 1 at the back.
  // Y center is biased to keep the flange ≥ OUTER_EDGE_SAFETY_BORDER
  // from the box's outer front/back faces when geometry allows.
  const useCombined = useCombinedChamber(s2, s1, od, subCount);
  const chamberWidth = useCombined ? (s2 + s1) : s2;
  const cx = t + chamberWidth / 2;
  const cutoutD = inputs.subCutoutDiameter || od;
  const s1Depth = useCombined
    ? (calc.s1RightDepth > 0 ? calc.s1RightDepth : (boxD - 2 * t - portW - t))
    : 0;
  const cy = resolveSupbAutoCenterY({
    boxDepth: boxD,
    portWidth: portW,
    wallT: t,
    tBaffle: t,
    tBack: t,
    s1Depth,
    useCombined,
    halfOD: od / 2,
    halfCutout: cutoutD / 2,
  });
  return { cx, cy, chamberWidth, useCombined };
}

/** Apply user-supplied offsets to the auto-computed center. */
export function applyOffsets(
  center: { cx: number; cy: number },
  inputs: EnclosureInputs,
): { cx: number; cy: number } {
  return {
    cx: center.cx + (inputs.subwooferXOffset ?? 0),
    cy: center.cy + (inputs.subwooferYOffset ?? 0),
  };
}

// ─── Safe-zone bounds ────────────────────────────────────────────────────────

export interface SafeZone {
  /** Inclusive panel-X range the cutout center must keep its OD inside (with safety border). */
  xMin: number; xMax: number;
  /** Inclusive panel-Y range the cutout center must keep its OD inside. */
  yMin: number; yMax: number;
  /** Human-readable description of the active zone (for tooltips / debug). */
  label: string;
}

/**
 * Compute the safe rectangle the entire pattern's bounding extent must fit
 * inside. We treat the pattern as a single "envelope" (multi-sub stretches
 * X-wise via gap spacing) so the validity check below subtracts the
 * pattern's half-width from xMin/xMax instead of restating it per-sub.
 *
 * SUPB single port:
 *  - S2-only: chamber is a clean rectangle, X = [t, t+s2], Y = [tBaffle, boxD-tBack].
 *  - Combined: simplified to the front part of the interior that's NOT
 *    inside the L-shape port leg. X = [t, boxW-t], Y = [tBaffle, tBaffle+s1RightDepth].
 *    This is conservative — the back-left corner (over S2 width) is
 *    actually deeper, but treating the safe zone as the front rectangle
 *    avoids the user putting a sub partly over port leg 1.
 *
 * SUPB dual port: the safe zone is whichever chamber is currently hosting
 *  the cutout (left or right). We default to the left chamber for offset
 *  purposes; the offset shifts both subs symmetrically. xMin/xMax for the
 *  left chamber: [t + portW + pp1Thick, t + portW + pp1Thick + s2].
 */
export function computeSafeZone(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SafeZone {
  const isDualPort = inputs.portQuantity === 'Dual';
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const subCount = subCountOf(inputs);
  const t = wallThickness(inputs);
  const tBaffle = baffleThickness(inputs, cutList);
  const tBack = wallThickness(inputs);
  const boxD = inputs.boxDepth;
  const boxW = calc.boxWidth;
  const s2 = calc.s2LeftWidth;
  const s1 = calc.s1RightWidth;
  const portW = inputs.portWidth || 0;

  if (isDualPort) {
    // Dual port: pick the left chamber's bounds. PP1 thickness from cut list
    // (or fall back to wall thickness).
    const pp1Thick = portPiece1ThicknessFromCutList(cutList) || t;
    const leftMin = t + portW + pp1Thick;
    const leftMax = leftMin + s2;
    return {
      xMin: leftMin, xMax: leftMax,
      yMin: tBaffle, yMax: boxD - tBack,
      label: 'Dual-port left chamber (S2 Left)',
    };
  }
  // Single port:
  // PP1 runs depth-wise on the right side of the chamber (its right face = baffleWidth).
  // Right of PP1 is the port channel — cutouts there would dump into the port,
  // so the safe X zone must cap at PP1's LEFT face for both S2-only and
  // combined-fallback paths.
  const baffleW_in = baffleWidthFromCutList(cutList);
  const pp1Thick_in = portPiece1ThicknessFromCutList(cutList) || t;
  const pp1LeftFace = baffleW_in > 0 ? baffleW_in - pp1Thick_in : (boxW - t);

  const useCombined = useCombinedChamber(s2, s1, od, subCount);
  if (!useCombined) {
    // S2-only: chamber spans Side Left interior to PP1 left face for the
    // full box depth. (s2LeftWidth from calc is volume-derived, not geometric;
    // use the actual geometric bound from PP1 instead.)
    return {
      xMin: t, xMax: pp1LeftFace,
      yMin: tBaffle, yMax: boxD - tBack,
      label: 'S2 Left chamber (sub fits)',
    };
  }
  // Combined fallback — front strip of the interior that doesn't include the
  // L-shape port leg's back-side intrusion. PP1 cuts through the front strip
  // at baffleW − tPP1, so cap xMax there to keep cutouts clear of the port
  // channel (which sits between PP1's right face and Side Right interior).
  const s1Depth = calc.s1RightDepth > 0 ? calc.s1RightDepth : (boxD - tBaffle - tBack - portW - t);
  return {
    xMin: t, xMax: pp1LeftFace,
    yMin: tBaffle, yMax: tBaffle + s1Depth,
    label: 'Combined S1+S2 chamber (front strip, left of PP1 / port channel)',
  };
}

// ─── Pattern bounding extent (multi-sub spread) ─────────────────────────────

/**
 * Compute the half-width of the cutout pattern's X extent (from cx to the
 * outer edge of the leftmost / rightmost sub). For a single sub this is
 * just od/2. For multi-sub, the leftmost sub's center is offset from the
 * pattern center by (chamber/2 - od/2 - safetyMargin) — but here we just
 * want the X extent of the pattern itself, so it's:
 *
 *   halfWidth = (subCount-1) * (od + gap)/2 + od/2
 *
 * where gap is computed by the existing getSubwooferXPositions formula.
 * For the half-EXTENT (= pattern half-width PLUS sub radius) we add od/2
 * on top.
 */
function patternHalfExtentX(subCount: number, od: number, chamberWidth: number): number {
  if (subCount <= 0 || od <= 0) return 0;
  if (subCount === 1) return od / 2;
  // gap = (chamberWidth - od*subCount) / (subCount+1). Pattern endpoints sit
  // halfway between the outer subs and the chamber edge, so the pattern's
  // half-width from the pattern center is (chamberWidth - 2*gap) / 2 - od/2.
  // For the extent (center → outer edge of outer sub), we add od/2 back:
  // halfExtent = (chamberWidth - 2*gap) / 2.
  const gap = (chamberWidth - od * subCount) / (subCount + 1);
  return (chamberWidth - 2 * gap) / 2;
}

// ─── Safe offset range (for slider min/max) ─────────────────────────────────

export interface SafeOffsetRange {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
}

/**
 * Convert the safe zone (absolute panel coords) into safe-offset-from-auto-center
 * bounds, after subtracting the pattern's half-extent and the safety borders.
 * Used by the Design tab UI to clamp slider min/max so the operator can't
 * drag the pattern into an unsafe region.
 *
 * Two independent constraints combined per axis:
 *  - Chamber walls: the through-hole CUTOUT must clear interior walls
 *    (Side Left, PP1, baffle, back, PP2 / L-port leg) by SUB_SAFETY_BORDER.
 *  - Box outer faces: the visible flange OD must not overhang the box's
 *    outer rectangle (front/back/sides), bounded by OUTER_EDGE_SAFETY_BORDER.
 *
 * The CUTOUT-based chamber check is what allows the user to push a sub
 * inward past the OD's footprint of the chamber wall — the flange harmlessly
 * laps over the wall's top edge while the through-hole stays inside.
 *
 * If the chamber is too small for the sub at any offset (rare but possible
 * when the math has produced a chamber narrower than `cutout + 2*SAFETY`),
 * the returned range collapses (xMax < xMin); the UI should treat that as
 * "no safe placement on this axis" and surface it as an error.
 */
export function getSafeOffsetRange(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SafeOffsetRange {
  const auto = resolveAutoCenter(inputs, calc);
  const chamber = computeSafeZone(inputs, calc, cutList);
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  const chamberWidth = auto.chamberWidth || (chamber.xMax - chamber.xMin);

  // Pattern half-extents — same X spread (gap-spaced flanges) for both
  // checks; only the radius portion differs (cutout vs OD).
  const patternHalfX_OD = patternHalfExtentX(subCount, od, chamberWidth);
  const patternHalfX_cutout = patternHalfX_OD - od / 2 + cutoutD / 2;

  // Outer panel bounds = box outer rectangle for SUPB
  const boxW = calc.boxWidth;
  const boxD = inputs.boxDepth;

  // Required absolute-coord min/max from each constraint
  const xMinChamber = chamber.xMin + patternHalfX_cutout + SUB_SAFETY_BORDER;
  const xMaxChamber = chamber.xMax - patternHalfX_cutout - SUB_SAFETY_BORDER;
  const xMinOuter = 0 + patternHalfX_OD + OUTER_EDGE_SAFETY_BORDER;
  const xMaxOuter = boxW - patternHalfX_OD - OUTER_EDGE_SAFETY_BORDER;

  const yMinChamber = chamber.yMin + cutoutD / 2 + SUB_SAFETY_BORDER;
  const yMaxChamber = chamber.yMax - cutoutD / 2 - SUB_SAFETY_BORDER;
  const yMinOuter = 0 + od / 2 + OUTER_EDGE_SAFETY_BORDER;
  const yMaxOuter = boxD - od / 2 - OUTER_EDGE_SAFETY_BORDER;

  return {
    xMin: Math.max(xMinChamber, xMinOuter) - auto.cx,
    xMax: Math.min(xMaxChamber, xMaxOuter) - auto.cx,
    yMin: Math.max(yMinChamber, yMinOuter) - auto.cy,
    yMax: Math.min(yMaxChamber, yMaxOuter) - auto.cy,
  };
}

/**
 * Absolute safe-center rectangle for the sub cutout on the Top panel.
 * Same constraints as `getSafeOffsetRange`, but returned in panel-local
 * inches (X = box width axis, Y = box depth axis) instead of as relative
 * offsets from the auto-center. The 3D viewer's no-go overlay reads this
 * to render a translucent outline showing where the cutout center can
 * sit.
 */
export interface SubSafeCenterRect {
  xMin: number; xMax: number;
  yMin: number; yMax: number;
  /** True if at least one axis collapsed (xMax < xMin || yMax < yMin) —
   *  i.e. the geometry has no valid placement. UI should surface this. */
  collapsed: boolean;
}

export function computeSubSafeCenterRect(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
): SubSafeCenterRect {
  const auto = resolveAutoCenter(inputs, calc);
  const range = getSafeOffsetRange(inputs, calc, cutList);
  const xMin = auto.cx + range.xMin;
  const xMax = auto.cx + range.xMax;
  const yMin = auto.cy + range.yMin;
  const yMax = auto.cy + range.yMax;
  return { xMin, xMax, yMin, yMax, collapsed: xMax < xMin || yMax < yMin };
}

// ─── Placement check ────────────────────────────────────────────────────────

export interface SubPlacementCheck {
  safe: boolean;
  conflict?: { axis: 'x' | 'y'; side: 'min' | 'max'; overrun: number; label: string };
  /** The pattern's resolved center after applying offsets. */
  center: { cx: number; cy: number };
  /** The safe zone the placement was validated against. */
  zone: SafeZone;
}

export function checkSubwooferPlacement(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  xOffsetOverride?: number,
  yOffsetOverride?: number,
): SubPlacementCheck {
  const auto = resolveAutoCenter(inputs, calc);
  const xOff = xOffsetOverride ?? inputs.subwooferXOffset ?? 0;
  const yOff = yOffsetOverride ?? inputs.subwooferYOffset ?? 0;
  const center = { cx: auto.cx + xOff, cy: auto.cy + yOff };
  const zone = computeSafeZone(inputs, calc, cutList);

  const od = inputs.outsideDiameter || inputs.subCutoutDiameter || 0;
  const cutoutD = inputs.subCutoutDiameter || od;
  const subCount = subCountOf(inputs);
  const chamberWidth = auto.chamberWidth || (zone.xMax - zone.xMin);
  const patternHalfX_OD = patternHalfExtentX(subCount, od, chamberWidth);
  const patternHalfX_cutout = patternHalfX_OD - od / 2 + cutoutD / 2;
  const halfCutout = cutoutD / 2;
  const halfOD = od / 2;
  const boxW = calc.boxWidth;
  const boxD = inputs.boxDepth;

  // Chamber-wall constraints: cutout must clear interior structure
  const xMinChamber = zone.xMin + patternHalfX_cutout + SUB_SAFETY_BORDER;
  const xMaxChamber = zone.xMax - patternHalfX_cutout - SUB_SAFETY_BORDER;
  const yMinChamber = zone.yMin + halfCutout + SUB_SAFETY_BORDER;
  const yMaxChamber = zone.yMax - halfCutout - SUB_SAFETY_BORDER;
  // Outer-panel constraints: flange OD must not overhang the box's outer faces
  const xMinOuter = 0 + patternHalfX_OD + OUTER_EDGE_SAFETY_BORDER;
  const xMaxOuter = boxW - patternHalfX_OD - OUTER_EDGE_SAFETY_BORDER;
  const yMinOuter = 0 + halfOD + OUTER_EDGE_SAFETY_BORDER;
  const yMaxOuter = boxD - halfOD - OUTER_EDGE_SAFETY_BORDER;

  // Check chamber-wall constraints first (they're the more nuanced ones).
  if (center.cx < xMinChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'min', overrun: xMinChamber - center.cx,
        label: 'Sub cutout would overlap the Side Left wall (or the chamber edge)',
      },
    };
  }
  if (center.cx > xMaxChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'max', overrun: center.cx - xMaxChamber,
        label: 'Sub cutout would overlap PP1 / port channel / Side Right wall',
      },
    };
  }
  if (center.cy < yMinChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'min', overrun: yMinChamber - center.cy,
        label: 'Sub cutout would overlap the front baffle/PP1 boundary',
      },
    };
  }
  if (center.cy > yMaxChamber) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'max', overrun: center.cy - yMaxChamber,
        label: 'Sub cutout would overlap PP2 / L-shape port leg at the back',
      },
    };
  }
  // Then outer-panel overhang checks.
  if (center.cx < xMinOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'min', overrun: xMinOuter - center.cx,
        label: 'Sub flange would overhang the box’s left face',
      },
    };
  }
  if (center.cx > xMaxOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'x', side: 'max', overrun: center.cx - xMaxOuter,
        label: 'Sub flange would overhang the box’s right face',
      },
    };
  }
  if (center.cy < yMinOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'min', overrun: yMinOuter - center.cy,
        label: 'Sub flange would overhang the box’s front face',
      },
    };
  }
  if (center.cy > yMaxOuter) {
    return {
      safe: false, center, zone,
      conflict: {
        axis: 'y', side: 'max', overrun: center.cy - yMaxOuter,
        label: 'Sub flange would overhang the box’s back face',
      },
    };
  }
  return { safe: true, center, zone };
}

/** Find the nearest (xOffset, yOffset) pair that places the sub safely. */
export function findNearestSafeOffsets(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  desired: { x: number; y: number } = {
    x: inputs.subwooferXOffset ?? 0,
    y: inputs.subwooferYOffset ?? 0,
  },
): { x: number; y: number } | null {
  const initial = checkSubwooferPlacement(inputs, calc, cutList, desired.x, desired.y);
  if (initial.safe) return desired;

  // Sweep outward in 1/8" rings around the desired offset.
  const step = 0.125;
  const maxR = 12; // generous range; sweeps well past any sane offset.
  for (let r = step; r <= maxR; r += step) {
    // Check 8 points around a ring at this radius, in cardinal + diagonal order.
    for (const [dx, dy] of [
      [-r, 0], [r, 0], [0, -r], [0, r],
      [-r, -r], [r, -r], [-r, r], [r, r],
    ]) {
      const cand = { x: desired.x + dx, y: desired.y + dy };
      if (checkSubwooferPlacement(inputs, calc, cutList, cand.x, cand.y).safe) {
        return cand;
      }
    }
  }
  return null;
}

// ─── Internal helpers ───────────────────────────────────────────────────────

function subCountOf(inputs: EnclosureInputs): number {
  switch (inputs.subwooferQuantity) {
    case 'Dual': return 2;
    case 'Triple': return 3;
    case 'Quad': return 4;
    default: return 1;
  }
}

function wallThickness(inputs: EnclosureInputs): number {
  // Wall thickness for SUPB-RD/SD = B1/D1 (thin); HD = B2/D2 (thick).
  const isMDF = inputs.enclosureType.includes('MDF');
  const isHeavy = inputs.enclosureType.includes('Heavy');
  if (isMDF) return isHeavy ? 1.0 : 0.75;
  return isHeavy ? 0.945 : 0.709;
}

function baffleThickness(inputs: EnclosureInputs, cutList: CutListItem[]): number {
  const baffle = cutList.find(p => p.partName === 'Baffle');
  if (baffle?.thickness && baffle.thickness > 0) return baffle.thickness;
  return wallThickness(inputs);
}

function portPiece1ThicknessFromCutList(cutList: CutListItem[]): number {
  const pp1 =
    cutList.find(p => p.partName === 'Port Piece 1') ??
    cutList.find(p => p.partName === 'Port Piece 1 Left');
  return pp1?.thickness ?? 0;
}

function baffleWidthFromCutList(cutList: CutListItem[]): number {
  const baffle = cutList.find(p => p.partName === 'Baffle');
  return baffle?.width ?? 0;
}
