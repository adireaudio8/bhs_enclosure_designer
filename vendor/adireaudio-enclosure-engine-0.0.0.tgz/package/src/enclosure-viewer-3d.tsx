'use client';

import { resolveJoinery } from './manufacturing-profile';
import { SideLeftTerminalPreview } from './side-left-terminal-preview';
import { TerminalPanelPreview } from './terminal-panel-preview';

import React, { createContext, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState, Suspense } from 'react';
import { Canvas, useFrame, useThree, useLoader } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Grid, GizmoHelper, GizmoViewcube, Environment } from '@react-three/drei';
import { EffectComposer, Bloom, SSAO } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import { createRoot } from 'react-dom/client';
import * as THREE from 'three';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js';
import { useEnclosureStore } from './enclosure-store';
import {
  roundUpToEighth,
  getMaterialThickness,
  getPartMaterial,
  isMDF,
  isHeavyDuty,
  getSubwooferCount,
  getGussetCount,
} from './calculations';
import { parseEpsPaths, calculatePathsBounds, filterBoundingBoxPaths } from './eps-parser';
import type { EpsPath } from './eps-parser';
import { frameProfile, profileBounds, profileBaffleCenters, baffleBraceCenters, type ProfilePoint, type SubwooferCutoutProfile } from './subwoofer-profile';
import { roundPortRadiusAt, ROUND_PORT_FLANGE_THICKNESS_IN, type RoundPortLayout } from './round-port';

function holeOutline(h:{r:number;outline?:ProfilePoint[]}):ProfilePoint[] {
  return h.outline??Array.from({length:64},(_,i)=>({x:h.r*Math.cos(i*Math.PI/32),y:h.r*Math.sin(i*Math.PI/32)}));
}
function CutoutContourLine({points,position,rotation=[0,0,0],frameAnnotation=false}:{points:ProfilePoint[];position:[number,number,number];rotation?:[number,number,number];frameAnnotation?:boolean}) {
  const geo=useMemo(()=>new THREE.BufferGeometry().setFromPoints([...points,points[0]].map(p=>new THREE.Vector3(p.x,p.y,0))),[points]);
  useEffect(()=>()=>geo.dispose(),[geo]);
  return <lineLoop position={position} rotation={rotation} geometry={geo} renderOrder={frameAnnotation ? 100 : 0}><lineBasicMaterial color={frameAnnotation ? '#0076d6' : '#000'} depthTest={!frameAnnotation} depthWrite={!frameAnnotation}/></lineLoop>;
}
/** Generic custom driver silhouette; its footprint follows the saved frame. With the subwoofer's
 *  mounting depth (inches) a plain motor reaches that far behind the mounting face, red when the
 *  fit check finds it too deep for the box. */
function ProfileDriver({profile,position,isVertical,warning=false,mountingDepth,tooDeep=false}:{profile:SubwooferCutoutProfile;position:[number,number,number];isVertical:boolean;warning?:boolean;mountingDepth?:number;tooDeep?:boolean}) {
  const geometries=useMemo(()=>{
    const make=(points:ProfilePoint[])=>new THREE.Shape(points.map(p=>new THREE.Vector2(p.x*S,p.y*S)));
    const frame=make(frameProfile(profile));frame.holes.push(new THREE.Path(profile.opening.map(p=>new THREE.Vector2(p.x*S,p.y*S))));
    const flange=new THREE.ExtrudeGeometry(frame,{depth:.025,bevelEnabled:false});flange.translate(0,0,-.025);
    const cone=new THREE.ShapeGeometry(make(profile.opening));
    let motor:THREE.CylinderGeometry|null=null;
    if(mountingDepth&&mountingDepth>0){
      const xs=profile.opening.map(p=>p.x),ys=profile.opening.map(p=>p.y);
      const radius=.3*Math.min(Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys))*S;
      // the cylinder's axis is y: turn it onto the driver's axis (+z, into the box)
      motor=new THREE.CylinderGeometry(radius,radius,mountingDepth*S,32);motor.rotateX(Math.PI/2);motor.translate(0,0,mountingDepth*S/2);
    }
    return {flange,cone,motor};
  },[profile,mountingDepth]);
  useEffect(()=>()=>{geometries.flange.dispose();geometries.cone.dispose();geometries.motor?.dispose();},[geometries]);
  return <group position={position} rotation={isVertical?[0,0,0]:[Math.PI/2,0,0]}>
    <mesh geometry={geometries.flange}><meshStandardMaterial color={warning?'#d9ad24':'#56575a'} side={THREE.DoubleSide}/></mesh>
    <mesh geometry={geometries.cone} position={[0,0,-.001]}><meshStandardMaterial color="#202126" side={THREE.DoubleSide}/></mesh>
    {geometries.motor&&<mesh geometry={geometries.motor}><meshStandardMaterial color={tooDeep?'#e74c3c':'#3a3a3f'}/></mesh>}
  </group>;
}
import { computeNoGoBands, resolveTerminalPanel, resolveTerminalPlacementOffset, type TerminalPanel } from './terminal-placement';
import { resolveSupbAutoCenterY, resolveSupbSubLayout } from './subwoofer-placement';
import { topTerminalCenter } from './terminal-top-placement';
import { SUBWOOFER_PREVIEW_NOTICE, unresolvedSubwooferPreview } from './subwoofer-preview-layout';
import { subwooferSpacingNeedsWarning } from './subwoofer-layout-measurements';
import { subwooferDepthCheck } from './fit-check';
import {
  resolveWindowDimensions,
  resolveWindowSafeArea,
  resolveAutoFitPlateDimensions,
  resolveEffectiveWindowOffsets,
} from './acrylic-window';
import type { EnclosureInputs } from './types/enclosure';
import { appendDebug } from './debug-log';
import { viewerSpecifications, viewerDriverSpecifications } from './viewer-specifications';
import { resetViewerCamera, viewerCameraFrame, viewerCameraPose, VIEWER_FOV } from './viewer-camera';
import { getExportViews } from './viewer-export-views';
import { snapshotRenderGeometry, type RenderGeometry } from './viewer-render-snapshot';
import { drawRenderSpecifications, drawRenderFitWarning, renderSpecificationBox } from './viewer-render-annotation';

// A render set keeps the design present at the start of capture, even if the
// main window sends a new design to a pop-out while its images are rendering.
const RenderGeometryContext = createContext<RenderGeometry | null>(null);

// ─── PBR rendering tuning ─────────────────────────────────────────────────────

// Normal map intensity for textured panels. Default Three.js value is (1, 1).
// Reduced to (0.6, 0.6) so surface bumps don't read as overly deep shadow on
// the relatively small panel surfaces — gives a more natural wood/MDF look
// at typical Build tab preview view distance.
import { Vector2 } from 'three';
const NORMAL_INTENSITY = new Vector2(0.6, 0.6);

// ─── Color Scheme (from desktop EnclosureViewer3D.xaml.cs) ────────────────────

const COLORS = {
  birch: '#DEC396',      // RGB(222, 195, 150)
  // MDF: darker uniform brown, matches raw-MDF panel appearance better than
  // the previous tan #BEAA82 which read too light against Three.js lighting
  // (operator feedback: MDF should be a solid dark color, not the soft tan
  // that looked like faint wood grain due to lighting shading).
  mdf: '#7D6B4F',        // RGB(125, 107, 79)
  port: '#648CB4',       // RGB(100, 140, 180)
  gusset: '#B4A078',     // RGB(180, 160, 120)
  cutout: '#28283C',     // RGB(40, 40, 60)
  edge: '#000000',
  dimText: '#323232',    // RGB(50, 50, 50)
  dimLine: '#787878',    // RGB(120, 120, 120)
  portDimText: '#DC5000', // RGB(220, 80, 0) - orange for port dims
  portDimLine: '#E6781E', // RGB(230, 120, 30)
};

const PART_COLORS: Record<string, string> = {
  top: '#4285F4',        // Blue
  bottom: '#34A853',     // Green
  left: '#FBBC04',       // Yellow
  right: '#EA4335',      // Red
  back: '#7846A0',       // Purple
  baffle: '#9E9E9E',     // Gray
  port1: '#00ACC1',      // Teal
  port2: '#1E1E1E',      // Black
  gusset: '#9E9D24',     // Olive
};

// Driver colors (from desktop)
const DRIVER_COLORS = {
  flange: '#3A3E44',     // RGB(58, 62, 68)
  surround: '#464648',   // RGB(70, 70, 72)
  cone: '#323234',       // RGB(50, 50, 52)
  dustCap: '#232326',    // RGB(35, 35, 38)
  basket: '#34373C',     // RGB(52, 55, 60)
  magnet: '#1C1C1E',     // RGB(28, 28, 30)
};

// Scale: 1 inch = 0.1 Three.js units
const S = 0.1;

// ─── Roundover and Terminal Cup constants (from desktop) ────────────────────

const ROUNDOVER_R = 0.25;  // 0.25" quarter-inch roundover radius
const ROUNDOVER_SEGS = 8;
const DIM_OVERLAY_LIFT = 0.12 * S;

// Terminal cup cutout (left side panel)
const TC_WIDTH = 4.5;      // inches
const TC_HEIGHT = 2.75;    // inches
const TC_CORNER_R = 0.375; // inches
const TC_FROM_BOTTOM = 3.5; // center Y from panel bottom edge

// Terminal plate (inside left wall behind cutout)
const TP_WIDTH = 6.5;       // inches
const TP_HEIGHT = 4.75;     // inches
const TP_THICKNESS = 0.709; // 18mm
const TP_CORNER_R = 0.375;  // inches (rounded corners — matches desktop TerminalPlateCornerR)
const TP_COLOR = '#A0825A'; // RGB(160, 130, 90) birch plate color
const TP_HOLE_R = 0.128;    // 6.5mm / 2 binding post holes
const TP_HOLE_OFF_Z = 0.375; // ±0.375" from center (depth direction)
const TP_HOLE_OFF_Y = 0.397; // above center (height direction)

// Tangent line color (matching desktop PipeVisual3D color RGB(80, 70, 55))
const TANGENT_COLOR = '#504637';
const VIEWER_DPR_RANGE: [number, number] = [1.5, 2.5];
const EXPORT_RENDER_SIZE = { width: 1280, height: 960, dpr: 2 };
const EXPORT_RENDER_VARIANTS = [
  { folder: '3D Renders', fileTag: '3D', dimsMode: 'off' as const },
  { folder: '3D Renders - Dims', fileTag: '3D-Dims', dimsMode: 'exterior' as const },
] as const;

interface RenderExportFile {
  folder: string;
  filename: string;
  blob: Blob;
  type: 'png';
}

// ─── Geometry Helpers ───────────────────────────────────────────────────────

/** Darken a hex color by a factor (0.85 = 15% darker, matching desktop roundover shading) */
function darkenColor(hex: string, factor = 0.85): string {
  const c = new THREE.Color(hex);
  c.r *= factor; c.g *= factor; c.b *= factor;
  return '#' + c.getHexString();
}

/** Merge multiple BufferGeometries into one (avoids external dependency) */
function mergeGeos(geos: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let offset = 0;
  for (const geo of geos) {
    const pos = geo.getAttribute('position').array as Float32Array;
    for (let i = 0; i < pos.length; i++) positions.push(pos[i]);
    const uvAttr = geo.getAttribute('uv');
    if (uvAttr) {
      const uvArr = uvAttr.array as Float32Array;
      for (let i = 0; i < uvArr.length; i++) uvs.push(uvArr[i]);
    }
    const idx = geo.getIndex();
    if (idx) for (let i = 0; i < idx.count; i++) indices.push(idx.getX(i) + offset);
    offset += geo.getAttribute('position').count;
  }
  const merged = new THREE.BufferGeometry();
  merged.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  if (uvs.length > 0) merged.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  merged.setIndex(indices);
  merged.computeVertexNormals();
  return merged;
}

/**
 * Custom panel geometry matching desktop's AddPanelWithRoundoverCut.
 * Builds 6 faces: inner (full-size) + outer (inset by R) + 4 side faces (shortened + trimmed).
 * Origin at the box corner (0,0,0); caller positions via mesh/group position.
 * W = width (X), D = depth (Z), t = thickness (Y), R = roundover radius.
 * isTop: true = exterior at Y=t (top panel), false = exterior at Y=0 (bottom panel).
 */
interface RoundoverCutPanelVisibility {
  inner: boolean;
  outer: boolean;
  front: boolean;
  back: boolean;
  left: boolean;
  right: boolean;
}

interface RoundoverCutPanelFrontClip {
  x0: number;
  x1: number;
  depth: number;
}

interface RoundoverCutPanelRect {
  x0: number;
  x1: number;
  z0: number;
  z1: number;
}

function createRoundoverCutPanel(
  W: number, D: number, t: number, R: number, isTop: boolean,
  visibility: RoundoverCutPanelVisibility,
  innerFrontClip?: RoundoverCutPanelFrontClip | null,
  innerVisibleRects?: RoundoverCutPanelRect[] | null,
): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vi = 0;

  // Add a quad as two triangles with basic UVs
  function addQuad(
    a: [number, number, number], b: [number, number, number],
    c: [number, number, number], d: [number, number, number]
  ) {
    positions.push(...a, ...b, ...c, ...d);
    uvs.push(0, 0, 1, 0, 1, 1, 0, 1);
    indices.push(vi, vi + 1, vi + 2, vi, vi + 2, vi + 3);
    vi += 4;
  }

  // Y positions
  const yInner = isTop ? 0 : t;  // interior face
  const yOuter = isTop ? t : 0;  // exterior face
  const clipX0 = innerFrontClip ? Math.max(0, Math.min(W, innerFrontClip.x0)) : 0;
  const clipX1 = innerFrontClip ? Math.max(0, Math.min(W, innerFrontClip.x1)) : 0;
  const clipDepth = innerFrontClip ? Math.max(0, Math.min(D, innerFrontClip.depth)) : 0;
  const hasInnerFrontClip = clipDepth > 0 && clipX1 > clipX0;
  const clampedInnerRects = (innerVisibleRects ?? [])
    .map((rect) => ({
      x0: Math.max(0, Math.min(W, rect.x0)),
      x1: Math.max(0, Math.min(W, rect.x1)),
      z0: Math.max(0, Math.min(D, rect.z0)),
      z1: Math.max(0, Math.min(D, rect.z1)),
    }))
    .filter((rect) => rect.x1 > rect.x0 && rect.z1 > rect.z0);

  function addInnerRect(x0: number, x1: number, z0: number, z1: number) {
    if (isTop) {
      addQuad([x0, yInner, z0], [x1, yInner, z0], [x1, yInner, z1], [x0, yInner, z1]);
    } else {
      addQuad([x0, yInner, z1], [x1, yInner, z1], [x1, yInner, z0], [x0, yInner, z0]);
    }
  }

  // Desktop strategy (AddPanelWithRoundoverCut): THREE non-overlapping pieces:
  //   1. Horizontal panel: inset outer face + shortened side faces
  //   2. Vertical panels: trimmed to stop R short of horizontal panel
  //   3. Roundover geometry: fills the R-wide gap between them
  // This ensures NO coplanar surfaces → NO z-fighting.
  //
  // Side faces shortened by R at the outer edge (desktop: zSideStart = zBot + R for bottom)
  const ySideBot = isTop ? 0 : R;
  const ySideTop = isTop ? t - R : t;

  // Inner face — full rectangle (interior side, not visible externally)
  if (visibility.inner) {
    if (clampedInnerRects.length > 0) {
      for (const rect of clampedInnerRects) {
        addInnerRect(rect.x0, rect.x1, rect.z0, rect.z1);
      }
    } else if (hasInnerFrontClip) {
      if (isTop) {
        addInnerRect(0, W, clipDepth, D);
        if (clipX0 > 0) {
          addInnerRect(0, clipX0, 0, clipDepth);
        }
        if (clipX1 < W) {
          addInnerRect(clipX1, W, 0, clipDepth);
        }
      } else {
        addInnerRect(0, W, clipDepth, D);
        if (clipX0 > 0) {
          addInnerRect(0, clipX0, 0, clipDepth);
        }
        if (clipX1 < W) {
          addInnerRect(clipX1, W, 0, clipDepth);
        }
      }
    } else {
      addInnerRect(0, W, 0, D);
    }
  }

  // Outer face — INSET by R (desktop pattern: leaves gap for roundover geometry)
  // Corner octant spheres fill the L-shaped gaps at each corner.
  if (visibility.outer) {
    if (isTop)
      addQuad([R, yOuter, D - R], [W - R, yOuter, D - R], [W - R, yOuter, R], [R, yOuter, R]);
    else
      addQuad([R, yOuter, R], [W - R, yOuter, R], [W - R, yOuter, D - R], [R, yOuter, D - R]);
  }

  // Side faces — shortened by R at outer edge, trimmed to R..W-R or R..D-R
  // These DON'T extend into the roundover zone, avoiding z-fighting.
  // Front side (Z=0): X from R to W-R
  if (visibility.front) {
    addQuad([W - R, ySideBot, 0], [R, ySideBot, 0], [R, ySideTop, 0], [W - R, ySideTop, 0]);
  }
  // Back side (Z=D): X from R to W-R
  if (visibility.back) {
    addQuad([R, ySideBot, D], [W - R, ySideBot, D], [W - R, ySideTop, D], [R, ySideTop, D]);
  }
  // Left side (X=0): Z from R to D-R
  if (visibility.left) {
    addQuad([0, ySideBot, R], [0, ySideBot, D - R], [0, ySideTop, D - R], [0, ySideTop, R]);
  }
  // Right side (X=W): Z from R to D-R
  if (visibility.right) {
    addQuad([W, ySideBot, D - R], [W, ySideBot, R], [W, ySideTop, R], [W, ySideTop, D - R]);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Custom vertical panel geometry matching desktop's AddVerticalTrimmedPanel.
 * Builds the visible side faces of a vertical panel with quarter-circle arc notches
 * at specified corners, and side faces shortened by R at those corners.
 * Hidden top/bottom end caps are intentionally omitted in the web viewer to avoid
 * WebGL seam artifacts where these buried faces overlap the restored floor/ceiling.
 *
 * Web coordinates: X = width, Y = height, Z = depth.
 * W = width (X span), H = height (Y span), D = depth (Z span).
 * R = roundover radius (already scaled by S).
 *
 * trimCorners[0] = front-left  (X=0,   Z=0) — desktop trimFrontAtXmin
 * trimCorners[1] = front-right (X=W,   Z=0) — desktop trimFrontAtXmax
 * trimCorners[2] = back-right  (X=W,   Z=D) — desktop trimBackAtXmax
 * trimCorners[3] = back-left   (X=0,   Z=D) — desktop trimBackAtXmin
 */
function createTrimmedVerticalPanel(
  W: number, H: number, D: number, R: number,
  trimCorners: [boolean, boolean, boolean, boolean]
): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vi = 0;

  function addQuad(
    a: [number, number, number], b: [number, number, number],
    c: [number, number, number], d: [number, number, number]
  ) {
    positions.push(...a, ...b, ...c, ...d);
    uvs.push(0, 0, 1, 0, 1, 1, 0, 1);
    indices.push(vi, vi + 1, vi + 2, vi, vi + 2, vi + 3);
    vi += 4;
  }

  const [trimFL, trimFR, trimBR, trimBL] = trimCorners;

  let lfz0 = 0, lfz1 = D;
  if (trimFL) lfz0 = R;
  if (trimBL) lfz1 = D - R;
  addQuad([0, 0, lfz1], [0, 0, lfz0], [0, H, lfz0], [0, H, lfz1]);

  let rfz0 = 0, rfz1 = D;
  if (trimFR) rfz0 = R;
  if (trimBR) rfz1 = D - R;
  addQuad([W, 0, rfz0], [W, 0, rfz1], [W, H, rfz1], [W, H, rfz0]);

  let ffx0 = 0, ffx1 = W;
  if (trimFL) ffx0 = R;
  if (trimFR) ffx1 = W - R;
  addQuad([ffx0, 0, 0], [ffx1, 0, 0], [ffx1, H, 0], [ffx0, H, 0]);

  let bfx0 = 0, bfx1 = W;
  if (trimBL) bfx0 = R;
  if (trimBR) bfx1 = W - R;
  addQuad([bfx1, 0, D], [bfx0, 0, D], [bfx0, H, D], [bfx1, H, D]);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

interface BaffleFaceVisibility {
  caps: boolean;
  left: boolean;
  right: boolean;
  front: boolean;
  back: boolean;
  holeWalls: boolean;
}

function createBaffleWithCutoutGeometry(
  W: number, H: number, D: number,
  holes: { cx: number; cy: number; r: number; outline?: ProfilePoint[] }[],
  trimLeft: boolean,
  R: number,
  visibility: BaffleFaceVisibility,
  trimRight = false,
): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vi = 0;

  function addQuad(
    a: [number, number, number], b: [number, number, number],
    c: [number, number, number], d: [number, number, number]
  ) {
    positions.push(...a, ...b, ...c, ...d);
    uvs.push(0, 0, 1, 0, 1, 1, 0, 1);
    indices.push(vi, vi + 1, vi + 2, vi, vi + 2, vi + 3);
    vi += 4;
  }

  function addXYFaceWithHoles(
    contourPts: [number, number][],
    faceHoles: [number, number][][],
    z: number,
    reverseWinding: boolean,
    uvX0: number,
    uvW: number,
  ) {
    let contour = contourPts.map(([x, y]) => new THREE.Vector2(x, y));
    if (!THREE.ShapeUtils.isClockWise(contour)) contour = contour.reverse();

    const holes2D = faceHoles.map((hole) => {
      let pts = hole.map(([x, y]) => new THREE.Vector2(x, y));
      if (THREE.ShapeUtils.isClockWise(pts)) pts = pts.reverse();
      return pts;
    });

    const verts = contour.concat(...holes2D);
    const tris = THREE.ShapeUtils.triangulateShape(contour, holes2D);

    for (const tri of tris) {
      const order = reverseWinding ? [tri[0], tri[2], tri[1]] : tri;
      for (const idx of order) {
        const v = verts[idx];
        positions.push(v.x, v.y, z);
        uvs.push((v.x - uvX0) / uvW, v.y / H);
        indices.push(vi++);
      }
    }
  }

  function buildCapPerimeterXZ(): [number, number][] {
    if (!trimLeft && !trimRight) return [[0, 0], [0, D], [W, D], [W, 0]];

    const pts: [number, number][] = [];
    if (trimLeft) {
      for (let i = 0; i <= ROUNDOVER_SEGS; i++) {
        const angle = (3 * Math.PI / 2) - (Math.PI / 2) * i / ROUNDOVER_SEGS;
        pts.push([
          R + R * Math.cos(angle),
          R + R * Math.sin(angle),
        ]);
      }
    } else {
      pts.push([0, 0]);
    }
    pts.push([0, D], [W, D]);
    if (trimRight) {
      // Mirror of the left corner: from the right side face round to the front face.
      for (let i = 0; i <= ROUNDOVER_SEGS; i++) {
        const angle = -(Math.PI / 2) * i / ROUNDOVER_SEGS;
        pts.push([
          W - R + R * Math.cos(angle),
          R + R * Math.sin(angle),
        ]);
      }
    } else {
      pts.push([W, 0]);
    }
    return pts;
  }

  function addCapFace(y: number, reverseWinding: boolean) {
    let contour = buildCapPerimeterXZ().map(([x, z]) => new THREE.Vector2(x, z));
    if (!THREE.ShapeUtils.isClockWise(contour)) contour = contour.reverse();

    const tris = THREE.ShapeUtils.triangulateShape(contour, []);
    for (const tri of tris) {
      const order = reverseWinding ? [tri[0], tri[2], tri[1]] : tri;
      for (const idx of order) {
        const v = contour[idx];
        positions.push(v.x, y, v.y);
        uvs.push(v.x / W, v.y / D);
        indices.push(vi++);
      }
    }
  }

  const buildClampedHolePoints = (xMin: number, xMax: number) => holes.map((hole) => {
    const {cx,cy}=hole;
    const pts: [number, number][] = [];
    for (const p of holeOutline(hole)) {
      pts.push([
        Math.max(xMin, Math.min(xMax, cx + p.x)),
        Math.max(0, Math.min(H, cy + p.y)),
      ]);
    }
    return pts;
  });

  // Desktop AddBaffleMeshWithHoles keeps the top and bottom faces full-size and
  // only trims the front/left side faces. Keep that topology here as well.
  if (visibility.caps) {
    const eps = 0.0002;
    addCapFace(H - eps, false);
    addCapFace(eps, true);
  }

  const leftX = 0;
  const frontZ = 0;
  const leftZ0 = trimLeft ? R : 0;
  if (visibility.left) {
    addQuad([leftX, 0, D], [leftX, H, D], [leftX, H, leftZ0], [leftX, 0, leftZ0]);
  }
  const rightZ0 = trimRight ? R : 0;
  if (visibility.right) {
    addQuad([W, 0, rightZ0], [W, H, rightZ0], [W, H, D], [W, 0, D]);
  }

  const backHoles = buildClampedHolePoints(0, W);
  if (visibility.holeWalls) {
    for (const holePts of backHoles) {
      for (let i = 0; i < holePts.length; i++) {
        const next = (i + 1) % holePts.length;
        const [x0, y0] = holePts[i];
        const [x1, y1] = holePts[next];
        addQuad([x0, y0, 0], [x1, y1, 0], [x1, y1, D], [x0, y0, D]);
      }
    }
  }

  const frontX0 = trimLeft ? R : 0;
  const frontX1 = trimRight ? W - R : W;
  if (visibility.front) {
    addXYFaceWithHoles(
      [[frontX0, 0], [frontX1, 0], [frontX1, H], [frontX0, H]],
      buildClampedHolePoints(frontX0, frontX1),
      frontZ,
      true,
      frontX0,
      frontX1 - frontX0,
    );
  }
  if (visibility.back) {
    addXYFaceWithHoles(
      [[0, 0], [W, 0], [W, H], [0, H]],
      backHoles,
      D,
      false,
      0,
      W,
    );
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/** Quarter-cylinder between two points with two outward normals (matching desktop AddEdgeRound) */
function createEdgeRound(
  p1: THREE.Vector3, p2: THREE.Vector3,
  out1: THREE.Vector3, out2: THREE.Vector3,
  R: number, segs: number
): THREE.BufferGeometry {
  const inOff = new THREE.Vector3().addVectors(out1, out2).multiplyScalar(-R);
  const c1 = new THREE.Vector3().addVectors(p1, inOff);
  const c2 = new THREE.Vector3().addVectors(p2, inOff);
  const positions: number[] = [];
  const uvs: number[] = [];
  for (let e = 0; e < 2; e++) {
    const c = e === 0 ? c1 : c2;
    for (let a = 0; a <= segs; a++) {
      const th = (Math.PI / 2) * a / segs;
      const cos = Math.cos(th), sin = Math.sin(th);
      positions.push(
        c.x + R * (out1.x * cos + out2.x * sin),
        c.y + R * (out1.y * cos + out2.y * sin),
        c.z + R * (out1.z * cos + out2.z * sin),
      );
      uvs.push(a / segs, e);
    }
  }
  const cols = segs + 1;
  const indices: number[] = [];
  for (let a = 0; a < segs; a++) {
    indices.push(a, cols + a, cols + a + 1);
    indices.push(a, cols + a + 1, a + 1);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/** 1/8 sphere at a corner with three outward normals (matching desktop AddCornerRound) */
function createCornerRound(
  corner: THREE.Vector3,
  n1: THREE.Vector3, n2: THREE.Vector3, n3: THREE.Vector3,
  R: number, segs: number
): THREE.BufferGeometry {
  // Desktop: center = corner - R * (out1 + out2 + out3)
  // Offset sphere center INWARD from the corner by R in each outward normal direction
  const center = new THREE.Vector3(
    corner.x - R * (n1.x + n2.x + n3.x),
    corner.y - R * (n1.y + n2.y + n3.y),
    corner.z - R * (n1.z + n2.z + n3.z),
  );
  const positions: number[] = [];
  const uvs: number[] = [];
  for (let j = 0; j <= segs; j++) {
    const phi = (Math.PI / 2) * j / segs;
    const cp = Math.cos(phi), sp = Math.sin(phi);
    for (let i = 0; i <= segs; i++) {
      const th = (Math.PI / 2) * i / segs;
      const ct = Math.cos(th), st = Math.sin(th);
      positions.push(
        center.x + R * (n1.x * ct * cp + n2.x * st * cp + n3.x * sp),
        center.y + R * (n1.y * ct * cp + n2.y * st * cp + n3.y * sp),
        center.z + R * (n1.z * ct * cp + n2.z * st * cp + n3.z * sp),
      );
      uvs.push(i / segs, j / segs);
    }
  }
  const cols = segs + 1;
  const indices: number[] = [];
  for (let j = 0; j < segs; j++) {
    for (let i = 0; i < segs; i++) {
      const a = j * cols + i;
      indices.push(a, a + cols, a + cols + 1);
      indices.push(a, a + cols + 1, a + 1);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

// ─── X-Ray and Dims modes matching desktop ──────────────────────────────────

type XRayMode = 'off' | 'topOnly' | 'exterior';
type DimsMode = 'off' | 'exterior' | 'all' | 'full';
type ViewerDebugMode =
  | 'off'
  | 'noRoundover'
  | 'noRoEdges'
  | 'noRoCorners'
  | 'noBaffleFront'
  | 'noBaffleLeft'
  | 'noBaffleCaps'
  | 'noBaffleHoleWalls';

const DEBUG_MODE_ORDER: ViewerDebugMode[] = [
  'off',
  'noRoundover',
  'noRoEdges',
  'noRoCorners',
  'noBaffleFront',
  'noBaffleLeft',
  'noBaffleCaps',
  'noBaffleHoleWalls',
];

const DEBUG_MODE_LABELS: Record<ViewerDebugMode, string> = {
  off: 'Diag',
  noRoundover: 'Diag: NoRO',
  noRoEdges: 'Diag: NoRE',
  noRoCorners: 'Diag: NoRC',
  noBaffleFront: 'Diag: NoBF',
  noBaffleLeft: 'Diag: NoBL',
  noBaffleCaps: 'Diag: NoBC',
  noBaffleHoleWalls: 'Diag: NoBW',
};

type PanelLayerDebugMode =
  | 'off'
  | 'hideTopInner'
  | 'hideTopOuter'
  | 'hideTopFront'
  | 'hideTopBack'
  | 'hideTopLeft'
  | 'hideTopRight'
  | 'hideBottomInner'
  | 'hideBottomOuter'
  | 'hideBottomFront'
  | 'hideBottomBack'
  | 'hideBottomLeft'
  | 'hideBottomRight';

const PANEL_LAYER_DEBUG_ORDER: PanelLayerDebugMode[] = [
  'off',
  'hideTopInner',
  'hideTopOuter',
  'hideTopFront',
  'hideTopBack',
  'hideTopLeft',
  'hideTopRight',
  'hideBottomInner',
  'hideBottomOuter',
  'hideBottomFront',
  'hideBottomBack',
  'hideBottomLeft',
  'hideBottomRight',
];

const PANEL_LAYER_DEBUG_LABELS: Record<PanelLayerDebugMode, string> = {
  off: 'Layer',
  hideTopInner: 'Layer: T In',
  hideTopOuter: 'Layer: T Out',
  hideTopFront: 'Layer: T Fr',
  hideTopBack: 'Layer: T Bk',
  hideTopLeft: 'Layer: T L',
  hideTopRight: 'Layer: T R',
  hideBottomInner: 'Layer: B In',
  hideBottomOuter: 'Layer: B Out',
  hideBottomFront: 'Layer: B Fr',
  hideBottomBack: 'Layer: B Bk',
  hideBottomLeft: 'Layer: B L',
  hideBottomRight: 'Layer: B R',
};
// ─── X-Ray Diagonal Line (for wireframe mode) ──────────────────────────────

function XRayDiagLine({ points }: { points: [THREE.Vector3, THREE.Vector3] }) {
  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    return geo;
  }, [points]);

  return (
    <line>
      <primitive object={geometry} attach="geometry" />
      <lineBasicMaterial color={COLORS.edge} opacity={0.4} transparent />
    </line>
  );
}

// ─── Panel Component ──────────────────────────────────────────────────────────

interface PanelProps {
  position: [number, number, number];
  size: [number, number, number];
  color: string;
  opacity?: number;
  showEdges?: boolean;
}

function Panel({ position, size, color, opacity = 1, showEdges = true }: PanelProps) {
  const geo = useMemo(() => new THREE.BoxGeometry(...size), [size]);
  const isXRay = opacity === 0;

  // Diagonal X line points for wireframe mode (matching desktop BoundingBoxVisual3D + diagonals)
  const diagPoints = useMemo(() => {
    if (!isXRay) return null;
    const [sx, sy, sz] = size;
    const hx = sx / 2, hy = sy / 2, hz = sz / 2;
    return {
      d1: [new THREE.Vector3(-hx, -hy, -hz), new THREE.Vector3(hx, hy, hz)],
      d2: [new THREE.Vector3(hx, -hy, -hz), new THREE.Vector3(-hx, hy, hz)],
    };
  }, [isXRay, size]);

  return (
    <group position={position}>
      {/* Solid mesh: hidden when x-rayed (opacity=0), matching desktop behavior */}
      {!isXRay && (
        <mesh>
          <boxGeometry args={size} />
          <meshStandardMaterial color={color} side={THREE.DoubleSide} />
        </mesh>
      )}
      {/* Edge wireframe: always shown, thinner when solid */}
      {showEdges && (
        <lineSegments>
          <edgesGeometry args={[geo]} />
          <lineBasicMaterial color={COLORS.edge} opacity={isXRay ? 0.6 : 1} transparent={isXRay} />
        </lineSegments>
      )}
      {/* Diagonal X lines in wireframe mode (matching desktop X-Ray) */}
      {isXRay && diagPoints && (
        <>
          <XRayDiagLine points={diagPoints.d1 as [THREE.Vector3, THREE.Vector3]} />
          <XRayDiagLine points={diagPoints.d2 as [THREE.Vector3, THREE.Vector3]} />
        </>
      )}
    </group>
  );
}

// ─── Realistic Subwoofer Driver (matching desktop) ──────────────────────────

interface DriverProps {
  position: [number, number, number];
  radius: number;
  visibleDiameter?: number;
  isVertical?: boolean; // true = on baffle (Z-facing), false = on top (Y-facing)
  baffleThickness: number;
  spacingWarning?: boolean;
  /** The subwoofer's mounting depth, inches. Given: the model is stretched or shortened behind its
   *  mounting face so its motor ends that far back. Missing: the model's own depth. */
  mountingDepth?: number;
  /** The fit check finds the subwoofer too deep for the box: its motor is drawn red. */
  tooDeep?: boolean;
}

function RealisticDriver({ position, radius, visibleDiameter, isVertical = true, baffleThickness, spacingWarning = false, mountingDepth, tooDeep = false }: DriverProps) {
  // Load the SAME OBJ model file as desktop (Resources/SubwooferDriver.obj).
  // Desktop: EnclosureViewer3D.xaml.cs EnsureDriverModelLoaded() + AddObjDriver() + ColorDriverByComponent()
  const obj = useLoader(OBJLoader, '/models/SubwooferDriver.obj');

  // Desktop transform constants (from AddObjDriver lines 1359-1392):
  //   Model space: XY = circular face, Z = driver axis
  //   Model center in XY: (5.4, 38.15), gasket ring Z≈40.7, magnet Z≈-3
  //   Gasket ring diameter = 60mm (Tube05)
  //
  // Desktop scene: X=width, Y=depth (baffle at Y≈0), Z=height
  // Web scene:     X=width, Y=height, Z=depth (baffle at Z≈0)
  //
  // Scale: model is in mm, scene is in inches×S.
  //   Desktop: scale = cutoutDia_inches / 60mm (converts mm model to inch scene, 1:1 inch units)
  //   Web: scale = cutoutDia_sceneUnits / 60mm (converts mm model to scene units where S=0.1)
  // Visible outer frame OD of the shipped OBJ after the desktop-style filtering.
  // The 60mm gasket ring is closer to cutout size; the full rendered driver OD is ~65.2mm.
  const modelOuterDia = 65.207; // mm
  const modelCenterX = 5.4;
  const modelCenterY = 38.15;
  const modelMountZ = 37.173;
  const cutoutDia = radius * 2; // in scene units (already × S)
  const renderDia = visibleDiameter && visibleDiameter > 0 ? visibleDiameter : cutoutDia;
  const scale = renderDia / modelOuterDia; // mm → scene units
  const seatInset = Math.min(baffleThickness * 0.14, 0.08 * S);
  const seatedPosition: [number, number, number] = isVertical
    ? [position[0], position[1], position[2] + seatInset]
    : [position[0], position[1] - seatInset, position[2]];

  // Color the model by component bounding box diameter
  // (matches desktop ColorDriverByComponent lines 1432-1503)
  const coloredModel = useMemo(() => {
    const clone = obj.clone(true);

    const makeChrome = (r: number, g: number, b: number) => new THREE.MeshPhongMaterial({
      color: new THREE.Color(r / 255, g / 255, b / 255),
      specular: new THREE.Color(1, 1, 1),
      shininess: 90,
      side: THREE.DoubleSide,
    });
    const makeSatin = (r: number, g: number, b: number, shininess = 35) => new THREE.MeshPhongMaterial({
      color: new THREE.Color(r / 255, g / 255, b / 255),
      specular: new THREE.Color(140 / 255, 140 / 255, 148 / 255),
      shininess,
      side: THREE.DoubleSide,
    });
    const makeMatte = (r: number, g: number, b: number) => new THREE.MeshLambertMaterial({
      color: new THREE.Color(r / 255, g / 255, b / 255),
      side: THREE.DoubleSide,
    });

    // Desktop exact colors from original .3ds materials:
    const allumMat = spacingWarning ? makeMatte(245, 158, 11) : makeChrome(160, 160, 165);
    const rubberMat = spacingWarning ? makeMatte(245, 158, 11) : makeMatte(34, 34, 34);
    const kevlarBlkMat = makeMatte(15, 15, 15);          // surround
    const kevlarMat = makeMatte(55, 55, 58);             // dark gray dust cap
    const stabMat = makeMatte(235, 214, 92);             // more saturated yellow spider
    // Too deep for the box: the motor (and the basket rings it hangs on) red.
    const metalMat = tooDeep ? makeMatte(231, 76, 60) : makeSatin(78, 78, 84, 30);  // darker basket rings, motor
    const magnetMat = tooDeep ? makeMatte(231, 76, 60) : makeMatte(40, 40, 40);     // magnet
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const goldMat = makeChrome(84, 51, 0);               // terminals
    const plasicMat = makeMatte(17, 17, 17);             // terminal block, small plastic

    clone.traverse((child) => {
      if (child instanceof THREE.Mesh && child.geometry) {
        child.geometry.computeBoundingBox();
        const b = child.geometry.boundingBox;
        if (!b) return;
        const diaXY = Math.max(b.max.x - b.min.x, b.max.y - b.min.y);
        const sizeZ = b.max.z - b.min.z;

        // Hide cabinet/port geometry (>70mm diameter or >80mm Z extent)
        if (diaXY > 70 || sizeZ > 80) {
          child.visible = false;
          return;
        }

        let mat: THREE.Material;
        if (diaXY > 55) {
          mat = sizeZ > 15 ? allumMat : rubberMat;
        } else if (diaXY > 40) {
          mat = kevlarBlkMat;
        } else if (diaXY > 30) {
          if (diaXY > 36 && sizeZ < 5) mat = kevlarMat;
          else if (sizeZ > 10) mat = magnetMat;
          else mat = metalMat;
        } else if (diaXY > 20) {
          mat = stabMat;
        } else if (diaXY > 12) {
          mat = metalMat;
        } else if (diaXY < 3) {
          mat = allumMat;
        } else {
          mat = plasicMat;
        }
        child.material = mat;
      }
    });

    // The subwoofer's own depth: move every point behind the mounting face (model z below
    // modelMountZ) back or forward in proportion, so the motor ends mountingDepth behind the face
    // the frame sits on (the group is seated seatInset into the panel). The frame, surround and
    // cone in front of the face keep their shape. Normals follow the stretch.
    if (mountingDepth && mountingDepth > 0) {
      let minZ = Infinity;
      clone.traverse((child) => {
        if (child instanceof THREE.Mesh && child.visible && child.geometry.boundingBox) {
          minZ = Math.min(minZ, child.geometry.boundingBox.min.z);
        }
      });
      const naturalBack = modelMountZ - minZ;                               // model units
      const wantedBack = Math.max(0, mountingDepth * S - seatInset) / scale; // the same, in model units
      if (Number.isFinite(naturalBack) && naturalBack > 0 && wantedBack > 0) {
        const k = wantedBack / naturalBack;
        clone.traverse((child) => {
          if (!(child instanceof THREE.Mesh) || !child.visible) return;
          const geometry = (child.geometry as THREE.BufferGeometry).clone();
          const position = geometry.getAttribute('position');
          const normal = geometry.getAttribute('normal');
          for (let i = 0; i < position.count; i++) {
            const z = position.getZ(i);
            if (z >= modelMountZ) continue;
            position.setZ(i, modelMountZ - (modelMountZ - z) * k);
            if (normal) {
              const nx = normal.getX(i), ny = normal.getY(i), nz = normal.getZ(i) / k;
              const length = Math.hypot(nx, ny, nz) || 1;
              normal.setXYZ(i, nx / length, ny / length, nz / length);
            }
          }
          position.needsUpdate = true;
          if (normal) normal.needsUpdate = true;
          geometry.computeBoundingBox();
          geometry.computeBoundingSphere();
          child.geometry = geometry;
          child.userData.depthScaled = true;
        });
      }
    }
    return clone;
  }, [obj, spacingWarning, tooDeep, mountingDepth, scale, seatInset]);
  // Stretched copies belong to this driver alone (the loaded model's own geometry is shared).
  useEffect(() => () => {
    coloredModel.traverse((child) => {
      if (child instanceof THREE.Mesh && child.userData.depthScaled) child.geometry.dispose();
    });
  }, [coloredModel]);

  // Desktop transform chain (applied left-to-right = innermost first):
  //   T1: translate(-5.4, -38.15, -37.0) — center model on flange mount surface
  //   R2: rotate 90° around X — in WPF: (x,y,z)→(x,-z,y) maps model Z→desktop -Y (forward)
  //   S3: scale(s, s, s) — mm → inches
  //   T4: translate(cx, 0, cz) — position at cutout center
  //
  // Desktop coord mapping after R2: modelX→sceneX, modelZ→scene-Y(depth), modelY→sceneZ(height)
  // Web coord equivalents: desktopX→webX, desktopY→webZ, desktopZ→webY
  // So net: modelX→webX, modelZ→web-Z(depth,forward), modelY→webY(height)
  //
  // Web rotation to achieve modelX→X, modelY→Y, modelZ→-Z: rotate 180° around Y
  //   (x,y,z) → (-x, y, -z). The X flip mirrors the driver but it's rotationally symmetric.
  //
  // For SUPB (top-mounted): desktop has NO rotation (model Z already = scene Z = height).
  //   Web equivalent: modelZ→webY(height). This needs rotate -90° around X.
  //   Three.js -90° around X: (x,y,z) → (x, z, -y). So modelZ→webY ✓
  //
  // The visible outer frame extends farther forward, but the actual baffle contact
  // plane is the back of the gasket/flange at roughly Z≈37.17 in the shipped OBJ.
  // That matches the desktop mount rule much more closely than the visible front lip.

  // Three.js group nesting: T4 > S3 > R2 > T1 > model (outer to inner)
  const rot: [number, number, number] = isVertical
    ? [0, Math.PI, 0]       // Baffle: 180° around Y → modelZ faces -Z (forward through baffle)
    : [-Math.PI / 2, 0, 0]; // Top: -90° around X → modelZ faces +Y (upward through top panel)

  return (
    <group position={seatedPosition}>
      <group scale={[scale, scale, scale]} rotation={rot}>
        <primitive object={coloredModel} position={[-modelCenterX, -modelCenterY, -modelMountZ]} />
      </group>
    </group>
  );
}

// ─── Subwoofer Cutout Circle (flat fallback) ────────────────────────────────

interface CutoutProps {
  position: [number, number, number];
  rotation?: [number, number, number];
  radius: number;
}

function SubCutout({ position, rotation = [0, 0, 0], radius }: CutoutProps) {
  return (
    <mesh position={position} rotation={rotation}>
      <ringGeometry args={[0, radius, 48]} />
      <meshStandardMaterial color={COLORS.cutout} side={THREE.DoubleSide} />
    </mesh>
  );
}

// ─── Roundovers (12 edges + 8 corners matching desktop AddRoundovers) ────────

interface RoundoversProps {
  boxW: number; boxH: number; boxD: number;
  color: string; useGrain?: boolean;
  texture?: THREE.Texture | MaterialTexturePack | null;
  showEdges?: boolean;
  showCorners?: boolean;
}

function Roundovers({
  boxW, boxH, boxD, color, useGrain, texture, showEdges = true, showCorners = true,
}: RoundoversProps) {
  const R = ROUNDOVER_R * S;
  const segs = ROUNDOVER_SEGS;
  const W = boxW, H = boxH, D = boxD;

  const { edgeGeometry, cornerGeometry } = useMemo(() => {
    const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
    const nX = V(1, 0, 0), nY = V(0, 1, 0), nZ = V(0, 0, 1);
    const nXn = V(-1, 0, 0), nYn = V(0, -1, 0), nZn = V(0, 0, -1);

    const edgeGeos: THREE.BufferGeometry[] = [];
    const cornerGeos: THREE.BufferGeometry[] = [];

    // 12 edges (trimmed by R at each end for corner octants)
    // Bottom (Y=0)
    edgeGeos.push(createEdgeRound(V(R,0,0), V(W-R,0,0), nZn, nYn, R, segs));
    edgeGeos.push(createEdgeRound(V(R,0,D), V(W-R,0,D), nZ, nYn, R, segs));
    edgeGeos.push(createEdgeRound(V(0,0,R), V(0,0,D-R), nXn, nYn, R, segs));
    edgeGeos.push(createEdgeRound(V(W,0,R), V(W,0,D-R), nX, nYn, R, segs));
    // Top (Y=H)
    edgeGeos.push(createEdgeRound(V(R,H,0), V(W-R,H,0), nZn, nY, R, segs));
    edgeGeos.push(createEdgeRound(V(R,H,D), V(W-R,H,D), nZ, nY, R, segs));
    edgeGeos.push(createEdgeRound(V(0,H,R), V(0,H,D-R), nXn, nY, R, segs));
    edgeGeos.push(createEdgeRound(V(W,H,R), V(W,H,D-R), nX, nY, R, segs));
    // Vertical
    edgeGeos.push(createEdgeRound(V(0,R,0), V(0,H-R,0), nXn, nZn, R, segs));
    edgeGeos.push(createEdgeRound(V(W,R,0), V(W,H-R,0), nX, nZn, R, segs));
    edgeGeos.push(createEdgeRound(V(0,R,D), V(0,H-R,D), nXn, nZ, R, segs));
    edgeGeos.push(createEdgeRound(V(W,R,D), V(W,H-R,D), nX, nZ, R, segs));

    // 8 corner octants (1/8 spheres)
    cornerGeos.push(createCornerRound(V(0,0,0), nXn, nZn, nYn, R, segs));
    cornerGeos.push(createCornerRound(V(W,0,0), nX, nZn, nYn, R, segs));
    cornerGeos.push(createCornerRound(V(0,0,D), nXn, nZ, nYn, R, segs));
    cornerGeos.push(createCornerRound(V(W,0,D), nX, nZ, nYn, R, segs));
    cornerGeos.push(createCornerRound(V(0,H,0), nXn, nZn, nY, R, segs));
    cornerGeos.push(createCornerRound(V(W,H,0), nX, nZn, nY, R, segs));
    cornerGeos.push(createCornerRound(V(0,H,D), nXn, nZ, nY, R, segs));
    cornerGeos.push(createCornerRound(V(W,H,D), nX, nZ, nY, R, segs));

    return {
      edgeGeometry: mergeGeos(edgeGeos),
      cornerGeometry: mergeGeos(cornerGeos),
    };
  }, [W, H, D, R, segs]);
  const applyTexture = useGrain && !!texture;
  const matColor = useMemo(() => {
    if (applyTexture) return '#ffffff';
    const c = new THREE.Color(color);
    c.r *= 0.85; c.g *= 0.85; c.b *= 0.85;
    return '#' + c.getHexString();
  }, [color, applyTexture]);
  const matMap = applyTexture ? albedoOf(texture) : undefined;

  // 24 tangent lines: 2 per edge × 12 edges (matching desktop Roundover_Edge)
  const tangentLines = useMemo(() => {
    const lines: { start: [number, number, number]; end: [number, number, number] }[] = [];
    // Bottom edges (Z=0 plane): 8 tangent lines
    // Bottom-front (X edge at Y=0, Z=0): tangent on bottom face (Z=R) and front face (Y=R)
    lines.push({ start: [R, 0, R], end: [W - R, 0, R] });      // bottom face
    lines.push({ start: [R, R, 0], end: [W - R, R, 0] });      // front face
    // Bottom-back (X edge at Y=0, Z=D)
    lines.push({ start: [R, 0, D - R], end: [W - R, 0, D - R] }); // bottom face
    lines.push({ start: [R, R, D], end: [W - R, R, D] });       // back face
    // Bottom-left (Z edge at X=0, Y=0)
    lines.push({ start: [0, 0, R], end: [0, 0, D - R] });       // bottom face (wait, need X=R on bottom)
    // Actually, desktop tangent lines are inset by R from the edge on each adjacent face.
    // For bottom-left edge (runs along Z at X=0, Y=0):
    //   On bottom face (Y=0): line at X=R, running Z from R to D-R
    //   On left face (X=0): line at Y=R, running Z from R to D-R
    // Let me redo this properly:

    // Bottom-front (runs along X at Y=0, Z=0)
    lines.length = 0; // reset
    lines.push({ start: [R, R, 0], end: [W - R, R, 0] });       // on front face, at Y=R
    lines.push({ start: [R, 0, R], end: [W - R, 0, R] });       // on bottom face, at Z=R
    // Bottom-back (runs along X at Y=0, Z=D)
    lines.push({ start: [R, R, D], end: [W - R, R, D] });       // on back face, at Y=R
    lines.push({ start: [R, 0, D - R], end: [W - R, 0, D - R] }); // on bottom face, at Z=D-R
    // Bottom-left (runs along Z at X=0, Y=0)
    lines.push({ start: [R, 0, R], end: [R, 0, D - R] });       // on bottom face, at X=R
    lines.push({ start: [0, R, R], end: [0, R, D - R] });       // on left face, at Y=R
    // Bottom-right (runs along Z at X=W, Y=0)
    lines.push({ start: [W - R, 0, R], end: [W - R, 0, D - R] }); // on bottom face, at X=W-R
    lines.push({ start: [W, R, R], end: [W, R, D - R] });       // on right face, at Y=R

    // Top-front (runs along X at Y=H, Z=0)
    lines.push({ start: [R, H - R, 0], end: [W - R, H - R, 0] }); // on front face, at Y=H-R
    lines.push({ start: [R, H, R], end: [W - R, H, R] });       // on top face, at Z=R
    // Top-back (runs along X at Y=H, Z=D)
    lines.push({ start: [R, H - R, D], end: [W - R, H - R, D] }); // on back face, at Y=H-R
    lines.push({ start: [R, H, D - R], end: [W - R, H, D - R] }); // on top face, at Z=D-R
    // Top-left (runs along Z at X=0, Y=H)
    lines.push({ start: [R, H, R], end: [R, H, D - R] });       // on top face, at X=R
    lines.push({ start: [0, H - R, R], end: [0, H - R, D - R] }); // on left face, at Y=H-R
    // Top-right (runs along Z at X=W, Y=H)
    lines.push({ start: [W - R, H, R], end: [W - R, H, D - R] }); // on top face, at X=W-R
    lines.push({ start: [W, H - R, R], end: [W, H - R, D - R] }); // on right face, at Y=H-R

    // Vertical-front-left (runs along Y at X=0, Z=0)
    lines.push({ start: [R, R, 0], end: [R, H - R, 0] });       // on front face, at X=R
    lines.push({ start: [0, R, R], end: [0, H - R, R] });       // on left face, at Z=R
    // Vertical-front-right (runs along Y at X=W, Z=0)
    lines.push({ start: [W - R, R, 0], end: [W - R, H - R, 0] }); // on front face, at X=W-R
    lines.push({ start: [W, R, R], end: [W, H - R, R] });       // on right face, at Z=R
    // Vertical-back-left (runs along Y at X=0, Z=D)
    lines.push({ start: [R, R, D], end: [R, H - R, D] });       // on back face, at X=R
    lines.push({ start: [0, R, D - R], end: [0, H - R, D - R] }); // on left face, at Z=D-R
    // Vertical-back-right (runs along Y at X=W, Z=D)
    lines.push({ start: [W - R, R, D], end: [W - R, H - R, D] }); // on back face, at X=W-R
    lines.push({ start: [W, R, D - R], end: [W, H - R, D - R] }); // on right face, at Z=D-R

    return lines;
  }, [W, H, D, R]);

  return (
    <>
      {showEdges && (
        <mesh geometry={edgeGeometry}>
          <meshStandardMaterial color={matColor} map={matMap} side={THREE.DoubleSide} />
        </mesh>
      )}
      {showCorners && (
        <mesh geometry={cornerGeometry}>
          <meshStandardMaterial color={matColor} map={matMap} side={THREE.DoubleSide} />
        </mesh>
      )}
      {tangentLines.map((l, i) => (
        <DimLine key={`rotl${i}`} start={l.start} end={l.end} color={TANGENT_COLOR} />
      ))}
    </>
  );
}

// ─── Terminal Plate (inside left wall behind cutout, matching desktop AddTerminalPlate) ──

interface TerminalPlateProps {
  sideDepth: number; intH: number; tBaffle: number; t: number;
  texture?: THREE.Texture | MaterialTexturePack | null; useTexture?: boolean;
  /** Horizontal shift in scene units. 0 = centered on panel depth. */
  xOffsetSc?: number;
  /** True when the cup is drawn 90° CW on the panel (SUPP). */
  rotated?: boolean;
  /** Plate body color. Defaults to the Birch tan TP_COLOR. Pass COLORS.mdf
   *  on MDF designs so the recessed plate matches the surrounding panel. */
  color?: string;
}

function TerminalPlate({ sideDepth, intH, tBaffle, t, texture, useTexture: applyTexture, xOffsetSc = 0, rotated = false, color = TP_COLOR }: TerminalPlateProps) {
  // Swap plate dimensions when the cup is rotated 90° CW. Plate's "width"
  // (Z direction in plate-local) becomes "height" and vice versa.
  const tpW = (rotated ? TP_HEIGHT : TP_WIDTH) * S;
  const tpH = (rotated ? TP_WIDTH : TP_HEIGHT) * S;
  const tpT = TP_THICKNESS * S;
  const tpCR = TP_CORNER_R * S;
  const holeR = TP_HOLE_R * S;
  // Use the original constants for hole offsets — we apply the actual rotation
  // to the hole POSITIONS below (not just swap constants).
  const holeOffY = TP_HOLE_OFF_Y * S;
  const holeOffZ = TP_HOLE_OFF_Z * S;

  // Build rounded rectangle plate with binding post holes (matches desktop TerminalPlateCornerR=0.375")
  const plateGeo = useMemo(() => {
    const hw = tpW / 2;
    const hh = tpH / 2;
    const cr = tpCR;

    // Rounded rectangle shape (Z=width, Y=height in local coords)
    const shape = new THREE.Shape();
    shape.moveTo(-hw + cr, -hh);
    shape.lineTo(hw - cr, -hh);
    shape.quadraticCurveTo(hw, -hh, hw, -hh + cr);
    shape.lineTo(hw, hh - cr);
    shape.quadraticCurveTo(hw, hh, hw - cr, hh);
    shape.lineTo(-hw + cr, hh);
    shape.quadraticCurveTo(-hw, hh, -hw, hh - cr);
    shape.lineTo(-hw, -hh + cr);
    shape.quadraticCurveTo(-hw, -hh, -hw + cr, -hh);

    // Binding post holes (circles cut through plate).
    // Unrotated: holes side-by-side (Z=±holeOffZ) above center (Y=+holeOffY).
    // Rotated 90° CW: holes vertically stacked. Strict rigid-body rotation of
    // the original (Z, Y) positions gives both holes at Z=+holeOffY (right
    // of center) at Y=±holeOffZ (above and below center).
    const hole1 = new THREE.Path();
    const hole2 = new THREE.Path();
    if (rotated) {
      hole1.absarc(holeOffY, +holeOffZ, holeR, 0, Math.PI * 2, false);
      hole2.absarc(holeOffY, -holeOffZ, holeR, 0, Math.PI * 2, false);
    } else {
      hole1.absarc(-holeOffZ, holeOffY, holeR, 0, Math.PI * 2, false);
      hole2.absarc(+holeOffZ, holeOffY, holeR, 0, Math.PI * 2, false);
    }
    shape.holes.push(hole1);
    shape.holes.push(hole2);

    const geo = new THREE.ExtrudeGeometry(shape, { depth: tpT, bevelEnabled: false, curveSegments: 16 });
    // Rotate so extrusion (local Z) becomes world X (panel thickness direction)
    geo.rotateY(Math.PI / 2);
    return geo;
  }, [tpW, tpH, tpT, tpCR, holeR, holeOffY, holeOffZ, rotated]);

  // Position: inside left wall, centered on cutout. xOffsetSc shifts the
  // plate's Z position to match the cutout that SideLeftTerminalPreview moved.
  // When the cup is rotated (SUPP), cup center Y = intH/2 (panel height
  // center) so the cup is centered on the panel-local Y axis.
  const tcCenterFromBottom = rotated
    ? intH / S / 2  // intH/2 in inches
    : TC_FROM_BOTTOM;
  const py = t + tcCenterFromBottom * S;
  const pz = tBaffle + sideDepth / 2 + xOffsetSc;

  return (
    <group position={[t, py, pz]}>
      <mesh geometry={plateGeo}>
        <meshStandardMaterial
          color={applyTexture && texture ? '#ffffff' : color}
          map={applyTexture ? albedoOf(texture) : undefined}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

// ─── No-Go Band Overlay (V2 — visualizes PP1/PP2/port bands on chosen panel) ──
//
// Renders translucent red rectangles on the inside face of the chosen
// terminal panel showing exactly where the cutout cannot go. Only visible
// when the operator has opted into customization (either inputs.terminal*
// field set), so the default experience is unchanged. Used together with
// the form's inline error to give a visual "why" for the conflict.

interface NoGoBandOverlayProps {
  panel: 'Side Left' | 'Back';
  bands: Array<{ xMin: number; xMax: number; reason: string; label: string }>;
  /** Box geometry in scene units. */
  boxW: number; boxD: number; intH: number;
  t: number; tBack: number; tBaffle: number;
  /** Conversion from inches → scene units. */
  scale: number;
}

function NoGoBandOverlay({ panel, bands, boxW, boxD, intH, t, tBack, tBaffle, scale }: NoGoBandOverlayProps) {
  if (bands.length === 0) return null;

  const sideDepth = boxD - tBack - tBaffle;

  // Each band is rendered as a translucent rectangle:
  //   Side Left → on the inside face (X = t + epsilon), spanning Z = band X range
  //   Back      → on the inside face (Z = boxD - tBack - epsilon), spanning X range
  // Y always covers the full interior height. Rectangles are double-sided so
  // they're visible from both inside and X-Ray exterior.
  const eps = 0.005;
  const rects = bands.flatMap((band, i) => {
    if (band.xMin === -Infinity || band.xMax === Infinity) return [];

    if (panel === 'Side Left') {
      // Panel-X = box-Z (front-to-back, panel coord 0 = box Z 0).
      const zMin = band.xMin * scale;
      const zMax = band.xMax * scale;
      const zCenter = (zMin + zMax) / 2;
      const zSpan = Math.max(eps, zMax - zMin);
      return [{
        key: `nogoL${i}`,
        position: [t + eps, t + intH / 2, zCenter] as [number, number, number],
        size: [intH, zSpan] as [number, number],
        // Plane local axes: X-axis along Y (height), Y-axis along Z (depth).
        rotation: [0, Math.PI / 2, 0] as [number, number, number],
      }];
    }
    // Back panel — Panel-X = box-X (left-to-right). Wall offset = side-panel
    // thickness `t` from the box-left, so band coords are in baffleW frame
    // (origin at left side panel's interior face).
    const xMinAbs = t + band.xMin * scale;
    const xMaxAbs = t + band.xMax * scale;
    const xCenter = (xMinAbs + xMaxAbs) / 2;
    const xSpan = Math.max(eps, xMaxAbs - xMinAbs);
    return [{
      key: `nogoB${i}`,
      position: [xCenter, t + intH / 2, boxD - tBack - eps] as [number, number, number],
      size: [xSpan, intH] as [number, number],
      rotation: [0, 0, 0] as [number, number, number],
    }];
  });

  void sideDepth; void boxW;
  return (
    <group>
      {rects.map(r => (
        <mesh key={r.key} position={r.position} rotation={r.rotation}>
          <planeGeometry args={[r.size[0], r.size[1]]} />
          <meshBasicMaterial color="#E74C3C" transparent opacity={0.32} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}

// ─── Panel with rectangular hole (V2 — used for the acrylic window cutout) ──
//
// Generic "rectangular slab with a rounded-rectangle hole" panel. Built from
// THREE.Shape + ExtrudeGeometry so the hole is a real geometry hole — light
// passes through, the plate behind it is visible. Replaces the host panel's
// normal render when an acrylic window is enabled.

interface PanelWithRectHoleProps {
  /** Panel local-X extent (inches, scaled). */
  panelW: number;
  /** Panel local-Y extent (inches, scaled). */
  panelH: number;
  /** Panel thickness, extruded along local +Z (inches, scaled). */
  panelT: number;
  /** Cutout center in panel-local XY (inches, scaled). */
  cutoutCx: number;
  cutoutCy: number;
  /** Cutout width × height (inches, scaled). */
  cutoutW: number;
  cutoutH: number;
  /** Cutout corner radius (inches, scaled). 0 = sharp corners. */
  cutoutCornerRadius?: number;
  /** Outer perimeter corner radius (inches, scaled) — for the box's
   *  roundover. 0 = sharp box corners. When non-zero, all 4 outer corners
   *  of the panel arc with this radius so the corner roundover
   *  quarter-cylinders sit flush against the panel edge. */
  outerCornerRadius?: number;
  /** Group position in world coords. */
  position: [number, number, number];
  /** Group rotation (Euler). Default identity. */
  rotation?: [number, number, number];
  /** Surface color (used as tint when texture map present). */
  color: string;
  /** 0 = invisible / X-Ray, 1 = solid. */
  opacity: number;
  texture?: THREE.Texture | MaterialTexturePack | null;
  useTexture?: boolean;
  showEdges?: boolean;
}

function PanelWithRectHole({
  panelW, panelH, panelT,
  cutoutCx, cutoutCy, cutoutW, cutoutH, cutoutCornerRadius = 0,
  outerCornerRadius = 0,
  position, rotation = [0, 0, 0],
  color, opacity, texture, useTexture: applyTexture, showEdges = true,
}: PanelWithRectHoleProps) {
  const geo = useMemo(() => {
    const shape = new THREE.Shape();
    const oR = Math.max(0, Math.min(outerCornerRadius, Math.min(panelW, panelH) / 2 - 0.001));
    if (oR > 0.001) {
      // Outer shape with rounded corners — matches the box roundover so
      // the quarter-cylinder corner pieces from RoundoverCutPanel meet
      // this panel's edge cleanly.
      shape.moveTo(oR, 0);
      shape.lineTo(panelW - oR, 0);
      shape.absarc(panelW - oR, oR, oR, -Math.PI / 2, 0, false);
      shape.lineTo(panelW, panelH - oR);
      shape.absarc(panelW - oR, panelH - oR, oR, 0, Math.PI / 2, false);
      shape.lineTo(oR, panelH);
      shape.absarc(oR, panelH - oR, oR, Math.PI / 2, Math.PI, false);
      shape.lineTo(0, oR);
      shape.absarc(oR, oR, oR, Math.PI, 3 * Math.PI / 2, false);
      shape.closePath();
    } else {
      shape.moveTo(0, 0);
      shape.lineTo(panelW, 0);
      shape.lineTo(panelW, panelH);
      shape.lineTo(0, panelH);
      shape.closePath();
    }

    const hole = new THREE.Path();
    const x = cutoutCx - cutoutW / 2;
    const y = cutoutCy - cutoutH / 2;
    const r = Math.max(0, Math.min(cutoutCornerRadius, Math.min(cutoutW, cutoutH) / 2 - 0.001));
    if (r > 0.001) {
      hole.moveTo(x + r, y);
      hole.lineTo(x + cutoutW - r, y);
      hole.absarc(x + cutoutW - r, y + r, r, -Math.PI / 2, 0, false);
      hole.lineTo(x + cutoutW, y + cutoutH - r);
      hole.absarc(x + cutoutW - r, y + cutoutH - r, r, 0, Math.PI / 2, false);
      hole.lineTo(x + r, y + cutoutH);
      hole.absarc(x + r, y + cutoutH - r, r, Math.PI / 2, Math.PI, false);
      hole.lineTo(x, y + r);
      hole.absarc(x + r, y + r, r, Math.PI, 3 * Math.PI / 2, false);
      hole.closePath();
    } else {
      hole.moveTo(x, y);
      hole.lineTo(x + cutoutW, y);
      hole.lineTo(x + cutoutW, y + cutoutH);
      hole.lineTo(x, y + cutoutH);
      hole.closePath();
    }
    shape.holes.push(hole);

    return new THREE.ExtrudeGeometry(shape, { depth: panelT, bevelEnabled: false });
  }, [panelW, panelH, panelT, cutoutCx, cutoutCy, cutoutW, cutoutH, cutoutCornerRadius, outerCornerRadius]);

  // Memoize edges so we don't allocate a new EdgesGeometry on every camera
  // orbit. Tied to `geo` identity, which itself is memoized on its inputs.
  const edgesGeo = useMemo(() => new THREE.EdgesGeometry(geo), [geo]);

  const matColor = applyTexture && texture ? '#ffffff' : color;

  if (opacity === 0) {
    // X-Ray: render as wireframe box (matches existing panel components).
    return (
      <group position={position} rotation={rotation}>
        <lineSegments geometry={edgesGeo}>
          <lineBasicMaterial color={COLORS.edge} />
        </lineSegments>
      </group>
    );
  }

  return (
    <group position={position} rotation={rotation}>
      <mesh geometry={geo}>
        <meshStandardMaterial
          color={matColor}
          map={applyTexture ? albedoOf(texture) : undefined}
          transparent={opacity < 1}
          opacity={opacity}
          side={THREE.DoubleSide}
        />
      </mesh>
      {showEdges && (
        <lineSegments geometry={edgesGeo}>
          <lineBasicMaterial color={COLORS.edge} />
        </lineSegments>
      )}
    </group>
  );
}

// ─── Acrylic Window plate (V1 — surface plate, no hole-punch) ──────────────
//
// V1 renders the acrylic plate as a transmissive rectangle sitting on the
// host panel's outer face. Does NOT punch a hole through the underlying
// wood panel — that's a V2 polish item that requires re-doing the host
// panel's geometry as ExtrudeGeometry-with-hole. With X-Ray mode the wood
// goes translucent so the plate + internals all read; with X-Ray off the
// plate just looks like a glass rectangle on the wood.
//
// Position is keyed to the resolved host panel (SBPB → Top, SUPB → Baffle,
// SUPU → Bottom). World transform handled by the caller; this component
// just renders the plate geometry + transmissive material at the position
// it's given.

interface AcrylicWindowMeshProps {
  /** World position of the plate's geometric center. */
  position: [number, number, number];
  /** Euler rotation (radians) so the plate's local Z faces outward from
   *  the box. Top → [Math.PI/2, 0, 0] (face up), Baffle → [0, 0, 0]
   *  (face forward, +Z is already outward), Bottom → [-Math.PI/2, 0, 0]. */
  rotation: [number, number, number];
  /** Plate width in scene units (= cutout width × scale). */
  width: number;
  /** Plate height in scene units (= cutout height × scale). */
  height: number;
  /** Plate thickness in scene units. Matches the chosen acrylic gauge. */
  thickness: number;
}

function AcrylicWindowMesh({ position, rotation, width, height, thickness }: AcrylicWindowMeshProps) {
  // V2 perf: transmission was costing a full backbuffer scene render every
  // frame (every other mesh in the scene drawn twice when transmission is
  // active). Now that we punch a real hole through the wood the plate's
  // see-through is no longer doing anything — internals are visible
  // through the hole regardless. Switch to a cheap MeshStandardMaterial
  // with low opacity for the "glass-tinted plate" look. The redundant
  // BackSide-frame edge mesh is gone too — clearcoat-ish gloss + the
  // plate sitting in a real hole reads clearly enough on its own.
  return (
    <group position={position} rotation={rotation}>
      <mesh>
        <boxGeometry args={[width, height, thickness]} />
        <meshStandardMaterial
          color="#d8edf2"
          transparent
          opacity={0.35}
          roughness={0.1}
          metalness={0.05}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

// ─── Terminal Plate behind Back Panel (V1) ──
//
// Same rounded-rectangle plate as TerminalPlate, but oriented for the back
// wall: the plate sits flush against the inside face of the back panel,
// facing forward (toward −Z in box coordinates).

/** Plate body color. Pass COLORS.mdf on MDF designs so the recessed plate
 *  matches the surrounding panel. Defaults to the Birch tan TP_COLOR. */
interface BackTerminalPlateProps {
  boxW: number; intH: number; tBack: number; boxD: number; t: number;
  texture?: THREE.Texture | MaterialTexturePack | null; useTexture?: boolean;
  /** Horizontal shift in scene units; matches the cutout's offset. */
  xOffsetSc?: number;
  /** Explicit local center height for the rotated Top host, in scene units. */
  centerHeightSc?: number;
  color?: string;
}

function BackTerminalPlate({ boxW, intH, tBack, boxD, t, texture, useTexture: applyTexture, xOffsetSc = 0, centerHeightSc, color = TP_COLOR }: BackTerminalPlateProps) {
  const tpW = TP_WIDTH * S;
  const tpH = TP_HEIGHT * S;
  const tpT = TP_THICKNESS * S;
  const tpCR = TP_CORNER_R * S;
  const holeR = TP_HOLE_R * S;
  const holeOffY = TP_HOLE_OFF_Y * S;
  const holeOffX = TP_HOLE_OFF_Z * S;  // reused as horizontal offset on Back

  const plateGeo = useMemo(() => {
    const hw = tpW / 2;
    const hh = tpH / 2;
    const cr = tpCR;

    // Local coords: X = horizontal (boxW direction), Y = vertical, Z = extrusion (depth).
    const shape = new THREE.Shape();
    shape.moveTo(-hw + cr, -hh);
    shape.lineTo(hw - cr, -hh);
    shape.quadraticCurveTo(hw, -hh, hw, -hh + cr);
    shape.lineTo(hw, hh - cr);
    shape.quadraticCurveTo(hw, hh, hw - cr, hh);
    shape.lineTo(-hw + cr, hh);
    shape.quadraticCurveTo(-hw, hh, -hw, hh - cr);
    shape.lineTo(-hw, -hh + cr);
    shape.quadraticCurveTo(-hw, -hh, -hw + cr, -hh);

    const hole1 = new THREE.Path();
    hole1.absarc(-holeOffX, holeOffY, holeR, 0, Math.PI * 2, false);
    shape.holes.push(hole1);

    const hole2 = new THREE.Path();
    hole2.absarc(holeOffX, holeOffY, holeR, 0, Math.PI * 2, false);
    shape.holes.push(hole2);

    // Extrude toward −Z (into the chamber from the back wall).
    return new THREE.ExtrudeGeometry(shape, { depth: tpT, bevelEnabled: false, curveSegments: 16 });
  }, [tpW, tpH, tpT, tpCR, holeR, holeOffY, holeOffX]);

  // Position: centered on cutout (X = boxW/2 + offset), Y = TC_FROM_BOTTOM
  // up from the inside floor (= t + TC_FROM_BOTTOM*S), Z = inside face of
  // back panel = boxD - tBack. Plate extrudes toward −Z so it ends at
  // (boxD - tBack - tpT) at the inner face — same flush mounting feel as
  // the Side Left plate.
  const px = boxW / 2 + xOffsetSc;
  const py = centerHeightSc ?? t + TC_FROM_BOTTOM * S;
  const pz = boxD - tBack - tpT;

  return (
    <group position={[px, py, pz]}>
      <mesh geometry={plateGeo}>
        <meshStandardMaterial
          color={applyTexture && texture ? '#ffffff' : color}
          map={applyTexture ? albedoOf(texture) : undefined}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

// ─── Wood Grain Texture Loader ──────────────────────────────────────────────

/** A PBR texture set — what a meshStandardMaterial needs for photoreal rendering. */
export interface MaterialTexturePack {
  albedo: THREE.Texture;
  normal: THREE.Texture;
  roughness: THREE.Texture;
}

/** Both grain orientations of one material. Horizontal grain wraps top/bottom/baffle;
 *  vertical wraps sides/back. */
export interface MaterialOrientations {
  horizontal: MaterialTexturePack;
  vertical: MaterialTexturePack;
}

export interface WoodTextureSet {
  birch: MaterialOrientations;
  /** Gray-stained Birch — shares the natural Birch normal + roughness maps
   *  (the surface geometry is identical; only the albedo color changes). */
  birchStained: MaterialOrientations;
  mdf: MaterialOrientations;
  /** Ply-edge stripe textures — used on the narrow edges of Birch panels so
   *  they read as laminated plywood (alternating cream / dark glue layers)
   *  instead of solid wood. Indexed by thickness (mm). Stained variants
   *  are used when the viewer's Stained toggle is on. */
  birchPlyEdge18: THREE.Texture;
  birchPlyEdge24: THREE.Texture;
  birchPlyEdge18Stained: THREE.Texture;
  birchPlyEdge24Stained: THREE.Texture;
  /** Legacy single-texture access for any code path that hasn't been upgraded
   *  to use the full PBR set yet. Points at the Birch albedo. */
  horizontal: THREE.Texture;
  vertical: THREE.Texture;
}

/**
 * Texture failures must degrade the viewer's appearance, never its geometry.
 * The default THREE.TextureLoader rejects the whole useLoader batch when one
 * URL is missing, which previously replaced the entire preview with the error
 * boundary. Resolve a material-appropriate 1px texture instead so the box,
 * cutouts, ports, and dimensions remain usable while the missing asset is
 * recorded in the debug log.
 */
type WoodTextureLoaderOnLoad = NonNullable<Parameters<THREE.TextureLoader['load']>[1]>;
type WoodTextureLoaderTexture = Parameters<WoodTextureLoaderOnLoad>[0];

class ResilientWoodTextureLoader extends THREE.TextureLoader {
  // Declaring the field from TextureLoader's own signature keeps this package
  // compatible with both the engine's older non-generic Three.js types and
  // the web app's newer Texture<HTMLImageElement> declaration.
  load: THREE.TextureLoader['load'] = (url, onLoad, onProgress, _onError) => {
    return super.load(url, onLoad, onProgress, error => {
      const pixel = fallbackTexturePixel(url);
      const fallback = new THREE.DataTexture(
        new Uint8Array([pixel[0], pixel[1], pixel[2], 255]),
        1,
        1,
        THREE.RGBAFormat,
      );
      fallback.name = `Fallback for ${url}`;
      fallback.needsUpdate = true;
      appendDebug('viewer', 'warn', `Wood texture unavailable; using a solid fallback: ${url}`, error);
      onLoad?.(fallback as unknown as WoodTextureLoaderTexture);
    });
  };
}

function fallbackTexturePixel(url: string): [number, number, number] {
  if (url.includes('_normal.')) return [128, 128, 255];
  if (url.includes('_roughness.')) return [210, 210, 210];
  if (url.includes('_stained.')) return [92, 94, 92];
  if (url.includes('/mdf_')) return [182, 174, 158];
  return [220, 202, 164];
}

function useWoodTextures(): WoodTextureSet {
  // useLoader suspends (via React Suspense) until all textures are fully
  // loaded. This prevents the flash-to-black caused by shader recompilation
  // when switching from color-only to textured material mid-render.
  //
  // 6 maps loaded in parallel: albedo + normal + roughness × birch + mdf.
  // Total weight ~1.7 MB after JPEG/PNG compression — one-time on tab load.
  const [
    birchAlbedoBase,
    birchNormalBase,
    birchRoughnessBase,
    birchAlbedoStainedBase,
    mdfAlbedoBase,
    mdfNormalBase,
    mdfRoughnessBase,
    birchPlyEdge18Base,
    birchPlyEdge24Base,
    birchPlyEdge18StainedBase,
    birchPlyEdge24StainedBase,
  ] = useLoader(ResilientWoodTextureLoader, [
    '/textures/wood/birch_albedo.jpg',
    '/textures/wood/birch_normal.jpg',
    '/textures/wood/birch_roughness.jpg',
    '/textures/wood/birch_albedo_stained.jpg',
    '/textures/wood/mdf_albedo.jpg',
    '/textures/wood/mdf_normal.jpg',
    '/textures/wood/mdf_roughness.jpg',
    '/textures/wood/birch_ply_edge_18mm.jpg',
    '/textures/wood/birch_ply_edge_24mm.jpg',
    '/textures/wood/birch_ply_edge_18mm_stained.jpg',
    '/textures/wood/birch_ply_edge_24mm_stained.jpg',
  ]);

  return useMemo(() => {
    // Helper — set repeat-wrap + colorspace + repeat factor on a freshly-loaded
    // texture. Albedo is sRGB (gamma-corrected for display); normal/roughness
    // are linear (raw data, not color). Three.js handles the conversion.
    const setup = (tex: THREE.Texture, isColor: boolean): THREE.Texture => {
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(1, 1);
      tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      return tex;
    };

    // Vertical grain variant — same texture rotated 90°. clone() shares the
    // underlying image bytes so memory cost is small (just a new wrapper).
    const rotate90 = (tex: THREE.Texture, isColor: boolean): THREE.Texture => {
      const v = tex.clone();
      v.wrapS = THREE.RepeatWrapping;
      v.wrapT = THREE.RepeatWrapping;
      v.repeat.set(1, 1);
      v.rotation = Math.PI / 2;
      v.center.set(0.5, 0.5);
      v.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      v.needsUpdate = true;
      return v;
    };

    const birchH: MaterialTexturePack = {
      albedo:    setup(birchAlbedoBase, true),
      normal:    setup(birchNormalBase, false),
      roughness: setup(birchRoughnessBase, false),
    };
    const birchV: MaterialTexturePack = {
      albedo:    rotate90(birchAlbedoBase, true),
      normal:    rotate90(birchNormalBase, false),
      roughness: rotate90(birchRoughnessBase, false),
    };
    const mdfH: MaterialTexturePack = {
      albedo:    setup(mdfAlbedoBase, true),
      normal:    setup(mdfNormalBase, false),
      roughness: setup(mdfRoughnessBase, false),
    };
    const mdfV: MaterialTexturePack = {
      albedo:    rotate90(mdfAlbedoBase, true),
      normal:    rotate90(mdfNormalBase, false),
      roughness: rotate90(mdfRoughnessBase, false),
    };

    // Gray-stained Birch — same physical surface as natural Birch, just a
    // darker / desaturated / cool-tinted albedo. Reuses the natural normal +
    // roughness textures so memory cost is just one extra albedo (~574 KB).
    const birchStainedH: MaterialTexturePack = {
      albedo:    setup(birchAlbedoStainedBase, true),
      normal:    birchH.normal,
      roughness: birchH.roughness,
    };
    const birchStainedV: MaterialTexturePack = {
      albedo:    rotate90(birchAlbedoStainedBase, true),
      normal:    birchV.normal,
      roughness: birchV.roughness,
    };

    // Ply-edge stripe textures — used on narrow edges of Birch panels. sRGB
    // color space (these are color textures, not data). Wrap repeats so a
    // single texture tiles cleanly across long edges. Stained variants
    // match the same desaturation/darkening that the main birch albedo
    // gets in stained mode, so panel edges match panel faces.
    const plyEdge18 = setup(birchPlyEdge18Base, true);
    const plyEdge24 = setup(birchPlyEdge24Base, true);
    const plyEdge18Stained = setup(birchPlyEdge18StainedBase, true);
    const plyEdge24Stained = setup(birchPlyEdge24StainedBase, true);

    return {
      birch:        { horizontal: birchH,        vertical: birchV },
      birchStained: { horizontal: birchStainedH, vertical: birchStainedV },
      mdf:          { horizontal: mdfH,          vertical: mdfV },
      birchPlyEdge18: plyEdge18,
      birchPlyEdge24: plyEdge24,
      birchPlyEdge18Stained: plyEdge18Stained,
      birchPlyEdge24Stained: plyEdge24Stained,
      // Legacy single-texture access — Birch albedo only. Kept so any code path
      // that hasn't been upgraded to MaterialTexturePack still has a working
      // texture (will just lack normal/roughness response).
      horizontal: birchH.albedo,
      vertical: birchV.albedo,
    };
  }, [birchAlbedoBase, birchNormalBase, birchRoughnessBase, birchAlbedoStainedBase, mdfAlbedoBase, mdfNormalBase, mdfRoughnessBase, birchPlyEdge18Base, birchPlyEdge24Base, birchPlyEdge18StainedBase, birchPlyEdge24StainedBase]);
}

// ─── Roundover-Cut Panel (matches desktop AddPanelWithRoundoverCut) ──────────

interface RoundoverCutPanelProps {
  W: number; D: number; t: number; R: number; isTop: boolean;
  position: [number, number, number];
  color: string;
  opacity?: number;
  texture?: THREE.Texture | MaterialTexturePack | null;
  useTexture?: boolean;
  layerDebugMode?: PanelLayerDebugMode;
  innerFrontClip?: RoundoverCutPanelFrontClip | null;
  innerVisibleRects?: RoundoverCutPanelRect[] | null;
  showInnerFace?: boolean;
}

function RoundoverCutPanel({
  W, D, t, R, isTop, position, color, opacity = 1, texture, useTexture: applyTexture,
  layerDebugMode = 'off', innerFrontClip = null, innerVisibleRects = null, showInnerFace = true,
}: RoundoverCutPanelProps) {
  const visibility = useMemo<RoundoverCutPanelVisibility>(() => {
    const panelPrefix = isTop ? 'hideTop' : 'hideBottom';
    return {
      inner: showInnerFace && layerDebugMode !== `${panelPrefix}Inner`,
      outer: layerDebugMode !== `${panelPrefix}Outer`,
      front: layerDebugMode !== `${panelPrefix}Front`,
      back: layerDebugMode !== `${panelPrefix}Back`,
      left: layerDebugMode !== `${panelPrefix}Left`,
      right: layerDebugMode !== `${panelPrefix}Right`,
    };
  }, [isTop, layerDebugMode, showInnerFace]);
  const geo = useMemo(
    () => createRoundoverCutPanel(W, D, t, R, isTop, visibility, innerFrontClip, innerVisibleRects),
    [W, D, t, R, isTop, visibility, innerFrontClip, innerVisibleRects]
  );
  const matColor = applyTexture && texture ? '#ffffff' : color;
  const matMap = applyTexture ? albedoOf(texture) : undefined;
  const isXRay = opacity === 0;
  return (
    <group position={position}>
      {!isXRay && (
        <mesh>
          <primitive object={geo} attach="geometry" />
          <meshStandardMaterial color={matColor} map={matMap} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}

// ─── Trimmed Vertical Panel (matches desktop AddVerticalTrimmedPanel) ──────────
// Used for Right Side, Back, and Baffle panels when roundovers are active.
// Quarter-circle notches are cut at corners where roundover geometry sits.

interface TrimmedVerticalPanelProps {
  /** Panel width (X span, already scaled) */
  W: number;
  /** Panel height (Y span, already scaled) */
  H: number;
  /** Panel depth/thickness (Z span, already scaled) */
  D: number;
  /** Roundover radius (already scaled) */
  R: number;
  /** Which corners to trim: [front-left, front-right, back-right, back-left] */
  trimCorners: [boolean, boolean, boolean, boolean];
  /** Position of the panel's origin corner (not center) */
  position: [number, number, number];
  color: string;
  opacity?: number;
  texture?: THREE.Texture | MaterialTexturePack | null;
  useTexture?: boolean;
}

function TrimmedVerticalPanel({
  W, H, D, R, trimCorners, position, color, opacity = 1, texture, useTexture: applyTexture,
}: TrimmedVerticalPanelProps) {
  const geo = useMemo(
    () => createTrimmedVerticalPanel(W, H, D, R, trimCorners),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [W, H, D, R, trimCorners[0], trimCorners[1], trimCorners[2], trimCorners[3]]
  );
  const matColor = applyTexture && texture ? '#ffffff' : color;
  const matMap = applyTexture ? albedoOf(texture) : undefined;
  const isXRay = opacity === 0;
  return (
    <group position={position}>
      {!isXRay && (
        <mesh>
          <primitive object={geo} attach="geometry" />
          <meshStandardMaterial color={matColor} map={matMap} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}

// ─── Textured Panel Component ───────────────────────────────────────────────

interface TexturedPanelProps extends PanelProps {
  /** Either a single THREE.Texture (legacy — albedo only, no PBR maps) OR a
   *  MaterialTexturePack (albedo + normal + roughness). The pack form gives
   *  proper light response and surface detail; the single form is kept for
   *  backward-compat with code paths that haven't been upgraded yet. */
  texture?: THREE.Texture | MaterialTexturePack | null;
  useTexture?: boolean;
  /** Axis the panel is thin along ('x' | 'y' | 'z'). When provided together
   *  with `plyEdgeTexture`, the panel renders as Baltic Birch ply: face-grain
   *  on the 2 broad faces, ply-edge stripes (horizontal cream/dark bands) on
   *  the 4 narrow edges. */
  thicknessAxis?: 'x' | 'y' | 'z';
  /** Ply-edge stripe texture (sRGB) to apply to the 4 edge faces. Skipped
   *  when omitted — caller controls this so MDF panels (no plies) just pass
   *  undefined. */
  plyEdgeTexture?: THREE.Texture | null;
}

/** True when `t` is a MaterialTexturePack (vs a single THREE.Texture). */
function isTexturePack(t: THREE.Texture | MaterialTexturePack | null | undefined): t is MaterialTexturePack {
  return !!t && typeof t === 'object' && 'albedo' in t && 'normal' in t && 'roughness' in t;
}

/** Return the underlying albedo (color) THREE.Texture from either a pack or a
 *  legacy single texture. Returns undefined when input is null/undefined.
 *  Used by components that only render albedo (no normal/roughness response). */
function albedoOf(t: THREE.Texture | MaterialTexturePack | null | undefined): THREE.Texture | undefined {
  if (!t) return undefined;
  return isTexturePack(t) ? t.albedo : t;
}

function TexturedPanel({
  position, size, color, opacity = 1, showEdges = true,
  texture, useTexture: applyTexture,
  thicknessAxis, plyEdgeTexture,
}: TexturedPanelProps) {
  const geo = useMemo(() => new THREE.BoxGeometry(...size), [size]);
  const isXRay = opacity === 0;

  const diagPoints = useMemo(() => {
    if (!isXRay) return null;
    const [sx, sy, sz] = size;
    const hx = sx / 2, hy = sy / 2, hz = sz / 2;
    return {
      d1: [new THREE.Vector3(-hx, -hy, -hz), new THREE.Vector3(hx, hy, hz)],
      d2: [new THREE.Vector3(hx, -hy, -hz), new THREE.Vector3(-hx, hy, hz)],
    };
  }, [isXRay, size]);

  // Resolve color/map/normalMap/roughnessMap based on whether we have a full
  // PBR pack, a legacy single texture, or no texture at all.
  const pack = applyTexture && isTexturePack(texture) ? texture : null;
  const legacyTex = applyTexture && texture && !isTexturePack(texture) ? texture : null;
  const matColor = (pack || legacyTex) ? '#ffffff' : color;
  const matMap = pack?.albedo ?? legacyTex ?? undefined;
  const matNormal = pack?.normal ?? undefined;
  const matRoughness = pack?.roughness ?? undefined;

  // Build per-face material array when we have ply-edge data + a thickness
  // axis. Falls back to single-material rendering when not (MDF, legacy
  // callers, etc.). BoxGeometry face index order: +X, -X, +Y, -Y, +Z, -Z.
  // For each face the texture V axis maps to either +Y or +Z depending on
  // face — we rotate the ply-edge texture per face so its stripes always end
  // up aligned with the panel's thickness axis (showing layers stacked).
  const materials = useMemo(() => {
    if (!plyEdgeTexture || !thicknessAxis) return null;
    const broadFaceIndices: number[] =
      thicknessAxis === 'x' ? [0, 1]
      : thicknessAxis === 'y' ? [2, 3]
      : [4, 5];

    const mats: THREE.Material[] = [];
    for (let i = 0; i < 6; i++) {
      if (broadFaceIndices.includes(i)) {
        mats.push(new THREE.MeshStandardMaterial({
          color: matColor, map: matMap, normalMap: matNormal,
          normalScale: NORMAL_INTENSITY, roughnessMap: matRoughness,
          side: THREE.DoubleSide,
        }));
      } else {
        // Edge face. Determine if face's V-axis aligns with the panel's
        // thickness axis — if not, rotate the ply-edge texture 90° so stripes
        // always run perpendicular to thickness.
        //   Faces 2 (+Y), 3 (-Y) → V is Z axis
        //   All other faces → V is Y axis
        const faceVAxis = (i === 2 || i === 3) ? 'z' : 'y';
        const needsRotation = faceVAxis !== thicknessAxis;
        const edgeTex = plyEdgeTexture.clone();
        edgeTex.wrapS = THREE.RepeatWrapping;
        edgeTex.wrapT = THREE.RepeatWrapping;
        edgeTex.center.set(0.5, 0.5);
        if (needsRotation) edgeTex.rotation = Math.PI / 2;
        edgeTex.needsUpdate = true;
        mats.push(new THREE.MeshStandardMaterial({
          color: '#ffffff',
          map: edgeTex,
          side: THREE.DoubleSide,
          roughness: 0.85,
        }));
      }
    }
    return mats;
  }, [plyEdgeTexture, thicknessAxis, matColor, matMap, matNormal, matRoughness]);

  return (
    <group position={position}>
      {!isXRay && (
        materials ? (
          // Multi-material array — Three.js maps mats[i] to face group i.
          //
          // The `key` on each branch is load-bearing (2026-07-08 MDF white-panel
          // bug). Without keys, React reconciles the two <mesh> branches into
          // ONE instance when a design switch flips `materials` between the
          // array and null (Birch → MDF: plyEdgeTexture goes texture → undefined).
          // R3F's commitUpdate then sees the `material` prop REMOVED and resets
          // mesh.material to the constructor default — a shared plain-white
          // MeshBasicMaterial — AFTER the child <meshStandardMaterial> has
          // already attached (child placements commit before the parent's
          // update). Result: the panel renders stark white, ignoring the MDF
          // texture, until some later toggle remounts the mesh. Distinct keys
          // force a fresh mesh per branch, so the child material attaches to a
          // mesh that never had a `material` prop to un-set.
          <mesh key="face-mats" material={materials}>
            <boxGeometry args={size} />
          </mesh>
        ) : (
          <mesh key="single-mat">
            <boxGeometry args={size} />
            <meshStandardMaterial
              color={matColor}
              map={matMap}
              normalMap={matNormal}
              normalScale={NORMAL_INTENSITY}
              roughnessMap={matRoughness}
              side={THREE.DoubleSide}
            />
          </mesh>
        )
      )}
      {showEdges && (
        <lineSegments>
          <edgesGeometry args={[geo]} />
          <lineBasicMaterial color={COLORS.edge} opacity={isXRay ? 0.6 : 1} transparent={isXRay} />
        </lineSegments>
      )}
      {isXRay && diagPoints && (
        <>
          <XRayDiagLine points={diagPoints.d1 as [THREE.Vector3, THREE.Vector3]} />
          <XRayDiagLine points={diagPoints.d2 as [THREE.Vector3, THREE.Vector3]} />
        </>
      )}
    </group>
  );
}

// ─── Baffle Panel with Circular Cutout Holes ──────────────────────────────────
// Matches desktop AddBaffleMeshWithHoles: creates an ExtrudeGeometry from a
// THREE.Shape (rectangle) with circular Path holes cut through it.

interface BaffleCutoutsProps {
  baffleW: number; intH: number; tBaffle: number; t: number;
  holes: { cx: number; cy: number; r: number; outline?: ProfilePoint[] }[];
  color: string; opacity: number;
  texture?: THREE.Texture | MaterialTexturePack | null; useTexture?: boolean;
  isDualPort: boolean; boxW: number;
  trimLeft?: boolean;
  /** Round the right front corner too (a baffle that spans the whole box). */
  trimRight?: boolean;
  showEdges?: boolean;
  showHoleRings?: boolean;
  debugMode?: ViewerDebugMode;
}

function BaffleWithCutouts({
  baffleW, intH, tBaffle, t, holes, color, opacity,
  texture, useTexture: applyTexture, isDualPort, boxW, trimLeft = false, trimRight = false, showEdges = true,
  showHoleRings = true,
  debugMode = 'off',
}: BaffleCutoutsProps) {
  const isXRay = opacity === 0;
  const faceVisibility = useMemo<BaffleFaceVisibility>(() => ({
    caps: debugMode !== 'noBaffleCaps',
    left: debugMode !== 'noBaffleLeft',
    right: true,
    front: debugMode !== 'noBaffleFront',
    back: true,
    holeWalls: debugMode !== 'noBaffleHoleWalls',
  }), [debugMode]);

  const geo = useMemo(() => {
    const baffleStartX = isDualPort ? (boxW / 2 - baffleW / 2) : 0;
    const localHoles = holes.map((hole) => ({
      cx: hole.cx - baffleStartX,
      cy: hole.cy - t,
      r: hole.r,
      outline: hole.outline,
    }));
    return createBaffleWithCutoutGeometry(
      baffleW,
      intH,
      tBaffle,
      localHoles,
      trimLeft,
      ROUNDOVER_R * S,
      faceVisibility,
      trimRight,
    );
  }, [baffleW, intH, tBaffle, t, holes, isDualPort, boxW, trimLeft, trimRight, faceVisibility]);

  // Position: baffle left edge X, bottom panel top Y, front face Z=0
  const baffleStartX = isDualPort ? (boxW / 2 - baffleW / 2) : 0;
  const pos: [number, number, number] = [baffleStartX, t, 0];

  // Material — uses albedo + roughnessMap + a LOW-intensity normalMap.
  // Skipping normalMap entirely made the baffle render flatter and dimmer
  // than the BoxGeometry panels (no surface variation to catch lights).
  // Using it at full strength (NORMAL_INTENSITY=0.6) produced specular
  // blowout because ExtrudeGeometry has no auto-computed tangent vectors.
  // 0.15 intensity is the sweet spot — enough surface variation to match
  // the brightness of the BoxGeometry panels, low enough that tangent
  // artifacts stay subtle. envMapIntensity slightly above 1.0 nudges the
  // IBL contribution up too. Roughness floored at 1.0 keeps the surface
  // matte despite the bumps.
  const pack = applyTexture && isTexturePack(texture) ? texture : null;
  const matColor = applyTexture && texture ? '#ffffff' : color;
  const matMap = applyTexture ? albedoOf(texture) : undefined;
  const matNormal = pack?.normal ?? undefined;
  const matRoughness = pack?.roughness ?? undefined;
  const lowNormalScale = useMemo(() => new THREE.Vector2(0.15, 0.15), []);
  const boxEdgesGeo = useMemo(() => {
    const box = new THREE.BoxGeometry(baffleW, intH, tBaffle);
    return new THREE.EdgesGeometry(box);
  }, [baffleW, intH, tBaffle]);

  if (isXRay) {
    // X-ray mode: wireframe box + circle outlines (matches desktop)
    return (
      <group position={[baffleStartX + baffleW / 2, t + intH / 2, tBaffle / 2]}>
        <mesh>
          <boxGeometry args={[baffleW, intH, tBaffle]} />
          <meshBasicMaterial wireframe color="#000" />
        </mesh>
      </group>
    );
  }

  return (
    <group position={pos}>
      <mesh geometry={geo}>
        <meshStandardMaterial
          color={matColor}
          map={matMap}
          normalMap={matNormal}
          normalScale={lowNormalScale}
          roughnessMap={matRoughness}
          roughness={1.0}
          envMapIntensity={1.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      {showEdges && (
        <lineSegments geometry={boxEdgesGeo} position={[baffleW / 2, intH / 2, tBaffle / 2]}>
          <lineBasicMaterial color={COLORS.edge} />
        </lineSegments>
      )}
      {/* Circle outlines on front face (matching desktop PipeVisual3D circle outlines) */}
      {showHoleRings && debugMode !== 'noBaffleFront' && holes.map((hole, i) => hole.outline ? <CutoutContourLine key={`hole-ring-${i}`} points={hole.outline} position={[hole.cx-baffleStartX,hole.cy-t,-.001]}/> : (
        <mesh key={`hole-ring-${i}`}
          position={[hole.cx - baffleStartX, hole.cy - t, -0.001]}
          rotation={[0, 0, 0]}>
          <ringGeometry args={[hole.r - 0.003, hole.r + 0.003, 64]} />
          <meshBasicMaterial color="#000000" side={THREE.DoubleSide} />
        </mesh>
      ))}
    </group>
  );
}

// ─── Kerf Port (curve port): merged "Baffle + Port 1" bent piece ─────────────
// V1 first pass. The baffle + Port Piece 1 are built as ONE kerf-bent panel with
// a rounded slot-port mouth. The flat baffle leg is rendered separately
// (BaffleWithCutouts at width = legEndX = baffleRunIn, the exact span the subs
// sit on); THIS component renders the rounded corner + the PP1 leg as one solid,
// starting at legEndX so the leg always fully contains the sub cutouts.
//
// The bend fills the horizontal gap between the leg end (legEndX) and the PP1
// outer face (baffleW): span = baffleW − legEndX. Cross-section (world X–Z,
// uniform thickness tBent), outer convex radius Ro = span, inner radius
// Ri = span − tBent, arc center C = (legEndX, span):
//   • baffle OUTER face on Z=0, from X=legEndX out to the arc
//   • 90° convex (port-mouth) arc → (baffleW, span)
//   • PP1 OUTER (port-side) face on X=baffleW, running back to pp1BackZ
//   • PP1 INNER (chamber) face on X=baffleW−tBent, forward to the inner arc
//   • 90° concave inner arc → (legEndX, tBent)
//   • seam edge back down to the leg at X=legEndX
// Extruded along height (depth=intH). The group rotates the shape's extrude
// axis onto world +Y and maps shape (x,z) → world (X,Z):
//   rotateX(+90°): local (x,y,z) → (x,−z,y); with position y=t+intH this gives
//   worldX=x, worldZ=y(=panel Z), worldY=t+intH−z ∈ [t, t+intH].
function KerfBentPortPiece({
  legEndX, baffleW, pp1BackZ, tBent, t, intH,
  color, opacity, texture, useTexture: applyTexture,
}: {
  legEndX: number; baffleW: number; pp1BackZ: number; tBent: number;
  t: number; intH: number;
  color: string; opacity: number;
  texture?: THREE.Texture | MaterialTexturePack | null; useTexture?: boolean;
}) {
  const geo = useMemo(() => {
    const span = Math.max(0.01, baffleW - legEndX);  // horizontal bend gap = outer radius
    const Ro = span;
    const Ri = Math.max(0.001, span - tBent);        // inner (concave) radius
    const Cx = legEndX;                              // bend-arc center
    const Cz = span;
    const shape = new THREE.Shape();
    shape.moveTo(legEndX, 0);                              // baffle outer face @ leg end
    shape.absarc(Cx, Cz, Ro, -Math.PI / 2, 0, false);      // convex port-mouth arc → (baffleW, span)
    shape.lineTo(baffleW, pp1BackZ);                       // PP1 port-side (outer) face, going back
    shape.lineTo(baffleW - tBent, pp1BackZ);               // PP1 back edge
    shape.lineTo(baffleW - tBent, Cz);                     // PP1 chamber (inner) face, forward to arc
    shape.absarc(Cx, Cz, Ri, 0, -Math.PI / 2, true);       // concave inner arc → (legEndX, tBent)
    shape.closePath();                                     // seam down to (legEndX, 0)
    return new THREE.ExtrudeGeometry(shape, { depth: intH, bevelEnabled: false, curveSegments: 24 });
  }, [legEndX, baffleW, pp1BackZ, tBent, intH]);

  const lowNormalScale = useMemo(() => new THREE.Vector2(0.15, 0.15), []);
  const isXRay = opacity === 0;
  const pack = applyTexture && isTexturePack(texture) ? texture : null;
  const matColor = applyTexture && texture ? '#ffffff' : color;
  const matMap = applyTexture ? albedoOf(texture) : undefined;
  const matNormal = pack?.normal ?? undefined;
  const matRoughness = pack?.roughness ?? undefined;

  // X-Ray (exterior): the merged piece is treated like the baffle → hidden.
  if (isXRay) return null;
  return (
    <group position={[0, t + intH, 0]} rotation={[Math.PI / 2, 0, 0]}>
      <mesh geometry={geo}>
        <meshStandardMaterial
          color={matColor}
          map={matMap}
          normalMap={matNormal}
          normalScale={lowNormalScale}
          roughnessMap={matRoughness}
          roughness={1.0}
          envMapIntensity={1.6}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

// ─── Kerf Port: black paint coating on the curved port mouth ─────────────────
// Operators spray the port interior matte black. On a kerf design the left port
// wall is the rounded bend up front (a port-interior surface), so the flat paint
// strip can't follow it. This renders a thin double-sided black ribbon swept
// along the bend's convex outer arc (same center/radius as KerfBentPortPiece),
// nudged into the cavity by `offset` so it sits on the wood without z-fighting.
function KerfPortPaintCurve({ legEndX, span, yb, yt, offset, normalMap }: {
  legEndX: number; span: number; yb: number; yt: number; offset: number;
  normalMap?: THREE.Texture;
}) {
  const geo = useMemo(() => {
    const segs = 24;
    const baffleW = legEndX + span;
    const Rw = span + offset;       // vertical wall arc radius (nudged into the cavity)
    const Rf = span;                // floor/ceiling sliver arc edge (the wood arc)
    const Cx = legEndX, Cz = span;  // arc center — matches KerfBentPortPiece
    const positions: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];
    let vi = 0;
    const push = (x: number, y: number, z: number, u: number, v: number) => {
      positions.push(x, y, z); uvs.push(u, v); return vi++;
    };
    // Stitch two parallel vertex rows (one quad strip).
    const strip = (r0: number[], r1: number[]) => {
      for (let i = 0; i < segs; i++) {
        indices.push(r0[i], r0[i + 1], r1[i + 1], r0[i], r1[i + 1], r1[i]);
      }
    };
    const wallB: number[] = [], wallT: number[] = [];
    const flrA: number[] = [], flrS: number[] = [];
    const celA: number[] = [], celS: number[] = [];
    for (let i = 0; i <= segs; i++) {
      const u = i / segs;
      const th = -Math.PI / 2 + (Math.PI / 2) * u; // -90° (front) → 0° (port side)
      const cw = Math.cos(th), sw = Math.sin(th);
      const xw = Cx + Rw * cw, zw = Cz + Rw * sw;  // vertical wall (offset arc)
      const xf = Cx + Rf * cw, zf = Cz + Rf * sw;  // sliver arc edge (wood arc)
      wallB.push(push(xw, yb, zw, u, 0));
      wallT.push(push(xw, yt, zw, u, 1));
      // Floor + ceiling slivers: the tapering segment between the curved arc and
      // the straight port floor edge (X=baffleW) — fills the mouth corner that a
      // square box overshot. Lifted by `offset` to sit flush with the floor/top
      // paint without z-fighting.
      flrA.push(push(xf, yb + offset, zf, u, 0));
      flrS.push(push(baffleW, yb + offset, zf, u, 1));
      celA.push(push(xf, yt - offset, zf, u, 0));
      celS.push(push(baffleW, yt - offset, zf, u, 1));
    }
    strip(wallB, wallT);  // vertical convex mouth wall
    strip(flrA, flrS);    // mouth floor sliver
    strip(celA, celS);    // mouth ceiling sliver
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
  }, [legEndX, span, yb, yt, offset]);
  return (
    <mesh geometry={geo}>
      <meshStandardMaterial color="#1c1c1c" roughness={0.28} metalness={0}
        normalMap={normalMap} normalScale={[0.4, 0.4]} envMapIntensity={1.3} side={THREE.DoubleSide} />
    </mesh>
  );
}

// ─── Top Panel with Circular Cutout Holes (SUPB) ─────────────────────────────
// Matches desktop AddTopPanelWithHoles: horizontal panel with circular holes
// for subwoofer cutouts when subs face upward through the top panel.

interface TopPanelCutoutsProps {
  boxW: number; boxD: number; t: number;
  holes: { cx: number; cz: number; r: number; outline?: ProfilePoint[] }[];  // cx/cz in enclosure coords
  yBottom: number;  // Y of panel bottom face (boxH - t)
  color: string; opacity: number;
  texture?: THREE.Texture | MaterialTexturePack | null; useTexture?: boolean;
  showEdges?: boolean;
  showHoleRings?: boolean;
  /**
   * Roundover radius (already scaled by S). When > 0, the outer (top) face
   * is inset by R and the side walls are shortened by R at the outer edge,
   * leaving the L-shaped gap that the corner roundover quarter-cylinders /
   * octant spheres fill — same pattern as RoundoverCutPanel for the bottom.
   * Default 0 = no roundover (flush box geometry).
   */
  R?: number;
}

function TopPanelWithCutouts({
  boxW, boxD, t, holes, yBottom, color, opacity,
  texture, useTexture: applyTexture, showEdges = true, showHoleRings = true,
  R = 0,
}: TopPanelCutoutsProps) {
  const isXRay = opacity === 0;

  // Build geometry manually (same proven approach as BaffleWithCutouts)
  // Panel in XZ plane at Y=0..t (local coords), with holes through it.
  // When R>0, outer face is inset and side walls shortened to leave room for
  // roundover geometry — matches RoundoverCutPanel(isTop=true) layout but
  // with circular sub cutouts triangulated into the outer/inner faces.
  const geo = useMemo(() => {
    const positions: number[] = [];
    const uvs: number[] = [];
    const idxs: number[] = [];
    let vi = 0;

    function addQuad(
      a: [number,number,number], b: [number,number,number],
      c: [number,number,number], d: [number,number,number],
    ) {
      positions.push(...a, ...b, ...c, ...d);
      uvs.push(0,0, 1,0, 1,1, 0,1);
      idxs.push(vi, vi+1, vi+2, vi, vi+2, vi+3);
      vi += 4;
    }

    // XZ face with holes — caller supplies the rectangular contour bounds,
    // so the same builder serves the inset outer face and the full inner face.
    function addXZFaceWithHoles(
      y: number, reverseWinding: boolean,
      x0: number, x1: number, z0: number, z1: number,
    ) {
      let contour = [
        new THREE.Vector2(x0, z0),
        new THREE.Vector2(x1, z0),
        new THREE.Vector2(x1, z1),
        new THREE.Vector2(x0, z1),
      ];
      if (!THREE.ShapeUtils.isClockWise(contour)) contour = contour.reverse();

      const holes2D = holes.map(h => {
        const pts: THREE.Vector2[] = [];
        for (const p of holeOutline(h)) {
          pts.push(new THREE.Vector2(
            h.cx + p.x,
            h.cz + p.y,
          ));
        }
        if (THREE.ShapeUtils.isClockWise(pts)) pts.reverse();
        return pts;
      });

      const verts = contour.concat(...holes2D);
      const tris = THREE.ShapeUtils.triangulateShape(contour, holes2D);

      for (const tri of tris) {
        const order = reverseWinding ? [tri[0], tri[2], tri[1]] : tri;
        for (const idx of order) {
          const v = verts[idx];
          positions.push(v.x, y, v.y); // XZ plane at height y
          uvs.push(v.x / boxW, v.y / boxD);
          idxs.push(vi++);
        }
      }
    }

    // Outer (top) face at Y = t — inset by R when roundover active.
    addXZFaceWithHoles(t, false, R, boxW - R, R, boxD - R);
    // Inner (bottom) face at Y = 0 — full rectangle (matches today).
    addXZFaceWithHoles(0, true, 0, boxW, 0, boxD);

    // Side walls — shortened by R at the outer (top) edge and inset by R
    // along the transverse axis when R>0. Winding matches RoundoverCutPanel
    // (outward-facing normals); collapses to full-extent walls at R=0.
    const ySideTop = t - R;
    // Front (Z=0): X from R to W-R
    addQuad([boxW - R, 0, 0], [R, 0, 0], [R, ySideTop, 0], [boxW - R, ySideTop, 0]);
    // Back (Z=D): X from R to W-R
    addQuad([R, 0, boxD], [boxW - R, 0, boxD], [boxW - R, ySideTop, boxD], [R, ySideTop, boxD]);
    // Left (X=0): Z from R to D-R
    addQuad([0, 0, R], [0, 0, boxD - R], [0, ySideTop, boxD - R], [0, ySideTop, R]);
    // Right (X=W): Z from R to D-R
    addQuad([boxW, 0, boxD - R], [boxW, 0, R], [boxW, ySideTop, R], [boxW, ySideTop, boxD - R]);

    // Hole cylinder walls (connecting top and bottom faces)
    for (const h of holes) {
      const points=holeOutline(h);
      for (let i = 0; i < points.length; i++) {
        const a=points[i],b=points[(i+1)%points.length];
        const x0 = h.cx + a.x;
        const z0 = h.cz + a.y;
        const x1 = h.cx + b.x;
        const z1 = h.cz + b.y;
        // Quad from bottom to top (winding inward)
        addQuad([x0,0,z0], [x1,0,z1], [x1,t,z1], [x0,t,z0]);
      }
    }

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(idxs);
    g.computeVertexNormals();
    return g;
  }, [boxW, boxD, t, holes, R]);

  // Hoisted above the X-Ray early return so this hook runs on every render
  // path (matches the sibling BaffleWithCutouts). Leaving it below the early
  // return made the hook count differ when X-Ray toggled the top panel to
  // opacity 0, which throws React's "Rendered fewer hooks than during the
  // previous render" invariant and crashed the whole viewer.
  const lowNormalScale = useMemo(() => new THREE.Vector2(0.15, 0.15), []);

  if (isXRay) {
    return (
      <group position={[0, yBottom, 0]}>
        <mesh position={[boxW / 2, t / 2, boxD / 2]}>
          <boxGeometry args={[boxW, t, boxD]} />
          <meshBasicMaterial wireframe color="#000" />
        </mesh>
      </group>
    );
  }

  // Match the BoxGeometry panels' PBR brightness. Use low normalScale (0.15)
  // so tangent-less ExtrudeGeometry doesn't blow out highlights but still
  // gets enough surface variation to look as bright as the box panels.
  // envMapIntensity slightly boosted for IBL fill.
  const pack = applyTexture && isTexturePack(texture) ? texture : null;
  const matColor = applyTexture && texture ? '#ffffff' : color;
  const matMap = applyTexture ? albedoOf(texture) : undefined;
  const matNormal = pack?.normal ?? undefined;
  const matRoughness = pack?.roughness ?? undefined;

  return (
    <group position={[0, yBottom, 0]}>
      <mesh geometry={geo}>
        <meshStandardMaterial
          color={matColor}
          map={matMap}
          normalMap={matNormal}
          normalScale={lowNormalScale}
          roughnessMap={matRoughness}
          roughness={1.0}
          envMapIntensity={1.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      {showEdges && (
        <lineSegments position={[boxW / 2, t / 2, boxD / 2]}>
          <edgesGeometry args={[new THREE.BoxGeometry(boxW, t, boxD)]} />
          <lineBasicMaterial color={COLORS.edge} />
        </lineSegments>
      )}
      {showHoleRings && holes.map((hole, i) => hole.outline ? <CutoutContourLine key={`top-hole-ring-${i}`} points={hole.outline} position={[hole.cx,t+.001,hole.cz]} rotation={[Math.PI/2,0,0]}/> : (
        <group key={`top-hole-ring-${i}`}>
          {/* Circle outline on top face */}
          <mesh position={[hole.cx, t + 0.001, hole.cz]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[hole.r - 0.003, hole.r + 0.003, 64]} />
            <meshBasicMaterial color="#000000" side={THREE.DoubleSide} />
          </mesh>
          {/* Circle outline on bottom face */}
          <mesh position={[hole.cx, -0.001, hole.cz]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[hole.r - 0.003, hole.r + 0.003, 64]} />
            <meshBasicMaterial color="#000000" side={THREE.DoubleSide} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

// ─── Logo Debossing (matching desktop AddLogoDebossing) ───────────────────────
//
// Renders parsed EPS logo paths as thin black line segments on the appropriate
// panel surface:
//   SBPB: top panel at Y = boxH + 0.002 (web coords), area = (boxW - 2*border) x (boxD - 2*border)
//   SUPB: baffle front face at Z = -0.002 (web coords), area = (baffleW - 2*border) x (intH - 2*border)
//
// The epsContent prop should be the raw EPS file text. When not provided, the
// component renders nothing. The Build tab stores the selected logo in local
// state (not in the Zustand store), so the caller must pass epsContent down.
//
// TODO: Wire up logo data from Build tab. Options:
//   1. Add selectedLogo + logoEpsContent to the Zustand store so both tabs share it
//   2. Pass logo info via a shared context or global event
//   For now this component is structurally complete and renders correctly when
//   epsContent is provided — it just needs the data pipeline.

interface LogoDebossingProps {
  epsContent: string | null;
  boxW: number;       // scaled (already multiplied by S)
  boxH: number;       // scaled
  boxD: number;       // scaled
  baffleW: number;    // scaled
  intH: number;       // scaled
  tBaffle: number;    // scaled
  t: number;          // scaled (standard material thickness)
  isSubsUp: boolean;
  isSubsUpPortUp: boolean;
  isDualPort: boolean;
}

/**
 * Flatten EPS paths to 2D polyline point sequences, matching desktop's
 * ParseEpsLogoPolylines: bezier curves subdivided into 8 line segments,
 * bounding box rectangles filtered out.
 */
function flattenEpsPaths(paths: EpsPath[]): { x: number; y: number }[][] {
  const polylines: { x: number; y: number }[][] = [];

  for (const path of paths) {
    if (path.segments.length === 0) continue;
    const pts: { x: number; y: number }[] = [];

    for (const seg of path.segments) {
      if (pts.length === 0) {
        pts.push({ x: seg.start.x, y: seg.start.y });
      }

      if (seg.type === 'bezier') {
        // Flatten cubic bezier into 8 line segments (matching desktop steps=8)
        const steps = 8;
        for (let s = 1; s <= steps; s++) {
          const bt = s / steps;
          const u = 1 - bt;
          const x = u * u * u * seg.start.x
                  + 3 * u * u * bt * seg.control1.x
                  + 3 * u * bt * bt * seg.control2.x
                  + bt * bt * bt * seg.end.x;
          const y = u * u * u * seg.start.y
                  + 3 * u * u * bt * seg.control1.y
                  + 3 * u * bt * bt * seg.control2.y
                  + bt * bt * bt * seg.end.y;
          pts.push({ x, y });
        }
      } else {
        pts.push({ x: seg.end.x, y: seg.end.y });
      }
    }

    // Close path if needed
    if (path.isClosed && pts.length > 1) {
      pts.push(pts[0]);
    }

    if (pts.length >= 2) {
      polylines.push(pts);
    }
  }

  return polylines;
}

function LogoDebossing({
  epsContent, boxW, boxH, boxD, baffleW, intH, tBaffle, t, isSubsUp, isSubsUpPortUp, isDualPort,
}: LogoDebossingProps) {
  const geometry = useMemo(() => {
    if (!epsContent) return null;

    // Parse EPS paths
    const rawPaths = parseEpsPaths(epsContent);
    if (rawPaths.length === 0) return null;

    // Filter bounding box rectangles
    const bounds = calculatePathsBounds(rawPaths);
    const paths = bounds ? filterBoundingBoxPaths(rawPaths, bounds) : rawPaths;

    // Flatten to polylines (bezier -> line segments)
    const polylines = flattenEpsPaths(paths);
    if (polylines.length === 0) return null;

    // Calculate logo bounds (in EPS coordinates)
    let minX = Infinity, maxX = -Infinity;
    let minY = Infinity, maxY = -Infinity;
    for (const poly of polylines) {
      for (const pt of poly) {
        if (pt.x < minX) minX = pt.x;
        if (pt.x > maxX) maxX = pt.x;
        if (pt.y < minY) minY = pt.y;
        if (pt.y > maxY) maxY = pt.y;
      }
    }
    const logoW = maxX - minX;
    const logoH = maxY - minY;
    if (logoW <= 0 || logoH <= 0) return null;

    // Desktop uses 0.75" border, line diameter 0.02"
    const border = 0.75 * S;

    // Build line segment positions array
    const positions: number[] = [];

    if (isSubsUp) {
      // SUPB: Logo on baffle front face
      // Desktop: XZ plane at Y = -0.002, web coords: at Z = -0.002
      const areaW = baffleW - 2 * border;
      const areaH = intH - 2 * border;
      if (areaW <= 0 || areaH <= 0) return null;

      const scale = Math.min(areaW / logoW, areaH / logoH);
      const scaledW = logoW * scale;
      const scaledH = logoH * scale;

      // Baffle left edge X position (matching desktop and EnclosureScene)
      const baffleStartX = isDualPort ? (boxW / 2 - baffleW / 2) : 0;

      // Logo X -> 3D X (offset by baffle start)
      const offsetX = baffleStartX + border + (areaW - scaledW) / 2 - minX * scale;
      // Logo Y -> 3D Y (mapped to height, offset by bottom panel thickness)
      const offsetY = t + border + (areaH - scaledH) / 2 - minY * scale;
      // Z position: slightly in front of baffle surface
      // Desktop Y = -0.002 -> web Z = -0.002 (in enclosure-local coords before group flip)
      const z = -0.002;

      for (const poly of polylines) {
        for (let i = 0; i < poly.length - 1; i++) {
          const x1 = poly[i].x * scale + offsetX;
          const y1 = poly[i].y * scale + offsetY;
          const x2 = poly[i + 1].x * scale + offsetX;
          const y2 = poly[i + 1].y * scale + offsetY;

          const dx = x2 - x1, dy = y2 - y1;
          if (Math.sqrt(dx * dx + dy * dy) < 0.001 * S) continue;

          positions.push(x1, y1, z);
          positions.push(x2, y2, z);
        }
      }
    } else if (isSubsUpPortUp) {
      // SUPP: Logo on the BOTTOM panel surface (box-local Y = 0).
      // After the outer 'Subs Up/Port Up' rotation transform, the bottom
      // panel becomes the NEW FRONT face — the face the customer sees
      // when they open the trunk. We render the logo just below the
      // bottom panel surface (Y = -0.002) so it shows as a deboss on
      // that newly-front face.
      // Logo X -> box-local X (matches new world +X = right, after rotation)
      // Logo Y -> box-local Z (becomes vertical "up" after rotation)
      // Note: box-local Z=0 (baffle) maps to world +Y (new top), so
      // logo-Y values close to 0 should land near box-local Z=0 to read
      // as "upper part of the visible front face." We flip the Y-to-Z
      // mapping by anchoring at boxD - logoY so logo top renders toward
      // the box's baffle-side edge of the bottom panel.
      const areaW = boxW - 2 * border;
      const areaD = boxD - 2 * border;
      if (areaW <= 0 || areaD <= 0) return null;

      const scale = Math.min(areaW / logoW, areaD / logoH);
      const scaledW = logoW * scale;
      const scaledD = logoH * scale;

      const offsetX = border + (areaW - scaledW) / 2 - minX * scale;
      // Mirror logo-Y so it reads upright in the rotated rendering.
      const offsetZ = boxD - border - (areaD - scaledD) / 2 + minY * scale;
      // Y position: slightly below the bottom panel surface so the deboss
      // shows on the now-front face.
      const y = -0.002;

      for (const poly of polylines) {
        for (let i = 0; i < poly.length - 1; i++) {
          const x1 = poly[i].x * scale + offsetX;
          // Negate the y-multiplier so logo top maps to small box-local Z
          // (near baffle edge → upper portion of the rotated front face).
          const z1 = offsetZ - poly[i].y * scale;
          const x2 = poly[i + 1].x * scale + offsetX;
          const z2 = offsetZ - poly[i + 1].y * scale;

          const dx = x2 - x1, dz = z2 - z1;
          if (Math.sqrt(dx * dx + dz * dz) < 0.001 * S) continue;

          positions.push(x1, y, z1);
          positions.push(x2, y, z2);
        }
      }
    } else {
      // SBPB: Logo on top panel surface
      // Desktop: XY plane at Z = boxH + 0.002, web coords: at Y = boxH + 0.002
      const areaW = boxW - 2 * border;
      const areaD = boxD - 2 * border;
      if (areaW <= 0 || areaD <= 0) return null;

      const scale = Math.min(areaW / logoW, areaD / logoH);
      const scaledW = logoW * scale;
      const scaledD = logoH * scale;

      const offsetX = border + (areaW - scaledW) / 2 - minX * scale;
      // Logo Y -> 3D Z (depth direction)
      const offsetZ = border + (areaD - scaledD) / 2 - minY * scale;
      // Y position: slightly above top panel surface
      const y = boxH + 0.002;

      for (const poly of polylines) {
        for (let i = 0; i < poly.length - 1; i++) {
          const x1 = poly[i].x * scale + offsetX;
          const z1 = poly[i].y * scale + offsetZ;
          const x2 = poly[i + 1].x * scale + offsetX;
          const z2 = poly[i + 1].y * scale + offsetZ;

          const dx = x2 - x1, dz = z2 - z1;
          if (Math.sqrt(dx * dx + dz * dz) < 0.001 * S) continue;

          positions.push(x1, y, z1);
          positions.push(x2, y, z2);
        }
      }
    }

    if (positions.length === 0) return null;

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    return geo;
  }, [epsContent, boxW, boxH, boxD, baffleW, intH, tBaffle, t, isSubsUp, isSubsUpPortUp, isDualPort]);

  // Force a re-render when the geometry changes (e.g., logo EPS loaded asynchronously)
  const { invalidate } = useThree();
  useEffect(() => {
    if (geometry) invalidate();
  }, [geometry, invalidate]);

  if (!geometry) return null;

  // Desktop renders as PipeVisual3D with Diameter=0.02, black fill.
  // Web equivalent: lineSegments with lineWidth (note: WebGL lineWidth > 1 is not
  // widely supported, but the lines will still be visible at 1px).
  return (
    <lineSegments geometry={geometry}>
      <lineBasicMaterial color="#000000" />
    </lineSegments>
  );
}

// ─── Main Enclosure Scene ─────────────────────────────────────────────────────

interface EnclosureSceneProps {
  xrayMode: XRayMode;
  partMode: boolean;
  showDriver: boolean;
  dimsMode: DimsMode;
  showRoundover: boolean;
  debugMode: ViewerDebugMode;
  panelLayerDebugMode: PanelLayerDebugMode;
  logoEpsContent?: string | null;
  /** When true (and the design is Birch), render with the gray-stained albedo
   *  instead of natural raw Birch. No effect on MDF designs. */
  stainedBirch?: boolean;
}

// ─── Round flared port ──────────────────────────────────────────────────────
const ROUND_PORT_COLOR = '#3A3D42';
const ROUND_PORT_SIDES = 48;

/**
 * One round port as a thin-walled tube along its centreline, in world units with its
 * mouth centred on the origin: straight back from the baffle face (+Z), an optional
 * quarter-turn elbow toward -X (behind the drivers), then along the back wall.
 * Both flares follow the same radius the calculations use.
 */
function createRoundPortGeometry(layout: RoundPortLayout): THREE.BufferGeometry {
  const { port, geometry } = layout;
  const r = port.diameterIn / 2;
  const length = geometry.lengthIn;
  const elbow = geometry.needsElbow && geometry.elbowRadiusIn > 0;
  const leg1 = elbow ? geometry.leg1In : length;
  const bendR = geometry.elbowRadiusIn;
  const arc = geometry.elbowArcIn;
  const frame = (s: number): { c: [number, number, number]; tan: [number, number, number] } => {
    if (!elbow || s <= leg1) return { c: [0, 0, s], tan: [0, 0, 1] };
    if (s < leg1 + arc) {
      const a = (s - leg1) / bendR;
      return { c: [-bendR * (1 - Math.cos(a)), 0, leg1 + bendR * Math.sin(a)], tan: [-Math.sin(a), 0, Math.cos(a)] };
    }
    return { c: [-bendR - (s - leg1 - arc), 0, leg1 + bendR], tan: [-1, 0, 0] };
  };
  const stations = Math.max(48, Math.ceil(length / 0.2));
  const positions: number[] = [];
  const indices: number[] = [];
  const ring = (s: number, radius: number) => {
    const { c, tan } = frame(s);
    for (let k = 0; k < ROUND_PORT_SIDES; k++) {
      const theta = (2 * Math.PI * k) / ROUND_PORT_SIDES;
      // across = up x tangent; the path lies in a horizontal plane, so "up" is always square to it
      const ax = tan[2] * Math.cos(theta), az = -tan[0] * Math.cos(theta);
      positions.push((c[0] + radius * ax) * S, (c[1] + radius * Math.sin(theta)) * S, (c[2] + radius * az) * S);
    }
  };
  const join = (a: number, b: number) => {
    for (let k = 0; k < ROUND_PORT_SIDES; k++) {
      const n = (k + 1) % ROUND_PORT_SIDES;
      indices.push(a + k, b + k, b + n, a + k, b + n, a + n);
    }
  };
  // inside surface, then outside surface, each one ring per station
  for (const wall of [0, port.wallIn]) {
    const first = positions.length / 3;
    for (let i = 0; i <= stations; i++) {
      const s = (length * i) / stations;
      ring(s, roundPortRadiusAt(s, r, port.flareRadiusIn, length) + wall);
      if (i > 0) join(first + (i - 1) * ROUND_PORT_SIDES, first + i * ROUND_PORT_SIDES);
    }
  }
  // the two lips, joining inside to outside
  const perSurface = (stations + 1) * ROUND_PORT_SIDES;
  join(0, perSurface);
  join(stations * ROUND_PORT_SIDES, perSurface + stations * ROUND_PORT_SIDES);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/** Turns a tube built for the baffle (into the box along +Z, elbow toward -X) into one mounted in
 *  the right side panel: into the box along -X, elbow toward -Z (forward, toward the baffle). The
 *  flange, which stands proud of the baffle's face, then stands proud of the side's outside face. */
const ROUND_PORT_SIDE_ROTATION: [number, number, number] = [0, -Math.PI / 2, 0];

function RoundPortTube({ layout, position, color, rotation }: {
  layout: RoundPortLayout; position: [number, number, number]; color: string;
  /** Leave unset for a port in the baffle; ROUND_PORT_SIDE_ROTATION for one in the right side. */
  rotation?: [number, number, number];
}) {
  const geo = useMemo(() => createRoundPortGeometry(layout), [layout]);
  // The mounting flange: a flat ring on the outside face of the panel, round the hole.
  const flange = useMemo(() => {
    const inner = (layout.geometry.holeDiameterIn / 2) * S;
    const outer = (layout.geometry.flangeOutsideDiameterIn / 2) * S;
    if (!(outer > inner)) return null;
    const thick = ROUND_PORT_FLANGE_THICKNESS_IN * S;
    const ring = new THREE.LatheGeometry(
      [new THREE.Vector2(inner, 0), new THREE.Vector2(outer, 0), new THREE.Vector2(outer, -thick), new THREE.Vector2(inner, -thick), new THREE.Vector2(inner, 0)],
      ROUND_PORT_SIDES,
    );
    ring.rotateX(Math.PI / 2);                       // lathe axis (Y) to the box's depth (Z); the ring stands proud of the face
    return ring;
  }, [layout]);
  useEffect(() => () => { geo.dispose(); flange?.dispose(); }, [geo, flange]);
  return (
    <group position={position} rotation={rotation}>
      <mesh geometry={geo}>
        <meshStandardMaterial color={color} roughness={0.55} metalness={0.05} side={THREE.DoubleSide} />
      </mesh>
      {flange && (
        <mesh geometry={flange}>
          <meshStandardMaterial color={color} roughness={0.55} metalness={0.05} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}

function EnclosureScene({
  xrayMode, partMode, showDriver, dimsMode, showRoundover, debugMode, panelLayerDebugMode,
  logoEpsContent, stainedBirch = false,
}: EnclosureSceneProps) {
  const liveGeometry = useEnclosureStore();
  const renderGeometry = useContext(RenderGeometryContext);
  const { inputs, calculations, cutList } = renderGeometry ?? liveGeometry;

  const {
    boxDepth,
    boxHeight,
    portWidth,
    subCutoutDiameter,
    outsideDiameter,
    enclosureType,
    enclosureConfiguration,
    subwooferQuantity,
    portQuantity,
  } = inputs;

  const {
    boxWidth,
    internalHeight,
    portLength1,
    portLength2,
    s2LeftWidth,
    s1RightWidth,
    labyrinthPort,
  } = calculations;
  // Round flared port: no slot, no port panels; the baffle spans the box and
  // carries the port hole(s). Null for every slot design.
  const roundPort = calculations.roundPort?.active ? calculations.roundPort : null;
  // The same port mounted in the right side panel instead: the holes, flanges
  // and flare mouths are on that panel and nothing of the port is on the baffle.
  const roundPortSide = roundPort?.location === 'Side Right' && roundPort.side ? roundPort.side : null;

  const useMdf = isMDF(enclosureType);
  const useHeavy = isHeavyDuty(enclosureType);
  const isSubsUp = enclosureConfiguration === 'Subs Up/Port Back';
  // 'Subs Up/Port Up' is a pure visualization rotation of 'Subs Back/Port
  // Back' — same physical box, same panels, same cut list. The only
  // difference is the box is rendered tipped 90° onto its back so the
  // back face (with subs + port) appears on top.
  const isSubsUpPortUp = enclosureConfiguration === 'Subs Up/Port Up';
  const isDualPort = portQuantity === 'Dual';
  const subCount = getSubwooferCount(subwooferQuantity);
  const gussetCount = getGussetCount(subwooferQuantity);
  const sharedSupbLayout = isSubsUp
    ? resolveSupbSubLayout(inputs, calculations, cutList)
    : null;
  // Show finite manual positions even when unsafe so the operator can see
  // and correct the conflict. Manufacturing exports still require safe=true.
  const displayedSupbLayout = sharedSupbLayout?.points.length === subCount
    && sharedSupbLayout.points.every(p => Number.isFinite(p.x) && Number.isFinite(p.y))
    ? sharedSupbLayout : null;
  // An unresolved automatic multi-sub layout is not a request to render the
  // old overlapping row. Keep finite manual overrides visible for correction.
  const suppressSupbFallback = !!sharedSupbLayout && subCount > 1 && !displayedSupbLayout;
  const previewSupbPoints = sharedSupbLayout
    ? unresolvedSubwooferPreview(inputs, calculations, cutList, sharedSupbLayout) : null;
  const visibleSupbPoints = displayedSupbLayout?.points ?? previewSupbPoints;
  const supbSpacingWarning = !!visibleSupbPoints && subCount > 1
    && subwooferSpacingNeedsWarning(calculations.baffleCheck);
  // The subwoofer's own mounting depth, when the design gives one: the drivers are drawn that deep,
  // their motors red when the fit check finds them too deep for the box.
  const driverDepth = subwooferDepthCheck(inputs, calculations, cutList);

  // Material thicknesses — configuration-aware so SUPB-RD picks up the
  // top↔baffle thickness swap (Top thick, Baffle thin in RD-SUPB).
  const joint = resolveJoinery(inputs);
  const manufacturingMaterials = joint.profile.materials;
  const frontMate = joint.frontMate * S;
  const backMate = joint.backMate * S;
  const port2Offset = joint.port2VerticalOffset * S;
  const t = getPartMaterial('Side Left', enclosureType, manufacturingMaterials, enclosureConfiguration).thicknessInches * S;
  const tBottom = getPartMaterial('Bottom', enclosureType, manufacturingMaterials, enclosureConfiguration).thicknessInches * S;
  const tTop = getPartMaterial('Top', enclosureType, manufacturingMaterials, enclosureConfiguration).thicknessInches * S;
  // ─── Flush mount (recessed sub mounting) — viewer-side overrides ─────────
  // SBPB / SUPP use a thin structural face plus a backing plate; SUPB uses
  // a thin cap. Both constructions support Birch and MDF.
  // When active:
  //   - Structural baffle becomes thin stock regardless of duty.
  //   - A sub-mount plate (thick RD/HD, thin SD) sits glued to the back
  //     face of the structural baffle, centered horizontally within its
  //     footprint (narrower than the baffle — fits between Side Left and
  //     Port Piece 1).
  //   - Structural baffle's cutout becomes a flange recess hole sized to
  //     subOD + 0.25"; the plate carries the standard sub through-cutout.
  const isSubsUpPortBackCfg = enclosureConfiguration === 'Subs Up/Port Back';
  const isFlushMount = !!inputs.recessedMounting && !isSubsUpPortBackCfg;
  const isFlushMountSupb = !!inputs.recessedMounting && isSubsUpPortBackCfg;
  const thinFlushThicknessIn = useMdf ? manufacturingMaterials.D1 : manufacturingMaterials.B1;
  const thickFlushThicknessIn = useMdf ? manufacturingMaterials.D2 : manufacturingMaterials.B2;
  const tBaffleNatural = getPartMaterial('Baffle', enclosureType, manufacturingMaterials, enclosureConfiguration).thicknessInches * S;
  // Force the structural baffle to thin stock when flush mount is on.
  const tBaffle = isFlushMount ? thinFlushThicknessIn * S : tBaffleNatural;
  // Sub-mount plate: thick stock for RD/HD, thin stock for SD.
  const isStandardDutyCfg = enclosureType.includes('Standard');
  const tSubMountPlate = isFlushMount
    ? (isStandardDutyCfg ? thinFlushThicknessIn : thickFlushThicknessIn) * S
    : 0;
  // SUPB flush mount: a thin cap sits on top of the box (full outer
  // footprint). boxHeight is total external dim — the cap eats into chamber
  // internal height by tCap so the chamber, walls, baffle, back, sides, and
  // the top panel itself all shift down by tCap.
  const tCap = isFlushMountSupb ? thinFlushThicknessIn * S : 0;
  const tBack = getPartMaterial('Back', enclosureType, manufacturingMaterials, enclosureConfiguration).thicknessInches * S;
  const pp1Mat = getPartMaterial('Port Piece 1', enclosureType, manufacturingMaterials, enclosureConfiguration);
  const pp1Thick = pp1Mat.thicknessInches * S;

  // Scaled dimensions
  const boxW = roundUpToEighth(boxWidth) * S;
  const boxH = boxHeight * S;
  const boxD = boxDepth * S;
  // Internal cavity height = boxHeight − Top thickness − Bottom thickness.
  // Using the actual per-part thickness (rather than 2*t) keeps panels flush
  // in SUPB-RD where Top is 24mm but Bottom stays 18mm.
  const intH = boxH - tTop - tBottom - tCap;
  const pW = portWidth * S;
  const cutR = (subCutoutDiameter / 2) * S;

  // Port piece dimensions from CUT LIST (matches desktop GetCutListDimension pattern).
  // Desktop reads the cut list Width column for PP1 depth (physical panel dimension),
  // NOT the acoustic portLength1 (which is a centerline measurement and differs).
  // portPiece1Width = boxDepth - (portWidth + edgeMill*2 + backThickness + glueTolerance*2)
  // portLength1 = boxDepth - (thickness + portWidth/2)  ← different formula!
  const getCutListWidth = (partName: string, fallback: number): number => {
    if (!cutList) return fallback;
    // Exact match first, then try Left/Right variants (dual port uses "Port Piece 1 Left" etc.)
    const lower = partName.toLowerCase();
    const item = cutList.find(c => c.partName.toLowerCase() === lower)
      || cutList.find(c => c.partName.toLowerCase() === `${lower} left`)
      || cutList.find(c => c.partName.toLowerCase() === `${lower} right`);
    return item ? item.width : fallback;
  };
  const pp1Depth = getCutListWidth('Port Piece 1', portLength1) * S;
  const pp2PanelWidth = getCutListWidth('Port Piece 2', Math.max(0, portLength2 - portWidth)) * S;

  // X-Ray opacity per panel (matching desktop: 0 = wireframe only, 1 = solid)
  // Desktop uses binary opacity (0 or 255), never semi-transparent, to avoid z-buffer issues
  const getOpacity = (part: string): number => {
    if (xrayMode === 'off') return 1;
    if (xrayMode === 'topOnly') return part === 'top' ? 0 : 1;
    // exterior: top, sides, back, baffle hidden (wireframe only)
    if (['top', 'left', 'right', 'back', 'baffle'].includes(part)) return 0;
    return 1;
  };

  // Panel colors
  const getColor = (part: string): string => {
    if (partMode) return PART_COLORS[part] || COLORS.birch;
    return useMdf ? COLORS.mdf : COLORS.birch;
  };

  // Wood textures — full PBR (albedo + normal + roughness) for both Birch and
  // MDF. Horizontal grain on top/bottom/baffle, vertical on sides/back.
  // Picks the right material set based on the design's enclosureType.
  const woodTextures = useWoodTextures();
  // MDF designs always use the MDF set. Birch designs swap between natural
  // and stained albedo based on the viewer toggle.
  const woodSet = useMdf
    ? woodTextures.mdf
    : (stainedBirch ? woodTextures.birchStained : woodTextures.birch);
  // Pick a ply-edge texture based on panel thickness (world units, scaled
  // by S). MDF panels get undefined — MDF has no visible plies. Stained
  // mode picks the stained variant so panel edges match panel faces.
  // Threshold ~0.85" splits 18mm (0.709") from 24mm (0.945") cleanly.
  const pickPlyEdge = (thicknessWorld: number): THREE.Texture | undefined => {
    if (useMdf) return undefined;
    const isThick = (thicknessWorld / S) >= 0.85;
    if (stainedBirch) {
      return isThick ? woodTextures.birchPlyEdge24Stained : woodTextures.birchPlyEdge18Stained;
    }
    return isThick ? woodTextures.birchPlyEdge24 : woodTextures.birchPlyEdge18;
  };
  const hTexture = woodSet.horizontal;
  const vTexture = woodSet.vertical;
  // useGrain: textures enabled for ALL materials now. partMode still suppresses
  // (each part gets its own debug color), but MDF gets its own PBR set instead
  // of the previous flat-color fallback.
  const useGrain = !partMode;

  // Terminal cup check (matching desktop: TerminalCupHeight < intH && TerminalCupWidth < sideDepth)
  // Skipped when the design opts out via terminalPanel='None' — no cup
  // means no hole, no plate, no roundover, no no-go bands.
  const sideDepthRaw = getCutListWidth('Side Left', inputs.boxDepth - (inputs.portQuantity === 'Dual' ? joint.backMate : joint.frontMate + joint.backMate)) * S;
  const leftStart = isDualPort ? 0 : frontMate;
  const hasTerminal =
    inputs.terminalPanel !== 'None' &&
    TC_HEIGHT * S < intH &&
    TC_WIDTH * S < sideDepthRaw;

  // ─── Terminal placement resolution (V1) ──────────────────────────────────
  // Pick the panel and X-offset for the terminal cup. Both inputs.terminal*
  // fields are optional; when unset we fall back to the legacy default
  // (single port → Side Left, dual port → Back) and a centered cutout.
  // The 3D viewer renders the cutout, plate and outside roundover
  // wherever the user has placed it, so the scene matches the
  // generated DXF.
  // Single source of truth: terminal-placement.ts. Panel choice routes
  // single-port → Side Left, dual-port → Back. X offset is centered (0)
  // for SBPB / SUPB, but for SUPP on Side Left it defaults to a positive
  // shift toward the new-bottom edge of the rotated panel.
  // resolveTerminalPanel can return 'None' (skip-cup designs). hasTerminal
  // already filters those out above, so terminalOnLeft / terminalOnBack
  // stay false and the renderers below short-circuit cleanly.
  const terminalPanelChoice: TerminalPanel = resolveTerminalPanel(inputs);
  const terminalPanelForGeom: Exclude<TerminalPanel, 'None'> =
    terminalPanelChoice === 'None' ? 'Side Left' : terminalPanelChoice;
  const terminalXOffsetIn = resolveTerminalPlacementOffset(inputs, calculations, cutList, terminalPanelForGeom);
  const terminalXOffsetSc = terminalXOffsetIn * S;
  const terminalOnLeft = hasTerminal && terminalPanelChoice === 'Side Left';
  const terminalOnBack = hasTerminal && terminalPanelChoice === 'Back';
  const terminalOnTop = terminalPanelChoice === 'Top' && enclosureConfiguration === 'Subs Up/Port Up';
  const topTerminal = topTerminalCenter(boxW / S, boxD / S, tBack / S, terminalXOffsetIn);
  const terminalIsCustomized = inputs.terminalPanel !== undefined || inputs.terminalXOffset !== undefined;
  // Compute no-go bands once — only used by the overlay when the user opts in.
  // Reuses the same helper the Design tab + DXF generator validate against.
  const noGoBands = useMemo(() => {
    if (!terminalIsCustomized || !hasTerminal) return [];
    const all = computeNoGoBands(terminalPanelChoice, inputs, calculations, cutList);
    // Drop ±Infinity bands (legacy guard) — the band visualizer can't render those.
    return all.filter(b => Number.isFinite(b.xMin) && Number.isFinite(b.xMax));
  }, [terminalIsCustomized, hasTerminal, terminalPanelChoice, inputs, calculations, cutList]);

  // Sub placement safe-zone overlay was tried in the polish pass and
  // removed — too easy to mistake for a real geometry feature in X-Ray
  // view, and the slider already clamps to the safe range so the
  // visualization wasn't doing useful work.

  // Derived positions
  const sideDepth = sideDepthRaw;

  // Baffle width (from cut list formula)
  const btwS = joint.port2Stock * S;
  let baffleW: number;
  if (roundPort) {
    baffleW = boxW;
  } else if (isDualPort) {
    baffleW = boxW - (2 * pW + 2 * btwS);
  } else {
    baffleW = boxW - (pW + btwS);
  }

  // Port piece dimensions
  // These are acoustic port length values (kept for dimension labels only)
  const pl1 = portLength1 * S;
  const pl2 = portLength2 * S;
  // pp2Width used only for old reference; rendering now uses pp2PanelWidth from cut list

  const labyrinthPanelConfigs: Array<{
    key: string;
    position: [number, number, number];
    size: [number, number, number];
    anchoredAt: 'front' | 'back';
  }> = labyrinthPort.active ? (() => {
    const centerY = t + intH / 2;
    const pitch = labyrinthPort.lanePitch * S;
    return labyrinthPort.panels.slice(1).map(panel => {
      const depth = getCutListWidth(
        `Port Piece ${panel.partNumber}`,
        labyrinthPort.fullDividerLength * panel.fullLengthFraction,
      ) * S;
      const x = baffleW - pp1Thick / 2 - panel.laneIndex * pitch;
      const innerBack = boxD - backMate;
      const z = panel.anchoredAt === 'front'
        ? frontMate + depth / 2
        : innerBack - depth / 2;
      return {
        key: `labyrinth-pp${panel.partNumber}`,
        position: [x, centerY, z] as [number, number, number],
        size: [pp1Thick, intH, depth] as [number, number, number],
        anchoredAt: panel.anchoredAt,
      };
    });
  })() : [];

  // Gusset depth (extracted here for useMemo dependency stability)
  const gussetPartFromCutList = cutList.find(p => p.partName === 'Gusset');
  const gussetDepthInches = gussetPartFromCutList ? gussetPartFromCutList.width : 5.0;
  const gussetDepth = gussetDepthInches * S;

  const pp2Configs = useMemo(() => {
    if (roundPort || labyrinthPort.active || pp2PanelWidth <= 0) return [] as Array<{
      key: string;
      position: [number, number, number];
      origin: [number, number, number];
      trimCorners: [boolean, boolean, boolean, boolean];
      xLeft: number;
      xRight: number;
      zFront: number;
      zBack: number;
      freeEndIsLeft: boolean;
    }>;

    const zFront = frontMate + pp1Depth + port2Offset;
    const zBack = zFront + pp1Thick;
    const centerY = t + intH / 2;
    const centerZ = zFront + pp1Thick / 2;

    const makeConfig = (
      key: string,
      xLeft: number,
      xRight: number,
      freeEndIsLeft: boolean,
    ) => ({
      key,
      position: [(xLeft + xRight) / 2, centerY, centerZ] as [number, number, number],
      origin: [xLeft, t, zFront] as [number, number, number],
      trimCorners: [freeEndIsLeft, !freeEndIsLeft, true, true] as [boolean, boolean, boolean, boolean],
      xLeft,
      xRight,
      zFront,
      zBack,
      freeEndIsLeft,
    });

    if (isDualPort) {
      // Dual port PP2: extends from PP1 edge inward toward center
      // Same pattern as single port where PP2 right edge = baffleW = PP1 edge
      // PP2 Left: left edge at PP1 Left position, extends rightward
      const pp2lLeft = t + pW;
      // PP2 Right: right edge at PP1 Right position, extends leftward
      const pp2rRight = boxW - t - pW;
      return [
        makeConfig('pp2l', pp2lLeft, pp2lLeft + pp2PanelWidth, false),
        makeConfig('pp2r', pp2rRight - pp2PanelWidth, pp2rRight, true),
      ];
    }

    // Single port: free end on the LEFT, junction on the RIGHT
    return [makeConfig('pp2', baffleW - pp2PanelWidth, baffleW, true)];
  }, [roundPort, labyrinthPort.active, pp2PanelWidth, frontMate, port2Offset, pp1Depth, pp1Thick, t, intH, isDualPort, boxW, baffleW, pW]);

  // ─── PP2 roundover geometry (matching desktop: 3 vertical edges per PP2 panel) ───

  const pp2RoundoverGeo = useMemo(() => {
    if (pp2Configs.length === 0) return null;
    const R = ROUNDOVER_R * S;
    const segs = ROUNDOVER_SEGS;
    const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
    const yB = t, yT = t + intH;
    const geos: THREE.BufferGeometry[] = [];

    for (const cfg of pp2Configs) {
      const xFree = cfg.freeEndIsLeft ? cfg.xLeft : cfg.xRight;
      const xJunc = cfg.freeEndIsLeft ? cfg.xRight : cfg.xLeft;
      const freeDir = cfg.freeEndIsLeft ? -1 : 1;
      const juncDir = cfg.freeEndIsLeft ? 1 : -1;

      geos.push(
        createEdgeRound(V(xFree, yB, cfg.zFront), V(xFree, yT, cfg.zFront), V(freeDir, 0, 0), V(0, 0, -1), R, segs),
        createEdgeRound(V(xFree, yB, cfg.zBack), V(xFree, yT, cfg.zBack), V(freeDir, 0, 0), V(0, 0, 1), R, segs),
        createEdgeRound(V(xJunc, yB, cfg.zBack), V(xJunc, yT, cfg.zBack), V(juncDir, 0, 0), V(0, 0, 1), R, segs),
      );
    }

    return mergeGeos(geos);
  }, [pp2Configs, t, intH]);

  // PP2 tangent lines (thin lines where roundover meets flat face)
  const pp2TangentLines = useMemo((): { start: [number, number, number]; end: [number, number, number] }[] => {
    if (pp2Configs.length === 0) return [];
    const R = ROUNDOVER_R * S;
    const yB = t, yT = t + intH;
    const lines: { start: [number, number, number]; end: [number, number, number] }[] = [];

    for (const cfg of pp2Configs) {
      const xFree = cfg.freeEndIsLeft ? cfg.xLeft : cfg.xRight;
      const xJunc = cfg.freeEndIsLeft ? cfg.xRight : cfg.xLeft;
      const freeDir = cfg.freeEndIsLeft ? -1 : 1;
      const juncDir = cfg.freeEndIsLeft ? 1 : -1;

      lines.push(
        { start: [xFree - freeDir * R, yB, cfg.zFront], end: [xFree - freeDir * R, yT, cfg.zFront] },
        { start: [xFree, yB, cfg.zFront + R], end: [xFree, yT, cfg.zFront + R] },
        { start: [xFree - freeDir * R, yB, cfg.zBack], end: [xFree - freeDir * R, yT, cfg.zBack] },
        { start: [xFree, yB, cfg.zBack - R], end: [xFree, yT, cfg.zBack - R] },
        { start: [xJunc - juncDir * R, yB, cfg.zBack], end: [xJunc - juncDir * R, yT, cfg.zBack] },
        { start: [xJunc, yB, cfg.zBack - R], end: [xJunc, yT, cfg.zBack - R] },
      );
    }

    return lines;
  }, [pp2Configs, t, intH]);

  // ─── Gusset roundover geometry (matching desktop: 2 back edges per gusset) ───

  // Gusset front face Z. In standard construction: glued to the back of the
  // structural baffle, so zFront = tBaffle. In flush mount: glued to the
  // back of the SUB-MOUNT PLATE instead (the plate is between the gusset
  // and the structural baffle), so zFront = tBaffle + tSubMountPlate.
  const gussetFrontZ = tBaffle + (isFlushMount ? tSubMountPlate : 0);

  // Gusset X offset: SUPB designs let the user shift the sub pattern via
  // subwooferXOffset. Gussets sit between subs structurally, so they should
  // follow the same shift. SBPB has no per-design X offset (no UI), so this
  // resolves to 0 there.
  const gussetXShift = isSubsUpPortBackCfg ? (inputs.subwooferXOffset ?? 0) * S : 0;

  const gussetRoundoverGeo = useMemo(() => {
    if (gussetCount <= 0) return null;
    // SUPB single-port: the gusset is a free-standing column (not glued to
    // the baffle), so the back-edge roundovers don't apply. Skip the geo.
    if (isSubsUpPortBackCfg) return null;
    const R = ROUNDOVER_R * S;
    const segs = ROUNDOVER_SEGS;
    const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

    const geos: THREE.BufferGeometry[] = [];
    const yB = t, yT = t + intH;
    const zBack = gussetFrontZ + gussetDepth;

    for (let i = 0; i < gussetCount; i++) {
      const gx = !isSubsUpPortBackCfg
        ? baffleBraceCenters(inputs,cutList,calculations)[i]*S : baffleW * (i + 1) / (gussetCount + 1);
      if (!Number.isFinite(gx)) continue;
      const gxPos = (isDualPort ? boxW / 2 - baffleW / 2 + gx : gx) + gussetXShift;
      const xL = gxPos - t / 2;
      const xR = gxPos + t / 2;

      // Left-back edge
      geos.push(createEdgeRound(V(xL, yB, zBack), V(xL, yT, zBack), V(-1,0,0), V(0,0,1), R, segs));
      // Right-back edge
      geos.push(createEdgeRound(V(xR, yB, zBack), V(xR, yT, zBack), V(1,0,0), V(0,0,1), R, segs));
    }

    return mergeGeos(geos);
  }, [gussetCount, gussetDepth, baffleW, isDualPort, boxW, gussetFrontZ, gussetXShift, t, intH, isSubsUpPortBackCfg, inputs, cutList, calculations]);

  // Gusset tangent lines
  const gussetTangentLines = useMemo((): { start: [number, number, number]; end: [number, number, number] }[] => {
    if (gussetCount <= 0) return [];
    // SUPB single-port: gusset is free-standing, no back-edge tangents needed.
    if (isSubsUpPortBackCfg) return [];
    const R = ROUNDOVER_R * S;
    const yB = t, yT = t + intH;
    const zBack = gussetFrontZ + gussetDepth;
    const lines: { start: [number, number, number]; end: [number, number, number] }[] = [];

    for (let i = 0; i < gussetCount; i++) {
      const gx = !isSubsUpPortBackCfg
        ? baffleBraceCenters(inputs,cutList,calculations)[i]*S : baffleW * (i + 1) / (gussetCount + 1);
      if (!Number.isFinite(gx)) continue;
      const gxPos = (isDualPort ? boxW / 2 - baffleW / 2 + gx : gx) + gussetXShift;
      const xL = gxPos - t / 2;
      const xR = gxPos + t / 2;

      // Left-back tangents
      lines.push({ start: [xL + R, yB, zBack], end: [xL + R, yT, zBack] });
      lines.push({ start: [xL, yB, zBack - R], end: [xL, yT, zBack - R] });
      // Right-back tangents
      lines.push({ start: [xR - R, yB, zBack], end: [xR - R, yT, zBack] });
      lines.push({ start: [xR, yB, zBack - R], end: [xR, yT, zBack - R] });
    }

    return lines;
  }, [gussetCount, gussetDepth, baffleW, isDualPort, boxW, gussetFrontZ, gussetXShift, t, intH, isSubsUpPortBackCfg, inputs, cutList, calculations]);

  // Desktop hides edge wireframes when roundovers are on (tangent lines replace them)
  const hideExteriorEdges = showRoundover && xrayMode === 'off';

  // ─── Render panels ───
  // When roundovers are active, top/bottom panels use custom geometry matching
  // the desktop's AddPanelWithRoundoverCut: outer face at full Z position (inset
  // by R in X/Y), side faces shortened by R, inner face at full size.
  const roR = ROUNDOVER_R * S;
  const roActive = hideExteriorEdges; // roundovers visible and active
  const baffleStartX = isDualPort ? (boxW / 2 - baffleW / 2) : 0;
  const topBottomInnerFrontClip: RoundoverCutPanelFrontClip | null = roActive
    ? { x0: baffleStartX, x1: baffleStartX + baffleW, depth: tBaffle }
    : null;
  const topBottomInnerVisibleRects: RoundoverCutPanelRect[] | null = roActive ? (() => {
    const rects: RoundoverCutPanelRect[] = [];
    const rightInnerX = Math.max(0, boxW - t);
    const backInnerZ = Math.max(0, boxD - tBack);

    if (tBaffle > 0) {
      if (baffleStartX > 0) rects.push({ x0: 0, x1: baffleStartX, z0: 0, z1: tBaffle });
      const frontRightX0 = baffleStartX + baffleW;
      if (frontRightX0 < rightInnerX) rects.push({ x0: frontRightX0, x1: rightInnerX, z0: 0, z1: tBaffle });
    }

    if (backInnerZ > tBaffle && rightInnerX > t) {
      rects.push({ x0: t, x1: rightInnerX, z0: tBaffle, z1: backInnerZ });
    }

    return rects;
  })() : null;

  const panels: React.ReactElement[] = [];

  // ─── Acrylic window cutout precompute ─────────────────────────────────────
  // Resolve window dimensions + which panel hosts the cutout once, so each
  // host-panel render branch can punch a hole when relevant. Real geometry
  // hole (V2) — replaces the V1 "plate floats over solid wood" approach.
  const windowHostPart: 'Top' | 'Baffle' | 'Bottom' | null =
    inputs.windowEnabled && inputs.windowSize
      ? (isSubsUpPortBackCfg ? 'Baffle' : isSubsUpPortUp ? 'Bottom' : 'Top')
      : null;
  let windowCutWSc = 0;
  let windowCutHSc = 0;
  let windowPlateWSc = 0;
  let windowPlateHSc = 0;
  let windowCutXOffSc = 0;
  let windowCutYOffSc = 0;
  let windowCornerRadiusSc = 0;
  if (windowHostPart) {
    // Plate dims come from the size tier; cutout = plate − 2 × overhang.
    // Plate is auto-shrunk to the host panel's safe area (1" clearance
    // from baffle / PP1 / PP2 / sides) so the viewer renders exactly what
    // the DXF generator emits.
    const raw = resolveWindowDimensions(inputs);
    const safe = resolveWindowSafeArea(inputs, calculations, cutList);
    const fitted = resolveAutoFitPlateDimensions(
      { plateW: raw.plateW, plateH: raw.plateH },
      safe,
    );
    windowPlateWSc = fitted.plateW * S;
    windowPlateHSc = fitted.plateH * S;
    windowCutWSc = fitted.cutoutW * S;
    windowCutHSc = fitted.cutoutH * S;
    // Use effective offsets (saved clamped to safe range) so legacy
    // designs render correctly without requiring a manual Recenter.
    const effOff = resolveEffectiveWindowOffsets(inputs, calculations, cutList);
    windowCutXOffSc = effOff.x * S;
    windowCutYOffSc = effOff.y * S;
    windowCornerRadiusSc = (inputs.windowCornerRadius ?? 0.125) * S;
  }

  // Bottom panel (horizontal grain) — uses tBottom (always 18mm/3/4" except in HD)
  if (windowHostPart === 'Bottom') {
    // Acrylic window on the SUPU Bottom — real rectangular hole.
    // Same rotation convention as Top (local Y → world +Z, local Z → world -Y).
    // Group Y at tBottom (panel's top face inside the box) so the
    // downward extrude lands the panel at world Y = [0, tBottom].
    panels.push(
      <PanelWithRectHole key="bottom"
        panelW={boxW} panelH={boxD} panelT={tBottom}
        cutoutCx={boxW / 2 + windowCutXOffSc}
        cutoutCy={boxD / 2 + windowCutYOffSc}
        cutoutW={windowCutWSc}
        cutoutH={windowCutHSc}
        cutoutCornerRadius={windowCornerRadiusSc}
        outerCornerRadius={roActive ? roR : 0}
        position={[0, tBottom, 0]}
        rotation={[Math.PI / 2, 0, 0]}
        color={getColor('bottom')} opacity={getOpacity('bottom')}
        texture={hTexture} useTexture={useGrain}
        showEdges={true} />
    );
  } else if (roActive) {
    panels.push(
      <RoundoverCutPanel key="bottom" W={boxW} D={boxD} t={tBottom} R={roR} isTop={false}
        position={[0, 0, 0]}
        color={getColor('bottom')} opacity={getOpacity('bottom')} texture={hTexture} useTexture={useGrain}
        layerDebugMode={panelLayerDebugMode}
        innerFrontClip={topBottomInnerFrontClip}
        innerVisibleRects={topBottomInnerVisibleRects}
        showInnerFace={true} />
    );
  } else {
    panels.push(
      <TexturedPanel key="bottom" position={[boxW / 2, tBottom / 2, boxD / 2]} size={[boxW, tBottom, boxD]}
        color={getColor('bottom')} opacity={getOpacity('bottom')} texture={hTexture} useTexture={useGrain}
        thicknessAxis="y" plyEdgeTexture={pickPlyEdge(tBottom)}
        showEdges={true} />
    );
  }

  // Top panel (horizontal grain)
  // SUPB: top panel needs cutout holes for subwoofers (matching desktop AddTopPanelWithHoles)
  const topHoles: { cx: number; cz: number; r: number; outline?: ProfilePoint[] }[] = [];
  if (isSubsUp && subCutoutDiameter > 0 && cutR > 0) {
    const outsideDia = (outsideDiameter > 0 ? outsideDiameter : subCutoutDiameter) * S;
    const s2w = s2LeftWidth * S;
    const cy = boxD / 2; // centered along depth

    if (isDualPort && !sharedSupbLayout && !inputs.subwooferCutoutProfile && subCount === 1) {
      // Dual Port + Single Sub: center hole on full top panel
      topHoles.push({ cx: boxW / 2, cz: cy, r: cutR });
    } else if (isDualPort && !sharedSupbLayout && !inputs.subwooferCutoutProfile && subCount === 2) {
      const s1w = s1RightWidth * S;
      const leftChamberCenter = t + pW + pp1Thick + (s2w / 2);
      const rightChamberCenter = t + pW + pp1Thick + s2w + tBaffle + (s1w / 2);
      topHoles.push({ cx: leftChamberCenter, cz: cy, r: cutR });
      topHoles.push({ cx: rightChamberCenter, cz: cy, r: cutR });
    } else {
      if (displayedSupbLayout) {
        for (const point of displayedSupbLayout.points) {
          topHoles.push({ cx: point.x * S, cz: point.y * S, r: cutR });
        }
      } else if (!suppressSupbFallback) {
      // Single port: prefer S2 Left; if S2 is too small for the sub, fall back
      // to the combined (S2 + S1) chamber since the L-shape port connects them.
      const s2EdgeClearance = (s2w - outsideDia * subCount) / (subCount + 1);
      const s1w = s1RightWidth * S;
      const useCombined = s2EdgeClearance <= 0;
      const chamberW = useCombined ? (s2w + s1w) : s2w;
      const chamberLeftEdge = t;
      // Depth: biased to keep the flange ≥ 0.5" from the box's outer
      // front/back faces when geometry allows. Mirrors the helper used by
      // the slider's auto-center and the DXF generator so all three render
      // the same default location.
      const s1Depth_in = useCombined ? Math.max(0, boxDepth - 2 * (t / S) - portWidth - (t / S)) : 0;
      const cyEffIn = resolveSupbAutoCenterY({
        boxDepth,
        portWidth,
        wallT: t / S,
        tBaffle: t / S,
        tBack: t / S,
        s1Depth: s1Depth_in,
        useCombined,
        halfOD: (outsideDiameter > 0 ? outsideDiameter : subCutoutDiameter) / 2,
        halfCutout: subCutoutDiameter / 2,
      });
      const cyEff = cyEffIn * S;
      // Apply user X/Y offsets (SUPB-only sub placement override). These are
      // stored in inches; convert to scene units by multiplying by S.
      const subXOff = (inputs.subwooferXOffset ?? 0) * S;
      const subYOff = (inputs.subwooferYOffset ?? 0) * S;
      if (subCount === 1) {
        topHoles.push({ cx: chamberLeftEdge + chamberW / 2 + subXOff, cz: cyEff + subYOff, r: cutR });
      } else {
        const gap = (chamberW - outsideDia * subCount) / (subCount + 1);
        for (let j = 0; j < subCount; j++) {
          topHoles.push({
            cx: chamberLeftEdge + gap * (j + 1) + outsideDia * (j + 0.5) + subXOff,
            cz: cyEff + subYOff,
            r: cutR,
          });
        }
      }
      }
    }
  }
  if(inputs.subwooferCutoutProfile) for(const h of topHoles) h.outline=inputs.subwooferCutoutProfile.opening.map(p=>({x:p.x*S,y:p.y*S}));
  const hasTopHoles = topHoles.length > 0;

  // When SUPB flush mount is active, the top panel sits one cap thickness
  // BELOW the box top (the cap occupies the topmost tCap of total height).
  // The top panel still gets the standard sub through-cutouts — the cap
  // above carries the wider flange recess.
  const topPanelYBottom = boxH - tTop - tCap;
  if (terminalOnTop) {
    panels.push(
      <TerminalPanelPreview key="top"
        width={boxW} height={boxD} thickness={tTop}
        centerX={topTerminal.x * S} centerY={topTerminal.y * S}
        openingWidth={TC_WIDTH * S} openingHeight={TC_HEIGHT * S} cornerRadius={TC_CORNER_R * S}
        roundoverRadius={roActive ? roR : 0}
        outerCornerRadius={roActive ? roR : 0}
        position={[0, topPanelYBottom + tTop, 0]} rotation={[Math.PI / 2, 0, 0]}
        color={getColor('top')} opacity={getOpacity('top')}
        texture={useGrain ? albedoOf(hTexture) : undefined} showEdges={!hideExteriorEdges} />
    );
  } else if (hasTopHoles) {
    // SUPB: top panel with sub cutout holes (RD-SUPB renders thicker top via tTop).
    // When roundovers are active, inset the outer face by R and shorten side
    // walls so the corner roundover quarter-cylinders sit flush — matches the
    // bottom panel's RoundoverCutPanel layout. R=0 keeps the flat box look.
    panels.push(
      <TopPanelWithCutouts key="top"
        boxW={boxW} boxD={boxD} t={tTop}
        holes={topHoles}
        yBottom={topPanelYBottom}
        color={getColor('top')} opacity={getOpacity('top')}
        texture={hTexture} useTexture={useGrain}
        showEdges={!hideExteriorEdges}
        showHoleRings={!showDriver}
        R={roActive ? roR : 0} />
    );
  } else if (windowHostPart === 'Top') {
    // Acrylic window on the SBPB Top — panel rendered with a real
    // rectangular hole so the plate behind it is visible without X-Ray.
    // Rotation [+π/2, 0, 0] maps local Y → world +Z (so slider Y+ moves
    // the cutout toward box back) and local Z → world -Y (extrude
    // downward). Group Y at topPanelYBottom + tTop (= panel's top face)
    // so the downward extrude lands the panel at [topPanelYBottom,
    // topPanelYBottom + tTop].
    panels.push(
      <PanelWithRectHole key="top"
        panelW={boxW} panelH={boxD} panelT={tTop}
        cutoutCx={boxW / 2 + windowCutXOffSc}
        cutoutCy={boxD / 2 + windowCutYOffSc}
        cutoutW={windowCutWSc}
        cutoutH={windowCutHSc}
        cutoutCornerRadius={windowCornerRadiusSc}
        outerCornerRadius={roActive ? roR : 0}
        position={[0, topPanelYBottom + tTop, 0]}
        rotation={[Math.PI / 2, 0, 0]}
        color={getColor('top')} opacity={getOpacity('top')}
        texture={hTexture} useTexture={useGrain}
        showEdges={!hideExteriorEdges} />
    );
  } else if (roActive) {
    panels.push(
      <RoundoverCutPanel key="top" W={boxW} D={boxD} t={tTop} R={roR} isTop={true}
        position={[0, topPanelYBottom, 0]}
        color={getColor('top')} opacity={getOpacity('top')} texture={hTexture} useTexture={useGrain}
        layerDebugMode={panelLayerDebugMode}
        innerFrontClip={topBottomInnerFrontClip}
        innerVisibleRects={topBottomInnerVisibleRects}
        showInnerFace={true} />
    );
  } else {
    panels.push(
      <TexturedPanel key="top" position={[boxW / 2, topPanelYBottom + tTop / 2, boxD / 2]} size={[boxW, tTop, boxD]}
        color={getColor('top')} opacity={getOpacity('top')} texture={hTexture} useTexture={useGrain}
        thicknessAxis="y" plyEdgeTexture={pickPlyEdge(tTop)}
        showEdges={true} />
    );
  }

  // ─── Sub Mount Cap (SUPB flush mount only) ─────────────────────────────
  // Thin-stock slab (18mm Birch or 3/4" MDF) on top of the box, full outer
  // flange-recess holes (OD + 0.25") — the top panel below has the
  // standard sub through-cutouts. Holes share the SAME world X/Z as the
  // top panel's holes since the cap sits directly above with matching
  // footprint.
  if (isFlushMountSupb && hasTopHoles && tCap > 0) {
    const recessR = outsideDiameter > 0
      ? ((outsideDiameter + 0.25) / 2) * S
      : cutR;
    const capHoles = topHoles.map(h => ({ cx: h.cx, cz: h.cz, r: recessR, outline: inputs.subwooferCutoutProfile?frameProfile(inputs.subwooferCutoutProfile,.125).map(p=>({x:p.x*S,y:p.y*S})):undefined }));
    panels.push(
      <TopPanelWithCutouts key="sub-mount-cap"
        boxW={boxW} boxD={boxD} t={tCap}
        holes={capHoles}
        yBottom={boxH - tCap}
        color={getColor('top')} opacity={getOpacity('top')}
        texture={hTexture} useTexture={useGrain}
        showEdges={!hideExteriorEdges}
        showHoleRings={!showDriver}
        R={roActive ? roR : 0} />
    );
  }

  // Back panel: spans internal height (vertical grain).
  // Desktop: trimBackAtXmax=true, trimBackAtXmin=true (both back-face corners trimmed).
  // Web mapping: back face = Z=boxD, so trim corners 2 (back-right) and 3 (back-left).
  // Rear terminal meshes share a smooth, outside-only quarter-round lip.
  if (terminalOnBack && getOpacity('back') > 0) {
    panels.push(
      <TerminalPanelPreview key="back"
        width={boxW} height={intH} thickness={tBack}
        centerX={boxW / 2 - terminalXOffsetSc} centerY={TC_FROM_BOTTOM * S}
        openingWidth={TC_WIDTH * S} openingHeight={TC_HEIGHT * S} cornerRadius={TC_CORNER_R * S}
        roundoverRadius={roActive ? roR : 0}
        position={[boxW, t, boxD]} rotation={[0, Math.PI, 0]}
        color={getColor('back')} opacity={getOpacity('back')}
        texture={useGrain ? albedoOf(vTexture) : undefined}
        showEdges={!hideExteriorEdges} />
    );
  } else if (roActive && getOpacity('back') > 0) {
    panels.push(
      <TrimmedVerticalPanel key="back"
        W={boxW} H={intH} D={tBack} R={roR}
        trimCorners={[false, false, true, true]}
        position={[0, t, boxD - tBack]}
        color={getColor('back')} opacity={getOpacity('back')} texture={vTexture} useTexture={useGrain} />
    );
  } else {
    panels.push(
      <TexturedPanel key="back" position={[boxW / 2, t + intH / 2, boxD - tBack / 2]} size={[boxW, intH, tBack]}
        color={getColor('back')} opacity={getOpacity('back')} texture={vTexture} useTexture={useGrain}
        thicknessAxis="z" plyEdgeTexture={pickPlyEdge(tBack)}
        showEdges={!hideExteriorEdges} />
    );
  }

  // Baffle (vertical grain — matching desktop)
  // Desktop: AddBaffleMeshWithHoles creates baffle with circular cutout holes when subs are present.
  // Compute baffle hole positions (same formula as sub positioning below, for SBPB only).
  // Flush mount: structural baffle's cutout is the flange RECESS hole (subOD + 0.25"),
  // not the standard sub through-hole. The sub-mount plate behind it carries
  // the standard cutout. Both use the same X positions (plate is centered
  // behind baffle).

  // ─── Kerf Port (curve port) detection ─────────────────────────────────────
  // When the cut list carries the merged 'Baffle + Port 1' kerf part, the baffle
  // + Port Piece 1 are ONE kerf-bent panel. Subs sit on the flat baffle LEG
  // ahead of the bend, so their X positions are distributed across baffleRunIn
  // (matching the DXF's getSubwooferXPositions(baffleRunIn, …)) — NOT the full
  // baffle width. ONLY when kerf is active; non-kerf positioning is unchanged.
  const kerfPart = !isDualPort ? cutList.find(p => p.partName === 'Baffle + Port 1') : undefined;
  const kerfGeo = kerfPart?.kerf;
  const isKerf = !!kerfGeo;
  const kerfTBent = kerfGeo ? kerfGeo.bentThicknessIn * S : tBaffle;
  // Flat baffle LEG width = baffleRunIn for kerf (the span the subs sit on),
  // else the full baffle. The subs are distributed across this span (matching
  // the DXF), the leg is rendered exactly this wide, and the bend starts right
  // here — so the cutouts always sit on the flat leg, never riding into the bend.
  const labyrinthSafeSpanW = labyrinthPort.active
    ? Math.max(
      0,
      baffleW
        - pp1Thick
        - Math.max(0, labyrinthPort.panels.length - 1) * labyrinthPort.lanePitch * S,
    )
    : baffleW;
  const subSpanW = kerfGeo
    ? kerfGeo.baffleRunIn * S
    : labyrinthSafeSpanW;

  const baffleHoleRadius = isFlushMount && outsideDiameter > 0
    ? ((outsideDiameter + 0.25) / 2) * S
    : cutR;
  const baffleHoles: { cx: number; cy: number; r: number; outline?: ProfilePoint[] }[] = [];
  const subCenterXPositions: number[] = []; // World-coord X centers of subs — shared with the sub-mount plate.
  if (!isSubsUp && subCutoutDiameter > 0 && cutR > 0) {
    const positions = profileBaffleCenters(inputs,calculations,cutList).map(p=>({x:p.x*S,y:p.y*S}));
    for (const point of positions) {
      const worldCx = baffleStartX + point.x;
      baffleHoles.push({ cx: worldCx, cy: t + point.y, r: baffleHoleRadius, outline:inputs.subwooferCutoutProfile?(isFlushMount?frameProfile(inputs.subwooferCutoutProfile,.125):inputs.subwooferCutoutProfile.opening).map(p=>({x:p.x*S,y:p.y*S})):undefined });
      subCenterXPositions.push(worldCx);
    }
  }

  // Round flared port: one hole per tube, after the driver holes (drivers index
  // baffleHoles by position). The hole shown is the full mouth of the flare, the
  // room it takes on the baffle; how the flare is fixed there is a build detail.
  if (roundPort && !roundPortSide && !isSubsUp) {
    const holeR = (roundPort.geometry.flareOutsideDiameterIn / 2) * S;
    for (const center of roundPort.centers) {
      baffleHoles.push({ cx: baffleStartX + center.x * S, cy: t + center.y * S, r: holeR });
      panels.push(
        <RoundPortTube key={`round-port-${center.y.toFixed(3)}`} layout={roundPort}
          position={[baffleStartX + center.x * S, t + center.y * S, 0]}
          color={partMode ? PART_COLORS.port1 : ROUND_PORT_COLOR} />
      );
    }
  }

  const hasBaffleHoles = baffleHoles.length > 0;

  // Kerf merged piece: render the baffle leg (narrowed to the bend tangent,
  // keeps the real sub cutouts at their baffleRunIn positions) + the bent
  // corner/PP1 piece, and skip the flat PP1 render below. Single slot port only
  // (the kerf gate guarantees it). Detection consts are computed above.
  if (hasBaffleHoles && isKerf) {
    // Treated as the baffle for color + X-Ray.
    panels.push(
      <BaffleWithCutouts key="baffle"
        baffleW={subSpanW} intH={intH} tBaffle={kerfTBent} t={t}
        holes={baffleHoles}
        color={getColor('baffle')} opacity={getOpacity('baffle')}
        texture={vTexture} useTexture={useGrain}
        isDualPort={false} boxW={boxW}
        trimLeft={false}
        showEdges={!hideExteriorEdges}
        showHoleRings={!showDriver}
        debugMode={debugMode} />
    );
    panels.push(
      <KerfBentPortPiece key="baffle-port1-bend"
        legEndX={subSpanW} baffleW={baffleW} pp1BackZ={tBaffle + pp1Depth}
        tBent={kerfTBent}
        t={t} intH={intH}
        color={getColor('baffle')} opacity={getOpacity('baffle')}
        texture={vTexture} useTexture={useGrain} />
    );
  } else if (hasBaffleHoles) {
    // Baffle with cutout holes (matches desktop AddBaffleMeshWithHoles)
    panels.push(
      <BaffleWithCutouts key="baffle"
        baffleW={baffleW} intH={intH} tBaffle={tBaffle} t={t}
        holes={baffleHoles}
        color={getColor('baffle')} opacity={getOpacity('baffle')}
        texture={vTexture} useTexture={useGrain}
        isDualPort={isDualPort} boxW={boxW}
        trimLeft={roActive && !isDualPort}
        trimRight={roActive && !!roundPort}
        showEdges={!hideExteriorEdges}
        showHoleRings={!showDriver}
        debugMode={debugMode} />
    );
  } else if (windowHostPart === 'Baffle') {
    // Acrylic window on the SUPB Baffle — punch a real rectangular hole.
    // Baffle local frame: X = [0, baffleW], Y = [0, intH], Z = [0, tBaffle].
    // Group position offsets to baffle's bottom-front-left corner; default
    // rotation (extrude along +Z) matches baffle thickness direction.
    const baffleStartXRect = isDualPort ? (boxW / 2 - baffleW / 2) : 0;
    panels.push(
      <PanelWithRectHole key="baffle"
        panelW={baffleW} panelH={intH} panelT={tBaffle}
        cutoutCx={baffleW / 2 + windowCutXOffSc}
        cutoutCy={intH / 2 + windowCutYOffSc}
        cutoutW={windowCutWSc}
        cutoutH={windowCutHSc}
        cutoutCornerRadius={windowCornerRadiusSc}
        position={[baffleStartXRect, t, 0]}
        color={getColor('baffle')} opacity={getOpacity('baffle')}
        texture={vTexture} useTexture={useGrain}
        showEdges={!hideExteriorEdges} />
    );
  } else if (isDualPort) {
    panels.push(
      <TexturedPanel key="baffle" position={[boxW / 2, t + intH / 2, tBaffle / 2]} size={[baffleW, intH, tBaffle]}
        color={getColor('baffle')} opacity={getOpacity('baffle')} texture={vTexture} useTexture={useGrain}
        thicknessAxis="z" plyEdgeTexture={pickPlyEdge(tBaffle)}
        showEdges={!hideExteriorEdges} />
    );
  } else if (roActive && getOpacity('baffle') > 0) {
    panels.push(
      <TrimmedVerticalPanel key="baffle"
        W={baffleW} H={intH} D={tBaffle} R={roR}
        // a round-port baffle spans the box, so its right front corner is rounded too
        // (reached only with the port in the side and no driver hole in the baffle)
        trimCorners={[true, !!roundPort, false, false]}
        position={[0, t, 0]}
        color={getColor('baffle')} opacity={getOpacity('baffle')} texture={vTexture} useTexture={useGrain} />
    );
  } else {
    panels.push(
      <TexturedPanel key="baffle" position={[baffleW / 2, t + intH / 2, tBaffle / 2]} size={[baffleW, intH, tBaffle]}
        color={getColor('baffle')} opacity={getOpacity('baffle')} texture={vTexture} useTexture={useGrain}
        thicknessAxis="z" plyEdgeTexture={pickPlyEdge(tBaffle)}
        showEdges={!hideExteriorEdges} />
    );
  }

  // ─── Sub-mount plate (flush mount only) ─────────────────────────────────
  // Sits glued to the back face of the structural baffle, centered
  // horizontally within its footprint (narrower than the baffle by 2× wall
  // thickness so it slips between Side Left and Port Piece 1). Carries the
  // standard sub through-cutout (the recess hole is on the structural
  // baffle in front). No joinery to side panels — interior glue-up part.
  // SBPB / SUPP only.
  if (isFlushMount && hasBaffleHoles && tSubMountPlate > 0) {
    // Plate is narrower than the baffle by one wall thickness on each side
    // (with a tiny tolerance) — matches the engine's cut list math.
    const plateOffsetIn = (useHeavy ? thickFlushThicknessIn : thinFlushThicknessIn) + 0.01;
    const plateW = baffleW - (plateOffsetIn * 2) * S;
    const plateGapX = (baffleW - plateW) / 2;
    const plateWorldStartX = baffleStartX + plateGapX;
    // Holes share the same world X as the baffle's recess holes (plate is
    // centered behind, so cutout centers align). Convert to plate-local
    // coords for BaffleWithCutouts (which subtracts its own internal
    // baffleStartX = 0 when we pass isDualPort=false).
    const plateHoles = baffleHoles.map(hole => ({
      cx: hole.cx - plateWorldStartX,
      cy: hole.cy,
      r: cutR,
      outline: inputs.subwooferCutoutProfile?.opening.map(p=>({x:p.x*S,y:p.y*S})),
    }));
    panels.push(
      <group key="sub-mount-plate" position={[plateWorldStartX, 0, tBaffle]}>
        <BaffleWithCutouts
          baffleW={plateW} intH={intH} tBaffle={tSubMountPlate} t={t}
          holes={plateHoles}
          color={getColor('baffle')} opacity={getOpacity('baffle')}
          texture={vTexture} useTexture={useGrain}
          isDualPort={false} boxW={plateW}
          trimLeft={false}
          showEdges={!hideExteriorEdges}
          showHoleRings={!showDriver}
          debugMode={debugMode}
        />
      </group>,
    );
  }

  // Left side panel: spans from baffle to back (with terminal cup cutout if
  // the user / config chose Side Left as the terminal's panel).
  const leftOpacity = getOpacity('left');
  if (terminalOnLeft && leftOpacity > 0) {
    panels.push(
      <SideLeftTerminalPreview key="left"
        width={sideDepth} height={intH} thickness={t} frontInset={leftStart} floorInset={t}
        scale={S} offset={terminalXOffsetSc} rotated={isSubsUpPortUp}
        roundoverRadius={showRoundover && xrayMode === 'off' ? ROUNDOVER_R * S : 0}
        color={getColor('left')} opacity={leftOpacity}
        texture={useGrain ? albedoOf(vTexture) : undefined} showEdges={!hideExteriorEdges} />
    );
  } else if (roActive && leftOpacity > 0) {
    // Use TrimmedVerticalPanel with no trims to avoid Z-fighting cap faces
    panels.push(
      <TrimmedVerticalPanel key="left"
        W={t} H={intH} D={sideDepth} R={roR}
        trimCorners={[false, false, false, false]}
        position={[0, t, leftStart]}
        color={getColor('left')} opacity={leftOpacity} texture={vTexture} useTexture={useGrain} />
    );
  } else {
    panels.push(
      <TexturedPanel key="left" position={[t / 2, t + intH / 2, leftStart + sideDepth / 2]} size={[t, intH, sideDepth]}
        color={getColor('left')} opacity={leftOpacity} texture={vTexture} useTexture={useGrain}
        thicknessAxis="x" plyEdgeTexture={pickPlyEdge(t)}
        showEdges={!hideExteriorEdges} />
    );
  }

  // Right side panel: full depth minus back panel (horizontal grain — matching desktop)
  // Desktop: trimFrontAtXmax=true (front face at X=boxW gets trimmed).
  // In the desktop's local coordinate system, the right side panel spans:
  //   X: boxW-t to boxW,  Y(depth): 0 to sideDepth,  Z(height): t to t+intH
  //   trimFrontAtXmax means: front face (Y=0) at the X=boxW edge
  // In the web's local panel coords (origin at panel corner, X=thickness, Z=depth):
  //   The "front" of the right side panel is Z=0 (the enclosure front face).
  //   The trimmed corner is at X=W (outer face, X=boxW), Z=0 (front).
  //   That maps to trimCorners[1] = front-right.
  const rightSideDepth = getCutListWidth('Side Right', inputs.boxDepth - joint.backMate) * S;
  // Round flared port: the right side sits behind the baffle exactly as the left does,
  // so the front corner belongs to the baffle.
  const rightStart = roundPort ? frontMate : 0;
  if (roundPort && roundPortSide) {
    // Round flared port in the right side: the panel carries one hole per tube. It is the
    // baffle's hole-cutting panel turned a quarter turn, so its outside face is the box's
    // right face and its length runs front to back. The tubes use the same turn: mouth and
    // flange on the outside face, the tube across the box, an elbow toward the baffle.
    const holeR = (roundPort.geometry.holeDiameterIn / 2) * S;
    const axisZ = roundPortSide.axisDepthIn * S;
    const sideHoles = roundPort.centers.map(center => ({ cx: axisZ - rightStart, cy: t + center.y * S, r: holeR }));
    panels.push(
      <group key="right" position={[boxW, 0, rightStart]} rotation={ROUND_PORT_SIDE_ROTATION}>
        <BaffleWithCutouts
          baffleW={rightSideDepth} intH={intH} tBaffle={t} t={t}
          holes={sideHoles}
          color={getColor('right')} opacity={getOpacity('right')}
          texture={hTexture} useTexture={useGrain}
          isDualPort={false} boxW={rightSideDepth}
          trimLeft={false}
          showEdges={!hideExteriorEdges}
          showHoleRings={false} />
      </group>,
    );
    for (const center of roundPort.centers) {
      panels.push(
        <RoundPortTube key={`round-port-side-${center.y.toFixed(3)}`} layout={roundPort}
          position={[boxW, t + center.y * S, axisZ]} rotation={ROUND_PORT_SIDE_ROTATION}
          color={partMode ? PART_COLORS.port1 : ROUND_PORT_COLOR} />
      );
    }
  } else if (roActive && getOpacity('right') > 0) {
    panels.push(
      <TrimmedVerticalPanel key="right"
        W={t} H={intH} D={rightSideDepth} R={roR}
        trimCorners={[false, !roundPort, false, false]}
        position={[boxW - t, t, rightStart]}
        color={getColor('right')} opacity={getOpacity('right')} texture={hTexture} useTexture={useGrain} />
    );
  } else {
    panels.push(
      <TexturedPanel key="right" position={[boxW - t / 2, t + intH / 2, rightStart + rightSideDepth / 2]} size={[t, intH, rightSideDepth]}
        color={getColor('right')} opacity={getOpacity('right')} texture={hTexture} useTexture={useGrain}
        thicknessAxis="x" plyEdgeTexture={pickPlyEdge(t)}
        showEdges={!hideExteriorEdges} />
    );
  }

  // ─── Port pieces ───

  // Port grain: vertical (matching desktop). Only textured in normal birch mode (not part mode).
  const portUseGrain = useGrain && !partMode;
  // Port body color: COLORS.port (blue) was designed for the Birch case where
  // the wood-grain texture overrides it visually. On MDF (no grain), the blue
  // came through and looked wrong. Use the MDF body color when material is MDF
  // so X-Ray Top shows the port pieces in matching brown instead of blue.
  const portBodyColor = useMdf ? COLORS.mdf : COLORS.port;

  // Helper: use TrimmedVerticalPanel (no trims) when roActive to avoid Z-fighting cap faces
  const VertPanel = ({ k, pos, sz, clr, opac, tex, useTex, thickAxis, plyEdge }: {
    k: string; pos: [number,number,number]; sz: [number,number,number];
    clr: string; opac: number; tex: THREE.Texture | MaterialTexturePack | null; useTex: boolean;
    thickAxis?: 'x' | 'y' | 'z'; plyEdge?: THREE.Texture | null;
  }) => roActive ? (
    <TrimmedVerticalPanel key={k} W={sz[0]} H={sz[1]} D={sz[2]} R={roR}
      trimCorners={[false,false,false,false]} position={[pos[0]-sz[0]/2, pos[1]-sz[1]/2, pos[2]-sz[2]/2]}
      color={clr} opacity={opac} texture={tex} useTexture={useTex} />
  ) : (
    <TexturedPanel key={k} position={pos} size={sz}
      color={clr} opacity={opac} texture={tex} useTexture={useTex}
      thicknessAxis={thickAxis} plyEdgeTexture={plyEdge}
      showEdges={!hideExteriorEdges} />
  );

  // Port pieces use cut list dimensions (pp1Depth, pp2PanelWidth) matching desktop GetCutListDimension
  if (isDualPort) {
    const lpp1X = t + pW + pp1Thick / 2;
    panels.push(<VertPanel k="pp1l" pos={[lpp1X, t+intH/2, frontMate+pp1Depth/2]} sz={[pp1Thick, intH, pp1Depth]}
      clr={partMode ? PART_COLORS.port1 : portBodyColor} opac={getOpacity('port1')} tex={vTexture} useTex={portUseGrain}
      thickAxis="x" plyEdge={pickPlyEdge(pp1Thick)} />);
    const rpp1X = boxW - t - pW - pp1Thick / 2;
    panels.push(<VertPanel k="pp1r" pos={[rpp1X, t+intH/2, frontMate+pp1Depth/2]} sz={[pp1Thick, intH, pp1Depth]}
      clr={partMode ? PART_COLORS.port1 : portBodyColor} opac={getOpacity('port1')} tex={vTexture} useTex={portUseGrain}
      thickAxis="x" plyEdge={pickPlyEdge(pp1Thick)} />);
  } else if (!isKerf && !roundPort) {
    // Kerf merges PP1 into the bent "Baffle + Port 1" piece — skip the flat PP1.
    // A round flared port has no port panels at all.
    const pp1X = baffleW - pp1Thick / 2;
    panels.push(<VertPanel k="pp1" pos={[pp1X, t+intH/2, frontMate+pp1Depth/2]} sz={[pp1Thick, intH, pp1Depth]}
      clr={partMode ? PART_COLORS.port1 : portBodyColor} opac={getOpacity('port1')} tex={vTexture} useTex={portUseGrain}
      thickAxis="x" plyEdge={pickPlyEdge(pp1Thick)} />);
  }

  if (pp2Configs.length > 0) {
    for (const cfg of pp2Configs) {
      if (roActive && getOpacity('port2') > 0) {
        panels.push(
          <TrimmedVerticalPanel
            key={cfg.key}
            W={pp2PanelWidth}
            H={intH}
            D={pp1Thick}
            R={roR}
            trimCorners={cfg.trimCorners}
            position={cfg.origin}
            color={partMode ? PART_COLORS.port2 : portBodyColor}
            opacity={getOpacity('port2')}
            texture={vTexture}
            useTexture={portUseGrain}
          />
        );
      } else {
        panels.push(
          <TexturedPanel
            key={cfg.key}
            position={cfg.position}
            size={[pp2PanelWidth, intH, pp1Thick]}
            color={partMode ? PART_COLORS.port2 : portBodyColor}
            opacity={getOpacity('port2')}
            texture={vTexture}
            useTexture={portUseGrain}
            thicknessAxis="z"
            plyEdgeTexture={pickPlyEdge(pp1Thick)}
            showEdges={!hideExteriorEdges}
          />
        );
      }
    }
  }

  // Automatic labyrinth: PP2+ run parallel to PP1 and alternate front/back
  // anchoring. This is the same panel sequence emitted by the cut list.
  if (labyrinthPanelConfigs.length > 0) {
    for (const cfg of labyrinthPanelConfigs) {
      panels.push(
        <VertPanel
          k={cfg.key}
          pos={cfg.position}
          sz={cfg.size}
          clr={partMode ? PART_COLORS.port2 : portBodyColor}
          opac={getOpacity('port2')}
          tex={vTexture}
          useTex={portUseGrain}
          thickAxis="x"
          plyEdge={pickPlyEdge(pp1Thick)}
        />
      );
    }
  }

  // ─── Port cavity paint liner ───
  // Operators spray-paint the inside of the port black on every shipped
  // enclosure, so render a thin matte-black coating on the port channel's
  // interior walls. Single slot port (one channel between the baffle's right
  // edge / PP1 and the Side Right wall). Painted: PP1 port face + baffle right
  // edge (left wall), Side Right inner face (right wall), and the port-width
  // strips of the Back / Top / Bottom inner faces. PP2 and every non-cavity
  // surface stay wood. Each box is centered ON its wall (half embedded in the
  // panel, half in the cavity) so only its cavity-facing face shows — no
  // Z-fighting. Skipped in part-color mode, and for dual port / sealed boxes.
  if (!partMode && !isDualPort && pW > 0 && !labyrinthPort.active && !roundPort) {
    const lt = 0.06 * S;                  // thin coating; only its inner face is visible
    const colX0 = baffleW;                // left wall: baffle right edge + PP1 face
    const colX1 = boxW - t;               // right wall: Side Right inner face
    const colW = colX1 - colX0;           // port channel width (≈ port width)
    const colYb = tBottom;                // bottom inner face
    const colYt = tBottom + intH;         // top inner face
    const colZback = boxD - tBack;        // back inner face
    const colZleft = tBaffle + pp1Depth;  // left wall runs only as deep as PP1
    const cx = (colX0 + colX1) / 2;
    const cy = (colYb + colYt) / 2;
    const czFull = colZback / 2;
    // Only the BACK wall gets the wider painted patch (the port mouth opens up
    // there): 1.5× port width, anchored at the Side Right wall, extending toward
    // the chamber (clamped to the interior). Top / bottom / left / right stay at
    // the channel width so the paint doesn't bleed onto the chamber ceiling/floor.
    const wideW = Math.min(1.5 * pW, boxW - 2 * t);
    const wideCx = colX1 - wideW / 2;
    // Glossy black (NOT satin) + the wood NORMAL map as surface texture. The
    // scene's environment lighting is low, so a satin/matte finish diffuses what
    // little light there is into a flat black mass; a shinier surface (low
    // roughness) throws sharp specular highlights from the direct lights that
    // reveal the walls + curve, and the normal-map bumps catch those highlights
    // so the grain reads too. Albedo stays black; only normals add relief.
    const paintNormal = isTexturePack(vTexture) ? vTexture.normal : undefined;
    const portPaint = (key: string, pos: [number, number, number], size: [number, number, number]) => (
      <mesh key={key} position={pos}>
        <boxGeometry args={size} />
        <meshStandardMaterial color="#1c1c1c" roughness={0.28} metalness={0}
          normalMap={paintNormal} normalScale={[0.4, 0.4]} envMapIntensity={1.3} />
      </mesh>
    );
    if (isKerf && kerfGeo) {
      // Kerf: the left port wall is the curved bend up front, then the flat PP1
      // leg behind it. Paint the convex arc (rounded mouth) + a flat strip on
      // the PP1 face behind the bend. legEndX = subSpanW; the bend's outer
      // radius = baffleW − legEndX.
      const span = baffleW - subSpanW;
      panels.push(
        <KerfPortPaintCurve key="port-paint-left-curve"
          legEndX={subSpanW} span={span} yb={colYb} yt={colYt} offset={lt * 0.5} normalMap={paintNormal} />
      );
      const flatDepth = colZleft - span;
      if (flatDepth > 0) {
        panels.push(portPaint('port-paint-left', [colX0, cy, (span + colZleft) / 2], [lt, intH, flatDepth]));
      }
    } else {
      panels.push(portPaint('port-paint-left',   [colX0, cy, colZleft / 2], [lt, intH, colZleft]));
    }
    panels.push(portPaint('port-paint-right',  [colX1, cy, czFull],       [lt, intH, colZback]));
    panels.push(portPaint('port-paint-back',   [wideCx, cy, colZback],    [wideW, intH, lt]));
    panels.push(portPaint('port-paint-top',    [cx, colYt, czFull],       [colW, lt, colZback]));
    panels.push(portPaint('port-paint-bottom', [cx, colYb, czFull],       [colW, lt, colZback]));
  }

  // ─── Gussets ───

  // Gusset grain: vertical (matching desktop)
  const gussetUseGrain = useGrain && !partMode;

  if (gussetCount > 0) {
    // SUPB single-port multi-sub: gusset is a free-standing column
    // dowelled to Top + Bottom only (NOT touching the baffle). Centered
    // on the sub Z (depth) so it sits directly under the subs above.
    // X uses the chamber-frame midpoint between adjacent subs, matching
    // the dxf-generator's gusset dowel positions.
    // Everything else (SBPB any duty, SUPB dual-port edge case) keeps the
    // legacy path (gusset glued to back of baffle / Sub Mount Plate).
    const useSupbStandalone = isSubsUpPortBackCfg;
    if (useSupbStandalone) {
      if (displayedSupbLayout) {
        for (let i = 0; i < displayedSupbLayout.gussets.length; i++) {
          const gusset = displayedSupbLayout.gussets[i];
          panels.push(<VertPanel key={`gusset${i}`}
            k={`gusset${i}`}
            pos={[gusset.x * S, t + intH / 2, gusset.y * S]}
            sz={[t, intH, gussetDepth]}
            clr={partMode ? PART_COLORS.gusset : COLORS.gusset}
            opac={getOpacity('gusset')}
            tex={vTexture} useTex={gussetUseGrain} />);
        }
      } else if (!suppressSupbFallback) {
      const subCount_local = gussetCount + 1;
      const od_in = outsideDiameter > 0 ? outsideDiameter : subCutoutDiameter;
      const s2EdgeClearanceIn = subCount_local > 0
        ? (s2LeftWidth - od_in * subCount_local) / (subCount_local + 1)
        : 0;
      const useCombined = s2EdgeClearanceIn <= 0;
      const chamberW_in = useCombined ? (s2LeftWidth + s1RightWidth) : s2LeftWidth;
      const s1Depth_in = useCombined
        ? Math.max(0, boxDepth - 2 * (t / S) - portWidth - (t / S))
        : 0;
      const cyEffIn = resolveSupbAutoCenterY({
        boxDepth,
        portWidth,
        wallT: t / S,
        tBaffle: t / S,
        tBack: t / S,
        s1Depth: s1Depth_in,
        useCombined,
        halfOD: od_in / 2,
        halfCutout: subCutoutDiameter / 2,
      });
      const subYOffSc = (inputs.subwooferYOffset ?? 0) * S;
      const subZ = cyEffIn * S + subYOffSc;
      const subXOffSc = (inputs.subwooferXOffset ?? 0) * S;
      // Sub X centers in chamber frame (single-port SUPB chamberLeftEdge = t).
      const chamberW_sc = chamberW_in * S;
      const subOdSc = od_in * S;
      const gap = (chamberW_sc - subOdSc * subCount_local) / (subCount_local + 1);
      const subXs: number[] = [];
      for (let j = 0; j < subCount_local; j++) {
        subXs.push(t + gap * (j + 1) + subOdSc * (j + 0.5) + subXOffSc);
      }
      for (let i = 0; i < gussetCount; i++) {
        const gxPos = (subXs[i] + subXs[i + 1]) / 2;
        panels.push(<VertPanel key={`gusset${i}`}
          k={`gusset${i}`}
          pos={[gxPos, t + intH / 2, subZ]}
          sz={[t, intH, gussetDepth]}
          clr={partMode ? PART_COLORS.gusset : COLORS.gusset}
          opac={getOpacity('gusset')}
          tex={vTexture} useTex={gussetUseGrain} />);
      }
      }
    } else {
      for (let i = 0; i < gussetCount; i++) {
        const gx = !isSubsUpPortBackCfg
        ? baffleBraceCenters(inputs,cutList,calculations)[i]*S : baffleW * (i + 1) / (gussetCount + 1);
        if (!Number.isFinite(gx)) continue;
      const gxPos = (isDualPort ? boxW / 2 - baffleW / 2 + gx : gx) + gussetXShift;
        // Flush mount: gusset glues to the back of the Sub Mount Plate, not
        // the back of the structural baffle. gussetFrontZ already accounts
        // for the plate's thickness when isFlushMount is on.
        panels.push(<VertPanel key={`gusset${i}`}
          k={`gusset${i}`}
          pos={[gxPos, t + intH / 2, gussetFrontZ + gussetDepth / 2]}
          sz={[t, intH, gussetDepth]}
          clr={partMode ? PART_COLORS.gusset : COLORS.gusset}
          opac={getOpacity('gusset')}
          tex={vTexture} useTex={gussetUseGrain} />);
      }
    }
  }

  // ─── Subwoofer cutouts / drivers ───

  const subs: React.ReactElement[] = [];
  // Measured frame outlines sit on the actual mounting plane, sharing each
  // driver's center. They remain visible when Sub is off or a recess hides it.
  const frameOutline = inputs.subwooferCutoutProfile
    ? frameProfile(inputs.subwooferCutoutProfile).map(p => ({ x: p.x * S, y: p.y * S }))
    : holeOutline({ r: (outsideDiameter > 0 ? outsideDiameter : subCutoutDiameter) * S / 2 });
  if (subCutoutDiameter > 0) {
    if (isSubsUp) {
      // SUPB sub spacing matching desktop GetTopCutoutPositions()
      const outsideDia = (outsideDiameter > 0 ? outsideDiameter : subCutoutDiameter) * S;
      const s2w = s2LeftWidth * S;
      const s1w = s1RightWidth * S;
      const cy = boxD / 2; // centered along depth

      let subXPositions: number[];
      let subZ = cy;

      if (isDualPort && !sharedSupbLayout && !inputs.subwooferCutoutProfile && subCount === 1) {
        // Dual Port + Single Sub: center sub on the full top panel
        // The chamber area is centered between the two port channels
        subXPositions = [boxW / 2];
      } else if (isDualPort && !sharedSupbLayout && !inputs.subwooferCutoutProfile && subCount === 2) {
        // Dual Port + Dual Sub: center each sub in its respective chamber
        const leftChamberCenter = t + pW + pp1Thick + (s2w / 2);
        const rightChamberCenter = t + pW + pp1Thick + s2w + tBaffle + (s1w / 2);
        subXPositions = [leftChamberCenter, rightChamberCenter];
      } else {
        if (visibleSupbPoints) {
          subXPositions = visibleSupbPoints.map(point => point.x * S);
          // Driver rendering below historically accepted one shared Z. The
          // staggered path supplies per-driver Z directly in the render loop.
          subZ = visibleSupbPoints[0].y * S;
        } else if (suppressSupbFallback) {
          subXPositions = [];
        } else {
        // Single port: prefer S2 Left; if S2 is too small for the sub, fall back
        // to the combined (S2 + S1) chamber.
        const s2EdgeClearance = (s2w - outsideDia * subCount) / (subCount + 1);
        const useCombined = s2EdgeClearance <= 0;
        const chamberW = useCombined ? (s2w + s1w) : s2w;
        const chamberLeftEdge = t;
        // Y center matches the cutout block above (and the DXF generator):
        // bias toward ≥ 0.5" outer-edge clearance when geometry allows.
        const s1Depth_in_drv = useCombined ? Math.max(0, boxDepth - 2 * (t / S) - portWidth - (t / S)) : 0;
        const cyEffInDrv = resolveSupbAutoCenterY({
          boxDepth,
          portWidth,
          wallT: t / S,
          tBaffle: t / S,
          tBack: t / S,
          s1Depth: s1Depth_in_drv,
          useCombined,
          halfOD: (outsideDiameter > 0 ? outsideDiameter : subCutoutDiameter) / 2,
          halfCutout: subCutoutDiameter / 2,
        });
        subZ = cyEffInDrv * S;
        // User X/Y offsets shift the entire pattern by the same amount.
        const subXOff = (inputs.subwooferXOffset ?? 0) * S;
        const subYOff = (inputs.subwooferYOffset ?? 0) * S;
        subZ += subYOff;
        if (subCount === 1) {
          subXPositions = [chamberLeftEdge + chamberW / 2 + subXOff];
        } else {
          const gap = (chamberW - outsideDia * subCount) / (subCount + 1);
          subXPositions = [];
          for (let j = 0; j < subCount; j++) {
            subXPositions.push(chamberLeftEdge + gap * (j + 1) + outsideDia * (j + 0.5) + subXOff);
          }
        }
        }
      }

      // Flush mount (SUPB): the 18mm cap on top of the box carries the flange
      // recess. Push the driver DOWN by tCap so the flange's underside seats
      // on the top panel's top face (= bottom of cap), and the visible flange
      // sits IN the recess hole on the cap. baffleThickness becomes tCap
      // because the cap is now the panel the flange recesses into.
      const driverY = isFlushMountSupb ? (boxH + 0.001 - tCap) : (boxH + 0.001);
      const driverSeatT = isFlushMountSupb ? tCap : tTop;
      for (let i = 0; i < subXPositions.length; i++) {
        const cx = subXPositions[i];
        const driverZ = visibleSupbPoints
          ? visibleSupbPoints[i].y * S
          : subZ;
        if (dimsMode === 'full' && (inputs.subwooferCutoutProfile || outsideDiameter > 0)) subs.push(
          <CutoutContourLine key={`frame${i}`} points={frameOutline}
            position={[cx, driverY, driverZ]} rotation={[Math.PI / 2, 0, 0]} frameAnnotation />
        );
        if (showDriver) {
          // The failed layout deliberately leaves the wood uncut. Cover the
          // cone footprint visually so the panel does not show through the
          // preview driver; this disc is not a panel hole or CNC coordinate.
          if (previewSupbPoints && !inputs.subwooferCutoutProfile) subs.push(
            <SubCutout key={`preview-face${i}`} position={[cx, driverY + .002, driverZ]}
              rotation={[-Math.PI / 2, 0, 0]} radius={cutR} />
          );
          subs.push(
            inputs.subwooferCutoutProfile ? <ProfileDriver key={`drv${i}`} profile={inputs.subwooferCutoutProfile} position={[cx,driverY,driverZ]} isVertical={false} warning={supbSpacingWarning}
              mountingDepth={driverDepth?.depthIn} tooDeep={driverDepth?.severity === 'fail'}/> : <RealisticDriver key={`drv${i}`}
              position={[cx, driverY, driverZ]}
              radius={cutR}
              visibleDiameter={outsideDia}
              isVertical={false}
              spacingWarning={supbSpacingWarning}
              mountingDepth={driverDepth?.depthIn}
              tooDeep={driverDepth?.severity === 'fail'}
              // SUPB: driver mounts on the Top panel (or 18mm cap when flush).
              baffleThickness={driverSeatT} />
          );
        }
        // When driver is off, the panel cutout hole is already see-through (no disc needed).
      }
    } else {
      // Gap-based spacing formula matching desktop GetCutoutPositions()
      // gap = (baffleW - outsideDia * N) / (N + 1), evenly distributed
      const outsideDia = (outsideDiameter > 0 ? outsideDiameter : subCutoutDiameter) * S;
      const startX = isDualPort ? (boxW / 2 - baffleW / 2) : 0;

      const getSubXPositions = (w: number, n: number, od: number): number[] => {
        if (n === 1) return [w / 2];
        const positions: number[] = [];
        const gap = (w - od * n) / (n + 1);
        for (let j = 0; j < n; j++) {
          positions.push(gap * (j + 1) + od * (j + 0.5));
        }
        return positions;
      };

      // Use subSpanW (= baffleRunIn for kerf, full baffle otherwise) so the
      // driver models line up with the cutouts on the kerf baffle leg — without
      // this, the cutouts move to the leg but the gray drivers stay at the full-
      // width positions and ride into the bend.
      const xPositions = getSubXPositions(subSpanW, subCount, outsideDia);
      // Flush mount: sub mounts to the inner plate, not the structural baffle's
      // front face. Push the driver back by tBaffle (= 18mm) so the flange's
      // rear surface seats against the plate's front face (at z = tBaffle),
      // and the flange itself sits IN the recess hole on the structural
      // baffle. Standard non-flush behavior keeps z = 0 (flange seats on
      // the baffle's front face as today).
      const driverZ = isFlushMount ? tBaffle : 0;
      for (let i = 0; i < subCount; i++) {
        const hole=baffleHoles[i];
        if ((inputs.subwooferPositions !== undefined || inputs.subwooferCutoutProfile) && !hole) continue;
        const cx = hole?.cx ?? startX + xPositions[i];
        const cy = hole?.cy ?? t+intH/2;
        if (dimsMode === 'full' && (inputs.subwooferCutoutProfile || outsideDiameter > 0)) subs.push(
          <CutoutContourLine key={`frame${i}`} points={frameOutline}
            position={[cx, cy, driverZ]} frameAnnotation />
        );
        if (showDriver) {
          subs.push(
            inputs.subwooferCutoutProfile ? <ProfileDriver key={`drv${i}`} profile={inputs.subwooferCutoutProfile} position={[cx,cy,driverZ]} isVertical={true}
              mountingDepth={driverDepth?.depthIn} tooDeep={driverDepth?.severity === 'fail'}/> : <RealisticDriver key={`drv${i}`}
              position={[cx, cy, driverZ]}
              radius={cutR}
              visibleDiameter={outsideDia}
              isVertical={true}
              mountingDepth={driverDepth?.depthIn}
              tooDeep={driverDepth?.severity === 'fail'}
              baffleThickness={tBaffle} />
          );
        }
        // When driver is off, baffle cutout hole is already see-through (matches desktop).
      }
    }
  }

  // ─── Dimension labels (matching desktop DimsMode) ───

  const dims: React.ReactElement[] = [];
  if (dimsMode !== 'off') {
    const offset = 1.5 * S;
    const bw = roundUpToEighth(boxWidth);
    const topPart = cutList.find(p => p.partName === 'Top');
    const widthVal = topPart ? topPart.width : bw;
    const depthVal = topPart ? topPart.height : boxDepth;
    const portHPart = cutList.find(p => p.partName === 'Port Piece 1');
    const portHVal = portHPart ? portHPart.height : (calculations.portHeight || 0);
    const desktopToWeb = (x: number, y: number, z: number): [number, number, number] => [x, z, y];
    const formatFixed3 = (value: number) => `${value.toFixed(3)}"`;
    const formatVariable13 = (value: number) => {
      const [whole, fracRaw] = value.toFixed(3).split('.');
      const frac = fracRaw.replace(/0+$/, '');
      return `${whole}.${frac || '0'}"`;
    };
    // boxCenterLocal: half-extents of the box in inner-group local frame.
    // Inner group transforms internal (0..boxW, 0..boxH, 0..boxD) coords.
    const boxCenterLocal: [number, number, number] = [boxW / 2, boxH / 2, boxD / 2];
    const innerOffset = { x: -boxW / 2, z: boxD / 2 };
    const addDimension = (
      key: string,
      start: [number, number, number],
      end: [number, number, number],
      text: string,
      textColor = COLORS.dimText,
      lineColor = COLORS.dimLine,
      lineDiameter = 0.06 * S,
      fontSize = 14,
    ) => {
      dims.push(
        <VisibleDimension
          key={key}
          start={start}
          end={end}
          text={text}
          textColor={textColor}
          lineColor={lineColor}
          lineDiameter={lineDiameter}
          fontSize={fontSize}
          boxCenterLocal={boxCenterLocal}
          innerOffset={innerOffset}
        />
      );
    };

    const widthText = formatFixed3(widthVal);
    const heightText = formatVariable13(boxHeight);
    const depthText = formatFixed3(depthVal);

    addDimension('dimW1', desktopToWeb(0, -offset, -offset), desktopToWeb(boxW, -offset, -offset), widthText);
    addDimension('dimW2', desktopToWeb(0, boxD + offset, -offset), desktopToWeb(boxW, boxD + offset, -offset), widthText);
    addDimension('dimH1', desktopToWeb(-offset, -offset, 0), desktopToWeb(-offset, -offset, boxH), heightText);
    addDimension('dimH2', desktopToWeb(boxW + offset, -offset, 0), desktopToWeb(boxW + offset, -offset, boxH), heightText);
    addDimension('dimD1', desktopToWeb(-offset, 0, -offset), desktopToWeb(-offset, boxD, -offset), depthText);
    addDimension('dimD2', desktopToWeb(boxW + offset, 0, -offset), desktopToWeb(boxW + offset, boxD, -offset), depthText);

    if (dimsMode === 'all' && portWidth > 0 && portHVal > 0 && !roundPort) {
      const portOffset = offset + 2.0 * S;
      const portTextColor = COLORS.portDimText;
      const portLineColor = COLORS.portDimLine;
      const portLineDiameter = 0.09 * S;

      const pp1RightEdge = baffleW;
      const rightWallInner = boxW - t;
      addDimension(
        'dimPW',
        desktopToWeb(pp1RightEdge, -portOffset, -offset),
        desktopToWeb(rightWallInner, -portOffset, -offset),
        `PW ${formatVariable13(portWidth)}`,
        portTextColor,
        portLineColor,
        portLineDiameter,
        16,
      );

      const phX = baffleW - pp1Thick - (1.0 * S);
      addDimension(
        'dimPH',
        desktopToWeb(phX, -offset, t),
        desktopToWeb(phX, -offset, t + portHVal * S),
        `PH ${formatVariable13(portHVal)}`,
        COLORS.dimText,
        COLORS.dimLine,
        0.06 * S,
        16,
      );

      if (portLength2 > 0 && Number.isFinite(portLength2)) {
        const pp2Width = portLength2 - portWidth;
        if (pp2Width > 0) {
          const pp2RightEdge = baffleW;
          const pp2LeftEdge = pp2RightEdge - pp2Width * S;
          addDimension(
            'dimPL2',
            desktopToWeb(pp2LeftEdge, boxD + portOffset, -offset),
            desktopToWeb(pp2RightEdge, boxD + portOffset, -offset),
            `PL2 ${formatVariable13(portLength2)}`,
            portTextColor,
            portLineColor,
            portLineDiameter,
            16,
          );
        }
      }
    }

    // ─── Dims: Full — extra annotations for image-export reference shots ───
    if (dimsMode === 'full') {
      // Driver frame outlines above follow every actual mounting center.
      // Exact frame/cutout values live in the Full dimensions footer, instead
      // of a diameter leader at box center (incorrect for custom/multiple subs).

      // Roundover radius callout — only when R/O mode is showing the rounded
      // edges. Annotate on the front-top edge so it reads from a front 3/4
      // view. Uses the same radius value the roundover geometry uses.
      if (showRoundover) {
        const roR = ROUNDOVER_R;
        const roText = `R/O ${formatVariable13(roR)}`;
        // Short horizontal callout near the top-front-right corner, lifted
        // slightly above the box edge so the line clears the rounded geometry.
        const yTop = boxH + 0.5 * S;
        const zFront = -offset;  // internal-Z negative -> world +Z (front)
        const xRight = boxW - 4 * S;
        const xRightEnd = boxW - 1 * S;
        addDimension(
          'dimRO',
          desktopToWeb(xRight, zFront, yTop),
          desktopToWeb(xRightEnd, zFront, yTop),
          roText,
          COLORS.dimText,
          COLORS.dimLine,
          0.06 * S,
          14,
        );
      }
    }
  }

  // Panel color for roundovers (same base color, not per-part)
  const panelColor = useMdf ? COLORS.mdf : COLORS.birch;

  return (
    // Outer group: applies the 'Subs Up/Port Up' rotation when selected.
    //   - rotate -π/2 about X tips the box onto its back: original BACK
    //     face (which holds subs + port) ends up facing UP. Sign flipped
    //     from +π/2 after a real-eyes test on the calculator showed the
    //     +π/2 form rotated the box the wrong way (subs + port ended up
    //     facing the floor). Three.js right-hand rule from the camera's
    //     +X-axis view: -π/2 swings the back panel up and over.
    //   - position [0, boxD/2, 0] lifts the rotated box so its new bottom
    //     sits on the y=0 grid plane. Translation is sign-agnostic — both
    //     rotation directions leave the box centered at Y=0 before lift.
    // For 'Subs Back/Port Back' and 'Subs Up/Port Back' the outer group is
    // the identity transform and renders the same as before.
    <group
      rotation={isSubsUpPortUp ? [-Math.PI / 2, 0, 0] : [0, 0, 0]}
      position={isSubsUpPortUp ? [0, boxD / 2, 0] : [0, 0, 0]}
    >
    <group position={[-boxW / 2, 0, boxD / 2]} scale={[1, 1, -1]}>
      {panels}
      {subs}
      {dims}
      {/* Terminal plate — rendered behind whichever panel hosts the cutout. */}
      {terminalOnLeft && (
        <TerminalPlate sideDepth={sideDepth} intH={intH} tBaffle={leftStart} t={t}
          texture={vTexture} useTexture={useGrain}
          xOffsetSc={terminalXOffsetSc}
          rotated={isSubsUpPortUp}
          color={useMdf ? COLORS.mdf : TP_COLOR} />
      )}
      {terminalOnBack && (
        <BackTerminalPlate boxW={boxW} intH={intH} tBack={tBack} boxD={boxD} t={t}
          texture={vTexture} useTexture={useGrain}
          xOffsetSc={terminalXOffsetSc}
          color={useMdf ? COLORS.mdf : TP_COLOR} />
      )}
      {terminalOnTop && (
        // Reorient the same plate onto Top's inner face. Its local up points
        // toward the baffle, which becomes physical up after the SUPP rotation.
        <group position={[0, boxH - tCap, boxD]} rotation={[-Math.PI / 2, 0, 0]}>
          <BackTerminalPlate boxW={boxW} intH={intH} tBack={tTop} boxD={0} t={0}
            centerHeightSc={boxD - topTerminal.y * S}
            texture={hTexture} useTexture={useGrain} xOffsetSc={terminalXOffsetSc}
            color={useMdf ? COLORS.mdf : TP_COLOR} />
        </group>
      )}
      {/* No-go band overlay — visualizes PP1/PP2 conflict zones on the chosen
          terminal panel when the operator has opted into customization.
          hasTerminal is already false when terminalPanel === 'None', but we
          re-check terminalPanelChoice here so TS narrows the prop type. */}
      {terminalIsCustomized && hasTerminal && (terminalPanelChoice === 'Side Left' || terminalPanelChoice === 'Back') && (
        <NoGoBandOverlay
          panel={terminalPanelChoice}
          bands={noGoBands}
          boxW={boxW} boxD={boxD} intH={intH}
          t={t} tBack={tBack} tBaffle={tBaffle}
          scale={S}
        />
      )}
      {/* PP2 roundovers (3 vertical edges, matching desktop AddSinglePortChannel) */}
      {showRoundover && xrayMode === 'off' && pp2RoundoverGeo && (
        <mesh geometry={pp2RoundoverGeo}>
          <meshStandardMaterial
            color={portUseGrain ? '#ffffff' : darkenColor(partMode ? PART_COLORS.port2 : portBodyColor)}
            map={portUseGrain ? albedoOf(vTexture) : undefined}
            side={THREE.DoubleSide} />
        </mesh>
      )}
      {/* PP2 tangent lines */}
      {showRoundover && xrayMode === 'off' && pp2TangentLines.map((l, i) => (
        <DimLine key={`pp2tl${i}`} start={l.start} end={l.end} color={TANGENT_COLOR} />
      ))}
      {/* Gusset roundovers (2 back edges per gusset, matching desktop) */}
      {showRoundover && xrayMode === 'off' && gussetRoundoverGeo && (
        <mesh geometry={gussetRoundoverGeo}>
          <meshStandardMaterial
            color={gussetUseGrain ? '#ffffff' : darkenColor(partMode ? PART_COLORS.gusset : COLORS.gusset)}
            map={gussetUseGrain ? albedoOf(vTexture) : undefined}
            side={THREE.DoubleSide} />
        </mesh>
      )}
      {/* Gusset tangent lines */}
      {showRoundover && xrayMode === 'off' && gussetTangentLines.map((l, i) => (
        <DimLine key={`gtl${i}`} start={l.start} end={l.end} color={TANGENT_COLOR} />
      ))}
      {/* Roundovers on exterior edges (hidden during X-Ray, matching desktop) */}
      {showRoundover && xrayMode === 'off' && debugMode !== 'noRoundover' && (
        <Roundovers
          boxW={boxW}
          boxH={boxH}
          boxD={boxD}
          color={panelColor}
          useGrain={useGrain}
          texture={hTexture}
          showEdges={debugMode !== 'noRoEdges'}
          showCorners={debugMode !== 'noRoCorners'}
        />
      )}
      {/* Acrylic window plate (V1 — surface plate, no hole-punch through the
          host panel yet; that's V2). The plate sits UNDERNEATH the wood
          panel — on the INNER face, inside the chamber. Hidden from the
          exterior view by the wood; only visible when X-Ray peels the
          wood away (or, in V2, when a real hole is punched). */}
      {inputs.windowEnabled && inputs.windowSize && (() => {
        // Plate dims come from the shared computation at the top of the
        // viewer (size tier auto-shrunk to the host panel's safe area).
        // Same numbers the DXF generator and cut list use, so the visible
        // plate matches what gets cut.
        const winW = windowPlateWSc;
        const winH = windowPlateHSc;
        // Same effective offsets the cutout hole uses (saved clamped to
        // safe range) so the plate sits over the wood hole, not next to it.
        const effOff2 = resolveEffectiveWindowOffsets(inputs, calculations, cutList);
        const xOff = effOff2.x * S;
        const yOff = effOff2.y * S;
        const epsilon = 0.005;
        // Acrylic gauge: 1/4" SD/RD, 3/8" HD. Convert to scene units.
        const isHD = enclosureType.includes('Heavy');
        const acrylicThicknessIn = isHD ? 0.375 : 0.25;
        const plateThickness = acrylicThicknessIn * S;

        if (isSubsUpPortBackCfg) {
          // SUPB → Baffle. Baffle spans Z = [0, tBaffle]. "Underneath" the
          // baffle from the exterior view (looking forward → -Z) is the
          // chamber side. Plate sits just inside the inner face of the
          // baffle, at Z = tBaffle + plateThickness/2 + epsilon.
          return (
            <AcrylicWindowMesh
              position={[boxW / 2 + xOff, t + intH / 2 + yOff, tBaffle + plateThickness / 2 + epsilon]}
              rotation={[0, 0, 0]}
              width={winW} height={winH} thickness={plateThickness}
            />
          );
        }
        if (isSubsUpPortUp) {
          // SUPU → Bottom. Bottom panel spans Y = [0, tBottom]. "Underneath"
          // from the visible (rotated-bottom-as-front) view is the chamber
          // side. Plate sits just above the inner face of the Bottom, at
          // Y = tBottom + plateThickness/2 + epsilon.
          return (
            <AcrylicWindowMesh
              position={[boxW / 2 + xOff, tBottom + plateThickness / 2 + epsilon, boxD / 2 + yOff]}
              rotation={[Math.PI / 2, 0, 0]}
              width={winW} height={winH} thickness={plateThickness}
            />
          );
        }
        // SBPB → Top. Top panel spans Y = [boxH - tTop, boxH]. "Underneath"
        // the top from the exterior (looking down → -Y) is the chamber side.
        // Plate sits just below the inner face of the Top, at
        // Y = (boxH − tTop) − plateThickness/2 − epsilon.
        return (
          <AcrylicWindowMesh
            position={[boxW / 2 + xOff, (boxH - tTop) - plateThickness / 2 - epsilon, boxD / 2 + yOff]}
            rotation={[-Math.PI / 2, 0, 0]}
            width={winW} height={winH} thickness={plateThickness}
          />
        );
      })()}

      {/* Logo debossing: SBPB logo is on top panel (hide in any X-Ray mode).
          SUPB logo is on baffle front face (show in X-Ray Top since baffle stays visible).
          When the acrylic window is enabled on the SAME panel that hosts the
          logo, hide the logo — the window cutout would either remove the
          debossed area or visually conflict.
            SBPB: window on Top conflicts with logo on Top
            SUPB: window on Baffle conflicts with logo on Baffle
            SUPU: logo is on Bottom, window is also on Bottom — same conflict
          So: hide the logo whenever the window is enabled. */}
      {logoEpsContent && !inputs.windowEnabled && (isSubsUp ? xrayMode !== 'exterior' : xrayMode === 'off') && (
        <LogoDebossing
          epsContent={logoEpsContent}
          boxW={boxW} boxH={boxH} boxD={boxD}
          baffleW={baffleW} intH={intH} tBaffle={tBaffle} t={t}
          isSubsUp={isSubsUp} isSubsUpPortUp={isSubsUpPortUp} isDualPort={isDualPort}
        />
      )}
    </group>
    </group>
  );
}

// ─── Dimension Label (HTML overlay via drei) ─────────────────────────────────

function DimLabel({
  position,
  text,
  color = COLORS.dimText,
  fontSize = 14,
}: {
  position: [number, number, number];
  text: string;
  color?: string;
  fontSize?: number;
}) {
  const canvas = useMemo(() => {
    const fontPx = fontSize * 2;
    const padX = 8;
    const padY = 4;
    const probe = document.createElement('canvas');
    const probeCtx = probe.getContext('2d')!;
    probeCtx.font = `${fontPx}px Segoe UI, Arial, sans-serif`;
    const measured = Math.ceil(probeCtx.measureText(text).width);
    const logicalWidth = Math.max(96, measured + padX * 2);
    const logicalHeight = Math.max(32, Math.ceil(fontPx * 1.35) + padY * 2);
    const dpr = 2;
    const c = document.createElement('canvas');
    c.width = logicalWidth * dpr;
    c.height = logicalHeight * dpr;
    const ctx = c.getContext('2d')!;
    ctx.scale(dpr, dpr);
    ctx.fillStyle = 'rgba(255,255,255,0.94)';
    ctx.fillRect(0, 0, logicalWidth, logicalHeight);
    ctx.fillStyle = color;
    ctx.font = `${fontPx}px Segoe UI, Arial, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, logicalWidth / 2, logicalHeight / 2);
    return { canvas: c, logicalWidth, logicalHeight };
  }, [text, color, fontSize]);

  const texture = useMemo(() => {
    const tex = new THREE.CanvasTexture(canvas.canvas);
    tex.needsUpdate = true;
    return tex;
  }, [canvas]);

  return (
    <sprite
      position={position}
      renderOrder={1000}
      scale={[canvas.logicalWidth * 0.0016, canvas.logicalHeight * 0.0016, 1]}
    >
      <spriteMaterial map={texture} transparent depthTest depthWrite={false} />
    </sprite>
  );
}

// ─── Dimension Line (thin line between two points, matching desktop) ─────────

function DimLine({ start, end, color = COLORS.dimLine }: {
  start: [number, number, number];
  end: [number, number, number];
  color?: string;
}) {
  const points = useMemo(() => [
    new THREE.Vector3(...start),
    new THREE.Vector3(...end),
  ], [start, end]);

  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    return geo;
  }, [points]);

  return (
    <line>
      <primitive object={geometry} attach="geometry" />
      <lineBasicMaterial color={color} />
    </line>
  );
}

function DimensionStroke({
  start,
  end,
  color = COLORS.dimLine,
  diameter = 0.06 * S,
}: {
  start: [number, number, number];
  end: [number, number, number];
  color?: string;
  diameter?: number;
}) {
  const meshData = useMemo(() => {
    const a = new THREE.Vector3(...start);
    const b = new THREE.Vector3(...end);
    const delta = new THREE.Vector3().subVectors(b, a);
    const length = delta.length();
    if (length <= 1e-6) return null;
    const midpoint = new THREE.Vector3().addVectors(a, b).multiplyScalar(0.5);
    const quaternion = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      delta.normalize(),
    );
    return { midpoint, quaternion, length };
  }, [start, end]);

  if (!meshData) return null;

  return (
    <mesh position={meshData.midpoint} quaternion={meshData.quaternion} renderOrder={1000}>
      <cylinderGeometry args={[diameter / 2, diameter / 2, meshData.length, 10]} />
      <meshBasicMaterial color={color} depthTest depthWrite={false} toneMapped={false} />
    </mesh>
  );
}

function DimensionAnnotation({
  start,
  end,
  text,
  textColor = COLORS.dimText,
  lineColor = COLORS.dimLine,
  lineDiameter = 0.06 * S,
  fontSize = 14,
}: {
  start: [number, number, number];
  end: [number, number, number];
  text: string;
  textColor?: string;
  lineColor?: string;
  lineDiameter?: number;
  fontSize?: number;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const { camera } = useThree();
  const geometry = useMemo(() => {
    const a = new THREE.Vector3(...start);
    const b = new THREE.Vector3(...end);
    const dir = new THREE.Vector3().subVectors(b, a);
    const totalLen = dir.length();
    if (totalLen <= 1e-6) return null;
    dir.normalize();

    let gapSize = totalLen * 0.18;
    const minGap = 1.2 * S;
    if (gapSize < minGap) gapSize = Math.min(minGap, totalLen * 0.4);
    const halfGap = gapSize / 2;
    const midpoint = new THREE.Vector3().addVectors(a, b).multiplyScalar(0.5);
    const gapStart = midpoint.clone().addScaledVector(dir, -halfGap);
    const gapEnd = midpoint.clone().addScaledVector(dir, halfGap);

    const tickDir = Math.abs(dir.y) > 0.9
      ? new THREE.Vector3(1, 0, 0)
      : new THREE.Vector3(0, 1, 0);
    const tickHalf = 0.6 * S / 2;

    return {
      midpoint,
      gapStart: gapStart.toArray() as [number, number, number],
      gapEnd: gapEnd.toArray() as [number, number, number],
      tickStart1: a.clone().addScaledVector(tickDir, tickHalf).toArray() as [number, number, number],
      tickEnd1: a.clone().addScaledVector(tickDir, -tickHalf).toArray() as [number, number, number],
      tickStart2: b.clone().addScaledVector(tickDir, tickHalf).toArray() as [number, number, number],
      tickEnd2: b.clone().addScaledVector(tickDir, -tickHalf).toArray() as [number, number, number],
    };
  }, [start, end]);

  // useFrame must run on every render (Rules of Hooks) — keep it above the
  // null-geometry early return and guard inside the callback instead, so a
  // degenerate zero-length dimension flipping null<->non-null can't change
  // the hook count and crash the viewer.
  useFrame(() => {
    if (!groupRef.current || !geometry) return;
    const lift = new THREE.Vector3()
      .subVectors(camera.position, geometry.midpoint)
      .normalize()
      .multiplyScalar(DIM_OVERLAY_LIFT);
    groupRef.current.position.copy(lift);
  });

  if (!geometry) return null;

  return (
    <group ref={groupRef} renderOrder={1000}>
      <DimensionStroke start={start} end={geometry.gapStart} color={lineColor} diameter={lineDiameter} />
      <DimensionStroke start={geometry.gapEnd} end={end} color={lineColor} diameter={lineDiameter} />
      <DimensionStroke start={geometry.tickStart1} end={geometry.tickEnd1} color={lineColor} diameter={lineDiameter} />
      <DimensionStroke start={geometry.tickStart2} end={geometry.tickEnd2} color={lineColor} diameter={lineDiameter} />
      <DimLabel position={geometry.midpoint.toArray() as [number, number, number]} text={text} color={textColor} fontSize={fontSize} />
    </group>
  );
}

// ─── Visibility-gated dimension wrapper ──────────────────────────────────────

/** Wraps DimensionAnnotation and only renders when the dim midpoint sits on
 *  the camera-facing hemisphere of the box. Used so the Dims: Full mode
 *  doesn't drown every view in 30+ labels — instead each view shows only the
 *  dims for geometry actually visible from this angle.
 *
 *  Visibility check: project camera and dim midpoint onto the unit sphere
 *  around boxCenter, then dot. Positive = same hemisphere = visible.
 *  Threshold -0.1 keeps edge-of-hemisphere dims visible (avoids flicker
 *  when slowly orbiting). */
function VisibleDimension(props: {
  start: [number, number, number];
  end: [number, number, number];
  text: string;
  textColor?: string;
  lineColor?: string;
  lineDiameter?: number;
  fontSize?: number;
  boxCenterLocal: [number, number, number];
  /** Local→world bias for the box's inner-group transform. See EnclosureScene
   *  where the inner group has scale [1,1,-1] and position [-W/2, 0, D/2].
   *  We invert that here so we can compare in a common frame. */
  innerOffset: { x: number; z: number };
}) {
  const { start, end, boxCenterLocal, innerOffset } = props;
  const groupRef = useRef<THREE.Group>(null);
  const { camera } = useThree();
  // Visibility via direct .visible mutation (not React state) so updates
  // land in the SAME frame as the useFrame call — critical for the Spec
  // Pack capture, which fires advance() and immediately captures the
  // canvas. React state batching would delay the update past the capture.
  useFrame(() => {
    if (!groupRef.current) return;
    const camLocalX = camera.position.x - innerOffset.x;
    const camLocalY = camera.position.y;
    const camLocalZ = (camera.position.z - innerOffset.z) * -1;

    const midX = (start[0] + end[0]) / 2;
    const midY = (start[1] + end[1]) / 2;
    const midZ = (start[2] + end[2]) / 2;

    const camDx = camLocalX - boxCenterLocal[0];
    const camDy = camLocalY - boxCenterLocal[1];
    const camDz = camLocalZ - boxCenterLocal[2];
    const camLen = Math.hypot(camDx, camDy, camDz) || 1;

    const dimDx = midX - boxCenterLocal[0];
    const dimDy = midY - boxCenterLocal[1];
    const dimDz = midZ - boxCenterLocal[2];
    const dimLen = Math.hypot(dimDx, dimDy, dimDz) || 1;

    const dot = (camDx * dimDx + camDy * dimDy + camDz * dimDz) / (camLen * dimLen);
    groupRef.current.visible = dot > -0.1;
  });
  return (
    <group ref={groupRef}>
      <DimensionAnnotation
        start={start}
        end={end}
        text={props.text}
        textColor={props.textColor}
        lineColor={props.lineColor}
        lineDiameter={props.lineDiameter}
        fontSize={props.fontSize}
      />
    </group>
  );
}

// ─── Camera-following directional light (matching desktop helix:SunLight) ────

function SunLight() {
  const lightRef = useRef<THREE.DirectionalLight>(null);
  const { camera } = useThree();
  useFrame(() => {
    if (lightRef.current) {
      // Position the light at the camera position so it always illuminates from the viewer's perspective
      lightRef.current.position.copy(camera.position);
    }
  });
  return <directionalLight ref={lightRef} intensity={0.15} />;
}

/* GLB export removed 2026-06-08 — the GLB toolbar button + GltfExportTrigger
 * were taken out per operator request. */

// ─── Toolbar Button ──────────────────────────────────────────────────────────

function ToolbarButton({ label, onClick, active }: { label: string; onClick: () => void; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`px-2 py-1 text-[11px] rounded transition-colors ${
        active
          ? 'bg-[#3498DB] text-white'
          : 'bg-[#6B7280] hover:bg-[#5B6370] text-white'
      }`}
    >
      {label}
    </button>
  );
}

// ─── Viewer Error Boundary ────────────────────────────────────────────────────
// R3F rethrows render errors from inside <Canvas> into the surrounding DOM
// tree, so a boundary here catches them. Without one, any viewer render crash
// unmounts the WHOLE consuming app (the 2026-06-18 X-Ray white-screen). This
// contains the crash to the viewer panel and keeps the rest of the app usable.

class ViewerErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback?: React.ReactNode; onError?: (error: unknown) => void },
  { error: Error | null }
> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    appendDebug('viewer', 'error', `3D viewer render crash: ${error.message}`, {
      stack: error.stack,
      componentStack: info.componentStack,
    });
    const onError = this.props.onError;
    if (onError) {
      // Deferred: the export path's onError unmounts this tree's root, which
      // React forbids mid-commit.
      setTimeout(() => onError(error), 0);
    }
  }

  render() {
    if (this.state.error) {
      if (this.props.fallback !== undefined) return this.props.fallback;
      return (
        <div className="w-full h-full flex flex-col items-center justify-center gap-2 bg-gray-50 p-6 text-center">
          <div className="text-sm font-bold text-gray-900">3D preview failed to render</div>
          <div className="text-xs text-gray-500 max-w-md break-words">{this.state.error.message}</div>
          <button
            onClick={() => this.setState({ error: null })}
            className="mt-1 px-3 py-1 text-[11px] rounded bg-[#6B7280] hover:bg-[#5B6370] text-white transition-colors"
          >
            Try Again
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// ─── Viewer Wrapper ───────────────────────────────────────────────────────────

function ViewerCamera({ width, height, depth, rotated, resetVersion }: {
  width: number; height: number; depth: number; rotated: boolean; resetVersion: number;
}) {
  const { camera, size, invalidate } = useThree();
  const controlsRef = useRef<React.ComponentRef<typeof OrbitControls>>(null);
  const pose = useMemo(() => viewerCameraPose(viewerCameraFrame(width, height, depth, rotated),
    size.width / Math.max(1, size.height)), [width, height, depth, rotated, size.width, size.height]);

  useLayoutEffect(() => {
    if (!controlsRef.current || !(camera instanceof THREE.PerspectiveCamera)) return;
    resetViewerCamera(camera, controlsRef.current, pose);
    invalidate();
  }, [camera, pose, resetVersion, invalidate]);

  return <>
    <OrbitControls ref={controlsRef} makeDefault enablePan enableZoom enableRotate
      minDistance={0.5} maxDistance={Math.max(30, pose.distance * 4)} />
    {/* Remount on reset to cancel a cube tween before it can overwrite the pose.
        makeDefault above gives the cube the same target and orbit-up recovery. */}
    <GizmoHelper key={`${resetVersion}:${pose.position.join(',')}`} alignment="top-right" margin={[80, 80]}>
      <GizmoViewcube faces={['R', 'L', 'T', 'Bt', 'Fr', 'Bk']} color="#f0f0f0"
        hoverColor="#999999" textColor="#000000" strokeColor="#555555" opacity={0.85} />
    </GizmoHelper>
  </>;
}

export function EnclosureViewer3D({ toolbarActions, onPopout }: { toolbarActions?: React.ReactNode; onPopout?: () => void } = {}) {
  const store = useEnclosureStore();
  const { inputs, calculations, cutList } = store;
  const previewOnly = !!unresolvedSubwooferPreview(inputs, calculations, cutList);
  const [xrayMode, setXrayMode] = useState<XRayMode>('off');
  const [dimsMode, setDimsMode] = useState<DimsMode>('off');
  const [partMode, setPartMode] = useState(false);
  const [showDriver, setShowDriver] = useState(true);
  const [showRoundover, setShowRoundover] = useState(false);
  const [stainedBirch, setStainedBirch] = useState(false);
  const [debugMode, setDebugMode] = useState<ViewerDebugMode>('off');
  const [panelLayerDebugMode, setPanelLayerDebugMode] = useState<PanelLayerDebugMode>('off');
  const [resetVersion, setResetVersion] = useState(0);

  const boxWidth = roundUpToEighth(calculations.boxWidth);
  const boxHeight = inputs.boxHeight;
  const boxDepth = inputs.boxDepth;

  const isSubsUpPortUp = inputs.enclosureConfiguration === 'Subs Up/Port Up';

  // X-Ray cycling: Off → Top Only → Exterior → Off
  const cycleXRay = () => {
    setXrayMode(m => m === 'off' ? 'topOnly' : m === 'topOnly' ? 'exterior' : 'off');
  };
  const xrayLabel = xrayMode === 'off' ? 'X-Ray' : xrayMode === 'topOnly' ? 'X-Ray: Top' : 'X-Ray: Ext';

  // Dims cycling: Off → Exterior → All → Full → Off
  const cycleDims = () => {
    setDimsMode(m =>
      m === 'off' ? 'exterior'
      : m === 'exterior' ? 'all'
      : m === 'all' ? 'full'
      : 'off');
  };
  const dimsLabel =
    dimsMode === 'off' ? 'Dims'
    : dimsMode === 'exterior' ? 'Dims: Ext'
    : dimsMode === 'all' ? 'Dims: All'
    : 'Dims: Full';
  const cycleDebugMode = () => {
    setDebugMode((mode) => DEBUG_MODE_ORDER[(DEBUG_MODE_ORDER.indexOf(mode) + 1) % DEBUG_MODE_ORDER.length]);
  };
  const cyclePanelLayerDebugMode = () => {
    setPanelLayerDebugMode((mode) => PANEL_LAYER_DEBUG_ORDER[(PANEL_LAYER_DEBUG_ORDER.indexOf(mode) + 1) % PANEL_LAYER_DEBUG_ORDER.length]);
  };
  const openPopoutViewer = () => {
    // Hosts with independent window workspaces own preview routing and storage.
    if (onPopout) { onPopout(); return; }
    try {
      const existingRaw = window.localStorage.getItem('enclosure-calculator-storage');
      const existing = existingRaw ? JSON.parse(existingRaw) : {};
      window.localStorage.setItem('enclosure-calculator-storage', JSON.stringify({
        ...existing,
        state: {
          ...(existing?.state ?? {}),
          inputs: store.inputs,
          brandCode: store.brandCode,
          glueTolerance: store.glueTolerance,
          selectedLogoName: store.selectedLogoName,
          selectedLogoMode: store.selectedLogoMode,
          logoEpsContent: store.logoEpsContent,
        },
      }));
    } catch {
      // If storage write fails, still attempt to open the viewer.
    }
    window.open('/viewer', '_blank', 'width=1200,height=800');
  };

  return (
    <div className="bg-white rounded-lg border border-gray-300 overflow-hidden flex flex-col h-full">
      {/* Header with toolbar matching desktop button style */}
      <div className="flex-shrink-0 flex flex-wrap gap-2 items-center justify-between px-3 py-1.5 border-b border-gray-200">
        <h3 className="text-sm font-bold text-gray-900">3D Preview</h3>
        <div className="flex flex-wrap items-center gap-1">
          {toolbarActions}
          <ToolbarButton label="Reset" onClick={() => setResetVersion(v => v + 1)} />
          <ToolbarButton label={xrayLabel} onClick={cycleXRay} active={xrayMode !== 'off'} />
          <ToolbarButton label={dimsLabel} onClick={cycleDims} active={dimsMode !== 'off'} />
          <ToolbarButton label="Parts" onClick={() => setPartMode(p => !p)} active={partMode} />
          <ToolbarButton label="R/O" onClick={() => setShowRoundover(r => !r)} active={showRoundover} />
          <ToolbarButton
            label={stainedBirch ? 'Stained' : 'Natural'}
            onClick={() => setStainedBirch(s => !s)}
            active={stainedBirch}
          />
          {/* Debug buttons (Diag, Layer) removed from toolbar — kept in code for future use.
              To restore: add ToolbarButton for DEBUG_MODE_LABELS[debugMode]/cycleDebugMode
              and PANEL_LAYER_DEBUG_LABELS[panelLayerDebugMode]/cyclePanelLayerDebugMode */}
          <ToolbarButton
            label={showDriver ? 'Sub' : 'Sub: Off'}
            onClick={() => setShowDriver(d => !d)}
            active={showDriver}
          />
          <ToolbarButton
            label={'\u26F6'}
            onClick={openPopoutViewer}
          />
        </div>
      </div>

      {calculations.baffleCheck.diagnostic && (
        <div role="status" className="shrink-0 px-3 py-2 text-xs text-red-800 bg-red-50 border-b border-red-200">
          {calculations.baffleCheck.diagnostic}
          {previewOnly && <p className="mt-1 font-semibold">{SUBWOOFER_PREVIEW_NOTICE}</p>}
        </div>
      )}
      {/* Canvas */}
      <div data-enclosure-canvas className="flex-1 w-full min-h-0">
        <ViewerErrorBoundary>
        <Canvas
          frameloop="demand"
          camera={{ fov: VIEWER_FOV, up: [0, 1, 0] }}
          dpr={VIEWER_DPR_RANGE}
          gl={{
            antialias: true,
            powerPreference: 'high-performance',
            // Photoreal modifier 2/4: ACES Filmic tone mapping (re-added
            // 2026-05-23). Compresses highlights cinematically + smoother
            // color rolloff than linear. Exposure 1.0 to start — bump up if
            // midtones feel dim after the ACES curve.
            toneMapping: THREE.ACESFilmicToneMapping,
            toneMappingExposure: 1.0,
          }}
        >
          <ViewerCamera width={boxWidth * S} height={boxHeight * S} depth={boxDepth * S}
            rotated={isSubsUpPortUp} resetVersion={resetVersion} />

          {/* Lighting — flat even setup per operator preference. AmbientLight
              provides uniform fill from all directions (every face gets the
              same illumination regardless of orientation). SunLight is kept
              very low for slight shape definition. HDRI removed entirely —
              its bright zones were creating uneven per-face brightness no
              matter how it was rotated. */}
          <ambientLight intensity={1.5} color="#FFFFFF" />
          <SunLight />

          {/* Grid matching desktop: 60" × 60", major=10", minor=2" */}
          <Grid position={[0, -0.01, 0]} args={[6, 6]}
            cellSize={0.2} cellThickness={0.5} cellColor="#c0c0c0"
            sectionSize={1} sectionThickness={1} sectionColor="#a0a0a0"
            fadeDistance={10} fadeStrength={1} />

          <Suspense fallback={null}>
            <group>
              <EnclosureScene
                xrayMode={xrayMode}
                partMode={partMode}
                showDriver={showDriver}
                dimsMode={dimsMode}
                showRoundover={showRoundover}
                debugMode={debugMode}
                panelLayerDebugMode={panelLayerDebugMode}
                logoEpsContent={store.logoEpsContent}
                stainedBirch={stainedBirch}
              />
            </group>
          </Suspense>

          {/* Photoreal modifiers, re-added one at a time (2026-05-23..05-31):
              1/4 SSAO — soft shadows in corners where panels meet so the box
                  doesn't read as paper-flat CAD. Conservative intensity
                  (12 vs original 18).
              3/4 Bloom — very subtle glow on the brightest pixels only
                  (driver dust cap, specular hits). intensity 0.08 +
                  luminanceThreshold 0.95 are the known-good pre-strip values;
                  aggressive defaults blow out the wood textures. Bump
                  intensity or drop the threshold if the operator wants more.
              (Modifier 2/4 ACES tone mapping lives on the Canvas gl prop;
               4/4 HDRI environment is still intentionally off.) */}
          <EffectComposer enableNormalPass multisampling={0}>
            <SSAO
              blendFunction={BlendFunction.MULTIPLY}
              samples={16}
              radius={3}
              intensity={12}
              luminanceInfluence={0.5}
              worldDistanceThreshold={1}
              worldDistanceFalloff={0.5}
              worldProximityThreshold={0.1}
              worldProximityFalloff={0.1}
            />
            <Bloom
              intensity={0.08}
              luminanceThreshold={0.95}
              luminanceSmoothing={0.3}
              mipmapBlur
            />
          </EffectComposer>

        </Canvas>
        </ViewerErrorBoundary>
      </div>
      {dimsMode === 'full' && (
        <div data-enclosure-specifications className="flex-shrink-0 border-t border-gray-200 bg-gray-50 px-4 py-3">
        <p className="text-xs text-center text-blue-700 mb-2">Blue outlines show the outside frames at the mounting surface. The cone and basket shape is illustrative.</p>
        <dl aria-label="Enclosure specifications" className="flex flex-wrap justify-center gap-x-8 gap-y-2 text-sm text-gray-900">
          {[...viewerDriverSpecifications(inputs, calculations), ...viewerSpecifications(inputs, calculations)].map(({ label, value }) => (
            <div key={label} className="flex items-baseline gap-2">
              <dt className="text-gray-600">{label}</dt>
              <dd className="font-semibold tabular-nums">{value}</dd>
            </div>
          ))}
        </dl>
        </div>
      )}
    </div>
  );
}

function ExportSceneReady({ onReady }: { onReady: () => void }) {
  useEffect(() => {
    onReady();
  }, [onReady]);
  return null;
}

function waitFrames(count: number): Promise<void> {
  return new Promise((resolve) => {
    let remaining = count;
    const tick = () => {
      remaining -= 1;
      if (remaining <= 0) {
        resolve();
        return;
      }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(blob);
        return;
      }
      reject(new Error('Failed to capture 3D render.'));
    }, 'image/png');
  });
}

/**
 * Capture the rendered frame and re-draw its visible content centered on a
 * fresh white canvas. Centering the camera on the 3D bounding box gets the box
 * in-frame and roughly centered, but at a 3/4 angle the box's *projected*
 * silhouette is still offset by perspective skew. This measures the actual
 * rendered pixels (anything that isn't the pure-white background) and recenters
 * them above a reserved specification-box area, so neither geometry nor
 * dimension labels can overlap the bottom-right annotation. Requires
 * preserveDrawingBuffer (set on the export Canvas) for WebGL readback.
 */
function recenterCanvasToBlob(srcCanvas: HTMLCanvasElement, specs: ReturnType<typeof viewerSpecifications>, failedFit: boolean): Promise<Blob> {
    const w = srcCanvas.width;
    const h = srcCanvas.height;
    const work = document.createElement('canvas');
    work.width = w;
    work.height = h;
    const wctx = work.getContext('2d', { willReadFrequently: true });
    if (!wctx) throw new Error('Could not prepare the render image. Please try again.');
    wctx.drawImage(srcCanvas, 0, 0);
    const data = wctx.getImageData(0, 0, w, h).data;

    // Content = any pixel not near-white. The export background is pure #ffffff;
    // wood is tan and the sub is gray, all well below this threshold.
    const TH = 248;
    const stride = 2; // sampling every 2nd pixel is plenty accurate for centering
    let minX = w, minY = h, maxX = -1, maxY = -1;
    for (let y = 0; y < h; y += stride) {
      const row = y * w * 4;
      for (let x = 0; x < w; x += stride) {
        const i = row + x * 4;
        if (data[i] < TH || data[i + 1] < TH || data[i + 2] < TH) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX < minX || maxY < minY) throw new Error('The render was empty. Please try again.');

    const cw = maxX - minX + 1;
    const ch = maxY - minY + 1;
    const out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    const octx = out.getContext('2d');
    if (!octx) throw new Error('Could not prepare the render specifications. Please try again.');
    octx.fillStyle = '#ffffff';
    octx.fillRect(0, 0, w, h);
    const specBox = renderSpecificationBox(w, h, specs.length);
    const warningHeight = failedFit ? 40 * specBox.scale : 0;
    const imageHeight = specBox.y - 2 * specBox.margin - warningHeight;
    const fit = Math.min(1, (w - 2 * specBox.margin) / cw, imageHeight / ch);
    const drawWidth = Math.round(cw * fit);
    const drawHeight = Math.round(ch * fit);
    octx.drawImage(
      work,
      minX, minY, cw, ch,
      Math.round((w - drawWidth) / 2), Math.round(specBox.margin + warningHeight + (imageHeight - drawHeight) / 2), drawWidth, drawHeight,
    );
    drawRenderSpecifications(octx, specs, specBox);
    if (failedFit) drawRenderFitWarning(octx, w);
    return canvasToBlob(out);
}

function ExportCaptureController({
  filenamePrefix,
  logoEpsContent,
  sceneReady,
  onComplete,
  onError,
}: {
  filenamePrefix: string;
  logoEpsContent?: string | null;
  sceneReady: boolean;
  onComplete: (files: RenderExportFile[]) => void;
  onError: (error: unknown) => void;
}) {
  const liveGeometry = useEnclosureStore();
  const renderGeometry = useContext(RenderGeometryContext);
  const { inputs, calculations } = renderGeometry ?? liveGeometry;
  const { gl, scene, camera } = useThree();
  const hasStartedRef = useRef(false);
  const [exportVariantIndex, setExportVariantIndex] = useState(0);

  const boxWidth = roundUpToEighth(calculations.boxWidth);
  const boxHeight = inputs.boxHeight;
  const boxDepth = inputs.boxDepth;
  const maxDim = Math.max(boxWidth, boxHeight, boxDepth) * S;
  const activeVariant = EXPORT_RENDER_VARIANTS[exportVariantIndex] ?? EXPORT_RENDER_VARIANTS[0];

  useEffect(() => {
    if (!sceneReady || hasStartedRef.current) return;
    hasStartedRef.current = true;

    const perspectiveCamera = camera as THREE.PerspectiveCamera;
    perspectiveCamera.up.set(0, 1, 0);

    (async () => {
      const files: RenderExportFile[] = [];

      const exportViews = getExportViews(inputs);

      for (let variantIndex = 0; variantIndex < EXPORT_RENDER_VARIANTS.length; variantIndex += 1) {
        setExportVariantIndex(variantIndex);
        await waitFrames(3);

        // Center + frame on the ACTUAL rendered bounding box rather than a
        // fixed origin-relative target. The enclosure geometry is NOT centered
        // on the origin (it lives in world space), so the old fixed lookAt
        // target framed every export up-and-to-the-left with dead space.
        // Measuring the scene bbox each variant centers the box horizontally +
        // vertically; for the dimensioned variant it also keeps the exterior
        // labels in frame. Lights + camera contribute no geometry to the Box3.
        const bbox = new THREE.Box3().setFromObject(scene);
        const center = bbox.getCenter(new THREE.Vector3());
        const size = bbox.getSize(new THREE.Vector3());
        // Camera distance tuned so the box fills ~75% of a 4:3 frame; the
        // margin keeps the dimensioned variant's labels from clipping. Falls
        // back to the dimension-derived size if the bbox is somehow empty.
        const fitDim = Math.max(size.x, size.y, size.z) || maxDim;
        const camDist = fitDim * 1.55 + 0.45;

        for (const view of exportViews) {
          // Position the camera camDist from the box CENTER along the view
          // vector (not from the origin) so lookAt(center) frames it centered.
          perspectiveCamera.position.set(
            center.x + view.vector[0] * camDist,
            center.y + view.vector[1] * camDist,
            center.z + view.vector[2] * camDist,
          );
          perspectiveCamera.lookAt(center);
          perspectiveCamera.updateProjectionMatrix();

          await waitFrames(3);
          gl.render(scene, perspectiveCamera);
          await waitFrames(1);

          const variant = EXPORT_RENDER_VARIANTS[variantIndex];
          files.push({
            folder: variant.folder,
            filename: `${filenamePrefix}-${variant.fileTag}-${view.suffix}.png`,
            blob: await recenterCanvasToBlob(gl.domElement, viewerSpecifications(inputs, calculations), calculations.baffleCheck.isFail),
            type: 'png',
          });
        }
      }

      onComplete(files);
    })().catch(onError);
  }, [camera, scene, maxDim, gl, onComplete, onError, sceneReady]);

  return (
    <EnclosureScene
      xrayMode="off"
      partMode={false}
      showDriver
      dimsMode={activeVariant.dimsMode}
      showRoundover
      debugMode="off"
      panelLayerDebugMode="off"
      logoEpsContent={logoEpsContent}
    />
  );
}

function OffscreenRenderExportCanvas({
  filenamePrefix,
  logoEpsContent,
  onComplete,
  onError,
}: {
  filenamePrefix: string;
  logoEpsContent?: string | null;
  onComplete: (files: RenderExportFile[]) => void;
  onError: (error: unknown) => void;
}) {
  const [sceneReady, setSceneReady] = useState(false);

  return (
    <div
      style={{
        position: 'fixed',
        left: '-20000px',
        top: '0',
        width: `${EXPORT_RENDER_SIZE.width}px`,
        height: `${EXPORT_RENDER_SIZE.height}px`,
        pointerEvents: 'none',
      }}
    >
      {/* fallback={null}: offscreen, nothing to show — but onError makes a
          render crash reject the export promise instead of hanging it. */}
      <ViewerErrorBoundary fallback={null} onError={onError}>
      <Canvas
        dpr={EXPORT_RENDER_SIZE.dpr}
        gl={{
          antialias: true,
          preserveDrawingBuffer: true,
          powerPreference: 'high-performance',
          // Match the interactive preview: ACES Filmic tone mapping. The old
          // export used `flat` (no tone mapping), which — combined with the
          // ambient-2.0 wash below — is why the rendered PNGs looked duller and
          // flatter than what the operator sees in the live 3D viewer.
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.0,
        }}
      >
        <color attach="background" args={['#ffffff']} />
        <PerspectiveCamera makeDefault fov={45} up={[0, 1, 0]} />
        {/* Lighting mirrors the interactive viewer EXACTLY (ambient 1.5 +
            camera-following SunLight) so the exported PNGs read like what the
            operator sees in the 3D preview. The old export used a single flat
            ambientLight at 2.0 — every face got identical illumination, so the
            box rendered as a flat sticker with no sense of form.
            NOTE: the preview's SSAO/Bloom (the EffectComposer) is NOT applied
            here — ExportCaptureController captures each view with a direct
            gl.render(scene, camera) that bypasses the composer. The lighting +
            ACES match is what carries over and drives the dimensional look; the
            subtle SSAO corner-shadows do not. If an exact match is needed, the
            capture loop must be rerouted through the composer (verify on a real
            render before shipping — the direct-render path is deliberate). */}
        <ambientLight intensity={1.5} color="#FFFFFF" />
        <SunLight />
        <Suspense fallback={null}>
          <ExportCaptureController
            filenamePrefix={filenamePrefix}
            logoEpsContent={logoEpsContent}
            sceneReady={sceneReady}
            onComplete={onComplete}
            onError={onError}
          />
          <ExportSceneReady onReady={() => setSceneReady(true)} />
        </Suspense>
      </Canvas>
      </ViewerErrorBoundary>
    </div>
  );
}

export async function captureEnclosureRenderSet({
  filenamePrefix,
  logoEpsContent,
}: {
  filenamePrefix: string;
  logoEpsContent?: string | null;
}): Promise<RenderExportFile[]> {
  if (typeof document === 'undefined') return [];

  const geometry = snapshotRenderGeometry(useEnclosureStore.getState());

  return new Promise((resolve, reject) => {
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = createRoot(container);

    const cleanup = () => {
      root.unmount();
      container.remove();
    };

    root.render(
      <RenderGeometryContext.Provider value={geometry}>
      <OffscreenRenderExportCanvas
        filenamePrefix={filenamePrefix}
        logoEpsContent={logoEpsContent}
        onComplete={(files) => {
          cleanup();
          resolve(files);
        }}
        onError={(error) => {
          cleanup();
          reject(error);
        }}
      />
      </RenderGeometryContext.Provider>
    );
  });
}

/**
 * Bulk-render entry point: temporarily swap the global enclosure store to
 * the supplied design inputs, capture the standard render set, then
 * restore the previous inputs. Used by the Pricing tab's "+3D renders"
 * batch path — the calc-side bulk pipeline doesn't have its own React
 * tree per design, so we lend it the live store for a few moments per
 * iteration.
 *
 * Restores the original inputs in a `finally` block so a failed render
 * never leaves the user's Design tab on a different design.
 *
 * NOTE: this DOES mutate the global store while running. Callers that
 * run a large batch should block user interaction (e.g., show a "Bulk
 * rendering — please wait" modal) so the visible store swap isn't
 * mistaken for an input bug.
 */
export async function captureRendersForInputs({
  inputs,
  filenamePrefix,
  logoEpsContent,
}: {
  inputs: EnclosureInputs;
  filenamePrefix: string;
  logoEpsContent?: string | null;
}): Promise<RenderExportFile[]> {
  if (typeof document === 'undefined') return [];

  const store = useEnclosureStore.getState();
  const originalInputs = store.inputs;
  try {
    // setInputs spreads (state.inputs ∪ newInputs); passing the full
    // EnclosureInputs object replaces every field. The setter triggers
    // recalculate() so the scene reads consistent dimensions.
    store.setInputs(inputs);
    // Let React + the recalc pipeline settle before mounting the canvas.
    await new Promise<void>((r) => setTimeout(r, 50));
    return await captureEnclosureRenderSet({ filenamePrefix, logoEpsContent });
  } finally {
    useEnclosureStore.getState().setInputs(originalInputs);
  }
}
