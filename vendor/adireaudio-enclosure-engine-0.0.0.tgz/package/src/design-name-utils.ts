// Enclosure identity naming. A series is part of the identity, not a removable
// dealer decoration. Only legacy unprefixed Performance names are aliases.

const VALID_PREFIXES = ['BHSP-', 'BHSS-', 'BHSF-'] as const;

export type EnclosureSeries = 'performance' | 'foundation' | 'select';
const SERIES_PREFIX: Record<EnclosureSeries, string> = {
  performance: 'BHSP-', foundation: 'BHSF-', select: 'BHSS-',
};

export function getEnclosureSeries(name: string): EnclosureSeries {
  const upper = name.trim().toUpperCase();
  return upper.startsWith('BHSF-') ? 'foundation' : upper.startsWith('BHSS-') ? 'select' : 'performance';
}

/** One prefixed name without the .json transport extension. Supplying a series
 * deliberately creates that variant; ordinary normalization retains its series. */
export function canonicalDesignName(name: string, series?: EnclosureSeries): string {
  const clean = name.trim().replace(/\.json$/i, '');
  if (!clean) return '';
  const body = stripPrefix(clean);
  if (!body.trim()) throw new Error('An enclosure name is required after the series prefix');
  if (hasValidPrefix(body)) throw new Error('An enclosure name must have exactly one series prefix');
  return SERIES_PREFIX[series ?? getEnclosureSeries(clean)] + body;
}

/**
 * Normalize an identity while preserving the finishing series.
 */
export function normalizeDesignName(name: string): string {
  return canonicalDesignName(name);
}

/**
 * Returns an empty array. PE- alias system has been retired.
 */
export function getDesignNameAliases(normalizedName: string): string[] {
  return [];
}

/**
 * Check if a value starts with a valid prefix (BHSP-, BHSS-, BHSF-).
 */
export function hasValidPrefix(value: string): boolean {
  const upper = value.toUpperCase();
  return VALID_PREFIXES.some(p => upper.startsWith(p));
}

/**
 * Extract prefix from a value. Returns 'BHSP', 'BHSS', 'BHSF', or null.
 */
export function getPrefixFromValue(value: string): string | null {
  const upper = value.toUpperCase();
  for (const prefix of VALID_PREFIXES) {
    if (upper.startsWith(prefix)) {
      return prefix.slice(0, -1); // Remove trailing dash
    }
  }
  return null;
}

/**
 * Strip the prefix (BHSP-/BHSS-/BHSF-) from a value.
 */
export function stripPrefix(value: string): string {
  for (const prefix of VALID_PREFIXES) {
    if (value.toUpperCase().startsWith(prefix)) {
      return value.slice(prefix.length);
    }
  }
  return value;
}

/**
 * Same-series legacy spellings only. Never make Foundation or Select inventory
 * eligible for Performance demand by swapping prefixes.
 */
export function getSkuMatchCandidates(name: string | undefined): string[] {
  if (!name) return [];
  const out = new Set<string>();
  const push = (v: string) => {
    const up = v.toUpperCase().trim();
    if (up) out.add(up);
  };
  const canonical = canonicalDesignName(name);
  if (!canonical) return [];
  push(canonical);
  push(canonical + '.json');
  if (getEnclosureSeries(canonical) === 'performance') {
    const legacy = stripPrefix(canonical);
    push(legacy);
    push(legacy + '.json');
  }
  return Array.from(out);
}
