// Design name normalization utilities
// Mirrors desktop DesignFileService.cs: NormalizeDesignName(), GetDesignNameAliases()

const VALID_PREFIXES = ['BHSP-', 'BHSS-', 'BHSF-'] as const;

/**
 * Strip .json extension and BHSP-/BHSS-/BHSF- prefixes from a design name.
 */
export function normalizeDesignName(name: string): string {
  let normalized = name;
  // Strip .json extension
  if (normalized.toLowerCase().endsWith('.json')) {
    normalized = normalized.slice(0, -5);
  }
  // Strip known prefixes
  for (const prefix of VALID_PREFIXES) {
    if (normalized.toUpperCase().startsWith(prefix)) {
      normalized = normalized.slice(prefix.length);
      break;
    }
  }
  return normalized;
}

/**
 * Returns an empty array. PE- alias system has been retired.
 */
export function getDesignNameAliases(normalizedName: string): string[] {
  return [];
}

/**
 * Check if a value starts with a valid prefix (BHSP-, BHSS-, BHSF-).
 */
export function hasValidPrefix(value: string): boolean {
  const upper = value.toUpperCase();
  return VALID_PREFIXES.some(p => upper.startsWith(p));
}

/**
 * Extract prefix from a value. Returns 'BHSP', 'BHSS', 'BHSF', or null.
 */
export function getPrefixFromValue(value: string): string | null {
  const upper = value.toUpperCase();
  for (const prefix of VALID_PREFIXES) {
    if (upper.startsWith(prefix)) {
      return prefix.slice(0, -1); // Remove trailing dash
    }
  }
  return null;
}

/**
 * Strip the prefix (BHSP-/BHSS-/BHSF-) from a value.
 */
export function stripPrefix(value: string): string {
  for (const prefix of VALID_PREFIXES) {
    if (value.toUpperCase().startsWith(prefix)) {
      return value.slice(prefix.length);
    }
  }
  return value;
}

/**
 * Generate SKU-match candidates for a design/master-part name: the name as-is,
 * the name with .json stripped, the normalized name (prefix stripped), and the
 * normalized name with each of BHSP-/BHSS-/BHSF- re-applied.
 *
 * Used for matching ShipStation SKUs (which carry a brand prefix like BHSP-)
 * against mapped design names (which do NOT carry the prefix) and vice-versa.
 * Returns uppercased, de-duplicated keys suitable for dictionary lookup.
 */
export function getSkuMatchCandidates(name: string | undefined): string[] {
  if (!name) return [];
  const out = new Set<string>();
  const push = (v: string) => {
    const up = v.toUpperCase().trim();
    if (up) out.add(up);
  };
  push(name);
  const bare = name.replace(/\.json$/i, '');
  push(bare);
  const norm = normalizeDesignName(bare);
  push(norm);
  for (const prefix of VALID_PREFIXES) {
    push(prefix + norm);
  }
  return Array.from(out);
}
