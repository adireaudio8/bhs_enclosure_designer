import { epsPathToPolylineVertices, type EpsPath, type PolylineVertex, type Vec2 } from './eps-parser';

// The logo converter uses 0.001 EPS point. Cutout source paths are frozen in
// inches, so use the same physical tolerance (72 PostScript points per inch).
export const CUTOUT_CURVE_TOLERANCE_IN = 0.001 / 72;
const JOIN_TOLERANCE_IN = 0.0005;
const distance = (a: Vec2, b: Vec2) => Math.hypot(a.x - b.x, a.y - b.y);

export function cutoutCurveVertices(path: EpsPath): PolylineVertex[] {
  if (!path || path.isClosed !== true || !Array.isArray(path.segments)
    || path.segments.length < 2 || path.segments.length > 256) {
    throw new Error('The cutout EPS must contain one closed, reasonably simple outline.');
  }
  for (let i = 0; i < path.segments.length; i++) {
    const s = path.segments[i], next = path.segments[(i + 1) % path.segments.length];
    if (!s || !['line', 'bezier'].includes(s.type)
      || [s.start, s.end, ...(s.type === 'bezier' ? [s.control1, s.control2] : [])]
        .some(p => !p || !Number.isFinite(p.x) || !Number.isFinite(p.y) || Math.abs(p.x) > 60 || Math.abs(p.y) > 60)
      || !next?.start || (i < path.segments.length - 1 && distance(s.end, next.start) > 1e-7) || distance(s.start, s.end) < 1e-7) {
      throw new Error('The cutout EPS has disconnected, invalid or zero-length segments. Correct the source outline and upload it again.');
    }
    // A collinear cubic is how the shared logo uploader retains straight edges.
    // Reject control-point backtracking instead of letting nearly-line fitting hide it.
    if (s.type === 'bezier') {
      const dx = s.end.x - s.start.x, dy = s.end.y - s.start.y, length2 = dx * dx + dy * dy;
      const cross = (p: Vec2) => Math.abs((p.x - s.start.x) * dy - (p.y - s.start.y) * dx) / Math.sqrt(length2);
      if (Math.max(cross(s.control1), cross(s.control2)) <= CUTOUT_CURVE_TOLERANCE_IN) {
        const t = (p: Vec2) => ((p.x - s.start.x) * dx + (p.y - s.start.y) * dy) / length2;
        if (t(s.control1) < -1e-8 || t(s.control2) > 1 + 1e-8 || t(s.control1) > t(s.control2) + 1e-8) {
          throw new Error('The cutout EPS contains a reversing straight curve. Correct the source outline and upload it again.');
        }
      }
    }
  }
  // Exactly the same conversion used by epsPathsToDxfEntities for logos.
  let vertices = epsPathToPolylineVertices(path, 1, 0, 0, CUTOUT_CURVE_TOLERANCE_IN);
  if (vertices.length < 3 || vertices.length > 256
    || vertices.some((p, i) => !Number.isFinite(p.bulge)
      || distance(p, vertices[(i + 1) % vertices.length]) < 0.01)) {
    throw new Error('The logo EPS converter produced an excessively segmented cutout. Review the source EPS and conversion before generating cutting files.');
  }
  if (!vertices.some(p => Math.abs(p.bulge) > 1e-6) && vertices.length > 64) {
    throw new Error('The cutout contains a dense straight-segment outline. Export the original curves and upload the EPS again.');
  }
  const signed = vertices.reduce((sum, p, i) => {
    const q = vertices[(i + 1) % vertices.length];
    return sum + p.x * q.y - p.y * q.x;
  }, 0);
  if (signed < 0) {
    vertices = vertices.map((_, i, a) => ({
      ...a[a.length - 1 - i], bulge: -a[(a.length - 2 - i + a.length) % a.length].bulge,
    }));
  }
  return vertices;
}

export function curveArc(a: PolylineVertex, b: Vec2) {
  const dx = b.x - a.x, dy = b.y - a.y, factor = (1 - a.bulge * a.bulge) / (4 * a.bulge);
  const center = { x: (a.x + b.x) / 2 - dy * factor, y: (a.y + b.y) / 2 + dx * factor };
  return { center, radius: distance(a, center), sweep: 4 * Math.atan(a.bulge) };
}

/** Sample only for fit/validation. These points never become machining paths. */
export function sampleCurveOutline(vertices: PolylineVertex[], tolerance = 0.0001): Vec2[] {
  return vertices.flatMap((a, i) => {
    if (Math.abs(a.bulge) < 1e-8) return [{ x: a.x, y: a.y }];
    const { center, radius, sweep } = curveArc(a, vertices[(i + 1) % vertices.length]);
    const count = Math.max(1, Math.ceil(Math.abs(sweep) / (2 * Math.acos(Math.max(-1, 1 - tolerance / radius)))));
    if (!Number.isFinite(count) || count > 4096) throw new Error('Invalid cutout arc.');
    const start = Math.atan2(a.y - center.y, a.x - center.x);
    return Array.from({ length: count }, (_, j) => ({
      x: center.x + radius * Math.cos(start + sweep * j / count),
      y: center.y + radius * Math.sin(start + sweep * j / count),
    }));
  });
}

/** Apply the design's cutout allowance to native lines/arcs before nesting.
 * This is not cutter compensation or reconstruction of flattened artwork.
 * Unsupported joins stop export instead of being repaired. Input is CCW. */
export function offsetCutoutCurves(vertices: PolylineVertex[], delta: number): PolylineVertex[] {
  if (!Number.isFinite(delta) || Math.abs(delta) > 1) throw new Error('Cutout clearance must be within one inch.');
  if (!delta) return vertices;
  const edges = vertices.map((a, i) => {
    const b = vertices[(i + 1) % vertices.length];
    if (Math.abs(a.bulge) < 1e-8) {
      const length = distance(a, b), nx = (b.y - a.y) / length, ny = -(b.x - a.x) / length;
      return { start: { x: a.x + nx * delta, y: a.y + ny * delta }, end: { x: b.x + nx * delta, y: b.y + ny * delta }, bulge: 0 };
    }
    const { center, radius } = curveArc(a, b), offsetRadius = radius + Math.sign(a.bulge) * delta;
    if (offsetRadius <= 0) throw new Error('Cutout clearance collapses an arc. Reduce the allowance or correct the source outline.');
    const move = (p: Vec2) => ({ x: center.x + (p.x - center.x) * offsetRadius / radius, y: center.y + (p.y - center.y) * offsetRadius / radius });
    return { start: move(a), end: move(b), bulge: a.bulge };
  });
  return edges.map((edge, i) => {
    const prev = edges[(i + edges.length - 1) % edges.length];
    if (distance(prev.end, edge.start) <= JOIN_TOLERANCE_IN) {
      return { x: (prev.end.x + edge.start.x) / 2, y: (prev.end.y + edge.start.y) / 2, bulge: edge.bulge };
    }
    if (!prev.bulge && !edge.bulge) {
      const u = { x: prev.end.x - prev.start.x, y: prev.end.y - prev.start.y };
      const v = { x: edge.end.x - edge.start.x, y: edge.end.y - edge.start.y };
      const det = u.x * v.y - u.y * v.x;
      if (Math.abs(det) > 1e-10) {
        const t = ((edge.start.x - prev.start.x) * v.y - (edge.start.y - prev.start.y) * v.x) / det;
        const p = { x: prev.start.x + t * u.x, y: prev.start.y + t * u.y, bulge: 0 };
        if (distance(p, vertices[i]) <= Math.abs(delta) * 10) return p;
      }
    }
    throw new Error('The cutout allowance cannot preserve this curve join. Review the EPS or allowance; no cutting file was generated.');
  });
}

export function roundedFrameVertices(width: number, height: number, radius: number, offset = 0): PolylineVertex[] {
  const w = width / 2 + offset, h = height / 2 + offset, r = radius > 0 ? radius + offset : 0;
  if (w <= 0 || h <= 0 || r < 0 || r > Math.min(w, h)) throw new Error('Invalid outside frame allowance.');
  if (!r) return [{ x: -w, y: -h, bulge: 0 }, { x: w, y: -h, bulge: 0 }, { x: w, y: h, bulge: 0 }, { x: -w, y: h, bulge: 0 }];
  const b = Math.tan(Math.PI / 8);
  return [
    { x: -w + r, y: -h, bulge: 0 }, { x: w - r, y: -h, bulge: b },
    { x: w, y: -h + r, bulge: 0 }, { x: w, y: h - r, bulge: b },
    { x: w - r, y: h, bulge: 0 }, { x: -w + r, y: h, bulge: b },
    { x: -w, y: h - r, bulge: 0 }, { x: -w, y: -h + r, bulge: b },
  ].filter((p, i, a) => distance(p, a[(i + 1) % a.length]) > 1e-8);
}
