/**
 * Shared cost calculator — ported from BuildTab.tsx cost logic.
 * Used by both the Build tab (single design) and Pricing tab (batch calculations).
 * Matches desktop's CalculateDesignCostFromDesignFile / BuildTabViewModel.MaterialCosting.cs.
 */

import {
  CutListItem,
  EnclosureInputs,
  EnclosureCalculations,
  MaterialConfig,
  DEFAULT_GLUE_TOLERANCE,
  DEFAULT_MATERIAL_CONFIG,
} from './types/enclosure';
import { calculateEnclosure, generateCutList, getPartMaterial, getGussetCount } from './calculations';
import { calculateOptimalStack } from './flat-pack-optimizer';
import { needsSplitDieline } from './dxf-generator';
import { calculateCartonDimensions } from './carton-dimensions';

// ─── Constants ──────────────────────────────────────────────────────────────

const SQ_IN_PER_SHEET = 4608; // 48" × 96"
const DENSITY_BALTIC_BIRCH = 0.0246; // lb/in³
const DENSITY_MDF = 0.029; // lb/in³
const PACKAGING_WEIGHT = 3.0; // lbs
const DIM_WEIGHT_FACTOR = 139; // UPS/FedEx DIM factor
const BOX_WALL_LW = 0.5512; // 14mm — length/width offset
const BOX_WALL_H = 1.1024; // 28mm — height offset

// ─── Types ──────────────────────────────────────────────────────────────────

export interface CostSettings {
  birch18mmPerSheet: number;
  birch24mmPerSheet: number;
  mdf34PerSheet: number;
  mdf1PerSheet: number;
  materialWastePercentage: number;
  cardboard350DWPerSheet: number;
  cratingPlyPerSheet: number;
  bindingPostPerUnit: number;
  wireWhipPerUnit: number;
  bagPerUnit: number;
  foamCornersPerUnit: number;
  finishingLaborPerSqFt: number;
  finishingMaterialsPerSqFt: number;
  /** MDF-specific finishing rate. Used when the design's enclosureType is MDF.
   *  When 0 or absent, the Birch rate is used as a fallback (preserves legacy
   *  behavior for configs created before the split). */
  finishingLaborPerSqFtMDF: number;
  finishingMaterialsPerSqFtMDF: number;
  costPerDowelPin: number;
  costPerGalGlue: number;
  sqFtPerGalGlue: number;
  sprayPaintCostPerCan: number;
  portPaint6_5Single: number;
  portPaint6_5Dual: number;
  portPaint6_5Triple: number;
  portPaint8Single: number;
  portPaint8Dual: number;
  portPaint10Single: number;
  portPaint10Dual: number;
  portPaint12Single: number;
  portPaint12Dual: number;
  portPaint15Single: number;
  portPaint15Dual: number;
  portPaint18Single: number;
  portPaint18Dual: number;
}

export const DEFAULT_COST_SETTINGS: CostSettings = {
  birch18mmPerSheet: 85, birch24mmPerSheet: 110, mdf34PerSheet: 45, mdf1PerSheet: 65,
  materialWastePercentage: 10,
  cardboard350DWPerSheet: 12, cratingPlyPerSheet: 35,
  bindingPostPerUnit: 2.50, wireWhipPerUnit: 1.25, bagPerUnit: 0.75, foamCornersPerUnit: 1.50,
  finishingLaborPerSqFt: 0.50, finishingMaterialsPerSqFt: 0.35,
  finishingLaborPerSqFtMDF: 0, finishingMaterialsPerSqFtMDF: 0,
  costPerDowelPin: 0.02, costPerGalGlue: 25, sqFtPerGalGlue: 400,
  sprayPaintCostPerCan: 8,
  portPaint6_5Single: 0.25, portPaint6_5Dual: 0.5, portPaint6_5Triple: 0.75,
  portPaint8Single: 0.33, portPaint8Dual: 0.66,
  portPaint10Single: 0.5, portPaint10Dual: 1.0,
  portPaint12Single: 0.66, portPaint12Dual: 1.25,
  portPaint15Single: 0.75, portPaint15Dual: 1.5,
  portPaint18Single: 1.0, portPaint18Dual: 2.0,
};

export interface CostResult {
  materialCost: number;
  glueCost: number;
  dowelPinsCost: number;
  portPaintCost: number;
  cardboardCost: number;
  packagingPlyCost: number;
  fixedCosts: number;
  finishingCost: number;
  totalCost: number;
  surfaceAreaSqFt: number;
  enclosureWeight: number;
  shippingWeight: number;
  dimensionalWeight: number;
  billableWeight: number;
  externalLength: number;
  externalWidth: number;
  externalHeight: number;
}

// Desktop → Web property mapping for parsing API settings
export const DESKTOP_TO_WEB: Record<string, keyof CostSettings> = {
  Birch18mmPerSheet: 'birch18mmPerSheet', Birch24mmPerSheet: 'birch24mmPerSheet',
  MDF34PerSheet: 'mdf34PerSheet', MDF1PerSheet: 'mdf1PerSheet',
  MaterialWastePercentage: 'materialWastePercentage',
  Cardboard350DWPerSheet: 'cardboard350DWPerSheet', CratingPlyPerSheet: 'cratingPlyPerSheet',
  BindingPostPerUnit: 'bindingPostPerUnit', WireWhipPerUnit: 'wireWhipPerUnit',
  BagPerUnit: 'bagPerUnit', FoamCornersPerUnit: 'foamCornersPerUnit',
  FinishingCostPerSqFt: 'finishingLaborPerSqFt', FinishingMaterialsPerSqFt: 'finishingMaterialsPerSqFt',
  FinishingCostPerSqFtMDF: 'finishingLaborPerSqFtMDF', FinishingMaterialsPerSqFtMDF: 'finishingMaterialsPerSqFtMDF',
  CostPerDowelPin: 'costPerDowelPin', CostPerGalOfGlue: 'costPerGalGlue',
  SqFtPerGalOfGlue: 'sqFtPerGalGlue', SprayPaintCostPerCan: 'sprayPaintCostPerCan',
  PortPaint6_5Single: 'portPaint6_5Single', PortPaint6_5Dual: 'portPaint6_5Dual',
  PortPaint6_5Triple: 'portPaint6_5Triple',
  PortPaint8Single: 'portPaint8Single', PortPaint8Dual: 'portPaint8Dual',
  PortPaint10Single: 'portPaint10Single', PortPaint10Dual: 'portPaint10Dual',
  PortPaint12Single: 'portPaint12Single', PortPaint12Dual: 'portPaint12Dual',
  PortPaint15Single: 'portPaint15Single', PortPaint15Dual: 'portPaint15Dual',
  PortPaint18Single: 'portPaint18Single', PortPaint18Dual: 'portPaint18Dual',
};

/** Parse cost settings from API response (handles PascalCase → camelCase) */
export function parseCostSettings(raw: Record<string, unknown>): CostSettings {
  const result = { ...DEFAULT_COST_SETTINGS };
  for (const [key, val] of Object.entries(raw)) {
    const webKey = DESKTOP_TO_WEB[key] || key as keyof CostSettings;
    if (webKey in result && typeof val === 'number') {
      (result as Record<string, number>)[webKey] = val;
    }
  }
  return result;
}

// ─── Core Calculator ────────────────────────────────────────────────────────

/**
 * Calculate full cost from a cut list. Matches BuildTab.tsx cost calculations.
 */
export function calculateCostFromCutList(
  cutList: CutListItem[],
  costSettings: CostSettings,
  options: {
    isFlatPack: boolean;
    isBare: boolean;
    isFoundation?: boolean;
    enclosureType: string;
    enclosureConfiguration?: string;
    subwooferQuantity: string;
    sizeCode: string;
    dutyType?: string;
    materialConfig?: MaterialConfig;
    boxDepth?: number;
    boxHeight?: number;
    boxWidth?: number;
    /** Cardboard sheet thickness (inches). Defaults to 0.25 (350# DW nominal).
     *  Caller should pass the operator's actual configured CardboardThickness
     *  (from app_settings.build_settings) so the dieline fit check matches
     *  what the DXF generator will physically cut. */
    cardboardThickness?: number;
  }
): CostResult {
  const { isFlatPack, isBare, isFoundation, enclosureType, subwooferQuantity, sizeCode } = options;
  // Default to SBPB so legacy callers without the field get the legacy
  // material rule. The desktop default (and parseDesignDataInputs default)
  // is SUPB, but here we want a conservative non-breaking default.
  const enclosureConfiguration = options.enclosureConfiguration || 'Subs Back/Port Back';

  if (cutList.length === 0) {
    return {
      materialCost: 0, glueCost: 0, dowelPinsCost: 0, portPaintCost: 0,
      cardboardCost: 0, packagingPlyCost: 0, fixedCosts: 0, finishingCost: 0, totalCost: 0,
      surfaceAreaSqFt: 0, enclosureWeight: 0, shippingWeight: 0,
      dimensionalWeight: 0, billableWeight: 0,
      externalLength: 0, externalWidth: 0, externalHeight: 0,
    };
  }

  // Cost per square inch
  const costPerSqIn = {
    birch18mm: costSettings.birch18mmPerSheet / SQ_IN_PER_SHEET,
    birch24mm: costSettings.birch24mmPerSheet / SQ_IN_PER_SHEET,
    mdf34: costSettings.mdf34PerSheet / SQ_IN_PER_SHEET,
    mdf1: costSettings.mdf1PerSheet / SQ_IN_PER_SHEET,
  };

  // Material cost
  const wasteMultiplier = 1 + costSettings.materialWastePercentage / 100;
  let materialCost = 0;
  for (const part of cutList) {
    const area = part.width * part.height * part.quantity;
    let perSqIn = 0;
    if (part.material.includes('18mm')) perSqIn = costPerSqIn.birch18mm;
    else if (part.material.includes('24mm')) perSqIn = costPerSqIn.birch24mm;
    else if (part.material.includes('3/4')) perSqIn = costPerSqIn.mdf34;
    else if (part.material.includes('1"')) perSqIn = costPerSqIn.mdf1;
    materialCost += area * perSqIn * wasteMultiplier;
  }

  // Edge surface area for glue
  const findPart = (name: string) => cutList.find(p => p.partName === name);
  let edgeSurfaceArea = 0;

  if (options.materialConfig) {
    const mc = options.materialConfig;
    const back = findPart('Back');
    const baffle = findPart('Baffle');
    const sideLeft = findPart('Side Left');
    const sideRight = findPart('Side Right');
    const port1 = findPart('Port Piece 1');
    const portDividers = cutList.filter(part => /^Port Piece ([2-9]|[1-9]\d+)$/.test(part.partName));
    const gusset = cutList.find(p => p.partName.startsWith('Gusset'));

    if (back) {
      const t = getPartMaterial('Back', enclosureType, mc, enclosureConfiguration).thicknessInches;
      edgeSurfaceArea += back.width * 2 * t;
    }
    if (baffle) {
      const t = getPartMaterial('Baffle', enclosureType, mc, enclosureConfiguration).thicknessInches;
      edgeSurfaceArea += baffle.width * 2 * t;
    }
    if (sideLeft) {
      const t = getPartMaterial('Side Left', enclosureType, mc, enclosureConfiguration).thicknessInches;
      edgeSurfaceArea += (sideLeft.width * 2 + sideLeft.height * 2) * t;
    }
    if (sideRight) {
      const t = getPartMaterial('Side Right', enclosureType, mc, enclosureConfiguration).thicknessInches;
      edgeSurfaceArea += (sideRight.width * 2 + sideRight.height * 1) * t;
    }
    if (port1) {
      const t = getPartMaterial('Port Piece 1', enclosureType, mc, enclosureConfiguration).thicknessInches;
      edgeSurfaceArea += (port1.width * 2 + port1.height * 2) * t;
    }
    for (const portDivider of portDividers) {
      const t = getPartMaterial('Port Piece 2', enclosureType, mc, enclosureConfiguration).thicknessInches;
      edgeSurfaceArea += portDivider.width * 2 * t;
    }
    if (gusset && gusset.quantity > 0) {
      const t = getPartMaterial('Gusset 1', enclosureType, mc, enclosureConfiguration).thicknessInches;
      edgeSurfaceArea += (gusset.width * 2 + gusset.height * 1) * t * gusset.quantity;
    }
    // Flush mount additions — face-to-face glue (not edge):
    //   - Sub Mount Plate: back face glues to baffle's back face. Contact
    //     area = plate width × plate height (no thickness multiplier).
    //   - Sub Mount Cap (SUPB): bottom face glues to top panel's top face.
    //     Contact area = cap width × cap height (no thickness multiplier).
    const subMountPlate = findPart('Sub Mount Plate');
    if (subMountPlate) {
      edgeSurfaceArea += subMountPlate.width * subMountPlate.height;
    }
    const subMountCap = findPart('Sub Mount Cap');
    if (subMountCap) {
      edgeSurfaceArea += subMountCap.width * subMountCap.height;
    }
  }

  // Glue cost
  let glueCost = 0;
  if (!isFlatPack && edgeSurfaceArea > 0) {
    const costPerSqFt = costSettings.sqFtPerGalGlue > 0
      ? costSettings.costPerGalGlue / costSettings.sqFtPerGalGlue : 0;
    glueCost = edgeSurfaceArea * (costPerSqFt / 144.0);
  }

  // Dowel pins — calculate extra holes from cut list
  const calcFromWidth = (w: number) => w < 11 ? 0 : w <= 18.5 ? 1 : w < 34 ? 2 : 3;
  const bottom = findPart('Bottom');
  const backPart = findPart('Back');
  const bafflePart = findPart('Baffle');
  const port2Part = findPart('Port Piece 2');

  const maxHeight = Math.max(backPart?.height || 0, bafflePart?.height || 0, port2Part?.height || 0);
  const heightExtraHoles = maxHeight < 8 ? 0 : maxHeight <= 16 ? 1 : 2;
  const bottomDepth = bottom?.height || 0;
  const bottomExtraHoles = calcFromWidth(bottomDepth);
  const bottomRightExtraHoles = calcFromWidth(bottomDepth);
  const bottomBackExtraHoles = calcFromWidth(bottom?.width || 0);
  const bottomFrontExtraHoles = calcFromWidth(bafflePart?.width || 0);

  void heightExtraHoles; // used implicitly through the hole patterns

  const bottomTopHoles = 2 + bottomBackExtraHoles + 2 + bottomFrontExtraHoles
    + 2 + bottomExtraHoles + 2 + bottomRightExtraHoles + 1 + 2;
  let totalHoles = bottomTopHoles * 2; // Top + Bottom
  // The legacy +2 above accounts for PP2. A labyrinth adds two alignment
  // dowels per Top/Bottom edge for every PP3+ divider (one centered dowel for
  // a final divider too short for the standard 1.25" inset pair).
  const additionalLabyrinthAlignmentHoles = cutList
    .filter(part => /^Port Piece ([3-9]|[1-9]\d+)$/.test(part.partName))
    .reduce((sum, part) => sum + (part.width <= 2.5 ? 1 : 2), 0);
  totalHoles += additionalLabyrinthAlignmentHoles * 2;
  totalHoles += 2 + bottomExtraHoles; // Side Left
  totalHoles += 2 + bottomRightExtraHoles; // Side Right
  totalHoles += 4 + bottomBackExtraHoles; // Back
  const subMountHoles = subwooferQuantity === 'Quad' ? 16 : subwooferQuantity === 'Triple' ? 12
    : subwooferQuantity === 'Dual' ? 8 : 4;
  totalHoles += subMountHoles + 4 + bottomFrontExtraHoles; // Baffle
  totalHoles += 6 * getGussetCount(subwooferQuantity); // Gussets

  const dowelPinsCost = totalHoles * costSettings.costPerDowelPin;

  // Port paint (matches desktop: Single/Dual stored, Triple/Quad = single × sub count)
  let portPaintCost = 0;
  if (!isFlatPack && costSettings.sprayPaintCostPerCan > 0 && sizeCode) {
    let fraction = 0;
    const qty = subwooferQuantity;
    const subCount = qty === 'Quad' ? 4 : qty === 'Triple' ? 3 : qty === 'Dual' ? 2 : 1;
    if (sizeCode === '6.5' || sizeCode === '6') {
      fraction = qty === 'Triple' ? costSettings.portPaint6_5Triple
        : qty === 'Dual' ? costSettings.portPaint6_5Dual
        : qty === 'Quad' ? costSettings.portPaint6_5Single * 4
        : costSettings.portPaint6_5Single;
    } else if (sizeCode === '8') {
      fraction = qty === 'Dual' ? costSettings.portPaint8Dual
        : subCount > 2 ? costSettings.portPaint8Single * subCount
        : costSettings.portPaint8Single;
    } else if (sizeCode === '10') {
      fraction = qty === 'Dual' ? costSettings.portPaint10Dual
        : subCount > 2 ? costSettings.portPaint10Single * subCount
        : costSettings.portPaint10Single;
    } else if (sizeCode === '12') {
      fraction = qty === 'Dual' ? costSettings.portPaint12Dual
        : subCount > 2 ? costSettings.portPaint12Single * subCount
        : costSettings.portPaint12Single;
    } else if (sizeCode === '15') {
      fraction = qty === 'Dual' ? costSettings.portPaint15Dual
        : subCount > 2 ? costSettings.portPaint15Single * subCount
        : costSettings.portPaint15Single;
    } else if (sizeCode === '18') {
      fraction = qty === 'Dual' ? costSettings.portPaint18Dual
        : subCount > 2 ? costSettings.portPaint18Single * subCount
        : costSettings.portPaint18Single;
    }
    portPaintCost = fraction > 0 ? costSettings.sprayPaintCostPerCan * fraction : 0;
  }

  // Cardboard cost — uses the real dieline geometry (same function the DXF
  // generator uses to decide whether to emit Box vs SplitBox), so the cost
  // calc and the physical cut stay consistent. Previously this used a
  // simplified estimate (2*(L+W)+0.25, 2*W+2*H+2) that overstated dimensions
  // and pushed ~30% of the catalog from 1 sheet to 2 sheets when they
  // actually fit on one — overcharging $8.28/unit in displayed cost for
  // those designs.
  const bw = options.boxWidth || 0;
  const bh = options.boxHeight || 0;
  const bd = options.boxDepth || 0;
  const carton = calculateCartonDimensions(bd, bh, bw);
  const cartonLength = carton.length;
  const cartonWidth = carton.width;
  const cartonHeight = carton.height;
  const cardboardThickness = options.cardboardThickness ?? 0.25;

  let cardboardSheetsNeeded = 1; // Desktop defaults to 1 sheet
  if (cartonLength > 0 && cartonWidth > 0 && cartonHeight > 0) {
    cardboardSheetsNeeded = needsSplitDieline(cartonLength, cartonWidth, cartonHeight, cardboardThickness) ? 2 : 1;
  }
  const cardboardCost = cardboardSheetsNeeded * costSettings.cardboard350DWPerSheet;

  // Packaging plywood cost (flat pack only — uses full 2D bin packer from flat-pack-optimizer.ts)
  let packagingPlyCost = 0;
  if (isFlatPack && costSettings.cratingPlyPerSheet > 0) {
    const dutyType = options.dutyType || 'RD';
    const fpResult = calculateOptimalStack(cutList, dutyType);
    if (fpResult.pkgTotalArea > 0) {
      const cratingPlyCostPerSqIn = costSettings.cratingPlyPerSheet / SQ_IN_PER_SHEET;
      packagingPlyCost = Math.round(fpResult.pkgTotalArea * cratingPlyCostPerSqIn * 100) / 100;
    }
  }

  // Fixed costs
  const fixedCosts = costSettings.bindingPostPerUnit + costSettings.wireWhipPerUnit +
    costSettings.bagPerUnit + (isFlatPack ? 0 : costSettings.foamCornersPerUnit);

  // Surface area — external box dimensions for finishing
  let surfaceAreaSqFt = 0;
  if (bw > 0 && bd > 0 && bh > 0) {
    surfaceAreaSqFt = 2 * (bw * bd + bw * bh + bd * bh) / 144.0;
  }

  // Finishing cost — three build tiers:
  //   • Flat Pack            → $0 (customer assembles flat panels; nothing to finish)
  //   • Bare / Foundation    → sanding labor only after glue-up, NO materials.
  //                            FOUNDATION_LABOR_FRACTION of the finishing labor:
  //                            25% for Birch, 30% for MDF. Triggered by either the
  //                            BHSF- name (isFoundation) OR the "Bare" build flag
  //                            (isBare) — they mean the same thing now.
  //   • Full (Performance)   → labor + materials (sand + stain + lacquer + engrave)
  //
  // NOTE: "Raw" (ship to LBS fully unsanded → $0 finishing) is NOT a build tier
  // here. It is a derived cost VIEW (totalCost minus finishingCost / per-unit
  // consumables / cardboard) surfaced as the "Cost Raw" column — see the Pricing
  // tab + the cost-sheet PDF. So there is deliberately no $0 finishing branch for
  // isBare any longer; isBare == Foundation == sanding labor.
  //
  // Material-aware rates: MDF designs use finishing*MDF rates when those are
  // configured (> 0). Falls back to the Birch rates when MDF rates are 0 or
  // unset — preserves legacy behavior for configs that pre-date the split.
  const isMDF = (enclosureType || '').toLowerCase().includes('mdf');
  const laborRate = (isMDF && costSettings.finishingLaborPerSqFtMDF > 0)
    ? costSettings.finishingLaborPerSqFtMDF
    : costSettings.finishingLaborPerSqFt;
  const materialsRate = (isMDF && costSettings.finishingMaterialsPerSqFtMDF > 0)
    ? costSettings.finishingMaterialsPerSqFtMDF
    : costSettings.finishingMaterialsPerSqFt;

  // Fraction of finishing labor charged for a Bare/Foundation (sanded, unfinished)
  // build. Birch boxes sand faster than MDF, so MDF carries a higher fraction.
  const FOUNDATION_LABOR_FRACTION_BIRCH = 0.25;
  const FOUNDATION_LABOR_FRACTION_MDF = 0.30;

  let finishingCost = 0;
  if (isFlatPack) {
    // Flat Pack: no finishing at all
    finishingCost = 0;
  } else if (isFoundation || isBare) {
    // Bare / Foundation: sanding labor only (no materials), material-aware fraction
    const foundationFraction = isMDF
      ? FOUNDATION_LABOR_FRACTION_MDF
      : FOUNDATION_LABOR_FRACTION_BIRCH;
    finishingCost = surfaceAreaSqFt * (laborRate * foundationFraction);
  } else {
    // Full finishing: labor + materials (stain, lacquer, engraving)
    finishingCost = surfaceAreaSqFt * (laborRate + materialsRate);
  }

  // Weight
  let enclosureWeight = 0;
  for (const part of cutList) {
    const area = part.width * part.height * part.quantity;
    const density = part.material.includes('MDF') ? DENSITY_MDF : DENSITY_BALTIC_BIRCH;
    enclosureWeight += area * part.thickness * density;
  }
  const shippingWeight = enclosureWeight + PACKAGING_WEIGHT;

  const externalLength = cartonLength + BOX_WALL_LW;
  const externalWidth = cartonWidth + BOX_WALL_LW;
  const externalHeight = cartonHeight + BOX_WALL_H;
  const dimensionalWeight = (externalLength * externalWidth * externalHeight) / DIM_WEIGHT_FACTOR;
  const billableWeight = Math.max(shippingWeight, dimensionalWeight);

  // Round each component to 2 decimal places before summing (matches desktop Math.Round(x, 2))
  const r2 = (n: number) => Math.round(n * 100) / 100;
  const rMaterialCost = r2(materialCost);
  const rGlueCost = r2(glueCost);
  const rDowelPinsCost = r2(dowelPinsCost);
  const rPortPaintCost = r2(portPaintCost);
  const rCardboardCost = r2(cardboardCost);
  const rPackagingPlyCost = r2(packagingPlyCost);
  const rFixedCosts = r2(fixedCosts);
  const rFinishingCost = r2(finishingCost);

  // Total — finishing already handles FP=0, Bare/Foundation=25% Birch / 30% MDF labor, Standard=full
  const totalCost = rMaterialCost + rDowelPinsCost + rCardboardCost + rPackagingPlyCost + rFixedCosts +
    (isFlatPack ? 0 : rGlueCost + rPortPaintCost) +
    rFinishingCost;

  return {
    materialCost: rMaterialCost, glueCost: rGlueCost, dowelPinsCost: rDowelPinsCost, portPaintCost: rPortPaintCost,
    cardboardCost: rCardboardCost, packagingPlyCost: rPackagingPlyCost, fixedCosts: rFixedCosts, finishingCost: rFinishingCost, totalCost: r2(totalCost),
    surfaceAreaSqFt, enclosureWeight, shippingWeight,
    dimensionalWeight, billableWeight,
    externalLength, externalWidth, externalHeight,
  };
}

// ─── Design Data Parser ─────────────────────────────────────────────────────

/**
 * Parse design_data from either web format (has `inputs` sub-object) or
 * desktop format (flat PascalCase properties with string values).
 * Returns EnclosureInputs or null if unparseable.
 *
 * Desktop saves: { SelectedEnclosureType: "Birch Ply - Regular Duty", BoxDepthText: "15.5", ... }
 * Web saves:     { inputs: { enclosureType: "Birch Ply - Regular Duty", boxDepth: 15.5, ... } }
 */
export function parseDesignDataInputs(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  designData: any
): EnclosureInputs | null {
  if (!designData) return null;

  // Web-saved format: has `inputs` sub-object with correct types
  if (designData.inputs) {
    return designData.inputs as EnclosureInputs;
  }

  // Desktop-saved format: flat PascalCase properties with string values
  // Replicates design-tab.tsx g()/gn() pattern
  const dd = designData;
  const g = (camel: string, pascal: string): string | undefined =>
    dd[camel] ?? dd[pascal] ?? undefined;
  const gn = (camel: string, pascal: string, fallback: number): number => {
    const v = dd[camel] ?? dd[pascal];
    return v !== undefined ? (parseFloat(v) || fallback) : fallback;
  };

  // Need at minimum boxDepth and boxHeight to do anything useful
  const boxDepth = gn('boxDepthText', 'BoxDepthText', 0);
  const boxHeight = gn('boxHeightText', 'BoxHeightText', 0);
  if (boxDepth <= 0 && boxHeight <= 0) return null;

  // Robust numeric reads — older desktop saves sometimes only have the bare
  // numeric form (`OutsideDiameter`) without the matching *Text string, and
  // some web saves only have the *Text form. Try *Text first, then fall back
  // to the bare key. Returning 0 here silently disables guards in
  // calculateEnclosure (e.g. the flush-mount baffle-height rule needs
  // outsideDiameter > 0 to fire), so we read both.
  const gnFlex = (camelText: string, pascalText: string, camelBare: string, pascalBare: string): number => {
    const fromText = gn(camelText, pascalText, 0);
    if (fromText > 0) return fromText;
    const v = dd[camelBare] ?? dd[pascalBare];
    return v !== undefined ? (parseFloat(v) || 0) : 0;
  };

  // Optional terminal placement fields. Preserve `undefined` when the keys
  // are absent so downstream code (DXF generator, 3D viewer) falls back to
  // legacy behavior; only adopt explicit values that round-trip cleanly.
  const tpRaw = g('terminalPanel', 'TerminalPanel');
  const terminalPanel: 'Side Left' | 'Back' | undefined =
    tpRaw === 'Side Left' || tpRaw === 'Back' ? tpRaw : undefined;
  const txoRaw = dd['terminalXOffset'] ?? dd['TerminalXOffset'];
  let terminalXOffset: number | undefined = undefined;
  if (txoRaw !== undefined && txoRaw !== null && txoRaw !== '') {
    const parsed = parseFloat(String(txoRaw));
    if (Number.isFinite(parsed)) terminalXOffset = parsed;
  }

  // Optional subwoofer placement override (SUPB only). Same round-trip rule.
  const sxoRaw = dd['subwooferXOffset'] ?? dd['SubwooferXOffset'];
  let subwooferXOffset: number | undefined = undefined;
  if (sxoRaw !== undefined && sxoRaw !== null && sxoRaw !== '') {
    const parsed = parseFloat(String(sxoRaw));
    if (Number.isFinite(parsed)) subwooferXOffset = parsed;
  }
  const syoRaw = dd['subwooferYOffset'] ?? dd['SubwooferYOffset'];
  let subwooferYOffset: number | undefined = undefined;
  if (syoRaw !== undefined && syoRaw !== null && syoRaw !== '') {
    const parsed = parseFloat(String(syoRaw));
    if (Number.isFinite(parsed)) subwooferYOffset = parsed;
  }

  // Optional acrylic window fields. Round-trip both web (camelCase) and
  // desktop (PascalCase) keys so designs survive save/load on either app.
  const windowEnabled = (() => {
    const v = dd['windowEnabled'] ?? dd['WindowEnabled'];
    if (v === undefined || v === null || v === '') return undefined;
    return v === true || v === 'true' || v === 'True' || v === '1' || v === 1;
  })();
  const winSizeRaw = dd['windowSize'] ?? dd['WindowSize'];
  const windowSize: '12x12' | '24x12' | 'custom' | undefined =
    winSizeRaw === '12x12' || winSizeRaw === '24x12' || winSizeRaw === 'custom'
      ? winSizeRaw : undefined;
  const winOrientRaw = dd['windowOrientation'] ?? dd['WindowOrientation'];
  const windowOrientation: 'landscape' | 'portrait' | undefined =
    winOrientRaw === 'landscape' || winOrientRaw === 'portrait' ? winOrientRaw : undefined;
  const wxoRaw = dd['windowXOffset'] ?? dd['WindowXOffset'];
  let windowXOffset: number | undefined = undefined;
  if (wxoRaw !== undefined && wxoRaw !== null && wxoRaw !== '') {
    const parsed = parseFloat(String(wxoRaw));
    if (Number.isFinite(parsed)) windowXOffset = parsed;
  }
  const wyoRaw = dd['windowYOffset'] ?? dd['WindowYOffset'];
  let windowYOffset: number | undefined = undefined;
  if (wyoRaw !== undefined && wyoRaw !== null && wyoRaw !== '') {
    const parsed = parseFloat(String(wyoRaw));
    if (Number.isFinite(parsed)) windowYOffset = parsed;
  }
  const wcrRaw = dd['windowCornerRadius'] ?? dd['WindowCornerRadius'];
  let windowCornerRadius: number | undefined = undefined;
  if (wcrRaw !== undefined && wcrRaw !== null && wcrRaw !== '') {
    const parsed = parseFloat(String(wcrRaw));
    if (Number.isFinite(parsed)) windowCornerRadius = parsed;
  }
  const wcwRaw = dd['windowCustomWidth'] ?? dd['WindowCustomWidth'];
  let windowCustomWidth: number | undefined = undefined;
  if (wcwRaw !== undefined && wcwRaw !== null && wcwRaw !== '') {
    const parsed = parseFloat(String(wcwRaw));
    if (Number.isFinite(parsed) && parsed > 0) windowCustomWidth = parsed;
  }
  const wchRaw = dd['windowCustomHeight'] ?? dd['WindowCustomHeight'];
  let windowCustomHeight: number | undefined = undefined;
  if (wchRaw !== undefined && wchRaw !== null && wchRaw !== '') {
    const parsed = parseFloat(String(wchRaw));
    if (Number.isFinite(parsed) && parsed > 0) windowCustomHeight = parsed;
  }

  return {
    enclosureType: g('selectedEnclosureType', 'SelectedEnclosureType') || 'Birch Ply - Regular Duty',
    enclosureConfiguration: g('selectedEnclosureConfiguration', 'SelectedEnclosureConfiguration') || 'Subs Up/Port Back',
    subwooferQuantity: g('selectedSubwooferQuantity', 'SelectedSubwooferQuantity') || 'Single',
    portQuantity: g('selectedPortQuantity', 'SelectedPortQuantity') || 'Single',
    size: g('selectedSize', 'SelectedSize') || '12"',
    subwooferBrand: g('selectedSubwooferBrand', 'SelectedSubwooferBrand') || '',
    subwooferModel: g('selectedSubwooferModel', 'SelectedSubwooferModel') || '',
    assemblyMethod: g('selectedAssemblyMethod', 'SelectedAssemblyMethod') || 'Press Together',
    boxDepth,
    boxHeight,
    portWidth: gn('portWidthText', 'PortWidthText', 0),
    tuningFrequency: gn('tuningFrequencyText', 'TuningFrequencyText', 0),
    netAirSpace: gn('netAirSpaceText', 'NetAirSpaceText', 0),
    subDisplacement: gn('subDisplacementText', 'SubDisplacementText', 0),
    subCutoutDiameter: gnFlex('subCutoutDiameterText', 'SubCutoutDiameterText', 'subCutoutDiameter', 'SubCutoutDiameter'),
    outsideDiameter: gnFlex('outsideDiameterText', 'OutsideDiameterText', 'outsideDiameter', 'OutsideDiameter'),
    isCustomEnclosure: dd['isCustomEnclosure'] === true || dd['IsCustomEnclosure'] === true
      || dd['isCustomEnclosure'] === 'true' || dd['IsCustomEnclosure'] === 'True',
    customNumber: parseInt(g('customNumber', 'CustomNumber') || '') || undefined,
    customNotes: g('customNotes', 'CustomNotes') || '',
    terminalPanel,
    terminalXOffset,
    subwooferXOffset,
    subwooferYOffset,
    windowEnabled,
    windowSize,
    windowOrientation,
    windowXOffset,
    windowYOffset,
    windowCornerRadius,
    windowCustomWidth,
    windowCustomHeight,
  } as EnclosureInputs;
}

// ─── Design-level Calculator ────────────────────────────────────────────────

/**
 * Calculate cost from design_data (as stored in Supabase design_files table).
 * Used by the Pricing tab to compute COST column for each design.
 *
 * Handles both web format ({ inputs: EnclosureInputs }) and
 * desktop format (flat PascalCase: { BoxDepthText: "15.5", ... }).
 */
export function calculateDesignCost(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  designData: any,
  costSettings: CostSettings,
  designName: string,
  /** Operator's CardboardThickness from app_settings.build_settings, in inches.
   *  Defaults to 0.25 (350# DW nominal) when omitted. Pass the configured
   *  value so the cost calc's dieline fit check matches the DXF generator. */
  cardboardThickness?: number,
  /** Operator's current GlueTolerance from app_settings.build_settings.
   *  Used only when the design itself has no saved tolerance. */
  fallbackGlueTolerance: number = DEFAULT_GLUE_TOLERANCE,
): CostResult | null {
  const inputs = parseDesignDataInputs(designData);
  if (!inputs) return null;

  // Run calculations from inputs
  let calculations: EnclosureCalculations;
  try {
    calculations = calculateEnclosure(inputs);
  } catch {
    return null;
  }

  // Generate cut list
  let cutList: CutListItem[];
  try {
    const buildSettings = designData.buildSettings;
    const candidates = [
      designData.glueTolerance,
      designData.GlueTolerance,
      buildSettings?.glueTolerance,
      buildSettings?.GlueTolerance,
      fallbackGlueTolerance,
      DEFAULT_GLUE_TOLERANCE,
    ];
    let glueTolerance = DEFAULT_GLUE_TOLERANCE;
    for (const candidate of candidates) {
      const parsed = typeof candidate === 'number' ? candidate : parseFloat(String(candidate ?? ''));
      if (Number.isFinite(parsed) && parsed >= 0) {
        glueTolerance = parsed;
        break;
      }
    }
    cutList = generateCutList(inputs, calculations, DEFAULT_MATERIAL_CONFIG, glueTolerance);
  } catch {
    return null;
  }

  // Determine flat pack / bare status
  const isFlatPack = designName.toUpperCase().endsWith('-FP') ||
    inputs.assemblyMethod === 'Flat Pack' ||
    designData.buildSettings?.assemblyMethod === 'Flat Pack';
  const isFoundation = designName.toUpperCase().startsWith('BHSF-');
  const isBare = designData.buildSettings?.isBare ?? isFoundation;

  // Extract size code from design name
  let sizeCode = '';
  const sizeMatch = designName.match(/[SDTQ](\d+(?:\.\d+)?)/i);
  if (sizeMatch) sizeCode = sizeMatch[1];

  // Extract duty type from enclosureType (e.g., "Birch Ply - Heavy Duty" → "HD")
  let dutyType = 'RD';
  const etUpper = inputs.enclosureType.toUpperCase();
  if (etUpper.includes('HEAVY')) dutyType = 'HD';
  else if (etUpper.includes('STANDARD')) dutyType = 'SD';

  const result = calculateCostFromCutList(cutList, costSettings, {
    isFlatPack,
    isBare,
    isFoundation,
    enclosureType: inputs.enclosureType,
    enclosureConfiguration: inputs.enclosureConfiguration,
    subwooferQuantity: inputs.subwooferQuantity,
    sizeCode,
    dutyType,
    materialConfig: DEFAULT_MATERIAL_CONFIG,
    boxDepth: inputs.boxDepth,
    boxHeight: inputs.boxHeight,
    boxWidth: calculations.boxWidth,
    cardboardThickness,
  });

  // Guard: stub-poisoned design_data (an `inputs` object missing dimensions,
  // the 2026-04 incident class) flows through parse + calc without throwing
  // but yields NaN totals alongside real-looking per-line costs. Return null
  // like the other failure paths so callers' existing null-handling shows
  // "no cost" instead of publishing NaN-adjacent numbers.
  if (!Number.isFinite(result.totalCost) || !Number.isFinite(result.billableWeight)) {
    return null;
  }
  return result;
}
