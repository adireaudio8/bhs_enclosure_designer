/**
 * Acrylic (plexiglass) window placement helpers.
 *
 * V1 ships ONE window per design, on a panel that's auto-determined by
 * `enclosureConfiguration` — operator can't pick the panel:
 *
 *   SBPB (Subs Back / Port Back)   → Top panel
 *   SUPB (Subs Up / Port Back)     → Baffle (front)
 *   SUPU (Subs Up / Port Up)       → Bottom panel  (visible "front face"
 *                                                   after the SUPU rotation
 *                                                   transform — same panel
 *                                                   that hosts the logo deboss)
 *
 * Each config has exactly one panel that's free of sub cutouts, port
 * openings, terminal cup, and gusset attachments — that's where the
 * window goes. The auto-rule trades flexibility for a simpler UI; if a
 * future config needs a different panel, this is the file to extend.
 *
 * Size convention follows the operator's plexi template (DXF in
 * `CNC Files/0000 - Plexi Templates/12x12 window pattern.dxf`):
 *
 *   - `windowSize` describes the PLATE — the acrylic piece bolted on top.
 *   - The WOOD CUTOUT is `plate − 2 × WINDOW_PLATE_OVERHANG_PER_SIDE` per
 *     axis. So "12×12" = 12×12 plate covering a 9.5×9.5 wood hole.
 *   - 8 T-nut pilots sit on a ring inset midway between cutout and plate
 *     edge (10.75 ring for the 12 plate) — emitted from the DXF generator.
 *
 * Pricing is handled separately via `pricing_modifiers.acrylicWindow` so
 * the operator can adjust the upcharge without a code change.
 *
 * Coordinate system: panel-local 2D. Origin at the panel's bottom-left
 * corner as the operator looks at it. X increases rightward, Y increases
 * upward. Offsets in `EnclosureInputs.windowXOffset` / `windowYOffset` are
 * relative to the panel's geometric CENTER (not the corner) — positive X
 * shifts right, positive Y shifts up. The DXF generator and 3D viewer
 * convert into their own native frames.
 */

import type {
  CutListItem,
  EnclosureCalculations,
  EnclosureInputs,
} from './types/enclosure';

/** Plate-to-cutout overhang per side (inches). 12×12 plate ↔ 9.5×9.5 cutout
 *  → 1.25" overhang each side. Matches the operator's plexi template. */
export const WINDOW_PLATE_OVERHANG_PER_SIDE = 1.25;

/** Required clearance between the plate's outer edge and any interior wall
 *  (baffle, PP1, PP2, side walls). T-nuts on the plate's underside need
 *  physical room to seat without colliding with vertical chamber walls. */
export const WINDOW_WALL_CLEARANCE = 0.5;

/** Default cutout corner radius (inches) when `windowCornerRadius` is unset. */
export const DEFAULT_WINDOW_CORNER_RADIUS = 0.125;

/** Acrylic plate thickness picked by enclosure duty. Higher-SPL ported
 *  builds run thicker plate to resist chamber pressure flex / seal failure. */
export function resolveAcrylicThickness(inputs: EnclosureInputs): 0.25 | 0.375 {
  const et = inputs.enclosureType || '';
  const isHD = et.includes('Heavy');
  return isHD ? 0.375 : 0.25;
}

// ─── Panel selection ────────────────────────────────────────────────────────

export type WindowPanel = 'Top' | 'Baffle' | 'Bottom';

/**
 * Resolve which panel the window cutout goes on, based purely on
 * enclosureConfiguration. Returns 'Top' as a safe fallback for any
 * config we don't explicitly know about.
 */
export function resolveWindowPanel(inputs: EnclosureInputs): WindowPanel {
  switch (inputs.enclosureConfiguration) {
    case 'Subs Back/Port Back': return 'Top';
    case 'Subs Up/Port Back':   return 'Baffle';
    case 'Subs Up/Port Up':     return 'Bottom';
    default:                    return 'Top';
  }
}

// ─── Size resolution ────────────────────────────────────────────────────────

export interface WindowDimensions {
  /** Acrylic plate width (inches) — the piece bolted on top. */
  plateW: number;
  /** Acrylic plate height (inches). */
  plateH: number;
  /** Wood cutout width (inches) — the hole through the host panel. */
  cutoutW: number;
  /** Wood cutout height (inches). */
  cutoutH: number;
}

/** Compute cutout dims from plate dims. Floor at 1" so degenerate inputs
 *  don't yield a non-cuttable hole. */
function cutoutFromPlate(plateW: number, plateH: number): { cutoutW: number; cutoutH: number } {
  return {
    cutoutW: Math.max(1, plateW - 2 * WINDOW_PLATE_OVERHANG_PER_SIDE),
    cutoutH: Math.max(1, plateH - 2 * WINDOW_PLATE_OVERHANG_PER_SIDE),
  };
}

/**
 * Resolve PLATE and CUTOUT dimensions from the size tier + orientation.
 *
 * `windowSize` describes the plate (the visible acrylic piece). The wood
 * cutout is always `plate − 2 × overhang` per axis so the plate fully
 * covers the hole with room for the screw ring.
 *
 *   12×12 → plate 12×12, cutout 9.5×9.5
 *   24×12 landscape → plate 24×12, cutout 21.5×9.5
 *   24×12 portrait  → plate 12×24, cutout 9.5×21.5
 *   custom → plate from windowCustomWidth/Height, cutout = plate − 2.5/axis
 *
 * Returns all-zero if the design has no enabled window — callers should
 * guard on `inputs.windowEnabled` before using these dimensions.
 */
export function resolveWindowDimensions(inputs: EnclosureInputs): WindowDimensions {
  if (!inputs.windowEnabled) return { plateW: 0, plateH: 0, cutoutW: 0, cutoutH: 0 };
  const size = inputs.windowSize || '12x12';
  let plateW = 12, plateH = 12;
  if (size === 'custom') {
    const w = inputs.windowCustomWidth;
    const h = inputs.windowCustomHeight;
    plateW = Number.isFinite(w) && (w as number) > 0 ? (w as number) : 12;
    plateH = Number.isFinite(h) && (h as number) > 0 ? (h as number) : 12;
  } else if (size === '24x12') {
    const orientation = inputs.windowOrientation || 'landscape';
    plateW = orientation === 'portrait' ? 12 : 24;
    plateH = orientation === 'portrait' ? 24 : 12;
  }
  const { cutoutW, cutoutH } = cutoutFromPlate(plateW, plateH);
  return { plateW, plateH, cutoutW, cutoutH };
}

// ─── Panel dimensions ───────────────────────────────────────────────────────

export interface PanelBox {
  /** Panel width along its local X axis (inches). */
  panelW: number;
  /** Panel height along its local Y axis (inches). */
  panelH: number;
}

/**
 * Return the panel-local dimensions of whichever panel hosts the window.
 *
 * Mapping (panel-local X / panel-local Y):
 *   Top    → boxWidth × boxDepth
 *   Bottom → boxWidth × boxDepth   (same physical panel as Top, just on the
 *                                    other Y face — the SUPU rotation puts
 *                                    this face forward but the panel itself
 *                                    has the same XY extents)
 *   Baffle → baffleWidth × internalHeight
 *            (baffleW = boxW − 2*t; internalH from calc)
 */
export function resolveHostPanelBox(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
): PanelBox {
  const panel = resolveWindowPanel(inputs);
  if (panel === 'Top' || panel === 'Bottom') {
    return { panelW: calc.boxWidth, panelH: inputs.boxDepth };
  }
  // Baffle — read side-wall thickness from the same rule subwoofer-placement
  // uses so the helpers stay consistent. SD/RD = 0.709" (B1/D1); HD = 0.945"
  // (B2/D2); MDF = 0.75" thin / 1.0" heavy.
  const t = sideWallThicknessFor(inputs);
  const baffleW = calc.boxWidth - 2 * t;
  return { panelW: baffleW, panelH: calc.internalHeight };
}

function sideWallThicknessFor(inputs: EnclosureInputs): number {
  const isMDF = inputs.enclosureType.includes('MDF');
  const isHeavy = inputs.enclosureType.includes('Heavy');
  if (isMDF) return isHeavy ? 1.0 : 0.75;
  return isHeavy ? 0.945 : 0.709;
}

/** Baffle thickness — same matrix `getPartMaterial` uses.
 *    SD            → thin
 *    HD            → thick
 *    RD + SBPB     → thick (baffle is the load-bearing panel in SBPB)
 *    RD + SUPB     → thin (Top is the load-bearing panel in SUPB)
 *  Returns 0.709 / 0.945 for Birch, 0.75 / 1.0 for MDF. */
function baffleThicknessFor(inputs: EnclosureInputs): number {
  const isMDF = inputs.enclosureType.includes('MDF');
  const isHeavy = inputs.enclosureType.includes('Heavy');
  const isRegular = inputs.enclosureType.includes('Regular');
  const isSUPB = inputs.enclosureConfiguration === 'Subs Up/Port Back';
  const thick = isMDF ? 1.0 : 0.945;
  const thin = isMDF ? 0.75 : 0.709;
  if (isHeavy) return thick;
  if (isRegular) return isSUPB ? thin : thick;
  return thin; // SD
}

// ─── Safe area for the plate on the host panel ──────────────────────────────

export interface SafeArea {
  /** Panel-local rect in inches. Plate must fit ENTIRELY inside this rect
   *  (with no shrink, the slider clamps to the offsets that keep the plate
   *  inside; with auto-shrink, the plate dims themselves are reduced). */
  xMin: number;
  xMax: number;
  yMin: number;
  yMax: number;
}

/**
 * Rectangle on the host panel where the plate can sit with
 * `WINDOW_WALL_CLEARANCE` inches of clearance from every interior wall.
 *
 * SBPB Top (single port): the FRONT sub-chamber rectangle — bounded by
 *   left wall, baffle, PP1's left face, and PP2's front face. Forbids
 *   the back of the chamber (behind PP2) and the port channel by design;
 *   the window goes over the sub which lives at the front.
 *
 * SBPB Top (dual port): the symmetric chamber between the two PP1 walls,
 *   from baffle back to where PP2 would start.
 *
 * SUPB Baffle: panel inset by the wall-clearance margin only — no
 *   internal walls touch the baffle's back face.
 *
 * SUPU Bottom: treated as the Bottom-panel mirror of SBPB Top for now —
 *   refine when SUPU production designs surface.
 */
export function resolveWindowSafeArea(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList?: CutListItem[],
): SafeArea {
  const host = resolveWindowPanel(inputs);
  const panel = resolveHostPanelBox(inputs, calc);
  const c = WINDOW_WALL_CLEARANCE;

  if (host === 'Baffle') {
    // SUPB baffle: side walls + Top + Bottom panels butt against the
    // baffle's edges but don't intrude on its back face. Panel-edge
    // margin only.
    return {
      xMin: c,
      xMax: Math.max(c, panel.panelW - c),
      yMin: c,
      yMax: Math.max(c, panel.panelH - c),
    };
  }

  // Top / Bottom hosts: interior walls project onto the panel from below.
  const t = sideWallThicknessFor(inputs);
  // Baffle uses its CONFIG-AWARE thickness — RD-SBPB has a thick baffle
  // (0.945") even though sides + back stay thin (0.709"). Without this,
  // the safe-area front boundary lands 0.236" too close to the chamber
  // face on RD-SBPB designs, and the plate ends up 0.764" from the
  // baffle instead of the requested 1.0".
  const baffleT = baffleThicknessFor(inputs);
  const backT = t;   // back panel always uses side-wall thickness
  const ppT = t;     // PP1/PP2 wall thickness (same as sides)
  const portW = inputs.portWidth;
  const isDual = inputs.portQuantity === 'Dual';

  // Read PP1's chamber-depth from the cut list when available. `Port Piece 1`
  // (single port) or `Port Piece 1 Left` (dual port) records the depth
  // measured front-to-back behind the baffle — the L-port channel length.
  const pp1Part = cutList?.find(p =>
    p.partName === 'Port Piece 1' || p.partName === 'Port Piece 1 Left',
  );
  // Fallback: derive from calc when cut list isn't threaded through. Mirrors
  // the cut-list formula (boxDepth − portW − pp2Thickness − small mill/glue).
  const pp1Depth = pp1Part?.width ?? Math.max(0, inputs.boxDepth - portW - ppT - 0.1);

  // Y extent: from front baffle face to PP2's front face (so the plate
  // stays in the L-port's front chamber over the sub).
  const yMin = baffleT + c;
  const yMax = Math.max(yMin, baffleT + pp1Depth - c);

  if (isDual) {
    // Subs centered between two PP1 walls. PP1 left face X = t + portW.
    return {
      xMin: t + portW + ppT + c,
      xMax: Math.max(t + portW + ppT + c, panel.panelW - t - portW - ppT - c),
      yMin, yMax,
    };
  }

  // Single port: baffle's left edge is flush at world X = 0 (3D viewer
  // convention), so the sub chamber spans X = [t, baffleWidth − ppT].
  const baffleW = panel.panelW - portW - ppT;
  return {
    xMin: t + c,
    xMax: Math.max(t + c, baffleW - ppT - c),
    yMin, yMax,
  };
}

/**
 * Shrink the requested plate dimensions axis-by-axis to fit inside the
 * safe area. Preserves the original dims when they already fit. Returns
 * the shrunk dims plus a flag indicating whether anything was clamped.
 *
 * Auto-shrink rule: each axis independently capped at the safe area's
 * extent on that axis. Aspect ratio is NOT preserved on purpose — the
 * operator chose specific plate dimensions; we don't force them smaller
 * than necessary on the un-constrained axis.
 */
export function resolveAutoFitPlateDimensions(
  requested: { plateW: number; plateH: number },
  safe: SafeArea,
): { plateW: number; plateH: number; cutoutW: number; cutoutH: number; shrunk: boolean } {
  const maxW = Math.max(0, safe.xMax - safe.xMin);
  const maxH = Math.max(0, safe.yMax - safe.yMin);
  const plateW = Math.max(0, Math.min(requested.plateW, maxW));
  const plateH = Math.max(0, Math.min(requested.plateH, maxH));
  const shrunk = plateW < requested.plateW - 1e-6 || plateH < requested.plateH - 1e-6;
  const { cutoutW, cutoutH } = cutoutFromPlate(plateW, plateH);
  return { plateW, plateH, cutoutW, cutoutH, shrunk };
}

// ─── Default offsets ────────────────────────────────────────────────────────

/**
 * Recommended default `(xOffset, yOffset)` for newly-enabled windows so the
 * cutout sits OVER the subwoofer instead of geometric-panel-center.
 *
 *   SBPB single port → window on Top panel, sub mounts on baffle, but the
 *          baffle (and therefore the sub) is offset to one side of the box
 *          because the port channel occupies the other side. The Top panel
 *          spans the full box width and its geometric center sits in the
 *          port channel, not over the sub. Default shifts X so the cutout
 *          lines up with the sub chamber's center (S2 = left chamber).
 *
 *   SBPB dual port → subs are centered (port channels on both sides). No
 *          shift needed; default stays at panel center.
 *
 *   SUPB → window on Baffle. Sub mounts on Top, in a different plane —
 *          no useful "over the sub" reading. Default stays at panel center.
 *
 *   SUPU → window on Bottom. Sub is on the rotated-front face — no useful
 *          reading. Default stays at panel center.
 *
 * Y offset always defaults to 0 (panel center): users prefer the window
 * sitting mid-depth on the Top so it shows the chamber interior, not pressed
 * up against the baffle.
 *
 * Callers using the explicit values stored in `inputs.windowXOffset` /
 * `windowYOffset` are unaffected; this only affects the values WRITTEN when
 * the operator toggles the feature on or hits Recenter.
 */
export function resolveDefaultWindowOffsets(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList?: CutListItem[],
): { x: number; y: number } {
  if (calc.boxWidth <= 0) return { x: 0, y: 0 };

  // Y always defaults to the SAFE AREA's center (not the panel's center).
  // When auto-shrink collapses the Y axis of the safe area to a single
  // point — which happens when the plate just fills the chamber's depth
  // — that single point is the only fitting Y. Defaulting to Y=0 (panel
  // center) would land outside the single-point range and read as
  // "Won't fit" the moment the operator enables the window.
  //
  // X defaults to the safe-area center too, then we OVERRIDE it for
  // SBPB single-port single-sub designs to align with the sub's chamber
  // center (the sub sits off-center because the port channel takes one
  // side of the box). Override is clamped to the X-axis safe-offset range.
  const dims = resolveWindowDimensions({
    ...inputs,
    windowEnabled: true,
    windowSize: inputs.windowSize ?? '12x12',
  });
  const safe = resolveWindowSafeArea(inputs, calc, cutList);
  const fitted = resolveAutoFitPlateDimensions({ plateW: dims.plateW, plateH: dims.plateH }, safe);
  const panel = resolveHostPanelBox(inputs, calc);

  const safeCenterX = (safe.xMin + safe.xMax) / 2;
  const safeCenterY = (safe.yMin + safe.yMax) / 2;
  let xOffset = safeCenterX - panel.panelW / 2;
  const yOffset = safeCenterY - panel.panelH / 2;

  const hostPanel = resolveWindowPanel(inputs);
  const isSBPBSinglePortSingleSub =
    hostPanel === 'Top' &&
    inputs.portQuantity === 'Single' &&
    inputs.subwooferQuantity === 'Single' &&
    inputs.portWidth > 0;
  if (isSBPBSinglePortSingleSub) {
    // 3D viewer renders the baffle with its LEFT edge at world x=0 (sub
    // chamber on the left, port channel on the right), so sub world-X =
    // baffleWidth/2. Top panel covers full box width with center at
    // world boxW/2 → ideal xOffset = baffleW/2 − boxW/2.
    const ppT = sideWallThicknessFor(inputs);
    const baffleWidth = calc.boxWidth - inputs.portWidth - ppT;
    if (baffleWidth > 0) {
      const idealX = baffleWidth / 2 - calc.boxWidth / 2;
      const xOffMin = safe.xMin + fitted.plateW / 2 - panel.panelW / 2;
      const xOffMax = safe.xMax - fitted.plateW / 2 - panel.panelW / 2;
      xOffset = Math.max(xOffMin, Math.min(xOffMax, idealX));
    }
  }

  return { x: xOffset, y: yOffset };
}

// ─── Effective offsets (saved, clamped to safe range) ──────────────────────

/**
 * Return the (xOffset, yOffset) the renderer should actually use, starting
 * from the saved `inputs.windowX/YOffset` and clamping them to the safe-
 * offset range so the plate always lands inside the safe area on the host
 * panel.
 *
 * This is what the DXF generator and 3D viewer call when positioning the
 * cutout / plate mesh — legacy designs with offsets predating the safe-
 * area work (typically 0/0) get auto-corrected to the nearest fitting
 * position at render time, without mutating the saved data.
 *
 * Returns 0/0 when the window isn't enabled (no rendering needed).
 */
export function resolveEffectiveWindowOffsets(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList?: CutListItem[],
): { x: number; y: number } {
  if (!inputs.windowEnabled) return { x: 0, y: 0 };

  const savedX = inputs.windowXOffset ?? 0;
  const savedY = inputs.windowYOffset ?? 0;

  const dims = resolveWindowDimensions(inputs);
  const safe = resolveWindowSafeArea(inputs, calc, cutList);
  const fitted = resolveAutoFitPlateDimensions(
    { plateW: dims.plateW, plateH: dims.plateH },
    safe,
  );
  const panel = resolveHostPanelBox(inputs, calc);
  const halfW = fitted.plateW / 2;
  const halfH = fitted.plateH / 2;
  const xOffMin = safe.xMin + halfW - panel.panelW / 2;
  const xOffMax = safe.xMax - halfW - panel.panelW / 2;
  const yOffMin = safe.yMin + halfH - panel.panelH / 2;
  const yOffMax = safe.yMax - halfH - panel.panelH / 2;

  return {
    x: Math.max(xOffMin, Math.min(xOffMax, savedX)),
    y: Math.max(yOffMin, Math.min(yOffMax, savedY)),
  };
}

// ─── Placement check ────────────────────────────────────────────────────────

export interface WindowPlacementCheck {
  /** True if the (auto-fitted) plate sits entirely inside the safe area. */
  safe: boolean;
  /** When `safe` is false, a short label describing the conflict. */
  conflict?: { label: string };
  /** Plate center in panel-local coordinates (origin = bottom-left). */
  center: { x: number; y: number };
  /** Auto-fitted plate + cutout dims (may be smaller than requested when
   *  the safe area can't accommodate the chosen size). */
  dimensions: WindowDimensions;
  /** Whether the plate was shrunk to fit the safe area. */
  shrunk: boolean;
  /** Originally-requested plate dimensions before auto-shrink. */
  requested: { plateW: number; plateH: number };
  /** The host panel's dimensions. */
  panel: PanelBox;
  /** The panel-local safe rectangle the plate is required to fit inside. */
  safeArea: SafeArea;
  /** Slider's safe-offset range relative to the panel center, accounting
   *  for the auto-fitted plate dims. */
  range: { xMin: number; xMax: number; yMin: number; yMax: number };
}

/**
 * Validate a plate placement (or a hypothetical override). Returns the
 * auto-fitted plate, the safe area, and the slider's offset range.
 *
 * `xOffsetOverride` / `yOffsetOverride` use the same panel-center frame as
 * `windowXOffset` / `windowYOffset`. When both are undefined the function
 * reads from `inputs.window*Offset` (default 0 → centered).
 *
 * `cutList` is optional — when provided, PP1's actual cut-list depth drives
 * the back of the safe area; otherwise we fall back to a calc-derived
 * estimate.
 */
export function checkWindowPlacement(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  xOffsetOverride?: number,
  yOffsetOverride?: number,
  cutList?: CutListItem[],
): WindowPlacementCheck {
  const requested = resolveWindowDimensions(inputs);
  const panel = resolveHostPanelBox(inputs, calc);
  const safeArea = resolveWindowSafeArea(inputs, calc, cutList);

  // Auto-shrink the plate to fit the safe area's extent on each axis.
  const fitted = resolveAutoFitPlateDimensions(
    { plateW: requested.plateW, plateH: requested.plateH },
    safeArea,
  );
  const dimensions: WindowDimensions = {
    plateW: fitted.plateW,
    plateH: fitted.plateH,
    cutoutW: fitted.cutoutW,
    cutoutH: fitted.cutoutH,
  };

  const halfW = dimensions.plateW / 2;
  const halfH = dimensions.plateH / 2;
  const xOff = xOffsetOverride ?? inputs.windowXOffset ?? 0;
  const yOff = yOffsetOverride ?? inputs.windowYOffset ?? 0;
  const cx = panel.panelW / 2 + xOff;
  const cy = panel.panelH / 2 + yOff;

  // Slider offset range = where the plate center can sit while keeping
  // the plate inside the safe area. After auto-shrink this is always a
  // non-empty range when the safe area itself has any extent.
  const range = {
    xMin: safeArea.xMin + halfW - panel.panelW / 2,
    xMax: safeArea.xMax - halfW - panel.panelW / 2,
    yMin: safeArea.yMin + halfH - panel.panelH / 2,
    yMax: safeArea.yMax - halfH - panel.panelH / 2,
  };

  const safeAreaEmpty = safeArea.xMax <= safeArea.xMin || safeArea.yMax <= safeArea.yMin;
  if (safeAreaEmpty) {
    return {
      safe: false,
      conflict: { label: 'No safe area on the host panel — chamber too small after wall clearance' },
      center: { x: cx, y: cy },
      dimensions,
      shrunk: fitted.shrunk,
      requested: { plateW: requested.plateW, plateH: requested.plateH },
      panel,
      safeArea,
      range,
    };
  }

  // Plate-edge clearance check against the safe area.
  const result: WindowPlacementCheck = {
    safe: true,
    center: { x: cx, y: cy },
    dimensions,
    shrunk: fitted.shrunk,
    requested: { plateW: requested.plateW, plateH: requested.plateH },
    panel,
    safeArea,
    range,
  };
  if (cx - halfW < safeArea.xMin - 1e-6) {
    return { ...result, safe: false, conflict: { label: 'Plate left edge crosses left wall (side / port piece)' } };
  }
  if (cx + halfW > safeArea.xMax + 1e-6) {
    return { ...result, safe: false, conflict: { label: 'Plate right edge crosses right wall (side / port piece)' } };
  }
  if (cy - halfH < safeArea.yMin - 1e-6) {
    return { ...result, safe: false, conflict: { label: 'Plate front edge crosses the baffle' } };
  }
  if (cy + halfH > safeArea.yMax + 1e-6) {
    return { ...result, safe: false, conflict: { label: 'Plate back edge crosses the port-back wall (PP2)' } };
  }
  return result;
}

// ─── Snap-to-safe ───────────────────────────────────────────────────────────

/**
 * Find the nearest (xOffset, yOffset) pair that places the window safely.
 * Sweeps outward in 1/8" rings until safe or maxR is exhausted.
 */
export function findNearestSafeWindowOffsets(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  desired: { x: number; y: number } = {
    x: inputs.windowXOffset ?? 0,
    y: inputs.windowYOffset ?? 0,
  },
  cutList?: CutListItem[],
): { x: number; y: number } | null {
  const initial = checkWindowPlacement(inputs, calc, desired.x, desired.y, cutList);
  if (initial.safe) return desired;

  const step = 0.125;
  const maxR = 12;
  for (let r = step; r <= maxR; r += step) {
    for (const [dx, dy] of [
      [-r, 0], [r, 0], [0, -r], [0, r],
      [-r, -r], [r, -r], [-r, r], [r, r],
    ]) {
      const cand = { x: desired.x + dx, y: desired.y + dy };
      if (checkWindowPlacement(inputs, calc, cand.x, cand.y, cutList).safe) {
        return cand;
      }
    }
  }
  return null;
}

// ─── Cut-list integration ───────────────────────────────────────────────────

/**
 * Build the Acrylic Window cut-list entry. Returns null when the design
 * has no enabled window. Callers should append the result to their cut
 * list (when non-null) so the part shows up in the BOM and cost calc.
 *
 * Plate dimensions come straight from `resolveWindowDimensions(inputs)`
 * (windowSize describes the plate). When `calc` is supplied the plate is
 * auto-shrunk to fit the host panel's safe area so the cut list always
 * matches what the DXF generator actually emits.
 */
export function buildAcrylicWindowCutListEntry(
  inputs: EnclosureInputs,
  calc?: EnclosureCalculations,
  cutList?: CutListItem[],
): CutListItem | null {
  if (!inputs.windowEnabled) return null;
  const dim = resolveWindowDimensions(inputs);
  if (dim.plateW <= 0 || dim.plateH <= 0) return null;

  let { plateW, plateH } = dim;
  if (calc) {
    const safe = resolveWindowSafeArea(inputs, calc, cutList);
    const fitted = resolveAutoFitPlateDimensions({ plateW, plateH }, safe);
    plateW = fitted.plateW;
    plateH = fitted.plateH;
  }

  const thickness = resolveAcrylicThickness(inputs);
  return {
    partName: `Acrylic Window ${inputs.windowSize}`,
    width: plateW,
    height: plateH,
    quantity: 1,
    material: 'Acrylic',
    thickness,
  };
}

// (Type aliases like CutListItem / EnclosureInputs / EnclosureCalculations
// already flow through the barrel from `./types/enclosure` — no re-export
// needed here.)
