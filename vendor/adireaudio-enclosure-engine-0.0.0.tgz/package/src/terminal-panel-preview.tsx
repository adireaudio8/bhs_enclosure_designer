'use client';
import React, { useEffect, useMemo } from 'react';
import { DoubleSide, type Texture } from 'three';
import { terminalPanelGeometry, type TerminalPanelGeometryOptions } from './terminal-panel-geometry';

export interface TerminalPanelPreviewProps extends TerminalPanelGeometryOptions {
  position: [number,number,number]; rotation?: [number,number,number];
  color: string; opacity: number; texture?: Texture; showEdges?: boolean;
}

/** Shared rear terminal surface for both original Back and rotated SUPP Top. */
export function TerminalPanelPreview({position,rotation=[0,0,0],color,opacity,texture,showEdges=true,
  width,height,thickness,centerX,centerY,openingWidth,openingHeight,cornerRadius,roundoverRadius,outerCornerRadius}:TerminalPanelPreviewProps) {
  const {solid,edges,lipEdges}=useMemo(()=>terminalPanelGeometry({width,height,thickness,centerX,centerY,openingWidth,openingHeight,cornerRadius,roundoverRadius,outerCornerRadius}),
    [width,height,thickness,centerX,centerY,openingWidth,openingHeight,cornerRadius,roundoverRadius,outerCornerRadius]);
  useEffect(()=>()=>{solid.dispose();edges.dispose();lipEdges.dispose();},[solid,edges,lipEdges]);
  return <group position={position} rotation={rotation}>
    {opacity>0&&<mesh geometry={solid}>
      <meshStandardMaterial color={texture?'#ffffff':color} map={texture} transparent={opacity<1} opacity={opacity} side={DoubleSide}/>
    </mesh>}
    {(showEdges||opacity===0)&&<lineSegments geometry={edges}>
      <lineBasicMaterial color="#000000" transparent={opacity===0} opacity={opacity===0?.6:1}/>
    </lineSegments>}
    {opacity>0&&!showEdges&&(roundoverRadius??0)>0&&<lineSegments geometry={lipEdges}>
      <lineBasicMaterial color="#504637"/>
    </lineSegments>}
  </group>;
}
