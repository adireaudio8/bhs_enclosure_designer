import {
  Clipper64,
  ClipType,
  EndType,
  FillRule,
  JoinType,
  PointInPolygonResult,
  areaPaths,
  inflatePaths,
  isPositive,
  pointInPolygon,
  simplifyPaths,
  union,
  type Path64,
  type Paths64,
} from 'clipper2-ts';

/**
 * Pocket Logo Toolpath Generator
 * Generates CNC toolpath files (.xxl) in SCM Xilog Plus format for
 * logo pocket clearing (debossing) operations.
 * Ported from C# PocketLogoToolpathGenerator.cs
 *
 * Uses Clipper2 to normalize arbitrary closed contours and generate bounded,
 * concentric inward passes while preserving holes and islands.
 */

// ─── Tool Constants (match desktop exactly) ──────────────────────────────────

const SHEET_WIDTH_MM = 2438.4;  // 96" × 25.4
const SHEET_HEIGHT_MM = 1219.2; // 48" × 25.4

const TOOL_NUMBER = 104;        // 1/8" down spiral end mill
const SPINDLE_RPM = 18000;
const FEED_RATE = 1524;          // mm/min
const PLUNGE_RATE = 1842;        // mm/min

const TOOL_DIAMETER_MM = 3.175;  // 1/8" = 3.175mm
const TOOL_RADIUS_MM = TOOL_DIAMETER_MM / 2;
const STEP_OVER_FRACTION = 0.5;
const STEP_OVER_MM = TOOL_DIAMETER_MM * STEP_OVER_FRACTION; // 1.5875mm

const SAFE_HEIGHT = -38.1;      // 1.5" above (negative = above surface)
const APPROACH_HEIGHT = -5.08;   // 0.2" above
const CUT_DEPTH = 1.5875;       // 0.0625" depth
const RAMP_DISTANCE_MM = 6.35;  // 0.25" ramp distance

const INCHES_TO_MM = 25.4;
const INTEGER_SCALE = 1000;     // Integer microns for deterministic clipping
const ARC_CHORD_TOLERANCE_MM = 0.05;
const ARC_FIT_TOLERANCE_MM = 0.025;
const ARC_FIT_MAX_CHORD_ERROR_MM = 0.05;
const MIN_ARC_SWEEP_RADIANS = 5 * Math.PI / 180;
const MAX_ARC_SWEEP_RADIANS = Math.PI + 1e-4;
const MIN_ARC_POINTS = 4;
const MAX_ARC_SEED_POINTS = 12;
const CLIPPER_SIMPLIFY_TOLERANCE = 10; // 0.01mm at INTEGER_SCALE
const CLIPPER_ARC_TOLERANCE = 50;      // 0.05mm at INTEGER_SCALE
// Permit a short linking cut when a sharp feature disappears between insets.
// The pocket is only 1.5875mm deep and the connector is separately proven to
// remain inside the tool-center-safe region. Longer moves deliberately retract.
const MAX_LINK_DISTANCE_MM = 10;
const CONNECTOR_CLIP_TOLERANCE = 5;    // 0.005mm at INTEGER_SCALE

// Fail-closed limits. A normal logo is thousands (not hundreds of thousands)
// of moves. These stop corrupt/pathological geometry before an XXL can reach
// the router while still allowing complex full-panel artwork.
const MAX_OFFSET_ITERATIONS = 2048;
const MAX_POCKET_PATHS = 5000;
const MAX_TOOLPATH_POINTS = 200_000;
const MAX_OUTPUT_BYTES = 12 * 1024 * 1024;
const BOUNDS_TOLERANCE_MM = 0.1;

// ─── Types ───────────────────────────────────────────────────────────────────

interface Point {
  x: number;
  y: number;
}

interface Polygon {
  points: Point[];
  closed: boolean;
}

interface DxfVertex extends Point {
  bulge: number;
}

interface Bounds {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

interface ArcFit {
  center: Point;
  radius: number;
  clockwise: boolean;
  sweep: number;
}

type ToolpathMove =
  | { type: 'line'; end: Point }
  | { type: 'arc'; end: Point; center: Point; clockwise: boolean };

type PocketChain = Point[][];

interface PocketChainEndpoints {
  chain: PocketChain;
  originalIndex: number;
  start: Point;
  end: Point;
}

interface PocketRing {
  path: Path64;
  pass: Point[];
  positive: boolean;
  chainIndex: number;
}

interface RingLink {
  previousIndex: number;
  nextIndex: number;
  distance: number;
  pass: Point[];
}

// ─── Robust Filled-Region Offsetting ────────────────────────────────────────
function toClipperPath(points: Point[]): Path64 {
  return points.map((point) => ({
    x: Math.round(point.x * INTEGER_SCALE),
    y: Math.round(point.y * INTEGER_SCALE),
  }));
}

function fromClipperPath(path: Path64): Point[] {
  return path.map((point) => ({
    x: point.x / INTEGER_SCALE,
    y: point.y / INTEGER_SCALE,
  }));
}

function getBounds(paths: Point[][]): Bounds {
  const bounds: Bounds = {
    minX: Number.POSITIVE_INFINITY,
    minY: Number.POSITIVE_INFINITY,
    maxX: Number.NEGATIVE_INFINITY,
    maxY: Number.NEGATIVE_INFINITY,
  };
  for (const path of paths) {
    for (const point of path) {
      bounds.minX = Math.min(bounds.minX, point.x);
      bounds.minY = Math.min(bounds.minY, point.y);
      bounds.maxX = Math.max(bounds.maxX, point.x);
      bounds.maxY = Math.max(bounds.maxY, point.y);
    }
  }
  return bounds;
}

function assertPointInBounds(point: Point, bounds: Bounds, context: string): void {
  if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) {
    throw new Error(`Pocket logo rejected: ${context} contains a non-finite coordinate`);
  }
  if (
    point.x < -BOUNDS_TOLERANCE_MM
    || point.y < -BOUNDS_TOLERANCE_MM
    || point.x > SHEET_WIDTH_MM + BOUNDS_TOLERANCE_MM
    || point.y > SHEET_HEIGHT_MM + BOUNDS_TOLERANCE_MM
  ) {
    throw new Error(
      `Pocket logo rejected: ${context} leaves the 96x48 sheet at `
      + `X=${point.x.toFixed(3)}, Y=${point.y.toFixed(3)}`,
    );
  }
  if (
    point.x < bounds.minX - BOUNDS_TOLERANCE_MM
    || point.x > bounds.maxX + BOUNDS_TOLERANCE_MM
    || point.y < bounds.minY - BOUNDS_TOLERANCE_MM
    || point.y > bounds.maxY + BOUNDS_TOLERANCE_MM
  ) {
    throw new Error(
      `Pocket logo rejected: an inward pass expanded beyond the source geometry at `
      + `X=${point.x.toFixed(3)}, Y=${point.y.toFixed(3)}`,
    );
  }
}

function squaredDistance(first: Point, second: Point): number {
  return (first.x - second.x) ** 2 + (first.y - second.y) ** 2;
}

function closedPass(points: Point[]): Point[] {
  return [...points, points[0]];
}

/**
 * Order completed pocket chains by the nearest available entry point.
 *
 * The offset/linking stage has already proven every cutting connector inside
 * its pocket. This function deliberately treats each chain as an immutable
 * unit: it changes only the order of safe-height entries, never pass geometry,
 * winding, depth, step-over, or the verified links within a chain.
 */
function orderPocketChainsForRapidTravel(chains: PocketChain[]): PocketChain[] {
  const remaining: PocketChainEndpoints[] = chains.flatMap((chain, originalIndex) => {
    const passes = chain.filter((pass) => pass.length >= 2);
    if (passes.length === 0) return [];
    const firstPass = passes[0];
    const lastPass = passes[passes.length - 1];
    return [{
      chain,
      originalIndex,
      start: firstPass[0],
      end: lastPass[lastPass.length - 1],
    }];
  });

  const ordered: PocketChain[] = [];
  let current: Point = { x: 0, y: 0 };
  while (remaining.length > 0) {
    let bestIndex = 0;
    let bestDistance = squaredDistance(current, remaining[0].start);
    for (let index = 1; index < remaining.length; index++) {
      const distance = squaredDistance(current, remaining[index].start);
      if (
        distance < bestDistance - 1e-9
        || (
          Math.abs(distance - bestDistance) <= 1e-9
          && remaining[index].originalIndex < remaining[bestIndex].originalIndex
        )
      ) {
        bestIndex = index;
        bestDistance = distance;
      }
    }

    const [next] = remaining.splice(bestIndex, 1);
    ordered.push(next.chain);
    current = next.end;
  }
  return ordered;
}

/**
 * Rotate a closed polygon to the point on its boundary nearest `reference`.
 * When the nearest point lies inside an edge, insert it without changing the
 * original contour or winding.
 */
function rotatePassNearestTo(points: Point[], reference: Point): { pass: Point[]; distance: number } {
  let bestDistanceSquared = Number.POSITIVE_INFINITY;
  let bestSegmentIndex = 0;
  let bestPoint = points[0];

  for (let index = 0; index < points.length; index++) {
    const start = points[index];
    const end = points[(index + 1) % points.length];
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const lengthSquared = dx * dx + dy * dy;
    const position = lengthSquared > 0
      ? Math.max(0, Math.min(1, (
        (reference.x - start.x) * dx + (reference.y - start.y) * dy
      ) / lengthSquared))
      : 0;
    const projected = {
      x: start.x + dx * position,
      y: start.y + dy * position,
    };
    const distanceSquared = squaredDistance(reference, projected);
    if (distanceSquared < bestDistanceSquared) {
      bestDistanceSquared = distanceSquared;
      bestSegmentIndex = index;
      bestPoint = projected;
    }
  }

  const nextIndex = (bestSegmentIndex + 1) % points.length;
  const vertexToleranceSquared = (1 / INTEGER_SCALE) ** 2;
  let rotated: Point[];
  if (squaredDistance(bestPoint, points[bestSegmentIndex]) <= vertexToleranceSquared) {
    rotated = [
      ...points.slice(bestSegmentIndex),
      ...points.slice(0, bestSegmentIndex),
    ];
  } else if (squaredDistance(bestPoint, points[nextIndex]) <= vertexToleranceSquared) {
    rotated = [
      ...points.slice(nextIndex),
      ...points.slice(0, nextIndex),
    ];
  } else {
    rotated = [
      bestPoint,
      ...points.slice(nextIndex),
      ...points.slice(0, nextIndex),
    ];
  }

  return {
    pass: closedPass(rotated),
    distance: Math.sqrt(bestDistanceSquared),
  };
}

function pathContainsPoint(path: Path64, point: Path64[number]): boolean {
  return pointInPolygon(point, path) !== PointInPolygonResult.IsOutside;
}

function pathLength(path: Path64): number {
  let length = 0;
  for (let index = 1; index < path.length; index++) {
    length += Math.hypot(
      path[index].x - path[index - 1].x,
      path[index].y - path[index - 1].y,
    );
  }
  return length;
}

/**
 * Prove the entire linking move remains inside the tool-center-safe region.
 * Clipping the open connector against the first tool-radius inset is stricter
 * than checking a few sample points and prevents a shortcut across a hole,
 * island, or narrow concavity.
 */
function connectorIsSafe(start: Point, end: Point, safeCenterRegion: Paths64): boolean {
  const connector = [toClipperPath([start, end])];
  const connectorLength = pathLength(connector[0]);
  if (connectorLength <= CONNECTOR_CLIP_TOLERANCE) return true;

  const clipper = new Clipper64();
  clipper.addOpenSubject(connector);
  clipper.addClip(safeCenterRegion);
  const closedSolution: Paths64 = [];
  const openSolution: Paths64 = [];
  if (!clipper.execute(ClipType.Intersection, FillRule.EvenOdd, closedSolution, openSolution)) {
    return false;
  }

  const clippedLength = openSolution.reduce((sum, path) => sum + pathLength(path), 0);
  return clippedLength + CONNECTOR_CLIP_TOLERANCE >= connectorLength;
}

function ringsAreNested(previous: PocketRing, nextPath: Path64, nextPositive: boolean): boolean {
  if (previous.positive !== nextPositive) return false;
  if (nextPositive) return pathContainsPoint(previous.path, nextPath[0]);
  return pathContainsPoint(nextPath, previous.path[0]);
}

/**
 * Normalize all contours as one even-odd filled region, preserving holes and
 * islands regardless of source winding, then iteratively inset that region.
 * Clipper2 resolves concavity and self-intersections before offsetting.
 */
function generatePocketPasses(polygons: Polygon[]): PocketChain[] {
  const inputPoints = polygons
    .filter((polygon) => polygon.closed && polygon.points.length >= 3)
    .map((polygon) => polygon.points);
  if (inputPoints.length === 0) return [];

  const sourceBounds = getBounds(inputPoints);
  for (const path of inputPoints) {
    for (const point of path) assertPointInBounds(point, sourceBounds, 'source geometry');
  }

  let region: Paths64 = union(inputPoints.map(toClipperPath), FillRule.EvenOdd);
  region = simplifyPaths(region, CLIPPER_SIMPLIFY_TOLERANCE);
  if (region.length === 0) return [];

  let previousArea = Math.abs(areaPaths(region));
  if (!Number.isFinite(previousArea) || previousArea <= 0) {
    throw new Error('Pocket logo rejected: source geometry has no positive filled area');
  }

  const chains: PocketChain[] = [];
  let previousRings: PocketRing[] = [];
  let safeCenterRegion: Paths64 | null = null;
  let pathCount = 0;
  let totalPoints = 0;
  let offset = Math.round(TOOL_RADIUS_MM * INTEGER_SCALE);
  let exhaustedNormally = false;

  for (let iteration = 0; iteration < MAX_OFFSET_ITERATIONS; iteration++) {
    let next = inflatePaths(
      region,
      -offset,
      JoinType.Round,
      EndType.Polygon,
      2,
      CLIPPER_ARC_TOLERANCE,
    );
    next = simplifyPaths(next, CLIPPER_SIMPLIFY_TOLERANCE);
    if (next.length === 0) {
      exhaustedNormally = true;
      break;
    }

    if (safeCenterRegion === null) safeCenterRegion = next;

    const nextArea = Math.abs(areaPaths(next));
    if (!Number.isFinite(nextArea) || nextArea >= previousArea - 1) {
      throw new Error(
        `Pocket logo rejected: inward offset did not reduce filled area at iteration ${iteration + 1}`,
      );
    }

    const nextPaths = next.filter((path) => path.length >= 3);
    const nextPoints = nextPaths.map(fromClipperPath);
    const possibleLinks: RingLink[] = [];

    if (safeCenterRegion !== null && previousRings.length > 0) {
      for (let previousIndex = 0; previousIndex < previousRings.length; previousIndex++) {
        const previous = previousRings[previousIndex];
        const linkStart = previous.pass[0];
        for (let nextIndex = 0; nextIndex < nextPaths.length; nextIndex++) {
          const nextPath = nextPaths[nextIndex];
          const positive = isPositive(nextPath);
          if (!ringsAreNested(previous, nextPath, positive)) continue;

          const candidate = rotatePassNearestTo(nextPoints[nextIndex], linkStart);
          if (candidate.distance > MAX_LINK_DISTANCE_MM) continue;
          if (!connectorIsSafe(linkStart, candidate.pass[0], safeCenterRegion)) continue;
          possibleLinks.push({ previousIndex, nextIndex, ...candidate });
        }
      }
    }

    // One-to-one, shortest-first matching handles normal concentric rings and
    // safely starts a fresh entry when an inset splits, merges, or is otherwise
    // ambiguous enough that no verified link exists.
    possibleLinks.sort((first, second) => first.distance - second.distance);
    const matchedPrevious = new Set<number>();
    const matchedNext = new Map<number, RingLink>();
    for (const link of possibleLinks) {
      if (matchedPrevious.has(link.previousIndex) || matchedNext.has(link.nextIndex)) continue;
      matchedPrevious.add(link.previousIndex);
      matchedNext.set(link.nextIndex, link);
    }

    const currentRings: PocketRing[] = [];
    for (let nextIndex = 0; nextIndex < nextPaths.length; nextIndex++) {
      const path = nextPaths[nextIndex];
      if (path.length < 3) continue;
      const link = matchedNext.get(nextIndex);
      const pass = link?.pass ?? closedPass(nextPoints[nextIndex]);
      const points = pass.slice(0, -1);
      for (const point of points) assertPointInBounds(point, sourceBounds, 'generated pass');
      totalPoints += pass.length;
      pathCount += 1;
      if (pathCount > MAX_POCKET_PATHS || totalPoints > MAX_TOOLPATH_POINTS) {
        throw new Error(
          `Pocket logo rejected: toolpath exceeds safety complexity limits `
          + `(${pathCount} paths, ${totalPoints} points)`,
        );
      }

      let chainIndex: number;
      if (link) {
        chainIndex = previousRings[link.previousIndex].chainIndex;
        chains[chainIndex].push(pass);
      } else {
        chainIndex = chains.length;
        chains.push([pass]);
      }
      currentRings.push({ path, pass, positive: isPositive(path), chainIndex });
    }

    previousRings = currentRings;
    region = next;
    previousArea = nextArea;
    offset = Math.round(STEP_OVER_MM * INTEGER_SCALE);
  }

  if (!exhaustedNormally) {
    throw new Error(
      `Pocket logo rejected: geometry did not collapse within ${MAX_OFFSET_ITERATIONS} inward passes`,
    );
  }
  return chains;
}

// ─── Pocket Arc Reconstruction ──────────────────────────────────────────────

function normalizeAngleDelta(angle: number): number {
  let normalized = angle;
  while (normalized <= -Math.PI) normalized += Math.PI * 2;
  while (normalized > Math.PI) normalized -= Math.PI * 2;
  return normalized;
}

/** Least-squares circle fit, centered first to keep large sheet coordinates stable. */
function fitCircle(points: Point[]): { center: Point; radius: number } | null {
  if (points.length < 3) return null;

  const meanX = points.reduce((sum, point) => sum + point.x, 0) / points.length;
  const meanY = points.reduce((sum, point) => sum + point.y, 0) / points.length;
  let sumUU = 0;
  let sumUV = 0;
  let sumVV = 0;
  let rhsU = 0;
  let rhsV = 0;

  for (const point of points) {
    const u = point.x - meanX;
    const v = point.y - meanY;
    const squaredRadius = u * u + v * v;
    sumUU += u * u;
    sumUV += u * v;
    sumVV += v * v;
    rhsU += u * squaredRadius / 2;
    rhsV += v * squaredRadius / 2;
  }

  const determinant = sumUU * sumVV - sumUV * sumUV;
  const matrixScale = (sumUU + sumVV) ** 2;
  if (!Number.isFinite(determinant) || matrixScale <= 0 || Math.abs(determinant) < matrixScale * 1e-10) {
    return null;
  }

  const centerU = (rhsU * sumVV - rhsV * sumUV) / determinant;
  const centerV = (sumUU * rhsV - sumUV * rhsU) / determinant;
  const center = { x: meanX + centerU, y: meanY + centerV };
  const radii = points.map((point) => Math.hypot(point.x - center.x, point.y - center.y));
  const radius = radii.reduce((sum, value) => sum + value, 0) / radii.length;
  if (!Number.isFinite(radius) || radius < 0.05 || radius > 100_000) return null;
  if (radii.some((value) => Math.abs(value - radius) > ARC_FIT_TOLERANCE_MM)) return null;

  return { center, radius };
}

/**
 * Fit one verified circular run. Besides radial fit error, limit the bow
 * between every original chord and the emitted arc so reconstruction never
 * moves the cutter materially away from Clipper2's already-validated path.
 */
function fitArc(points: Point[]): ArcFit | null {
  if (points.length < MIN_ARC_POINTS) return null;
  const initialCircle = fitCircle(points);
  if (!initialCircle) return null;

  // A least-squares center minimizes total error but is not guaranteed to be
  // exactly equidistant from the command endpoints. Xilog validates that
  // equality before executing G2/G3, so project the center onto the endpoints'
  // perpendicular bisector and revalidate the entire point run.
  const start = points[0];
  const end = points[points.length - 1];
  const chordX = end.x - start.x;
  const chordY = end.y - start.y;
  const endpointChord = Math.hypot(chordX, chordY);
  if (endpointChord < 1e-6) return null;
  const midpoint = { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2 };
  const normal = { x: -chordY / endpointChord, y: chordX / endpointChord };
  const centerDistance = (initialCircle.center.x - midpoint.x) * normal.x
    + (initialCircle.center.y - midpoint.y) * normal.y;
  const center = {
    x: midpoint.x + normal.x * centerDistance,
    y: midpoint.y + normal.y * centerDistance,
  };
  const radius = Math.hypot(start.x - center.x, start.y - center.y);
  if (!Number.isFinite(radius) || radius < 0.05 || radius > 100_000) return null;
  if (points.some((point) => (
    Math.abs(Math.hypot(point.x - center.x, point.y - center.y) - radius) > ARC_FIT_TOLERANCE_MM
  ))) return null;

  let direction = 0;
  let signedSweep = 0;
  for (let index = 1; index < points.length; index++) {
    const previous = points[index - 1];
    const current = points[index];
    const chord = Math.hypot(current.x - previous.x, current.y - previous.y);
    if (chord > radius * 2 + ARC_FIT_TOLERANCE_MM) return null;
    const halfChord = Math.min(radius, chord / 2);
    const chordError = radius - Math.sqrt(Math.max(0, radius ** 2 - halfChord ** 2));
    if (chordError > ARC_FIT_MAX_CHORD_ERROR_MM) return null;

    const previousAngle = Math.atan2(previous.y - center.y, previous.x - center.x);
    const currentAngle = Math.atan2(current.y - center.y, current.x - center.x);
    const delta = normalizeAngleDelta(currentAngle - previousAngle);
    if (Math.abs(delta) < 1e-8) continue;
    const deltaDirection = Math.sign(delta);
    if (direction === 0) direction = deltaDirection;
    else if (deltaDirection !== direction) return null;
    signedSweep += delta;
    if (Math.abs(signedSweep) > MAX_ARC_SWEEP_RADIANS) return null;
  }

  const sweep = Math.abs(signedSweep);
  if (direction === 0 || sweep < 1e-8) return null;
  return {
    center,
    radius,
    clockwise: direction < 0,
    sweep,
  };
}

/** Greedily replace the longest verified circular runs with G2/G3 moves. */
function reconstructPocketMoves(points: Point[]): ToolpathMove[] {
  const moves: ToolpathMove[] = [];
  let start = 0;

  while (start < points.length - 1) {
    let best: { end: number; fit: ArcFit } | null = null;
    const firstCandidateEnd = start + MIN_ARC_POINTS - 1;

    if (firstCandidateEnd < points.length) {
      for (let end = firstCandidateEnd; end < points.length; end++) {
        const fit = fitArc(points.slice(start, end + 1));
        if (!fit) {
          // Very shallow arcs can be numerically indistinguishable from a
          // line over their first four samples. Permit a short seed window to
          // grow, but once an established arc stops fitting, end that arc.
          if (best || end - start + 1 >= MAX_ARC_SEED_POINTS) break;
          continue;
        }
        if (fit.sweep >= MIN_ARC_SWEEP_RADIANS) best = { end, fit };
      }
    }

    if (best) {
      moves.push({
        type: 'arc',
        end: points[best.end],
        center: best.fit.center,
        clockwise: best.fit.clockwise,
      });
      start = best.end;
    } else {
      moves.push({ type: 'line', end: points[start + 1] });
      start += 1;
    }
  }

  return moves;
}

// ─── XXL Toolpath Generation ─────────────────────────────────────────────────

function formatNum(n: number, decimals = 3): string {
  return n.toFixed(decimals);
}

/**
 * Generate the complete pocket toolpath in SCM Xilog Plus format.
 * All coordinates in mm.
 */
function generateToolpathContent(
  chains: PocketChain[],
  materialThickness: number
): string {
  const lines: string[] = [];

  // Header
  lines.push(`H DX=${SHEET_WIDTH_MM.toFixed(1)} DY=${SHEET_HEIGHT_MM.toFixed(1)} DZ=${materialThickness.toFixed(3)} BX=0 BY=0 BZ=0 -AB V=10 T=0 R=0 *MM /"def" `);
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Program Info vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push(';Name: Logo Pocket');
  lines.push(';');
  lines.push(';Tools Used:');
  lines.push(';104 = End Mill (0.125 inch) - Down Spiral');
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Setup Commands vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push('SY=0 M=1');
  lines.push('C=0');
  lines.push('SET ZFAST=38.100');
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Begin Operations vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push(';================================================================');
  lines.push(';Operation   : Logo Pocket');
  lines.push(';Tool used   : End Mill (0.125 inch) - Down Spiral');
  lines.push(`;Feed Rate   : V=${FEED_RATE.toFixed(0)} mm/min`);
  lines.push(`;Plunge Rate : V=${PLUNGE_RATE.toFixed(0)} mm/min`);
  lines.push(`;Spindle RPM : S=${SPINDLE_RPM} RPM`);
  lines.push(`;Step Over   : ${STEP_OVER_MM.toFixed(3)} mm (${(STEP_OVER_FRACTION * 100).toFixed(0)}% of tool diameter)`);
  lines.push(';================================================================');
  lines.push(';');

  // Generate one entry per safely linked chain of concentric offset rings.
  // Chains are globally ordered only after their internal cutting geometry is
  // final, minimizing safe-height travel without changing the finished pocket.
  for (const chain of orderPocketChainsForRapidTravel(chains)) {
    const passes = chain.filter((pass) => pass.length >= 2);
    if (passes.length === 0) continue;

    const firstPass = passes[0];
    const start = firstPass[0];

    // Rapid to safe height above the first ring in this chain.
    lines.push(`G0 X=${formatNum(start.x)} Y=${formatNum(start.y)} Z=${formatNum(SAFE_HEIGHT)} T=${TOOL_NUMBER} V=${PLUNGE_RATE.toFixed(0)} S=${SPINDLE_RPM} E=0 `);

    // Rapid to approach height
    lines.push(`G0 X=${formatNum(start.x)} Y=${formatNum(start.y)} Z=${formatNum(APPROACH_HEIGHT)} T=${TOOL_NUMBER} V=${PLUNGE_RATE.toFixed(0)} S=${SPINDLE_RPM} E=0 `);

    // Plunge to surface
    lines.push(`G1 X=${formatNum(start.x)} Y=${formatNum(start.y)} Z=${formatNum(0)} V=${PLUNGE_RATE.toFixed(0)} `);

    // Smooth ramp into cut depth
    if (firstPass.length >= 2) {
      const second = firstPass[1];
      const dx = second.x - start.x;
      const dy = second.y - start.y;
      const segLen = Math.sqrt(dx * dx + dy * dy);

      if (segLen > 0.001) {
        if (segLen >= RAMP_DISTANCE_MM) {
          const dirX = dx / segLen;
          const dirY = dy / segLen;
          const rampEndX = start.x + dirX * RAMP_DISTANCE_MM;
          const rampEndY = start.y + dirY * RAMP_DISTANCE_MM;
          lines.push(`G1 X=${formatNum(rampEndX)} Y=${formatNum(rampEndY)} Z=${formatNum(CUT_DEPTH)} V=${PLUNGE_RATE.toFixed(0)} `);
          lines.push(`G1 X=${formatNum(second.x)} Y=${formatNum(second.y)} Z=${formatNum(CUT_DEPTH)} V=${FEED_RATE.toFixed(0)}`);
        } else {
          lines.push(`G1 X=${formatNum(second.x)} Y=${formatNum(second.y)} Z=${formatNum(CUT_DEPTH)} V=${PLUNGE_RATE.toFixed(0)} `);
        }
      } else {
        lines.push(`G1 X=${formatNum(second.x)} Y=${formatNum(second.y)} Z=${formatNum(CUT_DEPTH)} V=${PLUNGE_RATE.toFixed(0)} `);
      }
    }

    // The first chord is reserved for a controller-safe linear ramp. Rebuild
    // every remaining verified circular run as G2/G3; irregular sections stay
    // as G1 so arbitrary logo geometry remains supported without distortion.
    const emitMoves = (points: Point[]): void => {
      const moves = reconstructPocketMoves(points);
      for (const move of moves) {
        if (move.type === 'arc') {
          const command = move.clockwise ? 'G2' : 'G3';
          lines.push(
            `${command} X=${formatNum(move.end.x)} Y=${formatNum(move.end.y)} `
            + `Z=${formatNum(CUT_DEPTH)} I=${formatNum(move.center.x)} `
            + `J=${formatNum(move.center.y)} V=${FEED_RATE.toFixed(0)}`,
          );
        } else {
          lines.push(
            `G1 X=${formatNum(move.end.x)} Y=${formatNum(move.end.y)} `
            + `Z=${formatNum(CUT_DEPTH)} V=${FEED_RATE.toFixed(0)}`,
          );
        }
      }
    };

    emitMoves(firstPass.slice(1));
    for (let passIndex = 1; passIndex < passes.length; passIndex++) {
      const pass = passes[passIndex];
      const linkEnd = pass[0];
      lines.push(
        `G1 X=${formatNum(linkEnd.x)} Y=${formatNum(linkEnd.y)} `
        + `Z=${formatNum(CUT_DEPTH)} V=${FEED_RATE.toFixed(0)}`,
      );
      emitMoves(pass);
    }
  }

  // Closing commands
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Closing Commands vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push('N X=0 Y=0');

  const content = lines.join('\n') + '\n';
  if (content.length > MAX_OUTPUT_BYTES) {
    throw new Error(
      `Pocket logo rejected: generated XXL is ${(content.length / 1024 / 1024).toFixed(1)} MiB `
      + `(safety limit ${(MAX_OUTPUT_BYTES / 1024 / 1024).toFixed(0)} MiB)`,
    );
  }
  return content;
}

// ─── DXF Parsing (Logo) ─────────────────────────────────────────────────────
// Parse the generated logo DXF to extract closed polylines on the engrave layer.

const LOGO_LAYER_NAME = 'ENGRAVE_LOGO_ON_LINE_0625';

function parseLogoDxfPolylines(dxfContent: string): Polygon[] {
  const polygons: Polygon[] = [];
  const lines = dxfContent.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (line === 'LWPOLYLINE') {
      const poly = parseLwPolyline(lines, i);
      if (poly && poly.points.length >= 3 && poly.layerName === LOGO_LAYER_NAME) {
        polygons.push({ points: poly.points, closed: poly.closed });
      }
    }
  }

  return polygons;
}

/** Expand a DXF bulge arc into short chords with bounded radial error. */
function appendBulgeArc(
  output: Point[],
  start: DxfVertex,
  end: DxfVertex,
  tolerance: number,
): void {
  if (Math.abs(start.bulge) < 1e-9) return;
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const chord = Math.hypot(dx, dy);
  if (chord < 1e-12) return;

  const sweep = 4 * Math.atan(start.bulge);
  const radius = chord * (1 + start.bulge * start.bulge) / (4 * Math.abs(start.bulge));
  const midpointX = (start.x + end.x) / 2;
  const midpointY = (start.y + end.y) / 2;
  const leftNormalX = -dy / chord;
  const leftNormalY = dx / chord;
  const centerDistance = chord * (1 - start.bulge * start.bulge) / (4 * start.bulge);
  const centerX = midpointX + leftNormalX * centerDistance;
  const centerY = midpointY + leftNormalY * centerDistance;
  const startAngle = Math.atan2(start.y - centerY, start.x - centerX);
  const toleranceRatio = Math.max(-1, Math.min(1, 1 - tolerance / Math.max(radius, tolerance)));
  const toleranceStep = 2 * Math.acos(toleranceRatio);
  const maxAngleStep = Math.min(Math.PI / 12, toleranceStep || Math.PI / 12);
  const segmentCount = Math.max(1, Math.ceil(Math.abs(sweep) / maxAngleStep));

  for (let segment = 1; segment < segmentCount; segment++) {
    const angle = startAngle + sweep * (segment / segmentCount);
    output.push({
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle),
    });
  }
}

function tessellateBulges(vertices: DxfVertex[], closed: boolean): Point[] {
  if (vertices.length < 2) return [];
  const result: Point[] = [];
  const edgeCount = closed ? vertices.length : vertices.length - 1;
  const toleranceInches = ARC_CHORD_TOLERANCE_MM / INCHES_TO_MM;

  for (let i = 0; i < edgeCount; i++) {
    const start = vertices[i];
    const end = vertices[(i + 1) % vertices.length];
    result.push({ x: start.x, y: start.y });
    appendBulgeArc(result, start, end, toleranceInches);
  }
  if (!closed) {
    const last = vertices[vertices.length - 1];
    result.push({ x: last.x, y: last.y });
  }
  return result;
}

function parseLwPolyline(
  lines: string[], startIdx: number
): { points: Point[]; closed: boolean; layerName: string } | null {
  let layerName = '';
  let closed = false;
  const vertices: DxfVertex[] = [];
  let currentX = 0;
  let currentY = 0;
  let currentBulge = 0;
  let hasVertex = false;
  let i = startIdx + 1;

  while (i < lines.length - 1) {
    const code = lines[i].trim();
    const value = (i + 1 < lines.length) ? lines[i + 1].trim() : '';

    if (code === '0') {
      if (hasVertex) vertices.push({ x: currentX, y: currentY, bulge: currentBulge });
      break;
    }

    if (code === '8') {
      layerName = value;
      i += 2;
    } else if (code === '70') {
      const flags = parseInt(value, 10);
      if (!isNaN(flags)) closed = (flags & 1) === 1;
      i += 2;
    } else if (code === '10') {
      if (hasVertex) vertices.push({ x: currentX, y: currentY, bulge: currentBulge });
      hasVertex = true;
      currentX = parseFloat(value) || 0;
      currentBulge = 0;
      i += 2;
    } else if (code === '20') {
      currentY = parseFloat(value) || 0;
      i += 2;
    } else if (code === '42') {
      currentBulge = parseFloat(value) || 0;
      i += 2;
    } else {
      i += 2;
    }
  }

  if (vertices.length < 2) return null;

  return {
    points: tessellateBulges(vertices, closed),
    closed,
    layerName,
  };
}

// ─── Public API ──────────────────────────────────────────────────────────────

/**
 * Generate a pocket logo toolpath (.xxl) from a logo DXF content string.
 * The logo DXF should contain LWPOLYLINE entities on the ENGRAVE_LOGO_ON_LINE_0625 layer.
 * Coordinates in the DXF are in inches; output is in mm (SCM Xilog Plus format).
 *
 * @param logoDxfContent - DXF file content string (from generateLogoDxf)
 * @param buildStrength - 'Standard Duty' | 'Regular Duty' | 'Heavy Duty'
 * @returns XXL toolpath content string, or null if no valid polygons found
 */
export function generatePocketLogoToolpath(
  logoDxfContent: string,
  buildStrength: string,
  materialThicknessMm?: number,
): string | null {
  // Material thickness
  const bs = buildStrength.toUpperCase();
  const materialThickness = materialThicknessMm
    ?? ((bs.includes('HD') || bs.includes('HEAVY')) ? 24.0 : 18.0);

  // Parse polylines from logo DXF
  const polygons = parseLogoDxfPolylines(logoDxfContent);
  const closedPolygons = polygons.filter(p => p.closed && p.points.length >= 3);

  if (closedPolygons.length === 0) return null;

  // Convert the complete contour set from inches to millimeters. It must be
  // offset as one region so nested contours become holes/islands instead of
  // being pocketed independently.
  const millimeterPolygons: Polygon[] = closedPolygons.map((poly) => ({
    points: poly.points.map(p => ({ x: p.x * INCHES_TO_MM, y: p.y * INCHES_TO_MM })),
    closed: true,
  }));
  const allPasses = generatePocketPasses(millimeterPolygons);

  if (allPasses.length === 0) return null;

  return generateToolpathContent(allPasses, materialThickness);
}
