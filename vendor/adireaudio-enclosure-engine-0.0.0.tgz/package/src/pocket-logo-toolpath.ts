/**
 * Pocket Logo Toolpath Generator
 * Generates CNC toolpath files (.xxl) in SCM Xilog Plus format for
 * logo pocket clearing (debossing) operations.
 * Ported from C# PocketLogoToolpathGenerator.cs
 *
 * Uses concentric inward offset passes to fill closed polygons.
 * Implements polygon offsetting without external dependencies.
 */

// ─── Tool Constants (match desktop exactly) ──────────────────────────────────

const SHEET_WIDTH_MM = 2438.4;  // 96" × 25.4
const SHEET_HEIGHT_MM = 1219.2; // 48" × 25.4

const TOOL_NUMBER = 104;        // 1/8" down spiral end mill
const SPINDLE_RPM = 18000;
const FEED_RATE = 1524;          // mm/min
const PLUNGE_RATE = 1842;        // mm/min

const TOOL_DIAMETER_MM = 3.175;  // 1/8" = 3.175mm
const TOOL_RADIUS_MM = TOOL_DIAMETER_MM / 2;
const STEP_OVER_FRACTION = 0.4;
const STEP_OVER_MM = TOOL_DIAMETER_MM * STEP_OVER_FRACTION; // 1.27mm

const SAFE_HEIGHT = -38.1;      // 1.5" above (negative = above surface)
const APPROACH_HEIGHT = -5.08;   // 0.2" above
const CUT_DEPTH = 1.5875;       // 0.0625" depth
const RAMP_DISTANCE_MM = 6.35;  // 0.25" ramp distance

const INCHES_TO_MM = 25.4;

// ─── Types ───────────────────────────────────────────────────────────────────

interface Point {
  x: number;
  y: number;
}

interface Polygon {
  points: Point[];
  closed: boolean;
}

// ─── Simple Polygon Offset ───────────────────────────────────────────────────
// Offset a closed polygon inward by computing per-vertex bisector normals.
// This is a simplified implementation that handles convex and most concave
// shapes correctly. For production with complex self-intersecting results,
// a full Clipper2 library would be needed.

function polygonArea(pts: Point[]): number {
  let area = 0;
  for (let i = 0; i < pts.length; i++) {
    const j = (i + 1) % pts.length;
    area += pts[i].x * pts[j].y;
    area -= pts[j].x * pts[i].y;
  }
  return area / 2;
}

function offsetPolygon(pts: Point[], amount: number): Point[] | null {
  const n = pts.length;
  if (n < 3) return null;

  // Ensure counter-clockwise winding (positive area)
  const area = polygonArea(pts);
  const ordered = area < 0 ? [...pts].reverse() : [...pts];

  const result: Point[] = [];

  for (let i = 0; i < n; i++) {
    const prev = ordered[(i - 1 + n) % n];
    const curr = ordered[i];
    const next = ordered[(i + 1) % n];

    // Edge vectors
    const dx1 = curr.x - prev.x;
    const dy1 = curr.y - prev.y;
    const dx2 = next.x - curr.x;
    const dy2 = next.y - curr.y;

    // Outward normals (perpendicular to edges, pointing outward for CCW)
    const len1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);
    const len2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);
    if (len1 < 1e-10 || len2 < 1e-10) continue;

    const nx1 = -dy1 / len1;
    const ny1 = dx1 / len1;
    const nx2 = -dy2 / len2;
    const ny2 = dx2 / len2;

    // Bisector normal (average of the two edge normals)
    let bx = nx1 + nx2;
    let by = ny1 + ny2;
    const bLen = Math.sqrt(bx * bx + by * by);
    if (bLen < 1e-10) {
      bx = nx1;
      by = ny1;
    } else {
      bx /= bLen;
      by /= bLen;
    }

    // Scale factor: amount / cos(half-angle between normals)
    const dot = nx1 * bx + ny1 * by;
    const scale = dot > 0.1 ? amount / dot : amount;

    result.push({
      x: curr.x + bx * scale,
      y: curr.y + by * scale,
    });
  }

  if (result.length < 3) return null;

  // Check if the polygon collapsed (self-intersecting / degenerate)
  const newArea = Math.abs(polygonArea(result));
  if (newArea < 0.01) return null; // Collapsed

  return result;
}

/**
 * Generate concentric inward offset passes for a closed polygon.
 * Points are in mm. Returns array of pass polylines (each closed).
 */
function generatePocketPasses(polygon: Polygon): Point[][] {
  const passes: Point[][] = [];
  if (!polygon.closed || polygon.points.length < 3) return passes;

  // Start with tool radius inset, then step inward
  let currentOffset = -TOOL_RADIUS_MM;

  // Work with a copy of the original points
  let currentPts = [...polygon.points];

  for (let iteration = 0; iteration < 500; iteration++) {
    const offsetPts = offsetPolygon(currentPts, currentOffset);
    if (!offsetPts || offsetPts.length < 3) break;

    // Close the pass (return to start)
    const pass = [...offsetPts, offsetPts[0]];
    passes.push(pass);

    // For subsequent passes, offset from the ORIGINAL polygon
    // (not from the offset result) to avoid cumulative error
    currentOffset -= STEP_OVER_MM;
  }

  return passes;
}

// ─── XXL Toolpath Generation ─────────────────────────────────────────────────

function formatNum(n: number, decimals = 3): string {
  return n.toFixed(decimals);
}

/**
 * Generate the complete pocket toolpath in SCM Xilog Plus format.
 * All coordinates in mm.
 */
function generateToolpathContent(
  passes: Point[][],
  materialThickness: number
): string {
  const lines: string[] = [];

  // Header
  lines.push(`H DX=${SHEET_WIDTH_MM.toFixed(1)} DY=${SHEET_HEIGHT_MM.toFixed(1)} DZ=${materialThickness.toFixed(3)} BX=0 BY=0 BZ=0 -AB V=10 T=0 R=0 *MM /"def" `);
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Program Info vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push(';Name: Logo Pocket');
  lines.push(';');
  lines.push(';Tools Used:');
  lines.push(';104 = End Mill (0.125 inch) - Down Spiral');
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Setup Commands vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push('SY=0 M=1');
  lines.push('C=0');
  lines.push('SET ZFAST=38.100');
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Begin Operations vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push(';================================================================');
  lines.push(';Operation   : Logo Pocket');
  lines.push(';Tool used   : End Mill (0.125 inch) - Down Spiral');
  lines.push(`;Feed Rate   : V=${FEED_RATE.toFixed(0)} mm/min`);
  lines.push(`;Plunge Rate : V=${PLUNGE_RATE.toFixed(0)} mm/min`);
  lines.push(`;Spindle RPM : S=${SPINDLE_RPM} RPM`);
  lines.push(`;Step Over   : ${STEP_OVER_MM.toFixed(3)} mm (${(STEP_OVER_FRACTION * 100).toFixed(0)}% of tool diameter)`);
  lines.push(';================================================================');
  lines.push(';');

  // Generate moves for each pass
  for (const pass of passes) {
    if (pass.length < 2) continue;

    const start = pass[0];

    // Rapid to safe height above start
    lines.push(`G0 X=${formatNum(start.x)} Y=${formatNum(start.y)} Z=${formatNum(SAFE_HEIGHT)} T=${TOOL_NUMBER} V=${PLUNGE_RATE.toFixed(0)} S=${SPINDLE_RPM} E=0 `);

    // Rapid to approach height
    lines.push(`G0 X=${formatNum(start.x)} Y=${formatNum(start.y)} Z=${formatNum(APPROACH_HEIGHT)} T=${TOOL_NUMBER} V=${PLUNGE_RATE.toFixed(0)} S=${SPINDLE_RPM} E=0 `);

    // Plunge to surface
    lines.push(`G1 X=${formatNum(start.x)} Y=${formatNum(start.y)} Z=${formatNum(0)} V=${PLUNGE_RATE.toFixed(0)} `);

    // Smooth ramp into cut depth
    if (pass.length >= 2) {
      const second = pass[1];
      const dx = second.x - start.x;
      const dy = second.y - start.y;
      const segLen = Math.sqrt(dx * dx + dy * dy);

      if (segLen > 0.001) {
        if (segLen >= RAMP_DISTANCE_MM) {
          const dirX = dx / segLen;
          const dirY = dy / segLen;
          const rampEndX = start.x + dirX * RAMP_DISTANCE_MM;
          const rampEndY = start.y + dirY * RAMP_DISTANCE_MM;
          lines.push(`G1 X=${formatNum(rampEndX)} Y=${formatNum(rampEndY)} Z=${formatNum(CUT_DEPTH)} V=${PLUNGE_RATE.toFixed(0)} `);
          lines.push(`G1 X=${formatNum(second.x)} Y=${formatNum(second.y)} Z=${formatNum(CUT_DEPTH)} V=${FEED_RATE.toFixed(0)}`);
        } else {
          lines.push(`G1 X=${formatNum(second.x)} Y=${formatNum(second.y)} Z=${formatNum(CUT_DEPTH)} V=${PLUNGE_RATE.toFixed(0)} `);
        }
      } else {
        lines.push(`G1 X=${formatNum(second.x)} Y=${formatNum(second.y)} Z=${formatNum(CUT_DEPTH)} V=${PLUNGE_RATE.toFixed(0)} `);
      }
    }

    // Feed through remaining points at cut depth
    for (let i = 2; i < pass.length; i++) {
      const pt = pass[i];
      lines.push(`G1 X=${formatNum(pt.x)} Y=${formatNum(pt.y)} Z=${formatNum(CUT_DEPTH)} V=${FEED_RATE.toFixed(0)}`);
    }
  }

  // Closing commands
  lines.push(';');
  lines.push(';================================');
  lines.push(';vvv Closing Commands vvv');
  lines.push(';================================');
  lines.push(';');
  lines.push('N X=0 Y=0');

  return lines.join('\n') + '\n';
}

// ─── DXF Parsing (Logo) ─────────────────────────────────────────────────────
// Parse the generated logo DXF to extract closed polylines on the engrave layer.

const LOGO_LAYER_NAME = 'ENGRAVE_LOGO_ON_LINE_0625';

function parseLogoDxfPolylines(dxfContent: string): Polygon[] {
  const polygons: Polygon[] = [];
  const lines = dxfContent.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (line === 'LWPOLYLINE') {
      const poly = parseLwPolyline(lines, i);
      if (poly && poly.points.length >= 3 && poly.layerName === LOGO_LAYER_NAME) {
        polygons.push({ points: poly.points, closed: poly.closed });
      }
    }
  }

  return polygons;
}

function parseLwPolyline(
  lines: string[], startIdx: number
): { points: Point[]; closed: boolean; layerName: string } | null {
  let layerName = '';
  let closed = false;
  const vertices: { x: number; y: number }[] = [];
  let currentX = 0;
  let currentY = 0;
  let hasVertex = false;
  let i = startIdx + 1;

  while (i < lines.length - 1) {
    const code = lines[i].trim();
    const value = (i + 1 < lines.length) ? lines[i + 1].trim() : '';

    if (code === '0') {
      if (hasVertex) vertices.push({ x: currentX, y: currentY });
      break;
    }

    if (code === '8') {
      layerName = value;
      i += 2;
    } else if (code === '70') {
      const flags = parseInt(value, 10);
      if (!isNaN(flags)) closed = (flags & 1) === 1;
      i += 2;
    } else if (code === '10') {
      if (hasVertex) vertices.push({ x: currentX, y: currentY });
      hasVertex = true;
      currentX = parseFloat(value) || 0;
      i += 2;
    } else if (code === '20') {
      currentY = parseFloat(value) || 0;
      i += 2;
    } else {
      i += 2;
    }
  }

  if (vertices.length < 2) return null;

  return {
    points: vertices.map(v => ({ x: v.x, y: v.y })),
    closed,
    layerName,
  };
}

// ─── Public API ──────────────────────────────────────────────────────────────

/**
 * Generate a pocket logo toolpath (.xxl) from a logo DXF content string.
 * The logo DXF should contain LWPOLYLINE entities on the ENGRAVE_LOGO_ON_LINE_0625 layer.
 * Coordinates in the DXF are in inches; output is in mm (SCM Xilog Plus format).
 *
 * @param logoDxfContent - DXF file content string (from generateLogoDxf)
 * @param buildStrength - 'Standard Duty' | 'Regular Duty' | 'Heavy Duty'
 * @returns XXL toolpath content string, or null if no valid polygons found
 */
export function generatePocketLogoToolpath(
  logoDxfContent: string,
  buildStrength: string
): string | null {
  // Material thickness
  const bs = buildStrength.toUpperCase();
  const materialThickness = (bs.includes('HD') || bs.includes('HEAVY')) ? 24.0 : 18.0;

  // Parse polylines from logo DXF
  const polygons = parseLogoDxfPolylines(logoDxfContent);
  const closedPolygons = polygons.filter(p => p.closed && p.points.length >= 3);

  if (closedPolygons.length === 0) return null;

  // Convert from inches to mm and generate pocket passes
  const allPasses: Point[][] = [];
  for (const poly of closedPolygons) {
    const mmPoly: Polygon = {
      points: poly.points.map(p => ({ x: p.x * INCHES_TO_MM, y: p.y * INCHES_TO_MM })),
      closed: true,
    };
    const passes = generatePocketPasses(mmPoly);
    allPasses.push(...passes);
  }

  if (allPasses.length === 0) return null;

  return generateToolpathContent(allPasses, materialThickness);
}
