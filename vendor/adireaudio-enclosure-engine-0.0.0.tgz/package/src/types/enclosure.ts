// Enclosure Calculator Types
// Ported from C# WPF application

export type EnclosureType =
  | 'MDF - Standard Duty'
  | 'MDF - Regular Duty'
  | 'MDF - Heavy Duty'
  | 'Birch Ply - Standard Duty'
  | 'Birch Ply - Regular Duty'
  | 'Birch Ply - Heavy Duty';

export type SubwooferQuantity = 'Single' | 'Dual' | 'Triple' | 'Quad';
export type PortQuantity = 'Single' | 'Dual';
// 'Subs Up/Port Up' is logically identical to 'Subs Back/Port Back' for cut
// list / DXF / cost / port-area purposes — same physical enclosure, same
// assembly. The orientation choice is purely a customer-facing install
// preference: tip the 'Subs Back/Port Back' box 90° onto its back so the
// subs + port fire toward the ceiling. The 3D viewer applies a rotation
// transform when this value is selected; all engine math treats it as
// 'Subs Back/Port Back' via the default branch of every config switch.
export type EnclosureConfiguration = 'Subs Back/Port Back' | 'Subs Up/Port Back' | 'Subs Up/Port Up';
export type AssemblyMethod = 'Press Together' | 'Pocket Screw' | 'Flat Pack';
export type SubwooferSize = '6.5"' | '8"' | '10"' | '12"' | '13.5"' | '15"' | '18"' | '21"';

// Material thickness configuration (from MasterInfoConfig)
export interface MaterialConfig {
  // Birch Ply thicknesses (inches)
  B1: number; // 18mm = 0.709"
  B2: number; // 24mm = 0.945"
  // Legacy finished-thickness fields, retained only for old config compatibility.
  // New joinery derives the remaining thickness from B1/B2 minus duty milling depth.
  C1: number; // unused saved value
  C2: number; // unused saved value
  // MDF thicknesses (inches)
  D1: number; // 3/4" = 0.75"
  D2: number; // 1" = 1.0"
  // LEGACY — "MDF after edge mill". MDF is NEVER milled (operator ruling
  // 2026-07-08): every MDF panel mate is full stock thickness (D1/D2).
  // The engine no longer reads E1/E2 anywhere; the fields survive only so
  // persisted master configs and API payloads that carry them keep parsing.
  E1: number; // unused (was 3/4" milled = 0.71")
  E2: number; // unused (was 1" milled = 0.96")
}

// User inputs for enclosure design
export interface EnclosureInputs {
  /** Resolved manufacturing assumptions, saved with each newly generated design. */
  manufacturingProfile?: import('../manufacturing-profile').ManufacturingProfile;
  // Dimensions
  boxDepth: number;
  boxHeight: number;
  portWidth: number;

  // Acoustic parameters
  tuningFrequency: number;
  netAirSpace: number;
  subDisplacement: number;
  subCutoutDiameter: number;
  outsideDiameter: number;
  /** Frozen catalog cutout in inches; absent means the legacy round opening. */
  subwooferCutoutProfile?: import('../subwoofer-profile').SubwooferCutoutProfile;

  // Configuration selections
  enclosureType: EnclosureType;
  enclosureConfiguration: EnclosureConfiguration;
  subwooferQuantity: SubwooferQuantity;
  portQuantity: PortQuantity;
  size: SubwooferSize;
  assemblyMethod: AssemblyMethod;

  // Brand/Model (optional)
  subwooferBrand?: string;
  subwooferModel?: string;

  // Custom enclosure (optional)
  isCustomEnclosure?: boolean;
  customNumber?: number;
  customNotes?: string;

  // Terminal cup placement (optional). Both fields unset = legacy hardcoded
  // behavior: Side Left for single port, Back for dual port, centered X,
  // 2.125" from panel bottom. When the user opts in via the Design tab's
  // Terminal section, both fields persist and override that default.
  // - terminalPanel: which cut-list panel hosts the cutout. Side Left / Back / Top host
  //   the cup; 'None' skips the cutout entirely (customer wires through
  //   later or uses a different connector — no flush terminal). Top/
  //   Bottom/Baffle conflict with sub cutouts and ports.
  // - terminalXOffset: inches from the panel's horizontal center. Positive
  //   shifts toward the back of the box (Side Left placement) or toward the
  //   right wall (Back placement). Negative is the opposite direction.
  //   Ignored when terminalPanel === 'None'.
  // Y is always 2.125" from the panel bottom (not user-adjustable in V1).
  terminalPanel?: 'Side Left' | 'Back' | 'Top' | 'None'; // Top = upright rear wall in Subs Up/Port Up
  terminalXOffset?: number;

  // Subwoofer cutout placement (optional, SUPB only). Both fields unset =
  // auto position (chamber center; combined-chamber fallback for narrow S2,
  // depth-shifted forward to clear the L-shape port leg). When set, the
  // offsets shift the WHOLE pattern (multi-sub stays symmetric). SBPB always
  // uses auto positioning — these fields have no effect for that config.
  // Validation guards against the sub's outside diameter (OD) — not just the
  // cutout — running into the side walls, PP1/PP2, or port channel.
  // - subwooferXOffset: + shifts toward the right (Side Right) wall
  // - subwooferYOffset: + shifts toward the back of the box
  subwooferXOffset?: number;
  subwooferYOffset?: number;
  // Independent centers, one per driver (Single through Quad), in inches.
  // SUPB: Top panel, X from Side Left, Y from the front face.
  // Other configurations: finished baffle, X from left, Y from bottom.
  // DXF milling margins/mirroring are applied after these local coordinates.
  // When present, these replace the shared offsets. Unset restores automatic placement.
  subwooferPositions?: { x: number; y: number }[];

  // Recessed (flush) sub mounting. When true, the box adds a sub-mount
  // plate INSIDE the box behind the structural baffle:
  //   - The structural baffle becomes 18mm regardless of duty (was 24mm
  //     for RD-SBPB and HD). It does the joinery (dowel holes, glues to
  //     side panels) and has a flange-recess hole = subOD + 0.25".
  //   - A sub-mount plate (24mm for RD/HD, 18mm for SD) sits glued and
  //     screwed to the back of the structural baffle. It carries the
  //     standard sub through-hole + mounting holes — this is what the
  //     sub actually mounts to. No dowel holes / no joinery to side
  //     panels (interior glue-up part).
  //   - Combined effect: net wood thickness in front of the chamber
  //     increases by exactly one B1/D1 (~0.709"/0.75") across all
  //     duties, reducing chamber depth by that amount.
  //   - Side Left / Port Piece 1 widths shift to use the thin-baffle
  //     formula since the structural front panel is 18mm.
  //   - New fitment check: minimum baffle height = subOD + 1.25"
  //     (0.25" recess clearance + 0.5" margin above and below).
  //
  // SBPB / SUPP use a thin structural face plus backing plate. SUPB uses a
  // thin cap above the top panel. Both constructions support Birch and MDF.
  recessedMounting?: boolean;

  /** Build-only, per-design ramps into existing Back/Baffle/Port 2 dowel holes. */
  addDowChannels?: boolean;

  // ── Acrylic (plexiglass) window — V1 ────────────────────────────────────
  //
  // Adds a clear acrylic cutout to ONE panel of the enclosure. The hosting
  // panel is auto-determined by enclosureConfiguration (NOT operator-pickable
  // — see acrylic-window.ts:resolveWindowPanel for the rule):
  //
  //   SBPB  → Top panel
  //   SUPB  → Baffle (front)
  //   SUPU  → Bottom panel (the visible "front face" after the SUPU rotation)
  //
  // Sizes are fixed-tier ($75 / $150) — no free-form sizing. Width/height
  // are derived from windowSize + windowOrientation; the operator never
  // types in dimensions directly.
  //
  // Edge clearance: ~1.5" from any panel edge (room for screws + gasket).
  // The slider's safe range clamps to these bounds, plus any obstacles on
  // the chosen panel (port openings, terminal cup, sub cutouts on SBPB top
  // / SUPU bottom — neither has any in V1, but the no-go check is robust).
  //
  // Acrylic thickness is engine-picked, not customer-facing:
  //   SD/RD → 1/4" (6mm)    HD → 3/8" (10mm)
  //
  // V1 ships single-window-per-design. LED edge-lighting / multi-window /
  // logo-shape windows are V2 — see BOX_CUSTOMIZATION_IDEAS.md.

  /** When true, the design includes an acrylic window cutout. Default false. */
  windowEnabled?: boolean;
  /** Size tier:
   *    `12x12` — square 12"×12" tier ($75 default upcharge)
   *    `24x12` — rectangular 24"×12" tier ($150 default upcharge)
   *    `custom` — operator-specified width × height; price tier looked up
   *               in `pricing_modifiers.acrylicWindow.tiers.custom`
   *               (defaults to the 24x12 tier price unless edited). When
   *               `custom`, `windowCustomWidth` + `windowCustomHeight`
   *               drive the actual cutout dimensions. */
  windowSize?: '12x12' | '24x12' | 'custom';
  /** Only meaningful for `24x12`. `landscape` = 24w × 12h, `portrait` =
   *  12w × 24h. Ignored for the square `12x12` and free-form `custom` tiers. */
  windowOrientation?: 'landscape' | 'portrait';
  /** Free-form acrylic PLATE width (inches) — the physical acrylic panel.
   *  The wood cutout is derived from it (plate − 2×1.25" overhang, floored at
   *  1"), NOT entered directly. Only read when `windowSize === 'custom'`.
   *  Default 12 if missing. (Comment corrected 2026-07-03 — it previously
   *  said "cutout", contradicting the implementation in acrylic-window.ts.) */
  windowCustomWidth?: number;
  /** Free-form acrylic PLATE height (inches) — see windowCustomWidth.
   *  Default 12 if missing. */
  windowCustomHeight?: number;
  /** Inches from panel center along the panel's horizontal axis. + shifts
   *  toward the panel's right edge as drawn. Slider clamps to safe range. */
  windowXOffset?: number;
  /** Inches from panel center along the panel's vertical axis. + shifts
   *  toward the panel's top/back edge. Slider clamps to safe range. */
  windowYOffset?: number;
  /** Cutout corner radius in inches. Default `0.125"` (1/8"). UI may offer
   *  a small picker (0 / 0.125 / 0.25). Bigger radius reads softer / more
   *  modern; sharper corners feel more industrial. */
  windowCornerRadius?: number;

  // ── Kerf Port — V1 ──────────────────────────────────────────────────────
  //
  // SBPB SINGLE-SLOT-PORT, BIRCH ONLY. When true, the Baffle and Port Piece 1
  // are built as a kerf-bent assembly with a rounded slot-port mouth:
  //   • SD → one continuous 18mm panel (baffle + curve + full PP1) bent 90°
  //   • HD → one continuous 24mm panel, same idea
  //   • RD → a 24mm "Baffle + Curve" bent piece with a 3" flat stub (the 24mm
  //          baffle keeps the sub) + a flat 18mm "Port 1" doweled onto the stub
  //          (inner port face flush, 6mm step on the chamber side). Standard
  //          horizontal dowels at the joint.
  // Kerf grooves (centerlines on the KERF_GROOVE_<depth>_DEEP layer) run the
  // full panel height in the bend zone — the bit cuts down the centerline. All
  // geometry lives in kerf-port.ts. Gated off for dual port, SUPB/SUPU, MDF,
  // and flush mount (kerfPortGate()).

  /** When true, Baffle + Port Piece 1 are built as a kerf-bent assembly. Default false. */
  kerfPortEnabled?: boolean;
  /** Centerline bend radius (inches), per design — the one adjustable kerf knob.
   *  Default 2.0". Inside radius ≈ radius − thickness/2. The groove COUNT derives
   *  from this (bigger radius → more cuts); spacing/depth are locked constants
   *  in kerf-port.ts (KERF_SPEC_18 / KERF_SPEC_24), never per-design. */
  kerfPortRadius?: number;

  // ── Labyrinth Port manual override ─────────────────────────────────────
  //
  // The calculator normally enters labyrinth mode only when the legacy
  // one-fold PP2 geometry cannot fit the volume-derived enclosure. Operators
  // can force the same shared serpentine solver for an otherwise valid
  // single, non-kerf slot port so its preview, cut list, saved design, and
  // manufacturing-review export all use the labyrinth topology.
  /** True forces labyrinth mode when the port has a valid second leg. False/undefined keeps automatic activation. */
  forceLabyrinthPort?: boolean;

  // ── Round flared port ──────────────────────────────────────────────────
  //
  // Round tube port(s) flared on both ends, in place of the slot port. The
  // tube mounts in the baffle beside the drivers, or in the right side panel
  // (roundPortLocation). When it is too long to run straight it turns through
  // one 90-degree elbow: from the baffle it then runs along the back wall,
  // from the right side it runs forward along the left side wall. Front-port
  // boxes only, single slot-port setting, not kerf, not labyrinth, not flush
  // mount (roundPortGate()). All maths is in round-port.ts; what a side port
  // must clear inside the box is in round-port-side.ts.
  /** When true the box is built with round flared port(s) instead of a slot port. Default false. */
  roundPortEnabled?: boolean;
  /** Inside diameter of each tube, inches. */
  roundPortDiameter?: number;
  /** Number of identical tubes. Default 1. */
  roundPortQuantity?: number;
  /** Radius of the flare on each end, inches. Default 1.6. */
  roundPortFlareRadius?: number;
  /** Wall thickness of tube, flares and elbow, inches. Default 0.125. */
  roundPortWall?: number;
  /** Centreline radius of the elbow, in tube diameters. Default 1.0. */
  roundPortElbowRadius?: number;
  /** Width of the mounting flange beyond the hole in the baffle, inches. Default 0.75. */
  roundPortFlangeWidth?: number;
  /** Which panel carries the port. Missing or 'Baffle': beside the drivers, as first built.
   *  'Side Right': in the right side panel (the left side carries the terminal cup), for boxes
   *  whose baffle has no room for a driver and a flare. */
  roundPortLocation?: 'Baffle' | 'Side Right';
}

// Calculated values (derived from inputs)
export interface EnclosureCalculations {
  // Volume calculations
  totalNeeded: number;
  subCutoutAdd: number;
  gussetDisplacement: number;
  adjustedNeeded: number;
  netAirSpaceForPortCalculations: number;
  netAirSpacePerChamber: number;

  // Dimension calculations
  internalHeight: number;
  internalDepthWithDB: number;
  mountingDepthAvail: number;
  boxWidth: number;
  internalWidth: number;

  // Port calculations
  portHeight: number;
  portArea: number;
  portLength1: number;
  portLengthNoEC: number;
  portLength2: number;
  sqInPerCube: number;
  /** Shared automatic serpentine-port layout. Active in any enclosure
   *  orientation when the legacy one-fold PP2 cannot fit. */
  labyrinthPort: import('../labyrinth-port').LabyrinthPortLayout;
  /** Round flared port layout. Derived only (not enumerable), like labyrinthPort;
   *  absent on calculation rows that were not produced by calculateEnclosure. */
  roundPort?: import('../round-port').RoundPortLayout;

  // S1 Right calculations
  s1RightWidth: number;
  s1RightHeight: number;
  s1RightDepth: number;
  s1RightArea: number;
  s1RightStillNeeded: number;

  // S2 Left calculations
  s2LeftWidth: number;
  s2LeftHeight: number;
  s2LeftDepth: number;
  s2LeftArea: number;
  s2LeftStillNeeded: number;

  // Baffle check (subwoofer fit validation)
  baffleCheck: BaffleCheckResult;
}

// Baffle check result (subwoofer fit validation)
export interface BaffleCheckResult {
  visible: boolean;
  mountLabel: string;
  /** Specific placement/port failure, when the shared 2D solver rejects it. */
  diagnostic?: string;
  /** Multi-sub SUPB measurements use resolved centers or the amber preview.
   * Preview spacing never establishes port/brace safety. Unavailable values
   * are placeholders and must not be displayed as measured clearances. */
  clearanceBasis?: 'layout' | 'preview' | 'unavailable';
  netWidth: number;
  edgeClearance: number;
  subToSubGap: number;
  showSubGap: boolean;
  status: 'OK' | 'Tight Fit' | 'DOES NOT FIT';
  isFail: boolean;
  isWarning: boolean;
}

// Cut list item
export interface CutListItem {
  partName: string;
  width: number;
  height: number;
  quantity: number;
  material: string;
  thickness: number;
  /** Kerf-port geometry for the merged "Baffle + Port 1" bent part. Set only on
   *  that part; drives the DXF panel + groove emission. Inline import type to
   *  avoid a circular module import with kerf-port.ts. */
  kerf?: import('../kerf-port').KerfGeometry;
}

// Weight & shipping calculations
export interface ShippingInfo {
  // Cardboard box auto-dimensions
  cartonLength: number;   // boxDepth + standard allowance + 3.3 mm per side
  cartonWidth: number;    // boxHeight + standard allowance + 3.3 mm per side
  cartonHeight: number;   // roundedBoxWidth + standard allowance + 3.3 mm per side

  // External shipping dimensions (carton + cardboard wall)
  externalLength: number; // cartonLength + 0.5512" (14mm)
  externalWidth: number;  // cartonWidth + 0.5512" (14mm)
  externalHeight: number; // cartonHeight + 1.1024" (28mm)

  // Weight calculations
  enclosureWeight: number;   // sum of part volumes × density (lbs)
  shippingWeight: number;    // enclosureWeight + 3 lbs packaging
  dimensionalWeight: number; // (L × W × H) / 139
  billableWeight: number;    // max(shipping, dimensional)
}

// Complete enclosure state
export interface EnclosureState {
  inputs: EnclosureInputs;
  calculations: EnclosureCalculations;
  cutList: CutListItem[];
  modelNumber: string;
}

// Default material configuration
export const DEFAULT_MATERIAL_CONFIG: MaterialConfig = {
  B1: 0.709,  // 18mm Birch Ply
  B2: 0.945,  // 24mm Birch Ply
  C1: 0.67,   // 18mm Birch after mill
  C2: 0.91,   // 24mm Birch after mill
  D1: 0.75,   // 3/4" MDF
  D2: 1.0,    // 1" MDF
  E1: 0.71,   // LEGACY, unused — MDF is never milled (see MaterialConfig)
  E2: 0.96,   // LEGACY, unused — MDF is never milled (see MaterialConfig)
};

// Default enclosure inputs (matches desktop: all zeros, Standard Duty)
export const DEFAULT_INPUTS: EnclosureInputs = {
  boxDepth: 0,
  boxHeight: 0,
  portWidth: 0,
  tuningFrequency: 0,
  netAirSpace: 0,
  subDisplacement: 0,
  subCutoutDiameter: 0,
  outsideDiameter: 0,
  enclosureType: 'Birch Ply - Standard Duty',
  enclosureConfiguration: 'Subs Back/Port Back',
  subwooferQuantity: 'Single',
  portQuantity: 'Single',
  size: '12"',
  assemblyMethod: 'Press Together',
};

// Available options for dropdowns
export const ENCLOSURE_TYPES: EnclosureType[] = [
  'MDF - Standard Duty',
  'MDF - Regular Duty',
  'MDF - Heavy Duty',
  'Birch Ply - Standard Duty',
  'Birch Ply - Regular Duty',
  'Birch Ply - Heavy Duty',
];

export const SUBWOOFER_QUANTITIES: SubwooferQuantity[] = ['Single', 'Dual', 'Triple', 'Quad'];
export const PORT_QUANTITIES: PortQuantity[] = ['Single', 'Dual'];
export const ENCLOSURE_CONFIGURATIONS: EnclosureConfiguration[] = ['Subs Back/Port Back', 'Subs Up/Port Back', 'Subs Up/Port Up'];
export const ASSEMBLY_METHODS: AssemblyMethod[] = ['Press Together', 'Pocket Screw', 'Flat Pack'];

// Default glue tolerance (clearance per milled edge for glue space)
export const DEFAULT_GLUE_TOLERANCE = 0.01;
export const SUBWOOFER_SIZES: SubwooferSize[] = ['6.5"', '8"', '10"', '12"', '13.5"', '15"', '18"', '21"'];
