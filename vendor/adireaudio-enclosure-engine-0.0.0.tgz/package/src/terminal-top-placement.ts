import type { CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import type { NoGoBand, PlacementCheck } from './terminal-placement';
import { resolveJoinery } from './manufacturing-profile';
import { baffleBraceCenters } from './subwoofer-profile';

// Top becomes the upright rear wall in Subs Up/Port Up. Its DXF Y=0 edge
// touches the baffle (physical top), so height above the floor runs toward -Y.
/** Fixed center clearance above the INSIDE floor; not a user setting. */
export const TOP_TERMINAL_CENTER_ABOVE_INSIDE_FLOOR = 3.5;
export const TERMINAL_PLATE_WIDTH = 6.5;
export const TERMINAL_PLATE_HEIGHT = 4.75;
const PLATE_CLEARANCE = .125;
export const TOP_TERMINAL_HALF_ENVELOPE = TERMINAL_PLATE_WIDTH / 2 + PLATE_CLEARANCE;

export function topTerminalCenter(width: number, depth: number, floorThickness: number, xOffset = 0) {
  if (!Number.isFinite(floorThickness) || floorThickness <= 0) throw new Error('Rear-wall terminal requires a positive floor stock thickness.');
  return { x: width / 2 + xOffset, y: depth - floorThickness - TOP_TERMINAL_CENTER_ABOVE_INSIDE_FLOOR };
}

/** Bands cover the mounting plate, screws and posts, not just the opening.
 * Use finished parts and saved joinery to match the actual panel assembly. */
export function topTerminalNoGoBands(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[]): NoGoBand[] {
  const top = parts.find(p => p.partName === 'Top');
  const width = top?.width ?? 0, depth = top?.height ?? 0;
  const blocked = (label: string): NoGoBand[] => [{ xMin: -Infinity, xMax: Infinity, reason: 'BindingPostClearance', label }];
  if (inputs.enclosureConfiguration !== 'Subs Up/Port Up') return blocked('Rear-wall placement on the Top panel requires Subs Up/Port Up. Choose another terminal panel.');
  const part = (name: string) => parts.find(p => p.partName === name);
  const left = part('Side Left'), right = part('Side Right'), back = part('Back'), baffle = part('Baffle') ?? part('Baffle + Port 1');
  const pp1 = part('Port Piece 1') ?? part('Port Piece 1 Left');
  const pp2 = part('Port Piece 2') ?? part('Port Piece 2 Left');
  if (![top, left, right, back, baffle, pp1].every(p => p && p.width > 0 && p.height > 0 && p.thickness > 0)) return blocked('Complete panel dimensions are required to check the rear-wall terminal.');
  if (calc.internalHeight < 2.0 + (part('Bottom')?.thickness ?? top!.thickness) + PLATE_CLEARANCE) return blocked('The enclosure is too shallow behind the rear wall for the terminal binding posts.');
  // In SUPP the cut-list Back is the floor. Use its full stock thickness,
  // not the narrow milled mating edge or the cut-list Bottom panel.
  const cy = topTerminalCenter(width, depth, back!.thickness).y;
  const yMin = cy - TERMINAL_PLATE_HEIGHT / 2 - PLATE_CLEARANCE;
  const yMax = cy + TERMINAL_PLATE_HEIGHT / 2 + PLATE_CLEARANCE;
  if (yMin < 0 || yMax > depth) return blocked('The rear wall is too short for the terminal mounting plate.');
  const joint = resolveJoinery(inputs);
  const bands: NoGoBand[] = [];
  const rect = (x0: number, x1: number, y0: number, y1: number, label: string, reason: NoGoBand['reason'] = 'BindingPostClearance') => {
    if (yMin < y1 && y0 < yMax) bands.push({ xMin: x0, xMax: x1, reason, label });
  };
  rect(0, left!.thickness, 0, depth, 'Side Left wall and terminal mounting plate');
  rect(width - right!.thickness, width, 0, depth, 'Side Right wall and terminal mounting plate');
  const mountPlate = part('Sub Mount Plate')?.thickness ?? 0;
  rect(0, width, 0, baffle!.thickness + mountPlate, 'Baffle / sub mounting plate');
  rect(0, width, depth - back!.thickness, depth, 'Back panel (floor) and terminal mounting plate');
  const dual = inputs.portQuantity === 'Dual', pw = inputs.portWidth;
  const ppT = pp1!.thickness, front = joint.frontMate, run = pp1!.width;
  const baffleWidth = width - (dual ? 2 : 1) * (pw + joint.port2Stock);
  if (dual) {
    rect(0, left!.thickness + pw + ppT, front, front + run, 'Left port channel / Port Piece 1', 'PP1');
    rect(width - right!.thickness - pw - ppT, width, front, front + run, 'Right port channel / Port Piece 1', 'PP1');
  } else {
    rect(baffleWidth - ppT, width, 0, front + run, 'Port channel / Port Piece 1', 'PP1');
  }
  if (calc.labyrinthPort.active) {
    for (const divider of calc.labyrinthPort.panels.slice(1)) {
      const p = part(`Port Piece ${divider.partNumber}`);
      if (!p) return blocked('A labyrinth divider is missing from the terminal clearance check.');
      const x = baffleWidth - ppT / 2 - divider.laneIndex * calc.labyrinthPort.lanePitch;
      const start = divider.anchoredAt === 'front' ? front : depth - joint.backMate - p.width;
      rect(x - p.thickness / 2, x + p.thickness / 2, start, start + p.width, `Port Piece ${divider.partNumber}`, 'PP2');
    }
  } else if (pp2 && pp2.width > 0) {
    const z = front + run + joint.port2VerticalOffset;
    // Keep the cup out of the return channel as well as the PP2 wall.
    if (dual) {
      rect(0, left!.thickness + pw + pp2.width, z, depth, 'Left return port / Port Piece 2', 'PP2');
      rect(width - right!.thickness - pw - pp2.width, width, z, depth, 'Right return port / Port Piece 2', 'PP2');
    } else rect(baffleWidth - pp2.width, width, z, depth, 'Return port / Port Piece 2', 'PP2');
  }
  const brace = parts.find(p => p.partName.startsWith('Gusset'));
  if (brace) for (const center of baffleBraceCenters(inputs, parts, calc)) {
    const x = center + (dual ? (width - baffleWidth) / 2 : 0);
    rect(x - brace.thickness / 2, x + brace.thickness / 2, baffle!.thickness + mountPlate, baffle!.thickness + mountPlate + brace.width, 'Baffle brace and terminal mounting plate');
  }
  return bands;
}

export function checkTopTerminalPlacement(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[], xOffset: number): PlacementCheck {
  const width = parts.find(p => p.partName === 'Top')?.width ?? 0;
  const cx = width / 2 + xOffset;
  const footprint = { xMin: cx - TOP_TERMINAL_HALF_ENVELOPE, xMax: cx + TOP_TERMINAL_HALF_ENVELOPE };
  if (!Number.isFinite(xOffset) || footprint.xMin < 0 || footprint.xMax > width) return { safe: false, footprint, conflict: { xMin: 0, xMax: width, reason: 'BindingPostClearance', label: 'The terminal mounting plate extends past the Top panel edge.' } };
  const conflict = topTerminalNoGoBands(inputs, calc, parts).find(b => footprint.xMin < b.xMax && b.xMin < footprint.xMax);
  return { safe: !conflict, footprint, conflict };
}
