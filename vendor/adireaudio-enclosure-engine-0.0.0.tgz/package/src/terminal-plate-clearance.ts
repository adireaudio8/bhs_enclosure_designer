/**
 * The inside plate behind a terminal cup keeps an inch from every piece around it.
 *
 * Andrew, November 20, 2026: "we need to make sure that we can't move the terminal cut so far in
 * one direction that the inside plate collides with the baffle, the back, or any piece left to
 * right. We need at least 1 inch between a corresponding piece and the inside terminal plate."
 *
 * The plate is the 6.5 x 4.75 in board glued inside the panel behind the cup's 4.5 x 2.75 in
 * opening (an inch past the opening on every side; the 3D view draws it). It stands 18 mm (Birch)
 * or 3/4 in (MDF) into the box. A piece counts when it meets the panel or begins within an inch of
 * the plate's inside face:
 *   - cup on Side Left: the Baffle (with the Sub Mount Plate behind a flush baffle) and the Back,
 *     and where they come that close to the panel, Port Piece 1, Port Piece 2 with the port
 *     channel behind it, a labyrinth divider and a brace between drivers;
 *   - cup on the Back: Side Left and Side Right, Port Piece 2 with the port channel behind it
 *     (always: the plate may not sit in the port), and the dividers and braces that come that close.
 * The plate keeps an inch from each of them, measured square to the box (an inch along the panel,
 * or an inch out from the panel past the plate). Up and down it keeps an inch from the top and
 * bottom panels. A round port has its own check against the cup (round-port-side.ts), and the Top
 * panel of a Subs Up/Port Up box its own bands (terminal-top-placement.ts), with the same inch.
 *
 * Spans are in the cup's offset frame: the opening's centre is at panelWidth / 2 + offset.
 */

import type { CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import { resolveJoinery } from './manufacturing-profile';
import { baffleBraceCenters } from './subwoofer-profile';
import { TERMINAL_PLATE_CLEARANCE, TERMINAL_PLATE_HEIGHT, TERMINAL_PLATE_WIDTH } from './terminal-top-placement';

/** How far the plate stands into the box: 18 mm Birch or 3/4 in MDF; the thicker is used. */
export const TERMINAL_PLATE_DEPTH = 0.75;

/** A piece beside the plate. */
export interface TerminalPlateNeighbour {
  /** Its span along the panel, in the offset frame. */
  from: number;
  to: number;
  /** How far in from the panel's inside face it begins: 0 when it meets the panel. */
  inset: number;
  /** The piece, as the cut list names it. */
  label: string;
}

export interface TerminalPlateLayout {
  /** Half the plate's length along the panel (the plate is turned a quarter turn with the cup). */
  halfLength: number;
  neighbours: TerminalPlateNeighbour[];
  /** Room between the plate and the top or bottom panel, whichever is nearer. */
  heightRoom: number;
  /** Why the plate cannot keep its inch from the top and bottom panels, when it cannot. */
  heightProblem?: string;
}

// 0.54″, 1″: two places at most, no trailing zeros. Messages end without a full stop: callers add one.
const inches = (value: number) => `${Number(value.toFixed(2))}″`;

/**
 * The pieces beside the plate on Side Left or the Back. `cup.turned` is true when the cup is
 * turned a quarter turn; `cup.centreAboveFloor` is the opening's centre above the panel's bottom
 * edge, null when the cup is centred on the panel's height.
 */
export function terminalPlateLayout(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  cutList: CutListItem[],
  panel: 'Side Left' | 'Back',
  panelWidth: number,
  cup: { turned: boolean; centreAboveFloor: number | null },
): TerminalPlateLayout {
  const part = (name: string) => cutList.find(p => p.partName === name);
  const joint = resolveJoinery(inputs);
  const mdf = inputs.enclosureType.includes('MDF');
  const thin = mdf ? joint.profile.materials.D1 : joint.profile.materials.B1;
  const dual = inputs.portQuantity === 'Dual';
  const reach = TERMINAL_PLATE_DEPTH + TERMINAL_PLATE_CLEARANCE;
  const halfLength = (cup.turned ? TERMINAL_PLATE_HEIGHT : TERMINAL_PLATE_WIDTH) / 2;

  // ── the box, in inches: x across from the outside of Side Left, z back from the front face ──
  const left = part('Side Left'), right = part('Side Right'), back = part('Back');
  const baffle = part('Baffle') ?? part('Baffle + Port 1');
  const mountPlate = part('Sub Mount Plate');
  const boxW = back?.width ?? part('Top')?.width ?? calc.boxWidth;
  const boxD = inputs.boxDepth;
  const tLeft = left?.thickness ?? thin;
  const tRight = right?.thickness ?? tLeft;
  const tBack = back?.thickness ?? joint.port2Stock;
  const baffleInside = (baffle?.thickness ?? joint.frontMate - joint.profile.glueTolerance + joint.depth)
    + (mountPlate?.thickness ?? 0);
  const backInside = boxD - tBack;
  const pW = Math.max(0, Number(inputs.portWidth) || 0);
  const round = !!calc.roundPort?.active;
  const labyrinth = !!calc.labyrinthPort?.active;
  const pp1 = part('Port Piece 1') ?? part('Port Piece 1 Left');
  const pp2 = part('Port Piece 2') ?? part('Port Piece 2 Left');
  const pp1Thickness = pp1?.thickness ?? joint.port2Stock;
  const pp1Run = pp1?.width ?? Math.max(0, calc.portLength1 || 0);
  // Where Port Piece 1's outer face meets the baffle (the 3D view's baffle width).
  const baffleEnd = round ? boxW : dual ? boxW - 2 * (pW + joint.port2Stock) : boxW - (pW + joint.port2Stock);
  const pp2Front = joint.frontMate + pp1Run + joint.port2VerticalOffset;
  const slot = !round && !labyrinth && pW > 0 && !!pp2 && pp2.width > 0;
  const brace = cutList.find(p => p.partName.startsWith('Gusset'));
  const braceCentres = brace ? baffleBraceCenters(inputs, cutList, calc).filter(Number.isFinite)
    .map(centre => centre + (dual ? (boxW - baffleEnd) / 2 : 0)) : [];
  const dividers = labyrinth ? calc.labyrinthPort.panels.slice(1).map(divider => {
    const piece = part(`Port Piece ${divider.partNumber}`);
    const thickness = piece?.thickness ?? pp1Thickness;
    const length = piece?.width ?? calc.labyrinthPort.fullDividerLength * divider.fullLengthFraction;
    const x = baffleEnd - pp1Thickness / 2 - divider.laneIndex * calc.labyrinthPort.lanePitch;
    const z0 = divider.anchoredAt === 'front' ? joint.frontMate : boxD - joint.backMate - length;
    return { label: `Port Piece ${divider.partNumber}`, x0: x - thickness / 2, x1: x + thickness / 2, z0, z1: z0 + length };
  }) : [];

  const neighbours: TerminalPlateNeighbour[] = [];
  if (panel === 'Side Left') {
    // Along the panel: z, from where the panel starts (behind the baffle; at the front face
    // when the port runs along it). In from the panel: x past the inside of Side Left.
    const start = dual ? 0 : joint.frontMate;
    const add = (from: number, to: number, x: number, label: string) => {
      if (x - tLeft < reach - 1e-9) neighbours.push({ from: from - start, to: to - start, inset: Math.max(0, x - tLeft), label });
    };
    if (dual) add(-Infinity, 0, 0, 'the front of the box');
    else add(-Infinity, baffleInside, 0, mountPlate ? 'the Sub Mount Plate' : 'the Baffle');
    add(backInside, Infinity, 0, 'the Back');
    if (slot && pp1) {
      // The left port of a dual port runs along this panel: Port Piece 1, then Port Piece 2 and its channel.
      if (dual) add(joint.frontMate, Infinity, tLeft + pW, 'Port Piece 1 and the port');
      else {
        add(joint.frontMate, joint.frontMate + pp1Run, baffleEnd - pp1Thickness, 'Port Piece 1');
        add(pp2Front, Infinity, baffleEnd - pp2!.width, 'Port Piece 2 and the port behind it');
      }
    }
    for (const divider of dividers) add(divider.z0, divider.z1, divider.x0, divider.label);
    if (brace) for (const centre of braceCentres) {
      add(baffleInside, baffleInside + brace.width, centre - brace.thickness / 2, brace.partName);
    }
  } else {
    // Along the Back: x, from where the offset frame starts. In from the panel: z before the back.
    const start = boxW / 2 - panelWidth / 2;
    const add = (from: number, to: number, inset: number, label: string) => {
      if (inset < reach - 1e-9) neighbours.push({ from: from - start, to: to - start, inset: Math.max(0, inset), label });
    };
    add(-Infinity, tLeft, 0, 'Side Left');
    add(boxW - tRight, Infinity, 0, 'Side Right');
    if (slot) {
      if (dual) {
        add(-Infinity, tLeft + pW + pp2!.width, 0, 'the left port and its Port Piece 2');
        add(boxW - tRight - pW - pp2!.width, Infinity, 0, 'the right port and its Port Piece 2');
      } else add(baffleEnd - pp2!.width, Infinity, 0, 'Port Piece 2 and the port behind it');
    }
    // A labyrinth turns at the back between its dividers: keep the plate out of the whole maze.
    if (dividers.length) add(Math.min(...dividers.map(d => d.x0)), Infinity, 0, 'the labyrinth port');
    if (brace) for (const centre of braceCentres) {
      add(centre - brace.thickness / 2, centre + brace.thickness / 2, backInside - (baffleInside + brace.width), brace.partName);
    }
  }

  // Up and down: the plate keeps an inch from the top and bottom panels.
  const height = part(panel)?.height ?? calc.internalHeight;
  const halfHeight = (cup.turned ? TERMINAL_PLATE_WIDTH : TERMINAL_PLATE_HEIGHT) / 2;
  const centre = cup.centreAboveFloor ?? height / 2;
  const below = centre - halfHeight, above = height - centre - halfHeight;
  const heightRoom = Math.min(below, above);
  const nearer = above <= below ? 'Top' : 'Bottom';
  const heightProblem = heightRoom >= TERMINAL_PLATE_CLEARANCE - 1e-9 ? undefined
    : heightRoom < 0
      ? `The panel is too short for the cup's inside plate: it would run ${inches(-heightRoom)} into the ${nearer} panel; it needs ${inches(TERMINAL_PLATE_CLEARANCE)} clear of it`
      : `The panel is too short for the cup's inside plate: it would be ${inches(heightRoom)} from the ${nearer} panel; it needs ${inches(TERMINAL_PLATE_CLEARANCE)}`;
  return { halfLength, neighbours, heightRoom, ...(heightProblem ? { heightProblem } : {}) };
}

/**
 * The nearest piece the plate comes within an inch of, with its opening centred at `centre`.
 * `gap` is the room between them, measured square to the box; negative when the plate runs into
 * the piece (then by how far along the panel).
 */
export function terminalPlateConflict(layout: TerminalPlateLayout, centre: number):
  { neighbour: TerminalPlateNeighbour; gap: number; message: string } | null {
  let worst: { neighbour: TerminalPlateNeighbour; gap: number } | null = null;
  const lo = centre - layout.halfLength, hi = centre + layout.halfLength;
  for (const neighbour of layout.neighbours) {
    const along = Math.max(neighbour.from - hi, lo - neighbour.to);   // negative: level with the piece
    const across = neighbour.inset - TERMINAL_PLATE_DEPTH;            // negative: the piece reaches the plate
    const gap = along < 0 && across < 0 ? along : Math.max(along, across);
    if (gap < TERMINAL_PLATE_CLEARANCE - 1e-9 && (!worst || gap < worst.gap)) worst = { neighbour, gap };
  }
  if (!worst) return null;
  const { neighbour, gap } = worst;
  const need = inches(TERMINAL_PLATE_CLEARANCE);
  // A plate wholly over a piece's span (a port channel, say) overlaps it; otherwise it runs into it.
  const message = gap < 0 && -gap >= 2 * layout.halfLength
    ? `The cup's inside plate would overlap ${neighbour.label}; it needs ${need} clear of it`
    : gap < 0
    ? `The cup's inside plate would run ${inches(-gap)} into ${neighbour.label}; it needs ${need} clear of it`
    : `The cup's inside plate would be ${inches(gap)} from ${neighbour.label}; it needs ${need}`;
  return { neighbour, gap, message };
}

/**
 * The first and last opening centres outside every forbidden span, or null when there is none.
 * `forbidden` are open intervals of centres; `[low, high]` bounds the centre. Spans in between
 * (a brace, a divider) stay forbidden: the placement check reports them.
 */
export function freeCentreSpan(low: number, high: number, forbidden: Array<[number, number]>):
  { min: number; max: number } | null {
  if (!(low <= high)) return null;
  const covering = (centre: number) => forbidden.find(([a, b]) => a < centre && centre < b);
  // Walk up from `low` past each span that covers the point, then down from `high` likewise.
  let min = low;
  for (let span = covering(min); span; span = covering(min)) min = span[1];
  if (!(min <= high)) return null;
  let max = high;
  for (let span = covering(max); span; span = covering(max)) max = span[0];
  return { min, max };
}
