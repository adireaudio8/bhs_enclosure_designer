import type { EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import { profileBounds } from './subwoofer-profile';

/** Dimension-mode readout uses the same frame and measured layout as fitment.
 * Do not present the default/required gap of an unavailable layout as measured. */
export function viewerDriverSpecifications(inputs: EnclosureInputs, calculations: EnclosureCalculations) {
  const inch = (n: number) => Number.isFinite(n) ? `${n.toFixed(4).replace(/0+$/, '').replace(/\.$/, '')}″` : '—';
  const profile = inputs.subwooferCutoutProfile;
  const opening = profile ? profileBounds(profile.opening) : null;
  const check = calculations.baffleCheck;
  return [
    { label: profile ? 'Outside frame' : 'Frame OD', value: profile
      ? `${inch(profile.frame.width)} × ${inch(profile.frame.height)}` : inputs.outsideDiameter > 0 ? inch(inputs.outsideDiameter) : '—' },
    { label: 'Cutout', value: opening ? `${inch(opening.width)} × ${inch(opening.height)}` : inputs.subCutoutDiameter > 0 ? inch(inputs.subCutoutDiameter) : '—' },
    ...(inputs.subwooferQuantity !== 'Single' && (check.clearanceBasis === 'layout' || check.clearanceBasis === 'preview')
      ? [{ label: 'Frame gap', value: inch(check.subToSubGap) }] : []),
  ];
}

/** Net volume is the requested airspace, not gross wood/port displacement.
 * The calculation's portArea describes ONE opening, including on dual ports. */
export function viewerSpecifications(inputs: EnclosureInputs, calculations: EnclosureCalculations) {
  const format = (value: number, digits: number, unit: string) =>
    Number.isFinite(value) && value > 0 ? `${value.toFixed(digits)} ${unit}` : '—';
  const dual = inputs.portQuantity === 'Dual';
  return [
    { label: 'Net airspace', value: format(inputs.netAirSpace, 2, 'ft³') },
    { label: 'Tuning', value: format(inputs.tuningFrequency, 1, 'Hz') },
    { label: 'Total port area', value: format(calculations.portArea * (dual ? 2 : 1), 2, 'in²') },
    ...(dual ? [{ label: 'Each port', value: format(calculations.portArea, 2, 'in²') }] : []),
  ];
}
