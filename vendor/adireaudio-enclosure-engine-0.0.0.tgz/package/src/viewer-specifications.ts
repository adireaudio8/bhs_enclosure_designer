import type { EnclosureCalculations, EnclosureInputs } from './types/enclosure';

/** Net volume is the requested airspace, not gross wood/port displacement.
 * The calculation's portArea describes ONE opening, including on dual ports. */
export function viewerSpecifications(inputs: EnclosureInputs, calculations: EnclosureCalculations) {
  const format = (value: number, digits: number, unit: string) =>
    Number.isFinite(value) && value > 0 ? `${value.toFixed(digits)} ${unit}` : '—';
  const dual = inputs.portQuantity === 'Dual';
  return [
    { label: 'Net airspace', value: format(inputs.netAirSpace, 2, 'ft³') },
    { label: 'Tuning', value: format(inputs.tuningFrequency, 1, 'Hz') },
    { label: 'Total port area', value: format(calculations.portArea * (dual ? 2 : 1), 2, 'in²') },
    ...(dual ? [{ label: 'Each port', value: format(calculations.portArea, 2, 'in²') }] : []),
  ];
}
