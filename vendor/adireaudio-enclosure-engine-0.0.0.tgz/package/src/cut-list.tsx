'use client';

import { useEnclosureStore } from './enclosure-store';

/**
 * Display the cut list table - matches desktop light theme
 */
export function CutList() {
  const { cutList } = useEnclosureStore();

  return (
    <div>
      <h3 className="text-[18px] font-bold text-gray-900 mb-2">Cut List</h3>
      <div className="border border-[#CCCCCC] bg-white">
        <table className="w-full text-[13px]">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-300">
              <th className="text-left py-2 px-3 text-gray-700 font-semibold">Part</th>
              <th className="text-left py-2 px-3 text-gray-700 font-semibold">Width</th>
              <th className="text-left py-2 px-3 text-gray-700 font-semibold">Height</th>
              <th className="text-center py-2 px-3 text-gray-700 font-semibold">Qty</th>
              <th className="text-left py-2 px-3 text-gray-700 font-semibold">Material</th>
              <th className="text-left py-2 px-3 text-gray-700 font-semibold">Thickness</th>
            </tr>
          </thead>
          <tbody>
            {cutList.map((item, index) => (
              <tr
                key={`${item.partName}-${index}`}
                className={`border-b border-[#E0E0E0] transition-colors ${
                  index % 2 === 0 ? 'bg-white hover:bg-gray-100' : 'bg-[#F8F9FA] hover:bg-gray-100'
                }`}
              >
                <td className="py-2 px-3 text-gray-900 font-medium">{item.partName}</td>
                <td className="py-2 px-3 text-gray-700">
                  {item.width.toFixed(3)}
                </td>
                <td className="py-2 px-3 text-gray-700">
                  {item.height.toFixed(3)}
                </td>
                <td className="py-2 px-3 text-center text-gray-700">{item.quantity}</td>
                <td className="py-2 px-3 text-gray-700">{item.material}</td>
                <td className="py-2 px-3 text-gray-700">
                  {item.thickness.toFixed(3)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary */}
      <div className="mt-2 flex justify-between text-sm text-gray-500">
        <span>Total Parts: {cutList.length}</span>
        <span>
          Total Pieces:{' '}
          {cutList.reduce((sum, item) => sum + item.quantity, 0)}
        </span>
      </div>
    </div>
  );
}
