import { BufferGeometry, Float32BufferAttribute, Path, Shape, ShapeGeometry, Vector2 } from 'three';

export interface TerminalPanelGeometryOptions {
  width: number; height: number; thickness: number;
  centerX: number; centerY: number;
  openingWidth: number; openingHeight: number; cornerRadius: number;
  roundoverRadius?: number; outerCornerRadius?: number;
}
type Point = { x: number; y: number; nx: number; ny: number };
type Vertex = { x: number; y: number; z: number; nx: number; ny: number; nz: number };

/** CCW contour with analytic outward normals, shared by faces, walls and lip. */
function rectangle(cx: number, cy: number, w: number, h: number, r: number): Point[] {
  if (r === 0) return [
    {x:cx-w/2,y:cy-h/2,nx:0,ny:0},{x:cx+w/2,y:cy-h/2,nx:0,ny:0},
    {x:cx+w/2,y:cy+h/2,nx:0,ny:0},{x:cx-w/2,y:cy+h/2,nx:0,ny:0},
  ];
  const points: Point[] = [];
  for (const [x,y,start] of [[cx+w/2-r,cy-h/2+r,-Math.PI/2], [cx+w/2-r,cy+h/2-r,0],
    [cx-w/2+r,cy+h/2-r,Math.PI/2], [cx-w/2+r,cy-h/2+r,Math.PI]]) {
    for (let i=0;i<=16;i++) {
      const a=start+Math.PI/2*i/16, nx=Math.cos(a), ny=Math.sin(a);
      points.push({x:x+r*nx,y:y+r*ny,nx,ny});
    }
  }
  return points;
}

/** Local XY is the outside face; +Z goes into the panel. Only the opening
 * receives a quarter-circle lip. Never outline the mesh's tessellation. */
export function terminalPanelGeometry(o: TerminalPanelGeometryOptions) {
  const {width:w,height:h,thickness:t,centerX:cx,centerY:cy,openingWidth:ow,openingHeight:oh}=o;
  const r=Math.max(0,Math.min(o.cornerRadius,Math.min(ow,oh)/2));
  const ro=Math.max(0,Math.min(o.roundoverRadius??0,t));
  const outerR=Math.max(0,Math.min(o.outerCornerRadius??0,Math.min(w,h)/2));
  const outer=rectangle(w/2,h/2,w,h,outerR);
  const inner=rectangle(cx,cy,ow,oh,r);
  const mouth=rectangle(cx,cy,ow+2*ro,oh+2*ro,r+ro);
  const positions:number[]=[], normals:number[]=[], uvs:number[]=[], edgePositions:number[]=[];
  const vertex=(v:Vertex)=>{positions.push(v.x,v.y,v.z);normals.push(v.nx,v.ny,v.nz);uvs.push(v.x,v.y);};
  const triangle=(a:Vertex,b:Vertex,c:Vertex)=>{vertex(a);vertex(b);vertex(c);};
  const cap=(hole:Point[],z:number,front:boolean)=>{
    const shape=new Shape(outer.map(p=>new Vector2(p.x,p.y)));
    shape.holes.push(new Path(hole.map(p=>new Vector2(p.x,p.y))));
    const capGeo=new ShapeGeometry(shape), p=capGeo.getAttribute('position'), indices=capGeo.getIndex()!;
    for(let i=0;i<indices.count;i+=3) {
      for(const j of front?[2,1,0]:[0,1,2]) {
        const k=indices.getX(i+j);
        vertex({x:p.getX(k),y:p.getY(k),z,nx:0,ny:0,nz:front?-1:1});
      }
    }
    capGeo.dispose();
  };
  cap(mouth,0,true);cap(inner,t,false);
  const wall=(points:Point[],z0:number,z1:number,hole:boolean,smooth:boolean)=>{
    for(let i=0;i<points.length;i++) {
      const p=points[i],q=points[(i+1)%points.length], len=Math.hypot(q.x-p.x,q.y-p.y);
      if(len<1e-10)continue;
      const sign=hole?-1:1;
      const v=(p:Point,z:number):Vertex=>({x:p.x,y:p.y,z,
        nx:sign*(smooth?p.nx:(q.y-points[i].y)/len),
        ny:sign*(smooth?p.ny:-(q.x-points[i].x)/len),nz:0});
      const a=v(p,z0),b=v(q,z0),c=v(q,z1),d=v(p,z1);
      if(hole){triangle(a,c,b);triangle(a,d,c);}else{triangle(a,b,c);triangle(a,c,d);}
    }
  };
  wall(outer,0,t,false,outerR>0);
  wall(inner,ro,t,true,r>0);
  if(ro>0) {
    for(let i=0;i<inner.length;i++) {
      const p=inner[i],q=inner[(i+1)%inner.length];
      for(let j=0;j<12;j++) {
        const v=(p:Point,j:number):Vertex=>{
          const a=Math.PI/2*j/12, s=Math.sin(a), c=Math.cos(a);
          return {x:p.x+ro*p.nx*(1-s),y:p.y+ro*p.ny*(1-s),z:ro*(1-c),
            nx:-p.nx*s,ny:-p.ny*s,nz:-c};
        };
        triangle(v(p,j),v(q,j+1),v(q,j));triangle(v(p,j),v(p,j+1),v(q,j+1));
      }
    }
  }
  const line=(a:number[],b:number[])=>edgePositions.push(...a,...b);
  const outline=(points:Point[],z:number)=>{
    for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length];line([p.x,p.y,z],[q.x,q.y,z]);}
  };
  outline(outer,0);outline(outer,t);outline(mouth,0);outline(inner,t);
  if(outerR===0)for(const p of outer)line([p.x,p.y,0],[p.x,p.y,t]);
  const lipPositions:number[]=[];
  if(ro>0)for(const [points,z] of [[mouth,0],[inner,ro]] as const) {
    for(let i=0;i<points.length;i++) {
      const p=points[i],q=points[(i+1)%points.length];
      lipPositions.push(p.x,p.y,z,q.x,q.y,z);
    }
  }
  const solid=new BufferGeometry();
  solid.setAttribute('position',new Float32BufferAttribute(positions,3));
  solid.setAttribute('normal',new Float32BufferAttribute(normals,3));
  solid.setAttribute('uv',new Float32BufferAttribute(uvs,2));
  const edges=new BufferGeometry().setAttribute('position',new Float32BufferAttribute(edgePositions,3));
  const lipEdges=new BufferGeometry().setAttribute('position',new Float32BufferAttribute(lipPositions,3));
  return {solid,edges,lipEdges};
}
