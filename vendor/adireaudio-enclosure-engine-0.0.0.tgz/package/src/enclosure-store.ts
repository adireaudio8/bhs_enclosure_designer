/**
 * Enclosure Calculator - Zustand State Store
 *
 * Manages all state for the enclosure calculator with automatic recalculation.
 */

import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import {
  EnclosureInputs,
  EnclosureCalculations,
  CutListItem,
  ShippingInfo,
  MaterialConfig,
  DEFAULT_INPUTS,
  DEFAULT_MATERIAL_CONFIG,
  DEFAULT_GLUE_TOLERANCE,
  EnclosureType,
  SubwooferQuantity,
  PortQuantity,
  EnclosureConfiguration,
  SubwooferSize,
  AssemblyMethod,
} from './types/enclosure';
import {
  calculateEnclosure,
  generateCutList,
  generateModelNumber,
  calculateShippingInfo,
} from './calculations';
import { calculateOptimalStack, type FlatPackResult } from './flat-pack-optimizer';
import { type GeneratedFile } from './dxf-generator';
import { canonicalDesignName, getEnclosureSeries } from './design-name-utils';

interface EnclosureStore {
  // State
  inputs: EnclosureInputs;
  calculations: EnclosureCalculations;
  cutList: CutListItem[];
  shippingInfo: ShippingInfo;
  modelNumber: string;
  flatPackResult: FlatPackResult | null;
  generatedFiles: GeneratedFile[];
  materialConfig: MaterialConfig;
  brandCode: string;
  glueTolerance: number;
  isLoadingDesign: boolean;
  /** Build-tab "Bare" flag == Foundation finish tier: sanding labor only (25% of
   *  finishing labor for Birch, 30% for MDF), no finish-coat materials. True for
   *  every BHSF / Foundation design. (NOT $0 — that's the derived "Raw"/LBS cost
   *  view.) Store-backed so it travels with the design across the Design ↔ Build
   *  tabs regardless of which tab loaded it. */
  isBare: boolean;
  /** Full catalog name of the currently-loaded design (with series prefix,
   *  e.g. "BHSF-PE-S12-2.0V2-RD"). Set on load; powers the header "now editing"
   *  chip. Empty when nothing has been loaded (new / blank design). */
  currentDesignName: string;
  // Logo state (shared between Build tab and 3D viewer)
  selectedLogoName: string;       // 'None' or brand display name
  selectedLogoMode: 'On Line' | 'Pocket';
  logoEpsContent: string | null;  // cached EPS content for 3D rendering

  // Actions - Input setters
  setBoxDepth: (value: number) => void;
  setBoxHeight: (value: number) => void;
  setPortWidth: (value: number) => void;
  setTuningFrequency: (value: number) => void;
  setNetAirSpace: (value: number) => void;
  setSubDisplacement: (value: number) => void;
  setSubCutoutDiameter: (value: number) => void;
  setOutsideDiameter: (value: number) => void;

  // Actions - Configuration setters
  setEnclosureType: (value: EnclosureType) => void;
  setEnclosureConfiguration: (value: EnclosureConfiguration) => void;
  setSubwooferQuantity: (value: SubwooferQuantity) => void;
  setPortQuantity: (value: PortQuantity) => void;
  setSize: (value: SubwooferSize) => void;
  setAssemblyMethod: (value: AssemblyMethod) => void;
  setSubwooferBrand: (value: string) => void;
  setSubwooferModel: (value: string) => void;
  setBrandCode: (value: string) => void;

  // Actions - Custom enclosure
  setIsCustomEnclosure: (value: boolean) => void;
  setCustomNumber: (value: number | undefined) => void;
  setCustomNotes: (value: string) => void;

  // Actions - Build settings
  setMaterialConfig: (config: MaterialConfig) => void;
  setGlueTolerance: (value: number) => void;
  setIsBare: (value: boolean) => void;
  setCurrentDesignName: (value: string) => void;

  // Actions - Generated files
  setGeneratedFiles: (files: GeneratedFile[]) => void;

  // Actions - Loading state
  setIsLoadingDesign: (value: boolean) => void;

  // Actions - Logo
  setSelectedLogoName: (name: string) => void;
  setSelectedLogoMode: (mode: 'On Line' | 'Pocket') => void;
  setLogoEpsContent: (content: string | null) => void;

  // Actions - Bulk updates
  setInputs: (inputs: Partial<EnclosureInputs>) => void;
  /** Open a saved design: REPLACES inputs (DEFAULT_INPUTS base + incoming) so
   *  optional fields the design omits reset to default. Use for design loads;
   *  use setInputs for incremental edits. */
  loadInputs: (inputs: Partial<EnclosureInputs>) => void;
  resetToDefaults: () => void;

  // Internal
  recalculate: () => void;
}

// Initial calculations
const initialCalculations = calculateEnclosure(DEFAULT_INPUTS, DEFAULT_MATERIAL_CONFIG);
const initialCutList = generateCutList(DEFAULT_INPUTS, initialCalculations, DEFAULT_MATERIAL_CONFIG, DEFAULT_GLUE_TOLERANCE);
const initialShippingInfo = calculateShippingInfo(DEFAULT_INPUTS, initialCalculations, initialCutList);
const initialModelNumber = generateModelNumber(DEFAULT_INPUTS, 'XXX');

export const useEnclosureStore = create<EnclosureStore>()(
  devtools(
    persist(
      (set, get) => ({
        // Initial state
        inputs: DEFAULT_INPUTS,
        calculations: initialCalculations,
        cutList: initialCutList,
        shippingInfo: initialShippingInfo,
        modelNumber: initialModelNumber,
        flatPackResult: null,
        generatedFiles: [],
        materialConfig: DEFAULT_MATERIAL_CONFIG,
        brandCode: 'XXX',
        glueTolerance: DEFAULT_GLUE_TOLERANCE,
        isLoadingDesign: false,
        isBare: false,
        currentDesignName: '',
        selectedLogoName: 'None',
        selectedLogoMode: 'On Line' as const,
        logoEpsContent: null,

        // Recalculate helper
        recalculate: () => {
          const { inputs, materialConfig, brandCode, glueTolerance, isBare, currentDesignName } = get();
          const calculations = calculateEnclosure(inputs, materialConfig);
          const cutList = generateCutList(inputs, calculations, materialConfig, glueTolerance);
          const shippingInfo = calculateShippingInfo(inputs, calculations, cutList);
          const series = isBare ? 'foundation' : getEnclosureSeries(currentDesignName) === 'select' ? 'select' : 'performance';
          const modelNumber = generateModelNumber(inputs, brandCode, series);
          // Compute flat pack result when assembly method is Flat Pack
          let flatPackResult: FlatPackResult | null = null;
          if (inputs.assemblyMethod === 'Flat Pack' && cutList.length > 0) {
            const etUpper = inputs.enclosureType.toUpperCase();
            const dutyType = etUpper.includes('HEAVY') ? 'HD' : etUpper.includes('STANDARD') ? 'SD' : 'RD';
            flatPackResult = calculateOptimalStack(cutList, dutyType);
          }
          set({ calculations, cutList, shippingInfo, modelNumber, flatPackResult });
        },

        // Input setters
        setBoxDepth: (value) => {
          set((state) => ({ inputs: { ...state.inputs, boxDepth: value } }));
          get().recalculate();
        },

        setBoxHeight: (value) => {
          set((state) => ({ inputs: { ...state.inputs, boxHeight: value } }));
          get().recalculate();
        },

        setPortWidth: (value) => {
          set((state) => ({ inputs: { ...state.inputs, portWidth: value } }));
          get().recalculate();
        },

        setTuningFrequency: (value) => {
          set((state) => ({ inputs: { ...state.inputs, tuningFrequency: value } }));
          get().recalculate();
        },

        setNetAirSpace: (value) => {
          set((state) => ({ inputs: { ...state.inputs, netAirSpace: value } }));
          get().recalculate();
        },

        setSubDisplacement: (value) => {
          set((state) => ({ inputs: { ...state.inputs, subDisplacement: value } }));
          get().recalculate();
        },

        setSubCutoutDiameter: (value) => {
          set((state) => ({ inputs: { ...state.inputs, subCutoutDiameter: value } }));
          get().recalculate();
        },

        setOutsideDiameter: (value) => {
          set((state) => ({ inputs: { ...state.inputs, outsideDiameter: value } }));
          get().recalculate();
        },

        // Configuration setters
        setEnclosureType: (value) => {
          set((state) => {
            const nextInputs = { ...state.inputs, enclosureType: value };

            // Keep Flush Mount selected across Birch/MDF changes. SUPB uses a
            // material-specific cap (18mm Birch vs 3/4" MDF), so preserve the
            // existing port area when that cap thickness changes by scaling
            // port width against the recalculated chamber height.
            if (
              state.inputs.recessedMounting &&
              state.inputs.enclosureConfiguration === 'Subs Up/Port Back' &&
              state.inputs.portWidth > 0
            ) {
              const oldHeight = state.calculations.internalHeight;
              const nextHeight = calculateEnclosure(nextInputs, state.materialConfig).internalHeight;
              if (oldHeight > 0 && nextHeight > 0) {
                nextInputs.portWidth = Math.round(
                  state.inputs.portWidth * (oldHeight / nextHeight) * 100,
                ) / 100;
              }
            }

            return { inputs: nextInputs };
          });
          get().recalculate();
        },

        setEnclosureConfiguration: (value) => {
          set((state) => ({ inputs: { ...state.inputs, enclosureConfiguration: value } }));
          get().recalculate();
        },

        setSubwooferQuantity: (value) => {
          set((state) => ({ inputs: { ...state.inputs, subwooferQuantity: value } }));
          get().recalculate();
        },

        setPortQuantity: (value) => {
          set((state) => ({ inputs: { ...state.inputs, portQuantity: value } }));
          get().recalculate();
        },

        setSize: (value) => {
          set((state) => ({ inputs: { ...state.inputs, size: value } }));
          get().recalculate();
        },

        setAssemblyMethod: (value) => {
          set((state) => ({ inputs: { ...state.inputs, assemblyMethod: value } }));
          get().recalculate();
        },

        setSubwooferBrand: (value) => {
          set((state) => ({ inputs: { ...state.inputs, subwooferBrand: value } }));
          get().recalculate();
        },

        setSubwooferModel: (value) => {
          set((state) => ({ inputs: { ...state.inputs, subwooferModel: value } }));
          get().recalculate();
        },

        setBrandCode: (value) => {
          set({ brandCode: value });
          get().recalculate();
        },

        // Custom enclosure setters
        setIsCustomEnclosure: (value) => {
          set((state) => ({
            inputs: {
              ...state.inputs,
              isCustomEnclosure: value,
              customNumber: value ? (state.inputs.customNumber || 1) : undefined,
            },
          }));
          get().recalculate();
        },

        setCustomNumber: (value) => {
          set((state) => ({ inputs: { ...state.inputs, customNumber: value } }));
          get().recalculate();
        },

        setCustomNotes: (value) => {
          set((state) => ({ inputs: { ...state.inputs, customNotes: value } }));
        },

        // Build settings
        setMaterialConfig: (config) => {
          set({ materialConfig: config });
          get().recalculate();
        },
        setGlueTolerance: (value) => {
          const glueTolerance = Number.isFinite(value) && value >= 0
            ? value
            : DEFAULT_GLUE_TOLERANCE;
          set({ glueTolerance });
          get().recalculate();
        },

        // Generated files
        setGeneratedFiles: (files) => {
          set({ generatedFiles: files });
        },

        // Loading state
        setIsLoadingDesign: (value) => {
          set({ isLoadingDesign: value });
        },

        // Bare (exclude finishing costs) flag
        setIsBare: (value) => {
          set({ isBare: value });
          get().recalculate();
        },

        // Currently-loaded design name (header "now editing" chip)
        setCurrentDesignName: (value) => {
          set({ currentDesignName: canonicalDesignName(value), isBare: getEnclosureSeries(value) === 'foundation' });
          get().recalculate();
        },

        // Logo
        setSelectedLogoName: (name) => {
          // Idempotent: skip when name is unchanged so callers (e.g. Build tab
          // auto-sync) don't wipe a hydrated/cached EPS by re-setting the same
          // logo. Only clear cached EPS when the brand actually changes —
          // prevents stale content (e.g. American Bass EPS persisting when
          // switching to Sundown Audio).
          set((state) => {
            if (state.selectedLogoName === name) return state;
            return { selectedLogoName: name, logoEpsContent: null };
          });
        },
        setSelectedLogoMode: (mode) => {
          set({ selectedLogoMode: mode });
        },
        setLogoEpsContent: (content) => {
          set({ logoEpsContent: content });
          // Nudge a viewer frame. Under R3F frameloop="demand", the logo geometry
          // rebuilds when the EPS arrives async on a design load, but nothing
          // schedules a paint — so the logo wouldn't show until a refresh/orbit.
          // recalculate() emits fresh calculation refs that drive an R3F frame.
          get().recalculate();
        },

        // Bulk updates
        setInputs: (newInputs) => {
          set((state) => ({ inputs: { ...state.inputs, ...newInputs } }));
          get().recalculate();
        },

        // Full design load — REPLACE inputs from DEFAULT_INPUTS so optional fields
        // the saved design omits (recessedMounting, terminalPanel, terminal/
        // subwoofer/window offsets, …) reset to default instead of inheriting the
        // previously-loaded design's value (setInputs merges and would keep them).
        loadInputs: (newInputs) => {
          set({ inputs: { ...DEFAULT_INPUTS, ...newInputs } });
          get().recalculate();
        },

        resetToDefaults: () => {
          // Match desktop ClearFields() — only clear dimension inputs + brand/model,
          // preserve configuration selections (enclosureType, configuration, portQuantity, size, assemblyMethod)
          set((state) => ({
            inputs: {
              ...state.inputs,
              boxDepth: 0,
              boxHeight: 0,
              portWidth: 0,
              tuningFrequency: 0,
              netAirSpace: 0,
              subDisplacement: 0,
              subCutoutDiameter: 0,
              outsideDiameter: 0,
              subwooferQuantity: 'Single' as const,
              subwooferBrand: undefined,
              subwooferModel: undefined,
              isCustomEnclosure: false,
              customNumber: undefined,
              customNotes: undefined,
            },
            brandCode: 'XXX',
            isBare: false,
            currentDesignName: '',
          }));
          get().recalculate();
        },
      }),
      {
        name: 'enclosure-calculator-storage',
        // Bump when the persisted shape changes OR a hostile field needs eviction.
        // v2 (2026-05-18): stop persisting `logoEpsContent`. Brand logo EPS files
        // (esp. complex ones like B2 Audio) can run multi-MB and a single one is
        // enough to blow Chrome's ~5MB localStorage quota — when that happens
        // every setter throws QuotaExceededError and the Design tab appears frozen.
        // Re-fetched on demand by Build/Design tabs; no need to persist.
        version: 2,
        migrate: (persistedState: unknown, _version) => {
          // Drop any legacy logoEpsContent from older v1 payloads regardless of version.
          if (persistedState && typeof persistedState === 'object') {
            const s = persistedState as Record<string, unknown>;
            if ('logoEpsContent' in s) delete s.logoEpsContent;
          }
          return persistedState as never;
        },
        partialize: (state) => ({
          inputs: state.inputs,
          brandCode: state.brandCode,
          glueTolerance: state.glueTolerance,
          isBare: state.isBare,
          currentDesignName: state.currentDesignName,
          selectedLogoName: state.selectedLogoName,
          selectedLogoMode: state.selectedLogoMode,
        }),
        // After hydration from localStorage, recalculate all derived state
        // (calculations, cutList, shippingInfo, modelNumber) from the restored inputs.
        // Without this, pop-out viewer and page refreshes show default calculations.
        // Uses setTimeout(0) to ensure store is fully initialized before recalculating.
        onRehydrateStorage: () => (state) => {
          if (state) {
            setTimeout(() => {
              try { state.recalculate(); } catch { /* ignore if store not ready */ }
            }, 0);
          }
        },
      }
    ),
    { name: 'EnclosureStore' }
  )
);
