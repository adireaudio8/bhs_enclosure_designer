/**
 * A round flared port mounted in the right side panel: what its tube must clear inside the box,
 * and what it costs in mounting depth. Runs once the drivers are placed and the parts are known
 * (calculateRoundPortEnclosure). The port maths itself is in round-port.ts.
 *
 * Box coordinates used here, inches:
 *   x  across the box: 0 at the outside of the left side, the box width at the outside of the right side
 *   y  up from the inside floor (the bottom edge of the baffle, the sides and the back)
 *   z  front to back: 0 at the outside face of the baffle
 *
 * Mounting depth. The engine does not know how deep a driver is, so the rule is conservative:
 * a driver is taken to be as wide as its opening all the way back. Any part of a tube that lies
 * behind a driver's opening, seen from the front, limits that driver, and mounting depth is the
 * inside depth less what the tube takes from the back wall there: from the back wall to the
 * nearest part of the tube, flare and elbow included. With an elbow the second leg comes forward
 * beside the left wall; where it is in line with an opening the depth left is measured to its
 * inner mouth. A tube that lies behind no opening costs no depth.
 *
 * Where the drivers go. With a straight tube, or no better place, they are centred on the whole
 * baffle. An elbowed tube's second leg and inner flare take the left of the box, so the drivers
 * are tried in the space to their right: centred between the right-hand side of the inner flare
 * and the inside face of the right side panel (placeDriversRightOfTube). They go there when they
 * fit that space and it leaves more mounting depth (an eighth of an inch or more); drivers placed
 * by hand are never moved.
 *
 * Refusals. Nothing is moved to make a port fit; the design fails with the reason:
 *   - the tube, elbow or inner flare would come within half an inch of the terminal cup and its
 *     binding posts (the clearance the slot port's panels keep), or within a quarter inch of the
 *     cup's mounting plate;
 *   - the tube would come within a quarter inch of a brace between two drivers.
 */

import type { CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import { driverSpaceRightOfTube, roundPortStations, type RoundPortStation } from './round-port';
import {
  BINDING_POST_DEPTH, SAFETY_BORDER, TERMINAL_BOTTOM_OFFSET, TERMINAL_HEIGHT, TERMINAL_WIDTH,
  isTerminalRotated, resolveTerminalPanel, resolveTerminalPlacementOffset,
} from './terminal-placement';
import { TERMINAL_PLATE_HEIGHT, TERMINAL_PLATE_WIDTH, topTerminalCenter } from './terminal-top-placement';
import { baffleBraceCenters, bafflePositionBounds, profileBaffleCenters, profileBounds } from './subwoofer-profile';
import { resolveBaffleSubLayout } from './subwoofer-positioning';

/** Room the tube keeps from a brace and from the terminal cup's mounting plate. */
export const ROUND_PORT_PART_GAP_IN = 0.25;
/** The drivers are moved to the right of an elbowed tube only for at least this much more
 *  mounting depth; a smaller difference counts as no gain and they stay centred on the baffle. */
export const ROUND_PORT_DRIVER_MOVE_MIN_GAIN_IN = 0.125;
/** The mounting plate behind a terminal cup: 18 mm Birch or 3/4 in MDF; the thicker is used. */
const TERMINAL_PLATE_THICKNESS_IN = 0.75;

type Triple = [number, number, number];
interface Block { min: Triple; max: Triple; gap: number }

export interface RoundPortSideCheck {
  /** Plain reasons the port cannot be built this way. Empty when it clears everything. */
  diagnostics: string[];
  /** True when some part of a tube lies behind a driver opening. */
  passesBehindDriver: boolean;
  /** What the tube takes from the back wall where it lies behind a driver opening (0 for none). */
  depthTakenIn: number;
}

const clamp = (value: number, low: number, high: number) => Math.max(low, Math.min(high, value));

/** True when the tube's cross-section at this station comes closer to the block than its gap. */
function stationHitsBlock(station: RoundPortStation, x: number, y: number, z: number, block: Block): boolean {
  const [minX, minY, minZ] = block.min.map(v => v - block.gap);
  const [maxX, maxY, maxZ] = block.max.map(v => v + block.gap);
  const dx = x - clamp(x, minX, maxX);
  const dy = y - clamp(y, minY, maxY);
  const dz = z - clamp(z, minZ, maxZ);
  const reach = station.outerRadiusIn - 1e-9;
  // On a straight leg the cross-section is a flat disc square to the leg, so it only meets a
  // block it is level with. In the elbow the tube is plain (no flare): a ball is exact there.
  if (Math.abs(station.tangentAlong) > 0.9999) return dx === 0 && Math.hypot(dy, dz) < reach;
  if (Math.abs(station.tangentAcross) > 0.9999) return dz === 0 && Math.hypot(dx, dy) < reach;
  return Math.hypot(dx, dy, dz) < reach;
}

/** The terminal cup as two blocks inside the box: the cup with its binding posts, and its plate. */
function terminalBlocks(
  inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[],
  box: { widthIn: number; depthIn: number; heightIn: number; sideIn: number; backIn: number; sideFrontIn: number; sideWidthIn: number },
): { where: string; blocks: Block[] } | null {
  const panel = resolveTerminalPanel(inputs);
  // the same test the 3D preview uses before it draws a cup
  if (panel === 'None' || !(TERMINAL_HEIGHT < box.heightIn) || !(TERMINAL_WIDTH < box.sideWidthIn)) return null;
  const offset = resolveTerminalPlacementOffset(inputs, calc, parts, panel);
  // On the panel's face the cup is centred at (a, b); `build` turns a rectangle on the face and
  // a depth into the box into a block. The cup reaches in as far as its binding posts, the plate
  // by its own thickness.
  const pair = (centreA: number, centreB: number, halfA: number, halfB: number, plateA: number, plateB: number,
    build: (a0: number, a1: number, b0: number, b1: number, deep: number) => [Triple, Triple]): Block[] => {
    const [cupMin, cupMax] = build(centreA - halfA, centreA + halfA, centreB - halfB, centreB + halfB, BINDING_POST_DEPTH);
    const [plateMin, plateMax] = build(centreA - plateA, centreA + plateA, centreB - plateB, centreB + plateB, TERMINAL_PLATE_THICKNESS_IN);
    return [{ min: cupMin, max: cupMax, gap: SAFETY_BORDER }, { min: plateMin, max: plateMax, gap: ROUND_PORT_PART_GAP_IN }];
  };
  const halfW = TERMINAL_WIDTH / 2, halfH = TERMINAL_HEIGHT / 2, plateW = TERMINAL_PLATE_WIDTH / 2, plateH = TERMINAL_PLATE_HEIGHT / 2;
  const standardY = TERMINAL_BOTTOM_OFFSET + halfH;
  if (panel === 'Side Left') {
    // a = front to back along the panel, b = up the panel; the cup is turned a quarter turn in Subs Up/Port Up
    const turned = isTerminalRotated(inputs, panel);
    const z = box.sideFrontIn + box.sideWidthIn / 2 + offset;
    const y = turned ? box.heightIn / 2 : standardY;
    return { where: 'left side', blocks: pair(z, y, turned ? halfH : halfW, turned ? halfW : halfH, turned ? plateH : plateW, turned ? plateW : plateH,
      (z0, z1, y0, y1, deep) => [[box.sideIn, y0, z0], [box.sideIn + deep, y1, z1]]) };
  }
  if (panel === 'Back') {
    const x = box.widthIn / 2 + offset;
    const inside = box.depthIn - box.backIn;
    return { where: 'back panel', blocks: pair(x, standardY, halfW, halfH, plateW, plateH,
      (x0, x1, y0, y1, deep) => [[x0, y0, inside - deep], [x1, y1, inside]]) };
  }
  if (inputs.enclosureConfiguration !== 'Subs Up/Port Up' || !(box.backIn > 0)) return null;
  // Top (the upright rear wall of a Subs Up/Port Up box): a = across the box, b = front to back
  const centre = topTerminalCenter(box.widthIn, box.depthIn, box.backIn, offset);
  return { where: 'top panel', blocks: pair(centre.x, centre.y, halfW, halfH, plateW, plateH,
    (x0, x1, z0, z1, deep) => [[x0, box.heightIn - deep, z0], [x1, box.heightIn, z1]]) };
}

/**
 * Check a side-mounted round port against the drivers, the braces between them and the terminal
 * cup. `calc` must carry the side layout (calc.roundPort.side) and `parts` the design's cut list.
 */
export function checkRoundPortInSide(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[]): RoundPortSideCheck {
  const layout = calc.roundPort;
  const none: RoundPortSideCheck = { diagnostics: [], passesBehindDriver: false, depthTakenIn: 0 };
  if (!layout?.active || !layout.side || !(layout.geometry.lengthIn > 0)) return none;
  const part = (name: string) => parts.find(p => p.partName === name);
  const baffle = part('Baffle'), back = part('Back'), sideLeft = part('Side Left');
  if (!baffle || !back || !sideLeft) return none;

  const widthIn = baffle.width;                       // the baffle spans the whole box
  const heightIn = baffle.height;
  const depthIn = inputs.boxDepth;
  const backInsideIn = depthIn - back.thickness;
  const stations = roundPortStations(layout.port, layout.geometry);
  const { axisDepthIn, panelFrontIn } = layout.side;
  const at = (station: RoundPortStation) => ({ x: widthIn - station.along, z: axisDepthIn - station.across });

  // ── blocks the tube must clear ──
  const diagnostics: string[] = [];
  const hits = (blocks: Block[]) => layout.centers.some(centre => stations.some(station => {
    const { x, z } = at(station);
    return blocks.some(block => stationHitsBlock(station, x, centre.y, z, block));
  }));
  const terminal = terminalBlocks(inputs, calc, parts, {
    widthIn, depthIn, heightIn, sideIn: sideLeft.thickness, backIn: back.thickness,
    sideFrontIn: panelFrontIn, sideWidthIn: sideLeft.width,
  });
  if (terminal && hits(terminal.blocks)) {
    diagnostics.push(`The port would run into the terminal cup on the ${terminal.where}: it needs half an inch clear of the cup and its binding posts. Move the terminal cup or use a smaller tube.`);
  }
  const brace = parts.find(p => p.partName.startsWith('Gusset'));
  if (brace) {
    const braces: Block[] = baffleBraceCenters(inputs, parts, calc).filter(Number.isFinite).map(x => ({
      min: [x - brace.thickness / 2, 0, baffle.thickness], max: [x + brace.thickness / 2, heightIn, baffle.thickness + brace.width],
      gap: ROUND_PORT_PART_GAP_IN,
    }));
    if (hits(braces)) {
      diagnostics.push('The port would run into the brace between the drivers. The box is not deep enough for a port across its width.');
    }
  }

  // ── mounting depth: the nearest part of a tube that lies behind a driver opening ──
  const opening = inputs.subwooferCutoutProfile?.opening;
  const openingRadius = opening?.length
    ? Math.max(...opening.map(p => Math.hypot(p.x, p.y)))
    : inputs.subCutoutDiameter / 2;
  let frontIn = Infinity;
  if (openingRadius > 0) {
    const drivers = profileBaffleCenters(inputs, calc, parts).filter(p => Number.isFinite(p.x) && Number.isFinite(p.y));
    for (const centre of layout.centers) for (const station of stations) {
      const { x, z } = at(station);
      const radius = station.outerRadiusIn;
      const halfX = radius * Math.abs(station.tangentAcross);   // the cross-section seen from the front
      const behind = drivers.some(driver => {
        // a leg running front to back shows as a full circle; otherwise measure to its outline's box
        if (halfX > radius - 1e-9) return Math.hypot(driver.x - x, driver.y - centre.y) < openingRadius + radius;
        const nearX = clamp(driver.x, x - halfX, x + halfX), nearY = clamp(driver.y, centre.y - radius, centre.y + radius);
        return Math.hypot(driver.x - nearX, driver.y - nearY) < openingRadius;
      });
      if (behind) frontIn = Math.min(frontIn, z - radius * Math.abs(station.tangentAlong));
    }
  }
  const passesBehindDriver = Number.isFinite(frontIn);
  // never more than the whole inside depth (a port that does not fit can reach the baffle)
  const depthTakenIn = passesBehindDriver ? clamp(backInsideIn - frontIn, 0, Math.max(0, backInsideIn - baffle.thickness)) : 0;
  return { diagnostics, passesBehindDriver, depthTakenIn };
}

/**
 * Try the drivers in the space to the right of an elbowed side tube and keep them there when it
 * is the better place. `today` is the check of the usual placement (centred on the whole baffle),
 * which `calc.roundPort` must describe on entry.
 *
 * The drivers are centred between the right-hand side of the inner flare and the inside face of
 * the right side panel, the way the baffle location centres them between the left side wall and
 * its flange: the span they are spread over runs one side wall past each end of the space.
 *
 * They are moved only when all of this holds:
 *   - the placement is automatic (positions set by hand are never moved);
 *   - they fit the space: every opening a quarter inch clear of the flare, the engine's own
 *     limits toward the right side (opening a quarter inch off the side wall, frame a quarter
 *     inch inside the baffle's edge), and room for the brace between two drivers;
 *   - a layout that passes today still passes, and the tube meets nothing it does not meet
 *     today (the brace moves with the drivers);
 *   - it leaves more mounting depth, by an eighth of an inch or more.
 * Otherwise nothing changes: the layout is left exactly as it came in and null is returned.
 * When they are moved, `calc.roundPort` carries the new span (subSpanStartIn, subSpanWidthIn,
 * side.driversRightOfTube) and the check of the new placement is returned.
 */
export function placeDriversRightOfTube(
  inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[], today: RoundPortSideCheck,
): RoundPortSideCheck | null {
  const layout = calc.roundPort;
  if (!layout?.active || !layout.side || inputs.subwooferPositions !== undefined) return null;
  const baffle = parts.find(p => p.partName === 'Baffle');
  const sideLeft = parts.find(p => p.partName === 'Side Left');
  if (!baffle || !sideLeft) return null;
  const space = driverSpaceRightOfTube(layout, { widthIn: baffle.width, sideThicknessIn: sideLeft.thickness });
  if (!space) return null;
  const profile = inputs.subwooferCutoutProfile;
  const frameWidth = profile?.frame.width || inputs.outsideDiameter || inputs.subCutoutDiameter;
  // how far a driver's opening reaches to the left of its centre
  const openingLeft = profile ? -profileBounds(profile.opening).minX : inputs.subCutoutDiameter / 2;
  if (!(frameWidth > 0) || !(openingLeft > 0)) return null;

  const todayLayout = resolveBaffleSubLayout(inputs, calc, parts);
  const wholeWidth = layout.subSpanWidthIn;
  layout.subSpanStartIn = space.leftIn - sideLeft.thickness;
  layout.subSpanWidthIn = baffle.width - layout.subSpanStartIn;
  layout.side.driversRightOfTube = true;

  const moved = ((): RoundPortSideCheck | null => {
    const centres = profileBaffleCenters(inputs, calc, parts).map(p => p.x).sort((a, b) => a - b);
    const limits = bafflePositionBounds(inputs, calc, parts);
    const margin = 0.25 + (profile?.maxError ?? 0);
    if (centres.some(x => x - openingLeft < space.leftIn + margin - 1e-9 || x > limits.xMax + 1e-9 || x < limits.xMin - 1e-9)) return null;
    const brace = parts.find(p => p.partName.startsWith('Gusset'))?.thickness ?? 0;
    if (centres.slice(1).some((x, i) => x - centres[i] < frameWidth + brace + 0.5 - 1e-9)) return null;
    if (todayLayout.safe && !resolveBaffleSubLayout(inputs, calc, parts).safe) return null;
    const check = checkRoundPortInSide(inputs, calc, parts);
    if (check.diagnostics.some(reason => !today.diagnostics.includes(reason))) return null;
    return today.depthTakenIn - check.depthTakenIn >= ROUND_PORT_DRIVER_MOVE_MIN_GAIN_IN - 1e-9 ? check : null;
  })();
  if (!moved) {
    delete layout.subSpanStartIn;
    layout.subSpanWidthIn = wholeWidth;
    layout.side.driversRightOfTube = false;
  }
  return moved;
}
