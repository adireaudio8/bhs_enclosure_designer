/**
 * EPS (Encapsulated PostScript) Path Parser
 * Ported from C# EpsPathParser.cs + EpsDxfConverter.cs
 *
 * Parses EPS files to extract vector paths (lines + cubic Bezier curves),
 * then converts them to DXF polylines with arc/bulge support.
 */

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface Vec2 {
  x: number;
  y: number;
}

export interface LineSegment {
  type: 'line';
  start: Vec2;
  end: Vec2;
}

export interface CubicBezierSegment {
  type: 'bezier';
  start: Vec2;
  end: Vec2;
  control1: Vec2;
  control2: Vec2;
}

export type EpsSegment = LineSegment | CubicBezierSegment;

export interface EpsPath {
  segments: EpsSegment[];
  isClosed: boolean;
  startPoint: Vec2 | null;
  endPoint: Vec2 | null;
}

interface Matrix2D {
  a: number; b: number;
  c: number; d: number;
  e: number; f: number;
}

// ─── Matrix Operations ─────────────────────────────────────────────────────────

const IDENTITY: Matrix2D = { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 };

// VCarve can encode a closed vector by drawing the final segment exactly back
// to the starting point without emitting a separate PostScript `closepath`.
// Keep the tolerance extremely small and scale-aware so genuine open strokes
// remain open while floating-point transforms of the same endpoint still
// round-trip as closed contours.
const IMPLICIT_CLOSE_RELATIVE_TOLERANCE = 1e-7;

function endpointsCoincide(start: Vec2, end: Vec2): boolean {
  const coordinateScale = Math.max(
    1,
    Math.abs(start.x),
    Math.abs(start.y),
    Math.abs(end.x),
    Math.abs(end.y),
  );
  const tolerance = coordinateScale * IMPLICIT_CLOSE_RELATIVE_TOLERANCE;
  return Math.abs(start.x - end.x) <= tolerance
    && Math.abs(start.y - end.y) <= tolerance;
}

function concatMatrix(m: Matrix2D, other: Matrix2D): Matrix2D {
  return {
    a: m.a * other.a + m.c * other.b,
    b: m.b * other.a + m.d * other.b,
    c: m.a * other.c + m.c * other.d,
    d: m.b * other.c + m.d * other.d,
    e: m.a * other.e + m.c * other.f + m.e,
    f: m.b * other.e + m.d * other.f + m.f,
  };
}

function transformPoint(m: Matrix2D, p: Vec2): Vec2 {
  return {
    x: m.a * p.x + m.c * p.y + m.e,
    y: m.b * p.x + m.d * p.y + m.f,
  };
}

// ─── EPS Parser ─────────────────────────────────────────────────────────────────

/**
 * Extract the ASCII drawing section from EPS bytes.
 * Looks for content between %%EndPageSetup and %%PageTrailer/%%Trailer.
 */
function extractAsciiSection(text: string): string {
  let startIndex = text.indexOf('%%EndPageSetup');
  if (startIndex >= 0) {
    const nl = text.indexOf('\n', startIndex);
    startIndex = nl >= 0 ? nl + 1 : startIndex;
  } else {
    startIndex = 0;
  }

  let endIndex = text.indexOf('%%PageTrailer', startIndex);
  if (endIndex < 0) {
    endIndex = text.indexOf('%%Trailer', startIndex);
  }
  if (endIndex < 0) {
    endIndex = text.length;
  }

  return startIndex < endIndex ? text.substring(startIndex, endIndex) : '';
}

/**
 * Tokenize EPS content into individual tokens.
 * Strips comments (% to end of line), brackets, whitespace.
 */
function tokenize(content: string): string[] {
  const tokens: string[] = [];
  let current = '';
  let inComment = false;

  for (const ch of content) {
    if (inComment) {
      if (ch === '\n') inComment = false;
      continue;
    }
    if (ch === '%') {
      inComment = true;
      if (current) { tokens.push(current); current = ''; }
      continue;
    }
    if (/\s/.test(ch)) {
      if (current) { tokens.push(current); current = ''; }
      continue;
    }
    if (ch === '[' || ch === ']') {
      if (current) { tokens.push(current); current = ''; }
      continue;
    }
    current += ch;
  }
  if (current) tokens.push(current);
  return tokens;
}

function tryParseNumber(token: string): number | null {
  const n = parseFloat(token);
  return isFinite(n) ? n : null;
}

function tryPop(stack: number[], count: number): number[] | null {
  if (stack.length < count) return null;
  return stack.splice(stack.length - count, count);
}

/**
 * Parse EPS file content (as string) into vector paths.
 * Handles PostScript commands in both abbreviated (mo/m, li/l, cv/c, cp, np)
 * and full-name form (moveto, lineto, curveto, closepath, newpath, stroke, fill).
 * Also: gsave/grestore, scale, translate, concat (ct/cm/concat).
 */
export function parseEpsPaths(epsText: string): EpsPath[] {
  const paths: EpsPath[] = [];
  const ascii = extractAsciiSection(epsText);
  if (!ascii) return paths;

  const tokens = tokenize(ascii);
  const numberStack: number[] = [];
  const transformStack: Matrix2D[] = [];
  let currentTransform = { ...IDENTITY };
  let currentPath: EpsPath | null = null;
  let currentPoint: Vec2 | null = null;

  function flushPath() {
    if (currentPath && currentPath.segments.length >= 1) {
      if (
        !currentPath.isClosed
        && currentPath.segments.length >= 2
        && currentPath.startPoint
        && currentPath.endPoint
        && endpointsCoincide(currentPath.startPoint, currentPath.endPoint)
      ) {
        currentPath.isClosed = true;
      }
      paths.push(currentPath);
    }
    currentPath = null;
  }

  for (const token of tokens) {
    const num = tryParseNumber(token);
    if (num !== null) {
      numberStack.push(num);
      continue;
    }

    switch (token) {
      case 'gsave':
        transformStack.push({ ...currentTransform });
        break;
      case 'grestore':
        if (transformStack.length > 0) currentTransform = transformStack.pop()!;
        break;
      case 'scale': {
        const vals = tryPop(numberStack, 2);
        if (vals) currentTransform = concatMatrix(currentTransform, { a: vals[0], b: 0, c: 0, d: vals[1], e: 0, f: 0 });
        break;
      }
      case 'translate': {
        const vals = tryPop(numberStack, 2);
        if (vals) currentTransform = concatMatrix(currentTransform, { a: 1, b: 0, c: 0, d: 1, e: vals[0], f: vals[1] });
        break;
      }
      case 'ct':
      case 'cm': {
        const vals = tryPop(numberStack, 6);
        if (vals) currentTransform = concatMatrix(currentTransform, { a: vals[0], b: vals[1], c: vals[2], d: vals[3], e: vals[4], f: vals[5] });
        break;
      }
      case 'np':
      case 'newpath':
        flushPath();
        currentPoint = null;
        break;
      case 'stroke':
      case 'fill':
      case 'eofill':
        flushPath();
        break;
      case 'mo':
      case 'm':
      case 'moveto': {
        const vals = tryPop(numberStack, 2);
        if (vals) {
          flushPath();
          currentPath = { segments: [], isClosed: false, startPoint: null, endPoint: null };
          currentPoint = transformPoint(currentTransform, { x: vals[0], y: vals[1] });
          currentPath.startPoint = currentPoint;
          currentPath.endPoint = currentPoint;
        }
        break;
      }
      case 'li':
      case 'l':
      case 'lineto': {
        const vals = tryPop(numberStack, 2);
        if (currentPath && currentPoint && vals) {
          const point = transformPoint(currentTransform, { x: vals[0], y: vals[1] });
          currentPath.segments.push({ type: 'line', start: currentPoint, end: point });
          currentPoint = point;
          currentPath.endPoint = point;
        }
        break;
      }
      case 'cv':
      case 'c':
      case 'curveto': {
        const vals = tryPop(numberStack, 6);
        if (currentPath && currentPoint && vals) {
          const c1 = transformPoint(currentTransform, { x: vals[0], y: vals[1] });
          const c2 = transformPoint(currentTransform, { x: vals[2], y: vals[3] });
          const end = transformPoint(currentTransform, { x: vals[4], y: vals[5] });
          currentPath.segments.push({ type: 'bezier', start: currentPoint, control1: c1, control2: c2, end });
          currentPoint = end;
          currentPath.endPoint = end;
        }
        break;
      }
      case 'cp':
      case 'closepath':
        if (currentPath) currentPath.isClosed = true;
        break;
      case 'concat':
      case 'matrix': {
        const vals = tryPop(numberStack, 6);
        if (vals) currentTransform = concatMatrix(currentTransform, { a: vals[0], b: vals[1], c: vals[2], d: vals[3], e: vals[4], f: vals[5] });
        break;
      }
    }
  }

  flushPath();
  return paths;
}

// ─── Bounds & Filtering ─────────────────────────────────────────────────────────

export interface Bounds {
  minX: number; minY: number;
  maxX: number; maxY: number;
  width: number; height: number;
}

export function calculatePathsBounds(paths: EpsPath[]): Bounds | null {
  let minX = Infinity, minY = Infinity;
  let maxX = -Infinity, maxY = -Infinity;

  for (const path of paths) {
    for (const seg of path.segments) {
      minX = Math.min(minX, seg.start.x, seg.end.x);
      minY = Math.min(minY, seg.start.y, seg.end.y);
      maxX = Math.max(maxX, seg.start.x, seg.end.x);
      maxY = Math.max(maxY, seg.start.y, seg.end.y);
      if (seg.type === 'bezier') {
        minX = Math.min(minX, seg.control1.x, seg.control2.x);
        minY = Math.min(minY, seg.control1.y, seg.control2.y);
        maxX = Math.max(maxX, seg.control1.x, seg.control2.x);
        maxY = Math.max(maxY, seg.control1.y, seg.control2.y);
      }
    }
  }

  if (!isFinite(minX)) return null;
  return { minX, minY, maxX, maxY, width: maxX - minX, height: maxY - minY };
}

/**
 * Filter out bounding box rectangles and clipping paths from EPS paths.
 * Some EPS files include clipping rectangles/triangles that match the overall bounds.
 */
export function filterBoundingBoxPaths(paths: EpsPath[], bounds: Bounds): EpsPath[] {
  const tolerance = Math.max(bounds.width, bounds.height) * 0.05;

  return paths.filter(path => {
    // Check rectangle matching bounds (4-5 line segments, closed)
    if (path.isClosed && path.segments.length >= 4 && path.segments.length <= 5 &&
        path.segments.every(s => s.type === 'line')) {
      const points: Vec2[] = [];
      for (const seg of path.segments) {
        if (!points.some(p => Math.abs(p.x - seg.start.x) < tolerance && Math.abs(p.y - seg.start.y) < tolerance)) {
          points.push(seg.start);
        }
      }
      if (points.length === 4) {
        const rMinX = Math.min(...points.map(p => p.x));
        const rMinY = Math.min(...points.map(p => p.y));
        const rMaxX = Math.max(...points.map(p => p.x));
        const rMaxY = Math.max(...points.map(p => p.y));
        if (Math.abs(rMinX - bounds.minX) < tolerance && Math.abs(rMinY - bounds.minY) < tolerance &&
            Math.abs(rMaxX - bounds.maxX) < tolerance && Math.abs(rMaxY - bounds.maxY) < tolerance) {
          return false; // Filter out
        }
      }
    }

    // Check closed all-lines path spanning full bounds (clipping path)
    if (path.isClosed && path.segments.every(s => s.type === 'line')) {
      let pMinX = Infinity, pMinY = Infinity, pMaxX = -Infinity, pMaxY = -Infinity;
      for (const seg of path.segments) {
        pMinX = Math.min(pMinX, seg.start.x, seg.end.x);
        pMinY = Math.min(pMinY, seg.start.y, seg.end.y);
        pMaxX = Math.max(pMaxX, seg.start.x, seg.end.x);
        pMaxY = Math.max(pMaxY, seg.start.y, seg.end.y);
      }
      if (Math.abs(pMinX - bounds.minX) < tolerance && Math.abs(pMinY - bounds.minY) < tolerance &&
          Math.abs(pMaxX - bounds.maxX) < tolerance && Math.abs(pMaxY - bounds.maxY) < tolerance) {
        return false; // Filter out
      }
    }

    return true; // Keep
  });
}

// ─── Bezier → DXF Polyline Conversion ───────────────────────────────────────────

interface PolylineVertex {
  x: number;
  y: number;
  bulge: number; // 0 = line, non-zero = arc (tan of 1/4 included angle)
}

function distance(a: Vec2, b: Vec2): number {
  return Math.sqrt((b.x - a.x) ** 2 + (b.y - a.y) ** 2);
}

function distancePointToLine(point: Vec2, start: Vec2, end: Vec2): number {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  if (Math.abs(dx) < 1e-12 && Math.abs(dy) < 1e-12) return distance(point, start);
  const t = ((point.x - start.x) * dx + (point.y - start.y) * dy) / (dx * dx + dy * dy);
  return distance(point, { x: start.x + t * dx, y: start.y + t * dy });
}

function evaluateBezier(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2, t: number): Vec2 {
  const u = 1 - t;
  const uu = u * u, uuu = uu * u;
  const tt = t * t, ttt = tt * t;
  return {
    x: uuu * p0.x + 3 * uu * t * p1.x + 3 * u * tt * p2.x + ttt * p3.x,
    y: uuu * p0.y + 3 * uu * t * p1.y + 3 * u * tt * p2.y + ttt * p3.y,
  };
}

function isNearlyLine(start: Vec2, c1: Vec2, c2: Vec2, end: Vec2, tolerance: number): boolean {
  return distancePointToLine(c1, start, end) <= tolerance &&
         distancePointToLine(c2, start, end) <= tolerance;
}

function tryGetCircle(a: Vec2, b: Vec2, c: Vec2): { center: Vec2; radius: number } | null {
  const d = 2 * (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y));
  if (Math.abs(d) < 1e-12) return null;
  const aSq = a.x * a.x + a.y * a.y;
  const bSq = b.x * b.x + b.y * b.y;
  const cSq = c.x * c.x + c.y * c.y;
  const center: Vec2 = {
    x: (aSq * (b.y - c.y) + bSq * (c.y - a.y) + cSq * (a.y - b.y)) / d,
    y: (aSq * (c.x - b.x) + bSq * (a.x - c.x) + cSq * (b.x - a.x)) / d,
  };
  const radius = distance(center, a);
  return radius > 0 ? { center, radius } : null;
}

function calculateBulge(start: Vec2, end: Vec2, mid: Vec2, center: Vec2): number {
  let startAngle = Math.atan2(start.y - center.y, start.x - center.x);
  let endAngle = Math.atan2(end.y - center.y, end.x - center.x);
  let midAngle = Math.atan2(mid.y - center.y, mid.x - center.x);
  if (startAngle < 0) startAngle += 2 * Math.PI;
  if (endAngle < 0) endAngle += 2 * Math.PI;
  if (midAngle < 0) midAngle += 2 * Math.PI;

  let ccwAngle = endAngle - startAngle;
  if (ccwAngle < 0) ccwAngle += 2 * Math.PI;
  let cwAngle = startAngle - endAngle;
  if (cwAngle < 0) cwAngle += 2 * Math.PI;

  let midFromStart = midAngle - startAngle;
  if (midFromStart < 0) midFromStart += 2 * Math.PI;

  const isCcw = midFromStart <= ccwAngle;
  const includedAngle = isCcw ? ccwAngle : cwAngle;
  const bulge = Math.tan(includedAngle / 4.0);
  return isCcw ? bulge : -bulge;
}

function splitBezier(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2): { left: Vec2[]; right: Vec2[] } {
  const mid = (a: Vec2, b: Vec2): Vec2 => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
  const p01 = mid(p0, p1), p12 = mid(p1, p2), p23 = mid(p2, p3);
  const p012 = mid(p01, p12), p123 = mid(p12, p23);
  const p0123 = mid(p012, p123);
  return { left: [p0, p01, p012, p0123], right: [p0123, p123, p23, p3] };
}

function collectBezierVertices(
  start: Vec2, c1: Vec2, c2: Vec2, end: Vec2,
  tolerance: number, scale: number, offsetX: number, offsetY: number,
  vertices: PolylineVertex[], depth: number
): void {
  const tp = (p: Vec2): Vec2 => ({ x: p.x * scale + offsetX, y: p.y * scale + offsetY });

  if (vertices.length === 0) {
    vertices.push({ ...tp(start), bulge: 0 });
  }

  if (isNearlyLine(start, c1, c2, end, tolerance)) {
    if (vertices.length > 0) vertices[vertices.length - 1].bulge = 0;
    vertices.push({ ...tp(end), bulge: 0 });
    return;
  }

  // Try to fit an arc
  const mid = evaluateBezier(start, c1, c2, end, 0.5);
  const circle = tryGetCircle(start, mid, end);
  if (circle) {
    const quarter = evaluateBezier(start, c1, c2, end, 0.25);
    const threeQuarter = evaluateBezier(start, c1, c2, end, 0.75);
    const onCircle = (p: Vec2) => Math.abs(distance(circle.center, p) - circle.radius) <= tolerance;
    if (onCircle(quarter) && onCircle(threeQuarter)) {
      const bulge = calculateBulge(start, end, mid, circle.center);
      if (vertices.length > 0) vertices[vertices.length - 1].bulge = bulge;
      vertices.push({ ...tp(end), bulge: 0 });
      return;
    }
  }

  if (depth >= 10) {
    if (vertices.length > 0) vertices[vertices.length - 1].bulge = 0;
    vertices.push({ ...tp(end), bulge: 0 });
    return;
  }

  // Split and recurse
  const { left, right } = splitBezier(start, c1, c2, end);
  collectBezierVertices(left[0], left[1], left[2], left[3], tolerance, scale, offsetX, offsetY, vertices, depth + 1);
  collectBezierVertices(right[0], right[1], right[2], right[3], tolerance, scale, offsetX, offsetY, vertices, depth + 1);
}

// ─── EPS Paths → DXF Polyline Entities ──────────────────────────────────────────

/**
 * Convert EPS paths to DXF LWPOLYLINE entity strings.
 * Handles both line segments and cubic Bezier curves (converted to arcs via bulge).
 */
export function epsPathsToDxfEntities(
  paths: EpsPath[],
  layer: string,
  scale: number,
  offsetX: number,
  offsetY: number,
  tolerance: number = 0.001
): string {
  let entities = '';

  for (const path of paths) {
    if (path.segments.length === 0) continue;

    const vertices: PolylineVertex[] = [];

    for (const seg of path.segments) {
      if (seg.type === 'line') {
        if (vertices.length === 0) {
          vertices.push({ x: seg.start.x * scale + offsetX, y: seg.start.y * scale + offsetY, bulge: 0 });
        }
        vertices.push({ x: seg.end.x * scale + offsetX, y: seg.end.y * scale + offsetY, bulge: 0 });
      } else {
        collectBezierVertices(seg.start, seg.control1, seg.control2, seg.end,
          tolerance, scale, offsetX, offsetY, vertices, 0);
      }
    }

    if (vertices.length < 2) continue;

    // Remove duplicate last vertex for closed paths
    if (path.isClosed && vertices.length > 2) {
      const first = vertices[0];
      const last = vertices[vertices.length - 1];
      if (distance(first, last) < tolerance * scale) {
        vertices.pop();
      }
    }

    if (vertices.length < 2) continue;

    // Build LWPOLYLINE entity
    // Group codes: 0=LWPOLYLINE, 8=layer, 70=flags (1=closed), 90=vertex count,
    //              10=X, 20=Y, 42=bulge
    const flags = path.isClosed ? 1 : 0;
    let polyline = [
      '0', 'LWPOLYLINE',
      '8', layer,
      '70', String(flags),
      '90', String(vertices.length),
    ].join('\n') + '\n';

    for (const v of vertices) {
      polyline += `10\n${v.x.toFixed(4)}\n20\n${v.y.toFixed(4)}\n`;
      if (Math.abs(v.bulge) > 1e-6) {
        polyline += `42\n${v.bulge.toFixed(6)}\n`;
      }
    }

    entities += polyline;
  }

  return entities;
}
