'use client';

import { useEnclosureStore } from './enclosure-store';

/**
 * Advanced Calculations display — matches desktop AdvancedCalculationsWindow.xaml
 * 3-column layout: Internal Dimensions + Port Lengths | S1 Right | S2 Left
 * Desktop window is 720x280, 4-column with vertical separators
 *
 * A round flared port has no S1/S2 chambers: its box is one plain chamber, so the
 * second and third columns show the tube and what it takes out of the box instead.
 * The wording follows the port's location: in the baffle the second leg runs along the
 * back wall; in the right side panel it runs forward along the left side wall.
 */
export function CalculationsDisplay() {
  const { calculations } = useEnclosureStore();
  const roundPort = calculations.roundPort?.active ? calculations.roundPort : null;
  const inSide = roundPort?.location === 'Side Right' ? roundPort.side : undefined;

  return (
    <div className="flex gap-0 text-[13px]">
      {/* Column 1: Internal Dimensions + Port Lengths */}
      <div className="flex-1 space-y-2 pr-5">
        <h4 className="text-[13px] font-bold text-gray-900 mb-3">Internal Dimensions</h4>
        <CalcRow label="Width:" value={calculations.internalWidth} />
        <CalcRow label="Depth:" value={calculations.internalDepthWithDB} />
        <CalcRow label="Height:" value={calculations.internalHeight} />
        <div className="pt-2">
          <h4 className="text-[13px] font-bold text-gray-900 mb-3">Port Length</h4>
          <CalcRow label={roundPort ? 'Straight run:' : 'Length 1:'} value={calculations.portLength1} />
          <CalcRow label={inSide ? 'Along the left side:' : roundPort ? 'Along the back:' : 'Length 2:'} value={calculations.portLength2} />
        </div>
      </div>

      {/* Vertical Separator */}
      <div className="w-px bg-gray-300 mx-4" />

      {roundPort ? (
        <>
          {/* Column 2: the tube */}
          <div className="flex-1 space-y-2 px-5">
            <h4 className="text-[13px] font-bold text-gray-900 mb-3">Round Port (each tube)</h4>
            <CalcRow label="Inside diameter (in):" value={roundPort.port.diameterIn} />
            <CalcRow label="Outside diameter (in):" value={roundPort.geometry.tubeOutsideDiameterIn} />
            <CalcRow label="Length, face to face (in):" value={roundPort.geometry.lengthIn} />
            <CalcRow label="Acts like (in of air):" value={roundPort.geometry.effectiveLengthIn} />
            <CalcRow label="Elbow radius (in):" value={roundPort.geometry.elbowRadiusIn} />
          </div>

          {/* Vertical Separator */}
          <div className="w-px bg-gray-300 mx-4" />

          {/* Column 3: what it takes out of the box */}
          <div className="flex-1 space-y-2 pl-5">
            <h4 className="text-[13px] font-bold text-gray-900 mb-3">{inSide ? 'Round Port (right side)' : 'Round Port (in the box)'}</h4>
            <CalcRow label={inSide ? 'Right side hole (in):' : 'Baffle hole (in):'} value={roundPort.geometry.holeDiameterIn} />
            <CalcRow label="Flange (in):" value={roundPort.geometry.flangeOutsideDiameterIn} />
            <CalcRow label={'Airspace taken (ft³):'} value={roundPort.geometry.displacementTotalCuFt} />
            <CalcRow label={'Chamber (ft³):'} value={calculations.s2LeftArea} />
            {inSide ? (
              <>
                <CalcRow label="Hole from panel front (in):" value={inSide.axisDepthIn - inSide.panelFrontIn} />
                <CalcRow label="Depth behind a driver (in):" value={inSide.depthTakenIn} />
              </>
            ) : (
              <CalcRow label="Depth taken at the back (in):" value={roundPort.geometry.depthTakenAtFarWallIn} />
            )}
          </div>
        </>
      ) : (
        <>
          {/* Column 2: S1 Right */}
          <div className="flex-1 space-y-2 px-5">
            <h4 className="text-[13px] font-bold text-gray-900 mb-3">S1 Right (Side Panel)</h4>
            <CalcRow label="Width (in):" value={calculations.s1RightWidth} />
            <CalcRow label="Depth (in):" value={calculations.s1RightDepth} />
            <CalcRow label={'Area (ft³):'} value={calculations.s1RightArea} />
            <CalcRow label={'Still Needed (ft³):'} value={calculations.s1RightStillNeeded} />
          </div>

          {/* Vertical Separator */}
          <div className="w-px bg-gray-300 mx-4" />

          {/* Column 3: S2 Left */}
          <div className="flex-1 space-y-2 pl-5">
            <h4 className="text-[13px] font-bold text-gray-900 mb-3">S2 Left (Side Panel)</h4>
            <CalcRow label="Width (in):" value={calculations.s2LeftWidth} />
            <CalcRow label="Height (in):" value={calculations.s2LeftHeight} />
            <CalcRow label="Depth (in):" value={calculations.s2LeftDepth} />
            <CalcRow label={'Area (ft³):'} value={calculations.s2LeftArea} />
            <CalcRow label={'Still Needed (in²):'} value={calculations.s2LeftStillNeeded} />
          </div>
        </>
      )}
    </div>
  );
}

/** Single label-value row matching desktop's label + TextBox layout */
function CalcRow({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex justify-between gap-4">
      <span className="text-gray-700 whitespace-nowrap">{label}</span>
      <span className="font-semibold text-gray-900 tabular-nums">{value.toFixed(4)}</span>
    </div>
  );
}
