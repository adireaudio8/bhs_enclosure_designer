'use client';

import { useEnclosureStore } from './enclosure-store';

/**
 * Advanced Calculations display — matches desktop AdvancedCalculationsWindow.xaml
 * 3-column layout: Internal Dimensions + Port Lengths | S1 Right | S2 Left
 * Desktop window is 720x280, 4-column with vertical separators
 */
export function CalculationsDisplay() {
  const { calculations } = useEnclosureStore();

  return (
    <div className="flex gap-0 text-[13px]">
      {/* Column 1: Internal Dimensions + Port Lengths */}
      <div className="flex-1 space-y-2 pr-5">
        <h4 className="text-[13px] font-bold text-gray-900 mb-3">Internal Dimensions</h4>
        <CalcRow label="Width:" value={calculations.internalWidth} />
        <CalcRow label="Depth:" value={calculations.internalDepthWithDB} />
        <CalcRow label="Height:" value={calculations.internalHeight} />
        <div className="pt-2">
          <h4 className="text-[13px] font-bold text-gray-900 mb-3">Port Length</h4>
          <CalcRow label="Length 1:" value={calculations.portLength1} />
          <CalcRow label="Length 2:" value={calculations.portLength2} />
        </div>
      </div>

      {/* Vertical Separator */}
      <div className="w-px bg-gray-300 mx-4" />

      {/* Column 2: S1 Right */}
      <div className="flex-1 space-y-2 px-5">
        <h4 className="text-[13px] font-bold text-gray-900 mb-3">S1 Right (Side Panel)</h4>
        <CalcRow label="Width (in):" value={calculations.s1RightWidth} />
        <CalcRow label="Depth (in):" value={calculations.s1RightDepth} />
        <CalcRow label={'Area (ft\u00B3):'} value={calculations.s1RightArea} />
        <CalcRow label={'Still Needed (ft\u00B3):'} value={calculations.s1RightStillNeeded} />
      </div>

      {/* Vertical Separator */}
      <div className="w-px bg-gray-300 mx-4" />

      {/* Column 3: S2 Left */}
      <div className="flex-1 space-y-2 pl-5">
        <h4 className="text-[13px] font-bold text-gray-900 mb-3">S2 Left (Side Panel)</h4>
        <CalcRow label="Width (in):" value={calculations.s2LeftWidth} />
        <CalcRow label="Height (in):" value={calculations.s2LeftHeight} />
        <CalcRow label="Depth (in):" value={calculations.s2LeftDepth} />
        <CalcRow label={'Area (ft\u00B3):'} value={calculations.s2LeftArea} />
        <CalcRow label={'Still Needed (in\u00B2):'} value={calculations.s2LeftStillNeeded} />
      </div>
    </div>
  );
}

/** Single label-value row matching desktop's label + TextBox layout */
function CalcRow({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex justify-between gap-4">
      <span className="text-gray-700 whitespace-nowrap">{label}</span>
      <span className="font-semibold text-gray-900 tabular-nums">{value.toFixed(4)}</span>
    </div>
  );
}
