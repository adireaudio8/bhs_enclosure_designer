import { EndType, JoinType, inflatePaths } from "clipper2-ts";
import type { EpsPath } from "./eps-parser";
import { cutoutCurveVertices, sampleCurveOutline } from "./cutout-curves";
import { BAFFLE_FRAME_OVERHANG_IN, baffleFrameClearances, braceGapIn } from './subwoofer-clearances';
import type {
  EnclosureInputs,
  EnclosureCalculations,
  CutListItem,
} from "./types/enclosure";

export interface ProfilePoint {
  x: number;
  y: number;
}
/** A frozen, centered, inch-based contour. No brand lookup occurs on design load. */
export interface SubwooferCutoutProfile {
  version: 1 | 2;
  revision: string;
  name: string;
  filename: string;
  opening: ProfilePoint[];
  /** Original parsed EPS curves in centered inches. Version 1 polygons are
   * readable for history/preview, but cannot generate new cutting files. */
  sourcePath?: EpsPath;
  frame: { width: number; height: number; cornerRadius: number };
  maxError: number;
}
export const PROFILE_ERROR_IN = 0.001;
export function profileBounds(p: ProfilePoint[]) {
  const xs = p.map((v) => v.x),
    ys = p.map((v) => v.y);
  const minX = Math.min(...xs),
    maxX = Math.max(...xs),
    minY = Math.min(...ys),
    maxY = Math.max(...ys);
  return { minX, maxX, minY, maxY, width: maxX - minX, height: maxY - minY };
}
export function profileArea(p: ProfilePoint[]) {
  return (
    Math.abs(
      p.reduce((a, v, i) => {
        const q = p[(i + 1) % p.length];
        return a + v.x * q.y - v.y * q.x;
      }, 0),
    ) / 2
  );
}
function pointSegment(p: ProfilePoint, a: ProfilePoint, b: ProfilePoint) {
  const dx = b.x - a.x,
    dy = b.y - a.y;
  const t = Math.max(
    0,
    Math.min(
      1,
      ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy || 1),
    ),
  );
  return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy);
}
function cross(a: ProfilePoint, b: ProfilePoint, c: ProfilePoint) {
  return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}
function intersects(
  a: ProfilePoint,
  b: ProfilePoint,
  c: ProfilePoint,
  d: ProfilePoint,
) {
  if (
    cross(a, b, c) * cross(a, b, d) < 0 &&
    cross(c, d, a) * cross(c, d, b) < 0
  )
    return true;
  return (
    Math.min(
      pointSegment(a, c, d),
      pointSegment(b, c, d),
      pointSegment(c, a, b),
      pointSegment(d, a, b),
    ) < 1e-8
  );
}
function contains(p: ProfilePoint[], v: ProfilePoint) {
  let inside = false;
  for (let i = 0, j = p.length - 1; i < p.length; j = i++)
    if (
      p[i].y > v.y !== p[j].y > v.y &&
      v.x < ((p[j].x - p[i].x) * (v.y - p[i].y)) / (p[j].y - p[i].y) + p[i].x
    )
      inside = !inside;
  return inside;
}
/** Negative means overlap; positive is the exact polygon boundary separation. */
export function profileGap(a: ProfilePoint[], b: ProfilePoint[]) {
  if (contains(a, b[0]) || contains(b, a[0])) return -1;
  let gap = Infinity;
  for (let i = 0; i < a.length; i++)
    for (let j = 0; j < b.length; j++) {
      const p = a[i],
        q = a[(i + 1) % a.length],
        r = b[j],
        s = b[(j + 1) % b.length];
      if (intersects(p, q, r, s)) return -1e-8;
      gap = Math.min(
        gap,
        pointSegment(p, r, s),
        pointSegment(q, r, s),
        pointSegment(r, p, q),
        pointSegment(s, p, q),
      );
    }
  return gap;
}
export function moveProfile(p: ProfilePoint[], x: number, y: number) {
  return p.map((v) => ({ x: v.x + x, y: v.y + y }));
}
export function rectProfile(
  x0: number,
  y0: number,
  x1: number,
  y1: number,
): ProfilePoint[] {
  return [
    { x: x0, y: y0 },
    { x: x1, y: y0 },
    { x: x1, y: y1 },
    { x: x0, y: y1 },
  ];
}
export function frameProfile(
  p: SubwooferCutoutProfile,
  offset = 0,
): ProfilePoint[] {
  const w = p.frame.width / 2 + offset,
    h = p.frame.height / 2 + offset,
    r = p.frame.cornerRadius + offset;
  if (r <= 0) return rectProfile(-w, -h, w, h);
  const n = Math.max(
    4,
    Math.ceil(Math.PI / 2 / Math.acos(Math.max(-1, 1 - PROFILE_ERROR_IN / r))),
  );
  return [
    [w - r, h - r],
    [-w + r, h - r],
    [-w + r, -h + r],
    [w - r, -h + r],
  ].flatMap(([x, y], i) =>
    Array.from({ length: n + 1 }, (_, j) => ({
      x: x + r * Math.cos(((i + j / n) * Math.PI) / 2),
      y: y + r * Math.sin(((i + j / n) * Math.PI) / 2),
    })),
  );
}
export function offsetProfile(
  p: ProfilePoint[],
  delta: number,
): ProfilePoint[] {
  if (!delta) return p;
  if (!Number.isFinite(delta) || Math.abs(delta) > 1)
    throw new Error("Cutout clearance must be within one inch.");
  const scale = 1e6;
  const path = p.map((v) => ({
    x: Math.round(v.x * scale),
    y: Math.round(v.y * scale),
  }));
  const signed = path.reduce((a, v, i) => {
    const q = path[(i + 1) % path.length];
    return a + v.x * q.y - v.y * q.x;
  }, 0);
  const result = inflatePaths(
    [signed < 0 ? path.reverse() : path],
    delta * scale,
    JoinType.Round,
    EndType.Polygon,
    2,
    PROFILE_ERROR_IN * scale,
  );
  if (result.length !== 1 || result[0].length < 3)
    throw new Error("Cutout clearance collapses or splits this outline.");
  return result[0].map((v) => ({ x: v.x / scale, y: v.y / scale }));
}
export function validateCutoutProfile(
  value: unknown,
): asserts value is SubwooferCutoutProfile {
  const p = value as SubwooferCutoutProfile;
  if (
    !p ||
    (p.version !== 1 && p.version !== 2) ||
    typeof p.revision !== "string" ||
    !p.revision ||
    typeof p.name !== "string" ||
    !Array.isArray(p.opening) ||
    p.opening.length < 3 ||
    p.opening.length > 1024 ||
    p.opening.some(
      (v) =>
        !v ||
        !Number.isFinite(v.x) ||
        !Number.isFinite(v.y) ||
        Math.abs(v.x) > 30 ||
        Math.abs(v.y) > 30,
    ) ||
    !p.frame ||
    ![p.frame.width, p.frame.height].every(
      (n) => Number.isFinite(n) && n > 0 && n <= 60,
    ) ||
    !Number.isFinite(p.frame.cornerRadius) ||
    p.frame.cornerRadius < 0 ||
    p.frame.cornerRadius > Math.min(p.frame.width, p.frame.height) / 2 ||
    !Number.isFinite(p.maxError) ||
    p.maxError < 0 ||
    p.maxError > PROFILE_ERROR_IN
  )
    throw new Error("Invalid custom subwoofer cutout.");
  const b = profileBounds(p.opening);
  if (
    profileArea(p.opening) < 0.01 ||
    b.width < 0.1 ||
    b.height < 0.1 ||
    Math.abs(b.minX + b.maxX) > 0.002 ||
    Math.abs(b.minY + b.maxY) > 0.002 ||
    b.width >= p.frame.width ||
    b.height >= p.frame.height
  )
    throw new Error(
      "Confirm the cutout dimensions and a larger outside frame.",
    );
  for (let i = 0; i < p.opening.length; i++)
    for (let j = i + 2; j < p.opening.length; j++) {
      if (i === 0 && j === p.opening.length - 1) continue;
      if (
        intersects(
          p.opening[i],
          p.opening[(i + 1) % p.opening.length],
          p.opening[j],
          p.opening[(j + 1) % p.opening.length],
        )
      )
        throw new Error("The cutout outline crosses itself.");
    }
  const frame = frameProfile(p);
  if (p.opening.some((v) => !contains(frame, v)))
    throw new Error("The opening must be inside the outside frame outline.");
  if (p.version === 2) {
    if (!p.sourcePath) throw new Error("The custom cutout is missing its original EPS curves.");
    const curve = sampleCurveOutline(cutoutCurveVertices(p.sourcePath));
    const boundaryDistance = (v: ProfilePoint, points: ProfilePoint[]) => Math.min(...points.map((a, i) =>
      pointSegment(v, a, points[(i + 1) % points.length])));
    if (curve.some(v => boundaryDistance(v, p.opening) > PROFILE_ERROR_IN)
      || p.opening.some(v => boundaryDistance(v, curve) > PROFILE_ERROR_IN)) {
      throw new Error("The cutout preview does not match its EPS curves. Upload the original EPS again.");
    }
  }
}
export function profileCutoutArea(inputs: EnclosureInputs) {
  return inputs.subwooferCutoutProfile
    ? profileArea(inputs.subwooferCutoutProfile.opening)
    : Math.PI * (inputs.subCutoutDiameter / 2) ** 2;
}
export function normalizeProfileInputs(
  inputs: EnclosureInputs,
): EnclosureInputs {
  if (!inputs.subwooferCutoutProfile) return inputs;
  validateCutoutProfile(inputs.subwooferCutoutProfile);
  return {
    ...inputs,
    subCutoutDiameter: profileBounds(inputs.subwooferCutoutProfile.opening)
      .width,
    outsideDiameter: inputs.subwooferCutoutProfile.frame.width,
  };
}
export function measureProfileLayout(
  points: ProfilePoint[],
  width: number,
  height: number,
  p: SubwooferCutoutProfile,
) {
  const edgeClearance = Math.min(
    ...points.flatMap((v) => [
      v.x - p.frame.width / 2,
      width - v.x - p.frame.width / 2,
      v.y - p.frame.height / 2,
      height - v.y - p.frame.height / 2,
    ]),
  );
  let gap = Infinity;
  const f = frameProfile(p);
  for (let i = 0; i < points.length; i++)
    for (let j = i + 1; j < points.length; j++)
      gap = Math.min(
        gap,
        profileGap(
          moveProfile(f, points[i].x, points[i].y),
          moveProfile(f, points[j].x, points[j].y),
        ),
      );
  return { edgeClearance, subToSubGap: Number.isFinite(gap) ? gap : 0 };
}

/** Centers in baffle-local coordinates, shared by the viewer, fit check and DXF. */
export function profileBaffleCenters(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  parts: CutListItem[],
) {
  const part = parts.find(
    (v) => v.partName === "Baffle" || v.partName === "Baffle + Port 1",
  );
  if (!part) return [];
  const count = { Single: 1, Dual: 2, Triple: 3, Quad: 4 }[
    inputs.subwooferQuantity
  ];
  const pp1 = parts.find((v) => v.partName === "Port Piece 1");
  const width = calc.roundPort?.active ? calc.roundPort.subSpanWidthIn :
    part.kerf?.baffleRunIn ??
    (calc.labyrinthPort.active
      ? part.width -
        (pp1?.thickness ?? 0) -
        Math.max(0, calc.labyrinthPort.panels.length - 1) *
          calc.labyrinthPort.lanePitch
      : part.width);
  if (inputs.subwooferPositions !== undefined) {
    return Array.isArray(inputs.subwooferPositions)
      ? inputs.subwooferPositions.filter(p => p && Number.isFinite(p.x) && Number.isFinite(p.y)).map(p => ({...p})) : [];
  }
  const frameWidth = inputs.subwooferCutoutProfile?.frame.width || inputs.outsideDiameter || inputs.subCutoutDiameter;
  const gap = (width - count * frameWidth) / (count + 1);
  // The span starts at the baffle's left edge, except with the drivers placed to the right of
  // an elbowed side tube (round-port.ts: subSpanStartIn).
  const start = (calc.roundPort?.active && calc.roundPort.subSpanStartIn) || 0;
  return Array.from({ length: count }, (_, i) => ({
    x: start ? start + gap * (i + 1) + frameWidth * (i + 0.5) : gap * (i + 1) + frameWidth * (i + 0.5),
    y: part.height / 2,
  }));
}

/** Brace centerlines between adjacent physical drivers; labels retain their order. */
export function baffleBraceCenters(inputs: EnclosureInputs, parts: CutListItem[], calc: EnclosureCalculations): number[] {
  const centers = profileBaffleCenters(inputs, calc, parts).map(p => p.x).sort((a,b) => a-b);
  return centers.slice(1).map((x,i) => (x+centers[i])/2);
}

/** Finished-panel limits shared by automatic fit, custom controls and export.
 * Keep the outside frame clear of the panel and the opening clear of joinery.
 * A flush recess needs half an inch of wood above and below its OD + .25 opening. */
export function bafflePositionBounds(inputs: EnclosureInputs, calc: EnclosureCalculations, parts: CutListItem[], clearance=0) {
  const panel=parts.find(p=>p.partName==='Baffle'||p.partName==='Baffle + Port 1');
  const width=panel?.kerf?.baffleRunIn ?? panel?.width ?? 0, height=panel?.height ?? 0;
  const profile=inputs.subwooferCutoutProfile;
  const halfW=(profile?.frame.width || inputs.outsideDiameter || inputs.subCutoutDiameter)/2;
  const halfH=(profile?.frame.height || inputs.outsideDiameter || inputs.subCutoutDiameter)/2;
  const radius=inputs.subCutoutDiameter/2+clearance;
  const opening=profile ? profileBounds(offsetProfile(profile.opening,clearance))
    : {minX:-radius,maxX:radius,minY:-radius,maxY:radius};
  const wall=parts.find(p=>p.partName==='Side Left')?.thickness ?? 0;
  const pp1=parts.find(p=>p.partName==='Port Piece 1')?.thickness ?? wall;
  const maze=calc.labyrinthPort.active ? Math.max(0,calc.labyrinthPort.panels.length-1)*calc.labyrinthPort.lanePitch : 0;
  // Round flared port in the baffle: the frames and openings stop short of the flare(s) at the
  // right. In the right side panel it leaves the whole baffle to the drivers: with no port
  // panel in the cut list the ordinary limits below are then the two side walls.
  const round=calc.roundPort?.active && calc.roundPort.location !== 'Side Right' ? calc.roundPort : undefined;
  const right=round ? round.subRightLimitIn : panel?.kerf ? width : width-pp1-maze;
  const frameRight=round ? round.subRightLimitIn : width;
  const plate=parts.find(p=>p.partName==='Sub Mount Plate');
  const inset=plate ? Math.max(0,(width-plate.width)/2) : 0;
  const recess=inputs.recessedMounting ? .125 : 0;
  const margin=.25+(profile?.maxError ?? 0);
  // Use a small positive margin to agree with the legacy <= .25 failure boundary. Top and bottom:
  // a frame may run 1/8 in past the baffle (the panels there sit flush around it); a flush recess
  // still needs half an inch of wood (2026-11-16).
  const edge=.250001+recess, vertical=inputs.recessedMounting ? .625 : -BAFFLE_FRAME_OVERHANG_IN;
  return {xMin:Math.max(halfW+edge,Math.max(wall,inset)-opening.minX+margin),
    xMax:Math.min(frameRight-halfW-edge,Math.min(right,width-inset)-opening.maxX-margin),
    yMin:Math.max(halfH+vertical,-opening.minY+margin),
    yMax:Math.min(height-halfH-vertical,height-opening.maxY-margin)};
}

/** The same row centers as the front-panel DXF and viewer, including flush backing plates. */
export function checkProfileBaffle(
  inputs: EnclosureInputs,
  calc: EnclosureCalculations,
  parts: CutListItem[],
  clearance = 0,
) {
  const p = inputs.subwooferCutoutProfile!,
    baffle = parts.find(
      (v) => v.partName === "Baffle" || v.partName === "Baffle + Port 1",
    );
  if (!baffle)
    return {
      edgeClearance: 0,
      subToSubGap: 0,
      diagnostic: "Custom cutout requires a flat mounting baffle.",
    };
  const n = { Single: 1, Dual: 2, Triple: 3, Quad: 4 }[
      inputs.subwooferQuantity
    ],
    w = baffle.kerf?.baffleRunIn ?? baffle.width,
    h = baffle.height;
  const points = profileBaffleCenters(inputs, calc, parts);
  if(points.length!==n || (inputs.subwooferPositions !== undefined && (!Array.isArray(inputs.subwooferPositions) || inputs.subwooferPositions.length!==n)))
    return {edgeClearance:0,subToSubGap:0,diagnostic:`Enter finite X and Y centers for all ${n} subwoofers.`};
  const opening = offsetProfile(p.opening, clearance);
  validateCutoutProfile(p);
  // This temporary offset polygon is a fit envelope, not a saved EPS profile.
  validateCutoutProfile({ ...p, version: 1, sourcePath: undefined, opening });
  const margin = 0.25 + p.maxError;
  const limits = bafflePositionBounds(inputs,calc,parts,clearance);
  const metrics = measureProfileLayout(points, w, h, p);
  const invalid = points.some(
    (c) =>
      c.x < limits.xMin-1e-7 || c.x > limits.xMax+1e-7 ||
      c.y < limits.yMin-1e-7 || c.y > limits.yMax+1e-7,
  );
  const braceThickness =
    parts.find((v) => v.partName.startsWith("Gusset"))?.thickness ?? 0;
  const braceXs = baffleBraceCenters(inputs, parts, calc);
  const braces = braceXs.map(x => rectProfile(x-braceThickness/2,0,x+braceThickness/2,h));
  const recess = inputs.recessedMounting ? 0.125 : 0;
  const gap = braceGapIn(inputs, braceThickness);
  const braceConflict = braces.some((brace,i) =>
    points.some(
      (c) => profileGap(moveProfile(opening, c.x, c.y), brace) < margin ||
        Math.abs(c.x-braceXs[i]) < p.frame.width/2+gap/2+recess-1e-7,
    ),
  );
  // As for round frames: 1/8 in past the top and bottom is allowed, not past the sides.
  const room = baffleFrameClearances(points, w, h, p.frame.width, p.frame.height);
  const verticalNeed = inputs.recessedMounting ? 0.25 + recess : -BAFFLE_FRAME_OVERHANG_IN;
  const diagnostic = invalid
    ? "The custom opening does not clear the chamber walls, port or mounting plate."
    : braceConflict
      ? `Leave at least ${(gap + 2 * recess).toFixed(3)} inches between the outside frames for the baffle brace.`
      : room.side < 0.25 + recess - 1e-7 || room.vertical < verticalNeed - 1e-7 ||
          (n > 1 && metrics.subToSubGap < 0.25 + 2 * recess)
        ? "The custom outside frame or flush recess needs more space on the baffle."
        : undefined;
  return { ...metrics, diagnostic };
}
