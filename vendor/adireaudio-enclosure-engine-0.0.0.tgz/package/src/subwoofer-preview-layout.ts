import type { CutListItem, EnclosureCalculations, EnclosureInputs } from './types/enclosure';
import { resolveSupbSubLayout, type SupbLayoutResult, type SupbSubPosition } from './subwoofer-placement';

export const SUBWOOFER_PREVIEW_NOTICE = 'Amber subwoofers show an approximate placement only. Port and brace clearance is not verified; cutting files remain blocked.';

/** Display-only fallback. Never consumed by fit checks, holes, braces or CNC.
 * Keep drivers visible while editing an invalid automatic SUPB design without
 * presenting the old overlapping straight row as a validated arrangement. */
export function unresolvedSubwooferPreview(inputs: EnclosureInputs, calc: EnclosureCalculations,
  cutList: CutListItem[], layout?: SupbLayoutResult): SupbSubPosition[] | null {
  const count = { Single: 1, Dual: 2, Triple: 3, Quad: 4 }[inputs.subwooferQuantity];
  if (inputs.enclosureConfiguration !== 'Subs Up/Port Back' || inputs.portQuantity === 'Dual'
    || count < 2 || inputs.subwooferPositions !== undefined) return null;
  const od = inputs.outsideDiameter || inputs.subCutoutDiameter;
  const width = calc.boxWidth;
  const depth = inputs.boxDepth;
  if (![od, width, depth].every(n => Number.isFinite(n) && n > 0)) return null;
  const resolved = layout ?? resolveSupbSubLayout(inputs, calc, cutList);
  if (resolved.safe || resolved.points.length) return null;

  const edge = od / 2 + .5;
  const left = Math.min(edge, width / 2);
  const front = Math.min(edge, depth / 2);
  let right = Math.max(width - edge, width / 2);
  const back = Math.max(depth - edge, depth / 2);
  // Respect the known straight port wall when possible, but do NOT infer a
  // valid return wall from a negative/missing PP2. This is still only a sketch.
  const baffle = cutList.find(p => p.partName === 'Baffle');
  const pp1 = cutList.find(p => p.partName === 'Port Piece 1');
  const wallLimit = (baffle?.width ?? NaN) - (pp1?.thickness ?? NaN)
    - (inputs.subCutoutDiameter || od) / 2 - .25;
  if (Number.isFinite(wallLimit) && wallLimit > left) right = Math.min(right, wallLimit);
  const spanX = right - left;
  const spanY = back - front;
  const spacing = od + .25;
  const candidates: SupbSubPosition[][] = [];
  for (const rotated of [false, true]) {
    const w = rotated ? spanY : spanX;
    const d = rotated ? spanX : spanY;
    const add = (pattern: SupbSubPosition[]) => {
      const pw = Math.max(...pattern.map(p => p.x));
      const ph = Math.max(...pattern.map(p => p.y));
      candidates.push(pattern.map(p => {
        const x = p.x + (w - pw) / 2;
        const y = p.y + (d - ph) / 2;
        return { x: left + (rotated ? y : x), y: front + (rotated ? x : y) };
      }));
    };
    add(Array.from({ length: count }, (_, i) => ({ x: w * i / (count - 1), y: 0 })));
    if (count < 3) continue;
    for (let step = 0; step <= 32; step++) {
      const dy = d * step / 32;
      const shiftNeeded = Math.sqrt(Math.max(0, spacing ** 2 - dy ** 2));
      if (count === 3) {
        add([{ x: 0, y: 0 }, { x: w, y: 0 }, { x: w / 2, y: dy }]);
      } else {
        const shift = Math.min(w / 3, shiftNeeded);
        const pitch = w - shift;
        add([{ x: 0, y: 0 }, { x: pitch, y: 0 }, { x: shift, y: dy }, { x: w, y: dy }]);
      }
    }
  }
  const gap = (points: SupbSubPosition[]) => Math.min(...points.flatMap((p, i) =>
    points.slice(i + 1).map(q => Math.hypot(p.x - q.x, p.y - q.y) - od)));
  // Prefer a row/grid that clears the flanges; otherwise show the least
  // crowded candidate honestly, retaining the failed fit and amber warning.
  const clear = candidates.filter(p => gap(p) >= .25 - 1e-7);
  const chosen = clear[0] ?? candidates.sort((a, b) => gap(b) - gap(a))[0];
  const xOffset = Number.isFinite(inputs.subwooferXOffset) ? inputs.subwooferXOffset! : 0;
  const yOffset = Number.isFinite(inputs.subwooferYOffset) ? inputs.subwooferYOffset! : 0;
  return chosen.map(p => ({ x: p.x + xOffset, y: p.y + yOffset }));
}
