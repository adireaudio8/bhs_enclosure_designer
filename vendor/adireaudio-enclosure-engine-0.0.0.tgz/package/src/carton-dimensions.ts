const MM_PER_INCH = 25.4;

/** Additional carton clearance requested around every enclosure face. */
export const CARTON_ADDED_CLEARANCE_PER_SIDE_MM = 3.3;

/** Two opposing sides contribute to each overall carton dimension. */
export const CARTON_ADDED_CLEARANCE_TOTAL_IN =
  (CARTON_ADDED_CLEARANCE_PER_SIDE_MM * 2) / MM_PER_INCH;

// The original desktop allowances remain the packaging baseline. The added
// 3.3 mm on each opposing side increases every overall dimension by 6.6 mm.
export const CARTON_LENGTH_ALLOWANCE_IN = 1.125 + CARTON_ADDED_CLEARANCE_TOTAL_IN;
export const CARTON_WIDTH_ALLOWANCE_IN = 1.0 + CARTON_ADDED_CLEARANCE_TOTAL_IN;
export const CARTON_HEIGHT_ALLOWANCE_IN = 1.1875 + CARTON_ADDED_CLEARANCE_TOTAL_IN;

export interface CartonDimensions {
  length: number;
  width: number;
  height: number;
}

/**
 * Calculate the standard assembled-enclosure carton dimensions.
 * `roundedBoxWidth` is the Top cut-list width (or the box width rounded up to
 * the nearest eighth when a cut list is unavailable).
 */
export function calculateCartonDimensions(
  boxDepth: number,
  boxHeight: number,
  roundedBoxWidth: number,
): CartonDimensions {
  return {
    length: boxDepth + CARTON_LENGTH_ALLOWANCE_IN,
    width: boxHeight + CARTON_WIDTH_ALLOWANCE_IN,
    height: roundedBoxWidth + CARTON_HEIGHT_ALLOWANCE_IN,
  };
}
