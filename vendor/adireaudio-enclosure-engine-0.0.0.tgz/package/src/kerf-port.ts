// ─────────────────────────────────────────────────────────────────────────
// Kerf Port — geometry (V1)
//
// The Baffle and Port Piece 1 are built as a kerf-bent assembly with a rounded
// slot-port mouth. Kerf grooves (parallel partial-depth cuts on the inside
// face) let the panel wrap a ~2" centerline radius at the baffle→PP1 corner.
//
//   SD → ONE continuous 18mm panel: baffle + curve + full PP1, bent 90°.
//   HD → ONE continuous 24mm panel, same idea.
//   RD → HYBRID: a 24mm "Baffle + Port 1" piece (baffle + curve + a 3" flat
//        stub) bent 90°, PLUS a flat 18mm "Port 1" doweled onto the stub
//        (standard horizontal dowels; inner port face flush, 6mm step on the
//        chamber side). RD's native 24mm baffle + 18mm PP1 can't be one bent
//        piece, and we want the visible 24mm rounded mouth, so the baffle (with
//        the sub) bends and the 18mm port wall dowels on past the curve.
//
// SCOPE (kerfPortGate): SBPB · single slot port · Birch · not flush mount.
//
// All numbers are first-cut estimates locked from bench math; the four override
// fields on EnclosureInputs let the operator dial them in after test cuts.
// Pure functions only — no DOM, no Three.
// ─────────────────────────────────────────────────────────────────────────

import type { EnclosureInputs, MaterialConfig } from './types/enclosure';

const MM_PER_IN = 25.4;

/** Locked centerline bend radius (inches). Inside radius ≈ radius − thickness/2. */
export const KERF_CENTERLINE_RADIUS_IN = 2.0;

/** Flat 24mm stub past the last kerf cut, where the 18mm Port 1 dowels on (RD). */
export const KERF_STUB_IN = 3.0;

/** Below this leftover 18mm Port-1 width, skip the dowel and just bend the whole
 *  thing at 24mm (RD only) — avoids doweling a useless sliver on a shallow port. */
export const KERF_MIN_FLAT_PORT1_IN = 1.5;

/** 1/4" safety each side when checking the port-side sub clears the bend zone. */
export const KERF_SUB_SAFETY_IN = 0.25;

/** Per-thickness locked groove pattern (validate + tune at the test cut).
 *  18mm: 13 grooves, 7.0mm spacing, 16.25mm depth (skin ≈ 18 − 16.25 = 1.75mm)
 *  24mm: 14 grooves, 8.0mm spacing, 22.0mm depth (skin ≈ 24 − 22 = 2.0mm) */
export const KERF_SPEC_18 = { grooveCount: 13, spacingMm: 7.0, depthMm: 16.25 } as const;
export const KERF_SPEC_24 = { grooveCount: 14, spacingMm: 8.0, depthMm: 22.0 } as const;

export type KerfDuty = 'SD' | 'RD' | 'HD';

export interface KerfPattern {
  grooveCount: number;
  spacingMm: number;
  depthMm: number;
  /** Flat span the grooves occupy = grooveCount × spacing (inches). */
  bendZoneWidthIn: number;
}

export interface KerfGeometry {
  duty: KerfDuty;
  /** RD: a bent 24mm piece + a separate flat 18mm Port 1. SD/HD: one piece. */
  isHybrid: boolean;
  insideRadiusIn: number;

  // ── The kerf-bent piece ("Baffle + Port 1") ──
  bentThicknessIn: number;          // B1 for SD, B2 for RD/HD
  bentDevelopedLengthIn: number;    // flat panel WIDTH (the cut-list dimension)
  baffleRunIn: number;              // flat baffle portion (sub cutout lives here)
  bendZoneStartIn: number;          // = baffleRunIn (where grooves begin)
  bendZoneWidthIn: number;          // groove span
  bendZoneEndIn: number;
  pattern: KerfPattern;
  /** Absolute X (inches) of each groove centerline on the flat panel — the bit
   *  cuts straight down each line to pattern.depthMm. Full panel height. */
  grooveXsIn: number[];

  // ── RD-only flat remainder ("Port 1") ──
  flatPort1WidthIn?: number;
  flatPort1ThicknessIn?: number;    // B1 (18mm)
}

/** Parse the duty tier out of the enclosureType string. */
export function kerfDuty(enclosureType: string | undefined): KerfDuty {
  const s = (enclosureType || '').toLowerCase();
  if (s.includes('heavy')) return 'HD';
  if (s.includes('standard')) return 'SD';
  return 'RD';
}

/** True when a design should be built as a kerf-port assembly. SBPB single slot
 *  port, Birch, not flush mount. (Mirror this predicate everywhere — cut list,
 *  DXF, UI — so the gate is one source of truth.) */
export function kerfPortGate(inputs: EnclosureInputs): boolean {
  if (!inputs.kerfPortEnabled) return false;
  const isSBPB = inputs.enclosureConfiguration === 'Subs Back/Port Back';
  const isSinglePort = (inputs.portQuantity || 'Single') === 'Single';
  const isMDF = (inputs.enclosureType || '').toLowerCase().includes('mdf');
  const isFlush = !!inputs.recessedMounting;
  return isSBPB && isSinglePort && !isMDF && !isFlush;
}

/** Thickness (inches) of the kerf-BENT piece: SD→B1, RD→B2 (24mm baffle bends),
 *  HD→B2. (RD also has a separate flat 18mm Port-1 piece; see KerfGeometry.) */
export function resolveKerfThicknessIn(inputs: EnclosureInputs, config: MaterialConfig): number {
  return kerfDuty(inputs.enclosureType) === 'SD' ? config.B1 : config.B2;
}

/** Resolve the groove pattern for a given bent-piece thickness + bend radius.
 *  Spacing/depth are locked manufacturing constants per thickness; the groove
 *  COUNT derives from the radius (bigger radius → longer arc → more cuts). */
export function resolveKerfPattern(bentThicknessIn: number, radiusIn: number): KerfPattern {
  const base = bentThicknessIn * MM_PER_IN >= 21 ? KERF_SPEC_24 : KERF_SPEC_18;
  // Groove count scales with the bend radius: a 90° bend at a bigger radius
  // traces a longer arc, so it needs more cuts at the same (locked) spacing.
  // Anchored so the default radius reproduces the locked per-thickness count
  // exactly (2.0" → 13 on 18mm, 14 on 24mm), then scales ~linearly with radius
  // (arc length ∝ radius). Spacing + depth stay locked — manufacturing
  // constants. First-approximation slope; refine against the physical test cut.
  const spacingMm = base.spacingMm;
  const depthMm = base.depthMm;
  const grooveCount = Math.max(
    2,
    Math.round(base.grooveCount * (radiusIn / KERF_CENTERLINE_RADIUS_IN)),
  );
  return {
    grooveCount,
    spacingMm,
    depthMm,
    bendZoneWidthIn: (grooveCount * spacingMm) / MM_PER_IN,
  };
}

/**
 * Full kerf geometry for the merged Baffle + Port 1.
 *
 * `baffleWidthIn` and `port1WidthIn` are the EXISTING cut-list widths for the
 * separate Baffle and Port Piece 1 parts — the merge doesn't change how those
 * are computed; it concatenates them with the bend allowance. Developed length:
 *
 *   flat baffle (= baffleWidth − insideRadius)
 *     + bend zone (= groove span; flattens to the inside arc when bent)
 *     + flat run (SD/HD = port1Width − insideRadius ; RD = 3" stub)
 *
 * The curve advances ~insideRadius into the port depth, so on RD the flat 18mm
 * Port-1 remainder = port1Width − insideRadius − stub.
 */
export function resolveKerfGeometry(args: {
  inputs: EnclosureInputs;
  config: MaterialConfig;
  baffleWidthIn: number;
  port1WidthIn: number;
}): KerfGeometry {
  const { inputs, config, baffleWidthIn, port1WidthIn } = args;
  const duty = kerfDuty(inputs.enclosureType);
  const radiusIn = inputs.kerfPortRadius ?? KERF_CENTERLINE_RADIUS_IN;
  const bentThicknessIn = resolveKerfThicknessIn(inputs, config);
  // Neutral-axis inside radius. Clamp at 0 so a too-small radius override can't
  // produce a negative inside radius (which would feed a degenerate arc into the
  // DXF and the 3D viewer bend). Default 2.0" radius is well clear of this.
  const insideRadiusIn = Math.max(0, radiusIn - bentThicknessIn / 2);
  const pattern = resolveKerfPattern(bentThicknessIn, radiusIn);
  const bendZoneWidthIn = pattern.bendZoneWidthIn;

  const baffleRunIn = baffleWidthIn - insideRadiusIn;
  const bendZoneStartIn = baffleRunIn;
  const bendZoneEndIn = bendZoneStartIn + bendZoneWidthIn;

  // RD is the hybrid (24mm bent baffle + 18mm flat Port 1) UNLESS the leftover
  // 18mm piece would be a sliver — then bend the whole thing 24mm (no flat piece).
  let isHybrid = duty === 'RD';
  let bentDevelopedLengthIn: number;
  let flatPort1WidthIn: number | undefined;
  let flatPort1ThicknessIn: number | undefined;

  if (isHybrid) {
    const remainder = port1WidthIn - insideRadiusIn - KERF_STUB_IN;
    if (remainder >= KERF_MIN_FLAT_PORT1_IN) {
      bentDevelopedLengthIn = baffleRunIn + bendZoneWidthIn + KERF_STUB_IN;
      flatPort1WidthIn = remainder;
      flatPort1ThicknessIn = config.B1;
    } else {
      // sliver → bend the whole 24mm piece, no dowel-on flat part
      isHybrid = false;
      bentDevelopedLengthIn = baffleRunIn + bendZoneWidthIn + (port1WidthIn - insideRadiusIn);
    }
  } else {
    // SD / HD: one continuous bent piece, full PP1 included
    bentDevelopedLengthIn = baffleRunIn + bendZoneWidthIn + (port1WidthIn - insideRadiusIn);
  }

  // Groove centerlines, centered in the bend zone.
  const zoneCenterIn = bendZoneStartIn + bendZoneWidthIn / 2;
  const spacingIn = pattern.spacingMm / MM_PER_IN;
  const grooveXsIn: number[] = [];
  for (let i = 0; i < pattern.grooveCount; i++) {
    grooveXsIn.push(zoneCenterIn + (i - (pattern.grooveCount - 1) / 2) * spacingIn);
  }

  return {
    duty,
    isHybrid,
    insideRadiusIn,
    bentThicknessIn,
    bentDevelopedLengthIn,
    baffleRunIn,
    bendZoneStartIn,
    bendZoneWidthIn,
    bendZoneEndIn,
    pattern,
    grooveXsIn,
    flatPort1WidthIn,
    flatPort1ThicknessIn,
  };
}

/** DXF layer name for the kerf grooves — depth encoded so the CAM maps it to a
 *  partial-depth pass (matches the existing `8MM_DRILL__5_DEEP_24MM` style). */
export function kerfGrooveLayerName(depthMm: number): string {
  // 16.25 → "16_25", 22 → "22"
  const d = Number.isInteger(depthMm) ? String(depthMm) : depthMm.toFixed(2).replace(/0+$/, '').replace('.', '_');
  return `KERF_GROOVE_${d}MM_DEEP`;
}

/** Does the port-side subwoofer clear the start of the kerf bend? The subs sit
 *  on the flat baffle leg (baffleRunIn); the bend zone begins right after it, so
 *  the sub footprint must fit within baffleRunIn with safety margins. */
export function checkKerfSubClearance(
  geo: KerfGeometry,
  subOdIn: number,
  subCount: number,
): { fits: boolean; clearanceIn: number; message: string } {
  const needed = subCount * subOdIn + (subCount + 1) * KERF_SUB_SAFETY_IN;
  const avail = geo.baffleRunIn;
  const clearanceIn = avail - needed;
  return {
    fits: clearanceIn >= -1e-6,
    clearanceIn,
    message:
      clearanceIn >= -1e-6
        ? ''
        : `Sub(s) need ${needed.toFixed(2)}" across the baffle but only ${avail.toFixed(2)}" is clear of the kerf bend (short ${(-clearanceIn).toFixed(2)}"). Increase box width, reduce sub count, or disable kerf port.`,
  };
}
