import type { viewerSpecifications } from './viewer-specifications';

type Specifications = ReturnType<typeof viewerSpecifications>;

/** Keep the failed-fit status attached to shared customer images, not just UI. */
export function drawRenderFitWarning(ctx: CanvasRenderingContext2D, width: number) {
  const scale = width / 1280;
  ctx.fillStyle = '#fffbeb';
  ctx.fillRect(20 * scale, 20 * scale, width - 40 * scale, 32 * scale);
  ctx.fillStyle = '#92400e';
  ctx.font = `600 ${14 * scale}px Arial, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('PLACEMENT PREVIEW ONLY — fit check failed; not a validated cutting layout.', width / 2, 36 * scale);
}

export function renderSpecificationBox(width: number, height: number, rows: number) {
  const scale = width / 1280;
  const margin = 20 * scale;
  const boxWidth = 300 * scale;
  const boxHeight = (24 + rows * 24) * scale;
  return { scale, margin, width: boxWidth, height: boxHeight,
    x: width - margin - boxWidth, y: height - margin - boxHeight };
}

export function drawRenderSpecifications(ctx: CanvasRenderingContext2D, specs: Specifications,
  box: ReturnType<typeof renderSpecificationBox>) {
  const { x, y, width, height, scale } = box;
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(x, y, width, height);
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = scale;
  ctx.strokeRect(x, y, width, height);
  ctx.textBaseline = 'middle';
  specs.forEach(({ label, value }, index) => {
    const rowY = y + (24 + index * 24) * scale;
    ctx.fillStyle = '#475569';
    ctx.font = `${13 * scale}px Arial, sans-serif`;
    ctx.textAlign = 'left';
    ctx.fillText(label, x + 14 * scale, rowY);
    ctx.fillStyle = '#0f172a';
    ctx.font = `600 ${14 * scale}px Arial, sans-serif`;
    ctx.textAlign = 'right';
    ctx.fillText(value, x + width - 14 * scale, rowY);
  });
}
