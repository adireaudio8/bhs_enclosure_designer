/** Whole-pound packaged shipping weight. Keep raw material/enclosure mass precise.
 * Zero denotes an unavailable estimate; invalid/negative inputs must be rejected
 * at save boundaries rather than silently converted to a plausible weight.
 */
export function roundShippingWeight(weight: number): number {
  if (!Number.isFinite(weight) || weight < 0) {
    throw new RangeError('Shipping weight must be a finite non-negative number');
  }
  return Math.ceil(weight);
}
