/**
 * MDF part-SIZING pins — operator ruling 2026-07-08:
 *
 *   "MDF gets NO mill of any kind — not mill-down pockets, not edge
 *    milling. All MDF panel mates are FULL stock thickness: 0.75" (D1)
 *    or 1.0" (D2)."
 *
 * Before this ruling the cut list sized MDF Side Left / Side Right /
 * Port Piece 1 against the E1/E2 "MDF after mill" constants (0.71/0.96)
 * ported from the desktop C# (EnclosureViewModel.CutList.cs) — the desktop
 * shares the wrong assumption and is deliberately NOT parity here. Field
 * measurement confirmed the fix: the Side Right back-edge inset is 0.76"
 * (0.75 + 0.01 glue), not the 0.72" the E-values produced, matching the
 * 2.01/2.26-class drill-hole insets pinned in mdf-placement.test.ts.
 *
 * Pins cover the corrected dimensions across SD/RD/HD × SBPB/SUPB on the
 * CANONICAL_S12 fixture (boxDepth 18, portWidth 1.75, glue 0.01), plus:
 *   - dual-port symmetry (Side Left = Side Right)
 *   - Baffle width uses the true MDF PP2 mate (D1/D2), not the desktop's
 *     Birch-values-for-MDF quirk (operator ruling option A, 2026-07-08) —
 *     and calculateBaffleCheck's replica stays in lockstep
 *   - E1/E2 are inert: changing them must not move any MDF output
 *   - flush-mount MDF uses a 3/4" structural face/cap, with a 3/4" SD or
 *     1" RD/HD backing plate, and stays material-correct through DXF layers
 *   - DXF thickness fallbacks are material-aware for direct callers
 *     (HD MDF parts no longer trip the cut-depth safety assert)
 */
import { describe, it, expect } from 'vitest';
import { calculateEnclosure, generateCutList, calculateBaffleCheck, roundUpToEighth, getMaterialThickness } from '../src/calculations';
import { generatePartDxf } from '../src/dxf-generator';
import { DEFAULT_MATERIAL_CONFIG } from '../src/types/enclosure';
import type { EnclosureInputs, CutListItem } from '../src/types/enclosure';
import { makeInputs } from './fixtures';

const SBPB = 'Subs Back/Port Back';
const SUPB = 'Subs Up/Port Back';

function cutFor(overrides: Partial<EnclosureInputs>): CutListItem[] {
  const inputs = makeInputs(overrides);
  return generateCutList(inputs, calculateEnclosure(inputs));
}

function widthOf(cut: CutListItem[], partName: string): number {
  const part = cut.find((p) => p.partName === partName);
  expect(part, `part ${partName}`).toBeDefined();
  return part!.width;
}

// ─── Corrected single-port dimensions: SD/RD/HD × SBPB/SUPB ────────────────
// boxDepth 18. Mates per row: [front (baffle), back, PP2] class.
//   SD:      D1 front, D1 back, D1 pp2
//   RD-SBPB: D2 front, D1 back, D1 pp2   (Baffle is the thick panel)
//   RD-SUPB: D1 front, D1 back, D1 pp2   (Top is thick; baffle genuinely 3/4")
//   HD:      D2 front, D2 back, D2 pp2
// Side Left  = 18 − (front + back + 2·glue)
// Side Right = 18 − (back-class value + glue)  [HD → D2, else D1]
// Port 1     = 18 − (1.75 + front + back + pp2 + 2·glue)
const SINGLE_PORT_MATRIX = [
  { duty: 'MDF - Standard Duty', cfg: SBPB, sideLeft: 16.48, sideRight: 17.24, port1: 13.98 },
  { duty: 'MDF - Standard Duty', cfg: SUPB, sideLeft: 16.48, sideRight: 17.24, port1: 13.98 },
  { duty: 'MDF - Regular Duty',  cfg: SBPB, sideLeft: 16.23, sideRight: 17.24, port1: 13.73 },
  { duty: 'MDF - Regular Duty',  cfg: SUPB, sideLeft: 16.48, sideRight: 17.24, port1: 13.98 },
  { duty: 'MDF - Heavy Duty',    cfg: SBPB, sideLeft: 15.98, sideRight: 16.99, port1: 13.23 },
  { duty: 'MDF - Heavy Duty',    cfg: SUPB, sideLeft: 15.98, sideRight: 16.99, port1: 13.23 },
] as const;

describe('MDF cut list — full-stock mates, single port (CANONICAL_S12)', () => {
  for (const e of SINGLE_PORT_MATRIX) {
    it(`${e.duty} / ${e.cfg}: SL ${e.sideLeft}, SR ${e.sideRight}, P1 ${e.port1}`, () => {
      const cut = cutFor({ enclosureType: e.duty, enclosureConfiguration: e.cfg });
      expect(widthOf(cut, 'Side Left')).toBeCloseTo(e.sideLeft, 10);
      expect(widthOf(cut, 'Side Right')).toBeCloseTo(e.sideRight, 10);
      expect(widthOf(cut, 'Port Piece 1')).toBeCloseTo(e.port1, 10);
    });
  }

  it('Side Right back-edge inset is 0.76 (SD/RD) / 1.01 (HD) — matches the drill-hole insets', () => {
    // boxDepth − sideRightWidth = mate + glue. This is the number the
    // operator measures on the physical Top/Bottom panel.
    const sd = cutFor({ enclosureType: 'MDF - Standard Duty' });
    expect(18 - widthOf(sd, 'Side Right')).toBeCloseTo(0.76, 10);
    const hd = cutFor({ enclosureType: 'MDF - Heavy Duty' });
    expect(18 - widthOf(hd, 'Side Right')).toBeCloseTo(1.01, 10);
  });
});

describe('MDF cut list — dual port symmetry', () => {
  for (const duty of ['MDF - Standard Duty', 'MDF - Regular Duty', 'MDF - Heavy Duty'] as const) {
    it(`${duty}: Side Left = Side Right = boxDepth − (D + glue)`, () => {
      const cut = cutFor({ enclosureType: duty, portQuantity: 'Dual' });
      const expected = duty.includes('Heavy') ? 18 - (1.0 + 0.01) : 18 - (0.75 + 0.01);
      expect(widthOf(cut, 'Side Left')).toBeCloseTo(expected, 10);
      expect(widthOf(cut, 'Side Right')).toBeCloseTo(expected, 10);
    });
  }
});

describe('MDF baffle width — true D1/D2 PP2 mate (ruling option A)', () => {
  // The desktop quirk used B1/B2 even for MDF, making the MDF baffle
  // 0.041" (SD/RD) / 0.055" (HD) too wide per port. Pin the corrected
  // formula: baffleWidth = roundUpToEighth(boxWidth) − (portWidth + D)
  // single, − (2·portWidth + 2·D) dual, D = D1 thin / D2 heavy.
  for (const duty of ['MDF - Standard Duty', 'MDF - Regular Duty', 'MDF - Heavy Duty'] as const) {
    const mateD = duty.includes('Heavy') ? 1.0 : 0.75;
    for (const cfg of [SBPB, SUPB] as const) {
      it(`${duty} / ${cfg}: single + dual baffle widths use D mate ${mateD}`, () => {
        const single = makeInputs({ enclosureType: duty, enclosureConfiguration: cfg });
        const calcS = calculateEnclosure(single);
        const cutS = generateCutList(single, calcS);
        expect(widthOf(cutS, 'Baffle'))
          .toBeCloseTo(roundUpToEighth(calcS.boxWidth) - (1.75 + mateD), 12);

        const dual = makeInputs({ enclosureType: duty, enclosureConfiguration: cfg, portQuantity: 'Dual' });
        const calcD = calculateEnclosure(dual);
        const cutD = generateCutList(dual, calcD);
        expect(widthOf(cutD, 'Baffle'))
          .toBeCloseTo(roundUpToEighth(calcD.boxWidth) - (2 * 1.75 + 2 * mateD), 12);
      });
    }
  }

  it('MDF-RD SBPB absolute pin: 21 − (1.75 + 0.75) = 18.5 (was 18.541 under the Birch quirk)', () => {
    expect(widthOf(cutFor({ enclosureType: 'MDF - Regular Duty' }), 'Baffle')).toBeCloseTo(18.5, 12);
  });

  it('calculateBaffleCheck netWidth stays in lockstep with the cut-list baffle width (SBPB)', () => {
    for (const duty of ['MDF - Standard Duty', 'MDF - Regular Duty', 'MDF - Heavy Duty'] as const) {
      const inputs = makeInputs({ enclosureType: duty });
      const calc = calculateEnclosure(inputs);
      const baffleWidth = widthOf(generateCutList(inputs, calc), 'Baffle');
      const wallT = getMaterialThickness(duty);
      const pp1T = duty.includes('Heavy') ? 1.0 : wallT;
      expect(calc.baffleCheck.netWidth).toBeCloseTo(baffleWidth - wallT - pp1T, 12);
    }
  });

  it('Birch baffle width keeps desktop parity (B1 mate): RD SBPB = rounded − (1.75 + 0.709)', () => {
    const inputs = makeInputs({ enclosureType: 'Birch Ply - Regular Duty' });
    const calc = calculateEnclosure(inputs);
    expect(widthOf(generateCutList(inputs, calc), 'Baffle'))
      .toBeCloseTo(roundUpToEighth(calc.boxWidth) - (1.75 + 0.709), 12);
  });
});

describe('E1/E2 are inert — no MDF output reads the legacy "after mill" values', () => {
  it('poisoning E1/E2 changes nothing (cut list + calculations, all duties × configs)', () => {
    const poisoned = { ...DEFAULT_MATERIAL_CONFIG, E1: 999, E2: -999 };
    for (const duty of ['MDF - Standard Duty', 'MDF - Regular Duty', 'MDF - Heavy Duty'] as const) {
      for (const cfg of [SBPB, SUPB] as const) {
        for (const portQuantity of ['Single', 'Dual'] as const) {
          const inputs = makeInputs({ enclosureType: duty, enclosureConfiguration: cfg, portQuantity });
          const calcDefault = calculateEnclosure(inputs, DEFAULT_MATERIAL_CONFIG);
          const calcPoisoned = calculateEnclosure(inputs, poisoned);
          expect(calcPoisoned).toEqual(calcDefault);
          expect(generateCutList(inputs, calcPoisoned, poisoned))
            .toEqual(generateCutList(inputs, calcDefault, DEFAULT_MATERIAL_CONFIG));
        }
      }
    }
  });
});

describe('MDF flush mount construction', () => {
  it('SBPB MDF: backing stack reduces chamber and mounting depth by D1', () => {
    const base = calculateEnclosure(makeInputs({ enclosureType: 'MDF - Regular Duty' }));
    const flagged = calculateEnclosure(makeInputs({ enclosureType: 'MDF - Regular Duty', recessedMounting: true }));
    expect(flagged.internalDepthWithDB).toBeCloseTo(base.internalDepthWithDB - DEFAULT_MATERIAL_CONFIG.D1, 10);
    expect(flagged.mountingDepthAvail).toBeCloseTo(base.mountingDepthAvail - DEFAULT_MATERIAL_CONFIG.D1, 10);
  });

  it('SUPB MDF: 3/4" cap reduces internal height by D1', () => {
    const base = calculateEnclosure(makeInputs({ enclosureType: 'MDF - Standard Duty', enclosureConfiguration: SUPB }));
    const flagged = calculateEnclosure(makeInputs({ enclosureType: 'MDF - Standard Duty', enclosureConfiguration: SUPB, recessedMounting: true }));
    expect(flagged.internalHeight).toBeCloseTo(base.internalHeight - DEFAULT_MATERIAL_CONFIG.D1, 10);
  });

  it.each([
    ['Standard Duty', '3/4" MDF', DEFAULT_MATERIAL_CONFIG.D1],
    ['Regular Duty', '1" MDF', DEFAULT_MATERIAL_CONFIG.D2],
    ['Heavy Duty', '1" MDF', DEFAULT_MATERIAL_CONFIG.D2],
  ])('%s cut list uses a 3/4" face and the approved backing plate', (duty, plateMaterial, plateThickness) => {
    const cut = cutFor({ enclosureType: `MDF - ${duty}`, recessedMounting: true });
    const baffle = cut.find((p) => p.partName === 'Baffle');
    const plate = cut.find((p) => p.partName === 'Sub Mount Plate');
    expect(baffle?.material).toBe('3/4" MDF');
    expect(baffle?.thickness).toBe(DEFAULT_MATERIAL_CONFIG.D1);
    expect(plate?.material).toBe(plateMaterial);
    expect(plate?.thickness).toBe(plateThickness);
  });

  it('SUPB cut list emits a 3/4" MDF Sub Mount Cap', () => {
    const cut = cutFor({ enclosureType: 'MDF - Heavy Duty', enclosureConfiguration: SUPB, recessedMounting: true });
    const cap = cut.find((p) => p.partName === 'Sub Mount Cap');
    expect(cap?.material).toBe('3/4" MDF');
    expect(cap?.thickness).toBe(DEFAULT_MATERIAL_CONFIG.D1);
  });

  it('baffle check applies the flush minimum-height gate to MDF', () => {
    // internalHeight 12 < OD 12.81 + 1.25, so both supported materials fail.
    const mk = (enclosureType: string) => makeInputs({ enclosureType, recessedMounting: true });
    const birch = calculateBaffleCheck(mk('Birch Ply - Regular Duty'), 6.5, 20.7, DEFAULT_MATERIAL_CONFIG, 10.4, 12);
    expect(birch.isFail).toBe(true);
    expect(birch.mountLabel).toBe('Baffle (flush mount needs taller box)');
    const mdf = calculateBaffleCheck(mk('MDF - Regular Duty'), 6.5, 20.7, DEFAULT_MATERIAL_CONFIG, 10.4, 12);
    expect(mdf.isFail).toBe(true);
    expect(mdf.mountLabel).toBe('Baffle (flush mount needs taller box)');
  });

  it('DXF routes the MDF face on 3/4" layers and the RD plate on 1" layers', () => {
    const common = {
      buildStrength: 'Regular Duty',
      isBirchPly: false,
      enclosureConfiguration: SBPB,
      subCutoutDiameter: 10,
      outsideDiameter: 12,
      subwooferQuantity: 'Dual',
      recessedMounting: true,
    } as const;
    const baffle = generatePartDxf('Baffle', 30, 14, common);
    expect(baffle).toContain('CUT_OUT__75INCH');
    expect(baffle).toContain('CUT_INSIDE__75INCH');
    expect(baffle).toContain('8MM_DRILL__5_DEEP__75INCH');
    expect(baffle).not.toContain('CUT_OUT_18MM');

    const plate = generatePartDxf('Sub Mount Plate', 28.5, 14, common);
    expect(plate).toContain('CUT_OUT_1INCH');
    expect(plate).toContain('CUT_INSIDE_1INCH');
    expect(plate).toContain('8MM_DRILL__5_DEEP_1INCH');

    const cap = generatePartDxf('Sub Mount Cap', 30, 18, {
      ...common,
      enclosureConfiguration: SUPB,
    });
    expect(cap).toContain('CUT_OUT__75INCH');
    expect(cap).toContain('CUT_INSIDE__75INCH');
    expect(cap).not.toContain('CUT_OUT_1INCH');
  });
});

describe('DXF thickness fallbacks are material-aware (direct callers omitting options)', () => {
  it('HD MDF part with no thickness options generates (previously tripped the depth-safety assert)', () => {
    // CUT_OUT_1INCH cuts 1.0" deep; the old bare 0.945 fallback implied a
    // 0.055" overcut > 0.05" tolerance → throw. D2 fallback fixes it.
    expect(() => generatePartDxf('Baffle', 30, 14, { buildStrength: 'Heavy Duty', isBirchPly: false }))
      .not.toThrow();
    const dxf = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Heavy Duty', isBirchPly: false });
    expect(dxf).toContain('CUT_OUT_1INCH');
  });

  it('Birch fallbacks unchanged: HD Birch part without options still generates on 24MM layers', () => {
    const dxf = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Heavy Duty', isBirchPly: true });
    expect(dxf).toContain('CUT_OUT_24MM');
    expect(dxf).not.toContain('1INCH');
  });
});
