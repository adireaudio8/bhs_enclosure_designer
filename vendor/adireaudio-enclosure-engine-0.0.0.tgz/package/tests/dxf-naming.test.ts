// ─────────────────────────────────────────────────────────────────────────
// CHARACTERIZATION tests for the PURE parts of src/dxf-generator.ts:
// filename rules (XXL 14-char router cap, ACC dash+period strip), the
// kerf-port ACC numbering gap, dieline dimension/split boundaries, and a
// generatePartDxf smoke + snapshot. Canvas/PDF/browser paths are out of
// scope (generateAccBarcodesPdf is only pinned to reject in Node).
//
// All expected values were computed by running the code and recording
// the output — they pin CURRENT behavior (desktop-parity armor).
// ─────────────────────────────────────────────────────────────────────────
import { describe, it, expect } from 'vitest';
import {
  logoXxlFilename,
  boxXxlFilename,
  generateOnLineLogoToolpath,
  generateLogoDxf,
  getDielineDimensions,
  needsSplitDieline,
  generateAllFiles,
  generatePartDxf,
  generateAccBarcodesPdf,
  type GenerateAllOptions,
  type GeneratedFile,
} from '../src/dxf-generator';
import { generatePocketLogoToolpath } from '../src/pocket-logo-toolpath';
import { accBarcodeValue } from '../src/acc-naming';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import { resolveSupbSubLayout } from '../src/subwoofer-placement';
import { makeInputs } from './fixtures';
import { DEFAULT_MATERIAL_CONFIG, type EnclosureInputs, type MaterialConfig } from '../src/types/enclosure';

/** Drive generateAllFiles the way the app does: calc → cut list → files.
 *  Carton dims are 0 so the box dieline/toolpath stage is skipped — these
 *  tests focus on part DXFs + ACC files. */
function buildAllFiles(
  inputs: EnclosureInputs,
  prefix: string,
  buildStrength: string,
  outputMode: GenerateAllOptions['outputMode'] = 'all',
  materialConfig: MaterialConfig = DEFAULT_MATERIAL_CONFIG,
  glueTolerance: number = 0.01,
  accFilenamePrefix?: string,
) {
  const calc = calculateEnclosure(inputs, materialConfig);
  const cutList = generateCutList(inputs, calc, materialConfig, glueTolerance);
  const isBirch = !inputs.enclosureType.includes('MDF');
  const options: GenerateAllOptions = {
    filenamePrefix: prefix,
    accFilenamePrefix,
    cutList,
    subCutoutDiameter: inputs.subCutoutDiameter,
    outsideDiameter: inputs.outsideDiameter,
    subwooferQuantity: inputs.subwooferQuantity,
    cartonLength: 0,
    cartonWidth: 0,
    cartonHeight: 0,
    cardboardThickness: 0.25,
    enclosureConfiguration: inputs.enclosureConfiguration,
    buildStrength,
    isBirchPly: isBirch,
    portQuantity: inputs.portQuantity,
    portWidth: inputs.portWidth,
    s2LeftWidth: calc.s2LeftWidth,
    s1RightWidth: calc.s1RightWidth,
    materialThickness: isBirch ? materialConfig.B1 : materialConfig.D1,
    heavyThickness: isBirch ? materialConfig.B2 : materialConfig.D2,
    materialConfig,
    glueTolerance,
    outputMode,
    inputs,
    calc,
  };
  return { calc, cutList, files: generateAllFiles(options) };
}

function expectControllerSafeXilogArcs(xxl: string): void {
  let current: { x: number; y: number } | null = null;
  let checked = 0;
  for (const line of xxl.split(/\r?\n/)) {
    const command = line.match(/^(G[0-3])\b/)?.[1];
    if (!command) continue;
    const attributes = Object.fromEntries(
      [...line.matchAll(/\b([XYIJ])=([-\d.]+)/g)]
        .map((match) => [match[1], Number(match[2])]),
    );
    const end = {
      x: attributes.X ?? current?.x ?? 0,
      y: attributes.Y ?? current?.y ?? 0,
    };
    if ((command === 'G2' || command === 'G3') && current) {
      const startRadius = Math.hypot(current.x - attributes.I, current.y - attributes.J);
      const endRadius = Math.hypot(end.x - attributes.I, end.y - attributes.J);
      expect(Math.abs(startRadius - endRadius)).toBeLessThan(0.003);
      checked += 1;
    }
    current = end;
  }
  expect(checked).toBeGreaterThan(0);
}

describe('fast output modes', () => {
  const inputs = makeInputs({ enclosureType: 'Birch Ply - Regular Duty' });

  it('ACC-only skips every DXF, XXL, and TXT while retaining all ACC programs', () => {
    const { files } = buildAllFiles(inputs, 'BHSP-SUN-SAV3-D12-RD', 'Regular Duty', 'acc');
    expect(files).toHaveLength(7);
    expect(files.every(file => file.type === 'acc')).toBe(true);
  });

  it('Logo-only emits nothing when no logo was supplied and does not fall through to full output', () => {
    const { files } = buildAllFiles(inputs, 'BHSP-SUN-SAV3-D12-RD', 'Regular Duty', 'logo');
    expect(files).toEqual([]);
  });

  it('can bind ACC identity to the saved design name instead of a stale export prefix', () => {
    const { files } = buildAllFiles(
      { ...inputs, enclosureType: 'MDF - Regular Duty' },
      'BHS-4.0V2-D12-RD',
      'Regular Duty',
      'acc',
      DEFAULT_MATERIAL_CONFIG,
      0.01,
      'BHSF-BHS-4.0V2-D12-RD-MDF',
    );
    expect(accFilenames(files)[0]).toBe(`${accBarcodeValue('BHSF-BHS-4.0V2-D12-RD-MDF', 1)}.acc`);
  });
});

describe('labyrinth manufacturing export', () => {
  const labyrinthInputs = (enclosureConfiguration: EnclosureInputs['enclosureConfiguration']) => makeInputs({
    enclosureConfiguration,
    tuningFrequency: 20,
    netAirSpace: 1.5,
    boxDepth: 18,
    boxHeight: 16,
    portWidth: 2,
    subCutoutDiameter: 6.5,
    outsideDiameter: 7.25,
    size: '8"',
  });

  it.each([
    'Subs Back/Port Back',
    'Subs Up/Port Back',
    'Subs Up/Port Up',
  ] as const)('exports every DXF, guide, ACC program, and review reference for %s', (configuration) => {
    const prefix = 'LABYRINTH-RD';
    const { calc, cutList, files } = buildAllFiles(
      labyrinthInputs(configuration),
      prefix,
      'Regular Duty',
    );
    expect(calc.labyrinthPort.active).toBe(true);

    const portParts = cutList.filter(part => /^Port Piece \d+$/.test(part.partName));
    expect(portParts).toHaveLength(calc.labyrinthPort.panels.length);
    for (const panel of calc.labyrinthPort.panels) {
      expect(files.some(file => file.filename === `${prefix}-Port ${panel.partNumber}.dxf`)).toBe(true);
      expect(files.some(file => file.filename === `${prefix}-Port ${panel.partNumber}_wG.dxf`)).toBe(true);
    }

    const expectedAccNumbers = [1, 2, 3, 4, 5, 6, 7,
      ...calc.labyrinthPort.panels.slice(2).map(panel => panel.partNumber + 6)];
    expect(accFilenames(files)).toEqual(
      expectedAccNumbers.map(number => `${accBarcodeValue(prefix, number)}.acc`),
    );

    for (const panel of calc.labyrinthPort.panels.slice(1)) {
      const dxf = files.find(file => file.filename === `${prefix}-Port ${panel.partNumber}.dxf`)!;
      expect(dxf.content).toContain(`ASSEMBLY_${panel.anchoredAt.toUpperCase()}_ANCHOR`);
      expect(dxf.content).toContain('MILL_DOWN_');
      expect(dxf.content).not.toContain('8MM_DRILL__5_DEEP_');
    }

    const bottom = files.find(file => file.filename === `${prefix}-Bottom.dxf`)!;
    const top = files.find(file => file.filename === `${prefix}-Top.dxf`)!;
    const expectedHorizontalPanelDrills = 15 + 2 * (calc.labyrinthPort.panels.length - 1);
    expect(dxfCircles(bottom.content, '8MM_DRILL__5_DEEP_')).toHaveLength(expectedHorizontalPanelDrills);
    expect(dxfCircles(top.content, '8MM_DRILL__5_DEEP_')).toHaveLength(expectedHorizontalPanelDrills);

    const reference = files.find(file => file.filename.endsWith('Labyrinth-Assembly-REFERENCE-ONLY.dxf'));
    const review = files.find(file => file.filename.endsWith('Labyrinth-Assembly-Review.txt'));
    expect(reference?.content).toContain('REFERENCE_ONLY_BOX_OUTLINE');
    expect(reference?.content).toContain('REFERENCE_PP2_BACK_ANCHOR');
    expect(review?.content).toContain('MANUAL REVIEW REQUIRED BEFORE PRODUCTION CUTTING.');
    expect(review?.content).toContain('PP3:');
    expect(review?.content).toContain('Top X');
  });

  it('keeps multi-digit ACC values valid for Port 4 and beyond', () => {
    expect(accBarcodeValue('LABYRINTH-RD', 10)).toBe('LABYRINTHR10');
    expect(() => accBarcodeValue('LABYRINTH-RD', 0)).toThrow('positive integer');
  });
});

function accFilenames(files: GeneratedFile[]): string[] {
  return files.filter(f => f.type === 'acc').map(f => f.filename);
}

function accValues(file: GeneratedFile | undefined): number[] {
  expect(file).toBeDefined();
  return [...file!.content.matchAll(/^\d+\t([-\d.]+)\tYes/gm)]
    .map(match => parseFloat(match[1]));
}

function dxfCircles(dxf: string, layerPrefix: string): Array<{ x: number; y: number; r: number }> {
  const re = /0\nCIRCLE\n8\n([^\n]+)\n10\n([-\d.]+)\n20\n([-\d.]+)\n30\n0\.0\n40\n([-\d.]+)/g;
  return [...dxf.matchAll(re)]
    .filter(match => match[1].startsWith(layerPrefix))
    .map(match => ({ x: Number(match[2]), y: Number(match[3]), r: Number(match[4]) }));
}

// ─── XXL filenames (shortenedXxlFilename via the L_/B_ wrappers) ──────────

describe('XXL filenames — 14-char SCM router cap', () => {
  it('uses compact mixed-case logo names while retaining the legacy box name', () => {
    expect(logoXxlFilename('JL-W7-S13.5-RD')).toBe('LjlW7s135.xxl');
    expect(boxXxlFilename('JL-W7-S13.5-RD')).toBe('B_JL_W7_S13_5.xxl');
  });

  it('formats brand lower-case, model upper-case, and size lower-case', () => {
    expect(logoXxlFilename('SUN-SAv3-D10-HD')).toBe('LsunSAV3d10.xxl');
    expect(boxXxlFilename('SUN-SAv3-D10-HD')).toBe('B_SUN_SAv3_D10.xxl');
    expect(logoXxlFilename('BHS-2.0V2-S12-SD')).toBe('Lbhs20V2s12.xxl');
  });

  it('drops SUPB and duty from logo names', () => {
    expect(logoXxlFilename('JL-W7-S13.5-SUPB-RD')).toBe('LjlW7s135.xxl');
    expect(boxXxlFilename('JL-W7-S13.5-SUPB-RD')).toBe('B_JL_W7_S13_5.xxl');
  });

  it('ignores sales tier and retains lowercase mdf as the material discriminator', () => {
    expect(logoXxlFilename('BHSP-SUN-SAV3-D12-RD')).toBe('LsunSAV3d12.xxl');
    expect(logoXxlFilename('BHSF-SUN-SAV3-D12-RD')).toBe('LsunSAV3d12.xxl');
    expect(logoXxlFilename('BHSP-SUN-SAV3-D12-RD-MDF')).toBe('LsunSAV3d12mdf.xxl');
    expect(logoXxlFilename('BHSF-SUN-SAV3-D12-RD-MDF')).toBe('LsunSAV3d12mdf.xxl');
  });

  it('normalizes model-before-size even when the SKU stores size first', () => {
    expect(logoXxlFilename('BHSP-PE-S12-2.0V2-RD')).toBe('Lpe20V2s12.xxl');
    expect(logoXxlFilename('BHSP-PE-S12-2.0V2-RD-MDF')).toBe('Lpe20V2s12mdf.xxl');
  });

  it('hard-caps the basename at 14 chars (extension excluded)', () => {
    expect(logoXxlFilename('BHSP-AMB-GO-D12-HD')).toBe('LambGOd12.xxl');
    expect(boxXxlFilename('BHSP-AMB-GO-D12-HD')).toBe('B_BHSP_AMB_GO_.xxl');
    expect(logoXxlFilename('BHSP-VERYLONGBRAND-VERYLONGMODEL-D123-RD-MDF').replace(/\.xxl$/, '')).toHaveLength(14);
    expect(logoXxlFilename('BHSP-VERYLONGBRAND-VERYLONGMODEL-D123-RD-MDF')).toMatch(/mdf\.xxl$/);
  });

  it('empty prefix falls back to ENCLOSURE', () => {
    expect(logoXxlFilename('')).toBe('L_ENCLOSURE.xxl');
    expect(boxXxlFilename('')).toBe('B_ENCLOSURE.xxl');
  });

  it('drops duty markers wherever they occur in a recognized SKU', () => {
    expect(logoXxlFilename('A-SD-B')).toBe('LaB.xxl');
  });

  it('drops both duty and SUPB regardless of their order', () => {
    expect(logoXxlFilename('FOO-SD-SUPB')).toBe('Lfoo.xxl');
  });
});

describe('logo XXL material thickness', () => {
  const squareLogoEps = [
    '%!PS-Adobe-3.0 EPSF-3.0',
    '%%BoundingBox: 0 0 10 10',
    '%%EndPageSetup',
    '0 0 moveto',
    '10 0 lineto',
    '10 10 lineto',
    '0 10 lineto',
    'closepath',
    'stroke',
    '2 2 moveto',
    '8 2 lineto',
    '8 8 lineto',
    '2 8 lineto',
    'closepath',
    'stroke',
  ].join('\n');
  const squareLogoDxf = [
    '0', 'SECTION', '2', 'ENTITIES',
    '0', 'LWPOLYLINE',
    '8', 'ENGRAVE_LOGO_ON_LINE_0625',
    '70', '1',
    '10', '1', '20', '1',
    '10', '2', '20', '1',
    '10', '2', '20', '2',
    '10', '1', '20', '2',
    '0', 'ENDSEC', '0', 'EOF',
  ].join('\n');

  const allCurvedLogoDxf = [
    '0', 'SECTION', '2', 'ENTITIES',
    '0', 'LWPOLYLINE',
    '8', 'ENGRAVE_LOGO_ON_LINE_0625',
    '70', '1',
    '10', '10', '20', '12', '42', '1',
    '10', '14', '20', '12', '42', '1',
    '0', 'ENDSEC', '0', 'EOF',
  ].join('\n');

  it('generates a Pocket XXL for VCarve loops closed by a final return segment', () => {
    const implicitClosedEps = [
      '%!PS-Adobe-3.0 EPSF-3.0',
      '%%BoundingBox: 0 0 10 10',
      '%%EndPageSetup',
      '0 0 moveto',
      '10 0 lineto',
      '10 10 lineto',
      '0 10 lineto',
      '0 0 lineto',
      'stroke',
      '2 2 moveto',
      '8 2 lineto',
      '8 8 lineto',
      '2 8 lineto',
      '2 2 lineto',
      'stroke',
    ].join('\n');

    const dxf = generateLogoDxf(implicitClosedEps, 24.5, 19.75);
    expect(dxf).toBeTruthy();
    expect(generatePocketLogoToolpath(dxf!, 'Heavy Duty', 24.003)).toBeTruthy();
  });

  it('ramps along an all-curved On Line contour without invalid arc radii', () => {
    const xxl = generateOnLineLogoToolpath(allCurvedLogoDxf, 'Heavy Duty', 24.003);
    expect(xxl).toContain(';Name: Logo On');
    expect(xxl).toMatch(/^G3 X=.* Z=1\.587 I=.* V=1842$/m);
    expectControllerSafeXilogArcs(xxl);
  });

  it('uses 19.05 mm for MDF in both On Line and Pocket modes', () => {
    expect(generateOnLineLogoToolpath(squareLogoDxf, 'Heavy Duty', 19.05))
      .toContain('DZ=19.050');
    expect(generatePocketLogoToolpath(squareLogoDxf, 'Heavy Duty', 19.05))
      .toContain('DZ=19.050');
  });

  it('preserves the existing Birch duty defaults when no override is supplied', () => {
    expect(generateOnLineLogoToolpath(squareLogoDxf, 'Regular Duty'))
      .toContain('DZ=18.000');
    expect(generatePocketLogoToolpath(squareLogoDxf, 'Heavy Duty'))
      .toContain('DZ=24.000');
  });

  const exactConfig: MaterialConfig = {
    B1: 0.703,
    B2: 0.931,
    C1: 0.67,
    C2: 0.91,
    D1: 0.761,
    D2: 1.017,
    E1: 0.75,
    E2: 1.0,
  };

  function generatedLogoXxl(
    enclosureType: string,
    logoMode: 'On Line' | 'Pocket',
    enclosureConfiguration: EnclosureInputs['enclosureConfiguration'] = 'Subs Back/Port Back',
  ): GeneratedFile {
    const inputs = makeInputs({ enclosureType, enclosureConfiguration });
    const calc = calculateEnclosure(inputs, exactConfig);
    const cutList = generateCutList(inputs, calc, exactConfig);
    const files = generateAllFiles({
      filenamePrefix: enclosureType.includes('MDF')
        ? 'BHSP-SUN-SAV3-D12-RD-MDF'
        : 'BHSP-SUN-SAV3-D12-RD',
      cutList,
      subCutoutDiameter: inputs.subCutoutDiameter,
      outsideDiameter: inputs.outsideDiameter,
      subwooferQuantity: inputs.subwooferQuantity,
      cartonLength: 0,
      cartonWidth: 0,
      cartonHeight: 0,
      cardboardThickness: 0.25,
      epsLogoContent: squareLogoEps,
      logoMode,
      enclosureConfiguration,
      buildStrength: enclosureType.includes('Heavy') ? 'Heavy Duty'
        : enclosureType.includes('Regular') ? 'Regular Duty'
          : 'Standard Duty',
      isBirchPly: !enclosureType.includes('MDF'),
      portQuantity: inputs.portQuantity,
      portWidth: inputs.portWidth,
      s2LeftWidth: calc.s2LeftWidth,
      s1RightWidth: calc.s1RightWidth,
      materialThickness: enclosureType.includes('MDF') ? exactConfig.D1 : exactConfig.B1,
      heavyThickness: enclosureType.includes('MDF') ? exactConfig.D2 : exactConfig.B2,
      outputMode: 'logo',
    });
    const xxl = files.find(file => file.type === 'xxl');
    expect(xxl, `logo XXL for ${enclosureType} / ${logoMode}`).toBeDefined();
    return xxl!;
  }

  it.each([
    ['Birch Ply - Standard Duty', exactConfig.B1],
    ['Birch Ply - Regular Duty', exactConfig.B1],
    ['Birch Ply - Heavy Duty', exactConfig.B2],
    ['MDF - Standard Duty', exactConfig.D1],
    ['MDF - Regular Duty', exactConfig.D1],
    ['MDF - Heavy Duty', exactConfig.D2],
  ] as const)('uses the exact configured logo-panel thickness for %s', (enclosureType, thicknessInches) => {
    const expectedDz = (thicknessInches * 25.4).toFixed(3);
    expect(generatedLogoXxl(enclosureType, 'On Line').content).toContain(`DZ=${expectedDz}`);
    expect(generatedLogoXxl(enclosureType, 'Pocket').content).toContain(`DZ=${expectedDz}`);
  });

  it('uses the exact Baffle thickness for Subs Up logo programs', () => {
    const xxl = generatedLogoXxl('MDF - Regular Duty', 'On Line', 'Subs Up/Port Back');
    expect(xxl.content).toContain(`DZ=${(exactConfig.D1 * 25.4).toFixed(3)}`);
  });
});

// ─── ACC filenames + barcode lockstep ──────────────────────────────────────

describe('ACC filenames + encoded barcode strings (readable lockstep rule)', () => {
  const inputs = makeInputs({ enclosureType: 'Birch Ply - Regular Duty' });
  const { files } = buildAllFiles(inputs, 'JL-W7-S13.5-RD', 'Regular Duty');

  it('uses the readable physical-design code and single-digit parts 1..7', () => {
    expect(accFilenames(files)).toEqual([
      'JLW7S135R1.acc',
      'JLW7S135R2.acc',
      'JLW7S135R3.acc',
      'JLW7S135R4.acc',
      'JLW7S135R5.acc',
      'JLW7S135R6.acc',
      'JLW7S135R7.acc',
    ]);
  });

  it('each .acc filename is exactly the encoded barcode string + ".acc"', () => {
    // generateAccBarcodesPdf calls the same helper; the printed value must be
    // byte-for-byte equal to the on-disk filename stem.
    const expectedBarcodes = [1, 2, 3, 4, 5, 6, 7]
      .map(part => accBarcodeValue('JL-W7-S13.5-RD', part));
    expect(accFilenames(files)).toEqual(expectedBarcodes.map(b => `${b}.acc`));
  });

  it('generateAccBarcodesPdf is browser-only — rejects in Node', async () => {
    await expect(generateAccBarcodesPdf('JL-W7-S13.5-RD', 14.5))
      .rejects.toThrow('generateAccBarcodesPdf requires a browser environment');
  });

  it('ACC file content: HPJ header, CRLF, 6dp values padded/truncated to 8 chars', () => {
    const acc01 = files.find(f => f.filename === 'JLW7S135R1.acc')!;
    // 13.25 = Back panel height 14.5 − 1.25 corner inset; note "13.25000"
    // is the 8-char truncation of "13.250000".
    expect(acc01.content).toBe(
      'HPJ Program File\r\n' +
      'Version Number\r\n' +
      '66049\r\n' +
      'Zones\r\n' +
      '1\r\n' +
      'Glue Time\r\n' +
      '30\r\n' +
      'Num Items\r\n' +
      '2\r\n' +
      'Num\tX\t\tDrill\tDowel  Drill3\r\n' +
      '1\t1.250000\tYes\tNo    No\r\n' +
      '2\t13.25000\tYes\tNo    No\r\n',
    );
  });

  it('non-default Glue Tolerance keeps ACC holes aligned to the resized MDF parts', () => {
    const mdf = makeInputs({ enclosureType: 'MDF - Standard Duty' });
    const baseline = buildAllFiles(mdf, 'MDF-SD', 'Standard Duty', 'acc', DEFAULT_MATERIAL_CONFIG, 0.01);
    const adjusted = buildAllFiles(mdf, 'MDF-SD', 'Standard Duty', 'acc', DEFAULT_MATERIAL_CONFIG, 0.02);

    const baselineRight = baseline.cutList.find(part => part.partName === 'Side Right')!;
    const adjustedRight = adjusted.cutList.find(part => part.partName === 'Side Right')!;
    expect(adjustedRight.width).toBeCloseTo(baselineRight.width - 0.01, 6);

    const baseline04 = accValues(baseline.files.find(file => file.filename === 'SM4.acc'));
    const adjusted04 = accValues(adjusted.files.find(file => file.filename === 'SM4.acc'));
    expect(baseline04[baseline04.length - 1]).toBeCloseTo(baselineRight.width - 1.25, 6);
    expect(adjusted04[adjusted04.length - 1]).toBeCloseTo(adjustedRight.width - 1.25, 6);
  });

  it('full generated file list for the canonical non-kerf design (names only)', () => {
    expect(files.map(f => f.filename)).toMatchSnapshot();
  });
});

// ─── Kerf ACC numbering ────────────────────────────────────────────────────

describe('kerf-port ACC numbering (file 6 dropped, deliberate gap)', () => {
  it('kerf design emits 1-5 and 7 — no 6, Port 2 keeps 7', () => {
    const inputs = makeInputs({ enclosureType: 'Birch Ply - Regular Duty', kerfPortEnabled: true });
    const { cutList, files } = buildAllFiles(inputs, 'JL-W7-S13.5-KP-RD', 'Regular Duty');

    // Sanity: the cut list really merged Baffle + Port 1 into the bent piece
    // (RD hybrid also keeps a flat 18mm 'Port 1' doweled onto the stub).
    const merged = cutList.find(p => p.partName === 'Baffle + Port 1');
    expect(merged?.kerf).toBeTruthy();
    expect(cutList.some(p => p.partName === 'Baffle')).toBe(false);
    expect(cutList.some(p => p.partName === 'Port Piece 1')).toBe(false);

    expect(accFilenames(files)).toEqual([
      'JLW7S135RK1.acc',
      'JLW7S135RK2.acc',
      'JLW7S135RK3.acc',
      'JLW7S135RK4.acc',
      'JLW7S135RK5.acc',
      'JLW7S135RK7.acc', // numbering jumps 5 → 7 on purpose
    ]);
  });

  it('kerf merged part DXF is named Baffle-Port1 and carries the kerf groove layer', () => {
    const inputs = makeInputs({ enclosureType: 'Birch Ply - Regular Duty', kerfPortEnabled: true });
    const { files } = buildAllFiles(inputs, 'JL-W7-S13.5-KP-RD', 'Regular Duty');
    const merged = files.find(f => f.filename === 'JL-W7-S13.5-KP-RD-Baffle-Port1.dxf');
    expect(merged).toBeTruthy();
    expect(merged!.content).toContain('KERF_GROOVE_22MM_DEEP'); // 24mm bent piece (RD)
    expect(merged!.content).toContain('CUT_OUT_24MM');
  });

  it('non-kerf SUPB multi-sub design adds file 8 (gusset dowels) after 1..7', () => {
    const inputs = makeInputs({
      enclosureConfiguration: 'Subs Up/Port Back',
      subwooferQuantity: 'Dual',
      netAirSpace: 4.0,
      boxDepth: 16,
      boxHeight: 18,
      portWidth: 2,
    });
    const { files } = buildAllFiles(inputs, 'SUN-SAv3-D12-SUPB-SD', 'Standard Duty');
    expect(accFilenames(files)).toEqual([
      'SUNSAV3D12US1.acc',
      'SUNSAV3D12US2.acc',
      'SUNSAV3D12US3.acc',
      'SUNSAV3D12US4.acc',
      'SUNSAV3D12US5.acc',
      'SUNSAV3D12US6.acc',
      'SUNSAV3D12US7.acc',
      'SUNSAV3D12US8.acc',
    ]);
  });
});

describe('SUPB shared multi-sub placement', () => {
  it('staggered SUPB coordinates stay aligned across Top DXF, gusset drills, and ACC 8', () => {
    const inputs = makeInputs({
      enclosureConfiguration: 'Subs Up/Port Back',
      subwooferQuantity: 'Dual',
      outsideDiameter: 10,
      subCutoutDiameter: 8.5,
      netAirSpace: 2,
      boxHeight: 18,
      boxDepth: 16,
      portWidth: 1.75,
    });
    const { calc, cutList, files } = buildAllFiles(inputs, 'TEST-D10-SUPB-SD', 'Standard Duty');
    const layout = resolveSupbSubLayout(inputs, calc, cutList, 0, 0);
    expect(layout.safe).toBe(true);
    expect(layout.mode).toBe('staggered');

    const top = files.find(file => file.filename === 'TEST-D10-SUPB-SD-Top.dxf')!;
    const panelW = cutList.find(part => part.partName === 'Top')!.width;
    const cutouts = dxfCircles(top.content, 'CUT_INSIDE');
    expect(cutouts).toHaveLength(layout.points.length);
    layout.points.forEach((point, index) => {
      expect(cutouts[index].x).toBeCloseTo(panelW - point.x, 4);
      expect(cutouts[index].y).toBeCloseTo(point.y, 4);
      expect(cutouts[index].r).toBeCloseTo(inputs.subCutoutDiameter / 2, 4);
    });

    const drills = dxfCircles(top.content, '8MM_DRILL');
    for (const dowel of layout.gussets[0].dowels) {
      expect(drills.some(circle =>
        Math.abs(circle.x - (panelW - dowel.x)) < 0.0001 &&
        Math.abs(circle.y - dowel.y) < 0.0001
      )).toBe(true);
    }

    const acc8 = files.find(file => file.filename.endsWith('8.acc'));
    expect(accValues(acc8)).toEqual([
      1.25,
      Number(layout.gussets[0].x.toFixed(6)),
    ]);
  });

  it('refuses to generate files when valid port geometry has no safe dual-sub layout', () => {
    const inputs = makeInputs({
      enclosureConfiguration: 'Subs Up/Port Back',
      subwooferQuantity: 'Dual',
      outsideDiameter: 10,
      subCutoutDiameter: 8.5,
      netAirSpace: 1.5,
      boxHeight: 14,
      boxDepth: 16,
      portWidth: 1.25,
    });
    expect(() => buildAllFiles(inputs, 'TEST-D10-SUPB-SD', 'Standard Duty')).toThrow(
      /Subwoofer placement is unsafe: The two subwoofers do not fit safely/,
    );
  });
});

// ─── Dieline dimensions + split decision (96×48 sheet) ────────────────────

describe('getDielineDimensions() / needsSplitDieline() boundaries', () => {
  it('canonical S12 carton (19.125 × 17 × 24, 0.25 wall) fits the sheet', () => {
    const d = getDielineDimensions(19.125, 17, 24, 0.25);
    expect(d.widthInches).toBeCloseTo(75.2567, 3);
    expect(d.heightInches).toBeCloseTo(42.1236, 3);
    expect(needsSplitDieline(19.125, 17, 24, 0.25)).toBe(false);
  });

  it('horizontal-fit boundary: height crossing 48" flips the split (width ≤ 96)', () => {
    // (20, 17, 29): 77.0071 × 47.1236 → fits horizontally
    expect(getDielineDimensions(20, 17, 29, 0.25).heightInches).toBeCloseTo(47.1236, 3);
    expect(needsSplitDieline(20, 17, 29, 0.25)).toBe(false);
    // (20, 17, 30): 77.0071 × 48.1240 → 48 exceeded, too wide to rotate → split
    expect(getDielineDimensions(20, 17, 30, 0.25).heightInches).toBeCloseTo(48.1240, 3);
    expect(needsSplitDieline(20, 17, 30, 0.25)).toBe(true);
  });

  it('vertical (rotated) fit: a tall narrow dieline fits until height crosses 96"', () => {
    // (10, 10, 84): 43.0079 × 95.0374 → fits rotated (w ≤ 48, h ≤ 96)
    const d = getDielineDimensions(10, 10, 84, 0.25);
    expect(d.widthInches).toBeCloseTo(43.0079, 3);
    expect(d.heightInches).toBeCloseTo(95.0374, 3);
    expect(needsSplitDieline(10, 10, 84, 0.25)).toBe(false);
    // (10, 10, 85): 96.0374 tall → doesn't fit either way → split
    expect(getDielineDimensions(10, 10, 85, 0.25).heightInches).toBeCloseTo(96.0374, 3);
    expect(needsSplitDieline(10, 10, 85, 0.25)).toBe(true);
  });

  it('too wide for both orientations → split', () => {
    // 30" cube → 123.0079 wide (> 96) and 61.2736 tall (> 48)
    const d = getDielineDimensions(30, 30, 30, 0.25);
    expect(d.widthInches).toBeCloseTo(123.0079, 3);
    expect(d.heightInches).toBeCloseTo(61.2736, 3);
    expect(needsSplitDieline(30, 30, 30, 0.25)).toBe(true);
    // width alone can force the split even when height fits (45.1157 ≤ 48)
    expect(getDielineDimensions(40, 20, 24, 0.25).heightInches).toBeCloseTo(45.1157, 3);
    expect(needsSplitDieline(40, 20, 24, 0.25)).toBe(true);
  });

  it('small box fits comfortably', () => {
    expect(needsSplitDieline(12, 12, 12, 0.25)).toBe(false);
  });
});

// ─── generatePartDxf smoke + duty-correct cut layers ───────────────────────

describe('generatePartDxf() smoke', () => {
  it('output is a valid AC1009 DXF document (HEADER…ENTITIES…EOF, inches)', () => {
    const dxf = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Heavy Duty', isBirchPly: true });
    expect(dxf.startsWith('0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n1\n')).toBe(true);
    expect(dxf).toContain('AC1009');
    expect(dxf).toContain('0\nSECTION\n2\nTABLES\n');
    expect(dxf).toContain('0\nSECTION\n2\nENTITIES\n');
    expect(dxf.endsWith('0\nENDSEC\n0\nEOF\n')).toBe(true);
  });

  it('cut layer is duty-correct: HD → CUT_OUT_24MM, SD → CUT_OUT_18MM', () => {
    const hd = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Heavy Duty', isBirchPly: true });
    expect(hd).toContain('CUT_OUT_24MM');
    expect(hd).not.toContain('CUT_OUT_18MM');

    const sd = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Standard Duty', isBirchPly: true });
    expect(sd).toContain('CUT_OUT_18MM');
    expect(sd).not.toContain('CUT_OUT_24MM');
  });

  it('RD branches per part: SBPB thick panel is the Baffle, SUPB thick panel is the Top', () => {
    const sbpbBaffle = generatePartDxf('Baffle', 30, 14, {
      buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Back/Port Back', isBirchPly: true,
    });
    expect(sbpbBaffle).toContain('CUT_OUT_24MM');

    const sbpbTop = generatePartDxf('Top', 30, 20, {
      buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Back/Port Back',
    });
    expect(sbpbTop).toContain('CUT_OUT_18MM');
    expect(sbpbTop).not.toContain('CUT_OUT_24MM');

    const supbTop = generatePartDxf('Top', 30, 20, {
      buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Up/Port Back',
    });
    expect(supbTop).toContain('CUT_OUT_24MM');

    const supbBaffle = generatePartDxf('Baffle', 30, 14, {
      buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Up/Port Back', isBirchPly: true,
    });
    expect(supbBaffle).toContain('CUT_OUT_18MM');
    expect(supbBaffle).not.toContain('CUT_OUT_24MM');
  });

  it('mill-down strips are Birch-only', () => {
    const birch = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Standard Duty', isBirchPly: true });
    expect(birch).toContain('MILL_DOWN__034'); // SD/RD width variant
    const mdf = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Standard Duty', isBirchPly: false });
    expect(mdf).not.toContain('MILL_DOWN');
  });

  // ── MDF true-dimension layer names (2026-07-08): 18MM→_75INCH, 24MM→1INCH ──
  // MDF stock is true 0.75"/1.0" (D1/D2), so MDF parts carry their own layer
  // family; toolpath ops mapped to these names cut correspondingly deeper.
  const MDF_T = { materialThickness: 0.75, heavyThickness: 1.0, isBirchPly: false } as const;

  it('MDF cut layers: SD → CUT_OUT__75INCH, HD → CUT_OUT_1INCH, no Birch tokens', () => {
    const sd = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Standard Duty', ...MDF_T });
    expect(sd).toContain('CUT_OUT__75INCH');
    expect(sd).not.toContain('18MM');
    expect(sd).not.toContain('BOUNDING_FOR_NEST');

    const hd = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Heavy Duty', ...MDF_T });
    expect(hd).toContain('CUT_OUT_1INCH');
    expect(hd).not.toContain('24MM');
  });

  it('MDF RD branches per part like Birch: SBPB Baffle → 1INCH, Top → __75INCH; SUPB reversed', () => {
    const sbpbBaffle = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Back/Port Back', ...MDF_T });
    expect(sbpbBaffle).toContain('CUT_OUT_1INCH');
    const sbpbTop = generatePartDxf('Top', 30, 20, { buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Back/Port Back', ...MDF_T });
    expect(sbpbTop).toContain('CUT_OUT__75INCH');
    expect(sbpbTop).not.toContain('CUT_OUT_1INCH');
    const supbTop = generatePartDxf('Top', 30, 20, { buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Up/Port Back', ...MDF_T });
    expect(supbTop).toContain('CUT_OUT_1INCH');
  });

  it('MDF drill / terminal / sub-cutout layers carry the MDF token', () => {
    const back = generatePartDxf('Back', 30, 14, { buildStrength: 'Standard Duty', ...MDF_T });
    expect(back).toContain('8MM_DRILL__5_DEEP__75INCH');
    expect(back).not.toContain('8MM_DRILL__5_DEEP_18MM');

    const side = generatePartDxf('Side Left', 20, 14, { buildStrength: 'Standard Duty', portQuantity: 'Single', ...MDF_T });
    expect(side).toContain('CUT_INSIDE__75INCH');       // terminal cup
    expect(side).toContain('25_DRILL__5_DEEP__75INCH'); // terminal mounting

    const sideHd = generatePartDxf('Side Left', 20, 14, { buildStrength: 'Heavy Duty', portQuantity: 'Single', ...MDF_T });
    expect(sideHd).toContain('CUT_INSIDE_1INCH');
    expect(sideHd).toContain('25_DRILL__5_DEEP_1INCH');

    const baffle = generatePartDxf('Baffle', 30, 14, { buildStrength: 'Standard Duty', subCutoutDiameter: 11, subwooferQuantity: 'Single', ...MDF_T });
    expect(baffle).toContain('CUT_INSIDE__75INCH');     // sub cutout
  });

  it('MDF depth-safety: layer depths exactly match D1/D2 stock (no overcut throw)', () => {
    // 1" layer on 1.0" stock and 0.75" layer on 0.75" stock — overcut 0.
    expect(() => generatePartDxf('Baffle', 30, 14, { buildStrength: 'Heavy Duty', ...MDF_T })).not.toThrow();
    expect(() => generatePartDxf('Top', 30, 20, { buildStrength: 'Regular Duty', enclosureConfiguration: 'Subs Up/Port Back', ...MDF_T })).not.toThrow();
  });

  it('CANONICAL_S12 Birch-RD Baffle — full DXF snapshot (as produced by generateAllFiles)', () => {
    const inputs = makeInputs({ enclosureType: 'Birch Ply - Regular Duty' });
    const { cutList, files } = buildAllFiles(inputs, 'BHS-2.0V2-S12-RD', 'Regular Duty');
    const bafflePart = cutList.find(p => p.partName === 'Baffle')!;
    // Pin the cut-list dims feeding the DXF so a snapshot break is attributable.
    expect(bafflePart.width).toBeCloseTo(18.291, 3);
    expect(bafflePart.height).toBeCloseTo(14.5, 3);
    expect(bafflePart.thickness).toBeCloseTo(0.945, 3);
    const baffleDxf = files.find(f => f.filename === 'BHS-2.0V2-S12-RD-Baffle.dxf')!;
    expect(baffleDxf.content).toMatchSnapshot();
  });
});
