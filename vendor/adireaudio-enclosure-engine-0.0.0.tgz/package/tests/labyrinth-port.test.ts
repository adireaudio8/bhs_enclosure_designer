import { describe, expect, it } from 'vitest';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import { makeInputs } from './fixtures';

describe('automatic labyrinth slot port', () => {
  it('preserves the normal one-fold port when the volume solve has a positive S2 chamber', () => {
    const inputs = makeInputs();
    const calc = calculateEnclosure(inputs);
    const cut = generateCutList(inputs, calc);

    expect(calc.labyrinthPort.active).toBe(false);
    expect(cut.filter(part => part.partName.startsWith('Port Piece')).map(part => part.partName))
      .toEqual(['Port Piece 1', 'Port Piece 2']);
    expect(calc.boxWidth).toBeCloseTo(20.5747542149, 9);
  });

  it('lets the operator force an otherwise normal single-fold design into labyrinth mode', () => {
    const inputs = makeInputs({ forceLabyrinthPort: true });
    const calc = calculateEnclosure(inputs);
    const cut = generateCutList(inputs, calc);

    expect(calc.labyrinthPort.active).toBe(true);
    expect(calc.labyrinthPort.reason).toContain('manually activated');
    expect(calc.labyrinthPort.panels.length).toBeGreaterThan(1);
    expect(cut.filter(part => part.partName.startsWith('Port Piece')).map(part => part.partName))
      .toEqual(calc.labyrinthPort.panels.map(panel => `Port Piece ${panel.partNumber}`));
  });

  it('retains topology safety gates when manual mode is selected', () => {
    const dual = calculateEnclosure(makeInputs({ forceLabyrinthPort: true, portQuantity: 'Dual' }));
    const kerf = calculateEnclosure(makeInputs({ forceLabyrinthPort: true, kerfPortEnabled: true }));

    expect(dual.labyrinthPort.active).toBe(false);
    expect(dual.labyrinthPort.reason).toContain('Dual-port');
    expect(kerf.labyrinthPort.active).toBe(false);
    expect(kerf.labyrinthPort.reason).toContain('Kerf');
  });

  it.each([
    'Subs Back/Port Back',
    'Subs Up/Port Back',
    'Subs Up/Port Up',
  ] as const)('turns a negative legacy S2 solve into alternating in-box dividers for %s', (enclosureConfiguration) => {
    const inputs = makeInputs({
      enclosureConfiguration,
      tuningFrequency: 20,
      netAirSpace: 1.5,
      boxDepth: 18,
      boxHeight: 16,
      portWidth: 2,
    });
    const calc = calculateEnclosure(inputs);
    const cut = generateCutList(inputs, calc);
    const layout = calc.labyrinthPort;
    const portParts = cut.filter(part => part.partName.startsWith('Port Piece'));

    expect(layout.active).toBe(true);
    expect(layout.panels.length).toBeGreaterThan(2);
    expect(calc.s2LeftWidth).toBeGreaterThanOrEqual(0);
    expect(calc.boxWidth).toBeGreaterThan(layout.mazeWidth);
    expect(portParts).toHaveLength(layout.panels.length);
    expect(portParts.map(part => part.partName)).toEqual(
      layout.panels.map(panel => `Port Piece ${panel.partNumber}`),
    );
    expect(layout.panels.map(panel => panel.anchoredAt).slice(0, 6))
      .toEqual(['front', 'back', 'front', 'back', 'front', 'back']);
    expect(portParts.every(part => part.width > 0 && part.height === calc.portHeight)).toBe(true);

    const reconstructedLength = layout.initialLegLength
      + layout.terminalTurnLength
      + layout.panels.slice(1).reduce(
        (sum, panel) => sum + layout.lanePitch + panel.idealLength,
        0,
      );
    expect(reconstructedLength).toBeCloseTo(layout.acousticLength, 9);
  });

  it('keeps dual ports on their existing geometry instead of guessing a shared maze', () => {
    const inputs = makeInputs({
      portQuantity: 'Dual',
      tuningFrequency: 20,
      netAirSpace: 1.5,
      portWidth: 2,
    });
    const calc = calculateEnclosure(inputs);
    expect(calc.labyrinthPort.active).toBe(false);
    expect(calc.labyrinthPort.reason).toContain('Dual-port');
  });

});
