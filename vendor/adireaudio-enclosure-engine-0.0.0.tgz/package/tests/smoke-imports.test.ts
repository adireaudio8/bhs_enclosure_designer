import { describe, it, expect } from 'vitest';

// Import-safety smoke: every module under test must load in plain Node
// (no window/document/canvas at module scope). If one of these fails, the
// fix belongs in HOW we import/mock it — not in the module itself.
describe('module imports are Node-safe', () => {
  it('calculations', async () => {
    const m = await import('../src/calculations');
    expect(typeof m.calculateEnclosure).toBe('function');
  });
  it('cost-calculator', async () => {
    const m = await import('../src/cost-calculator');
    expect(typeof m.calculateCostFromCutList).toBe('function');
  });
  it('pricing-modifiers', async () => {
    const m = await import('../src/pricing-modifiers');
    expect(m).toBeTruthy();
  });
  it('dxf-generator', async () => {
    const m = await import('../src/dxf-generator');
    expect(m).toBeTruthy();
  });
  it('kerf-port', async () => {
    const m = await import('../src/kerf-port');
    expect(m).toBeTruthy();
  });
  it('terminal-placement', async () => {
    const m = await import('../src/terminal-placement');
    expect(m).toBeTruthy();
  });
  it('subwoofer-placement', async () => {
    const m = await import('../src/subwoofer-placement');
    expect(m).toBeTruthy();
  });
  it('acrylic-window', async () => {
    const m = await import('../src/acrylic-window');
    expect(m).toBeTruthy();
  });
  it('design-name-utils', async () => {
    const m = await import('../src/design-name-utils');
    expect(m).toBeTruthy();
  });
  it('extra-holes', async () => {
    const m = await import('../src/extra-holes');
    expect(m).toBeTruthy();
  });
  it('eps-parser', async () => {
    const m = await import('../src/eps-parser');
    expect(m).toBeTruthy();
  });
  it('flat-pack-optimizer', async () => {
    const m = await import('../src/flat-pack-optimizer');
    expect(m).toBeTruthy();
  });
});
