// ─────────────────────────────────────────────────────────────────────────
// CHARACTERIZATION tests for src/pricing-modifiers.ts
//
// These pin CURRENT behavior (regression armor for dealer-facing prices) —
// they are not a correctness review. Every expected number below was
// computed by running the module and recording the output.
//
// Resolution rule under test (see module header):
//   finalMap = round(baseMap × Π(1 + pct/100) + Σ(absolute), cents)
//   dealerPrice = round(finalMap × 0.6, cents)
// ─────────────────────────────────────────────────────────────────────────
import { describe, it, expect } from 'vitest';
import {
  resolveModifiedMAP,
  parsePricingModifiers,
  migrateFromLegacyDiscounts,
  detectMaterial,
  DEFAULT_PRICING_MODIFIERS,
  type PricingModifiersConfig,
  type PercentModifier,
} from '../src/pricing-modifiers';

/** Convenience: resolve against a base MAP of $1000 (deltas readable at a glance). */
function resolve1000(
  designName: string,
  size: string,
  modifiers: PricingModifiersConfig,
  extra: Partial<Parameters<typeof resolveModifiedMAP>[0]> = {},
) {
  return resolveModifiedMAP({ designName, size, baseMap: 1000, modifiers, ...extra });
}

/**
 * A live-config-shaped modifiers JSON, mirroring the operative
 * app_settings.pricing_modifiers documented in CALCULATION_AUDIT.md /
 * PROJECT_HISTORY.md (June 1): FP −45%, Foundation Birch −37.5% / MDF −50%,
 * Performance MDF −30%, Flush Mount + Acrylic Window absolute $ tiers.
 * (Code DEFAULTS differ: FP −25%, Foundation −30%, MDF disabled.)
 */
const LIVE_CONFIG: PricingModifiersConfig = {
  version: 1,
  modifiers: [
    {
      id: 'flushMount', label: 'Flush Mount',
      detector: { type: 'name_contains', pattern: '-FM-' },
      kind: 'absolute_by_size',
      tiers: { '6.5': 25, '8': 25, '10': 25, '12': 50, '13.5': 50, '15': 50, '18': 100 },
      enabled: true,
    },
    {
      id: 'flatPack', label: 'Flat Pack',
      detector: { type: 'name_ends', pattern: '-FP' },
      kind: 'percent', value: -45, enabled: true,
    },
    {
      id: 'foundation', label: 'Foundation',
      detector: { type: 'name_starts', pattern: 'BHSF-' },
      kind: 'percent', value: -37.5,
      materialOverrides: { mdf: -50 },
      enabled: true,
    },
    {
      id: 'select', label: 'Select',
      detector: { type: 'name_starts', pattern: 'BHSS-' },
      kind: 'percent', value: null, enabled: false,
    },
    {
      id: 'mdfDiscount', label: 'MDF Discount',
      detector: { type: 'material_is', material: 'mdf', nameExcludeStartsWith: ['BHSF-', 'BHSS-'] },
      kind: 'percent', value: -30, enabled: true,
    },
    {
      id: 'acrylicWindow', label: 'Acrylic Window',
      detector: { type: 'input_flag', field: 'windowEnabled' },
      kind: 'absolute_by_window_size',
      tiers: { '12x12': 75, '24x12': 150, custom: 150 },
      enabled: true,
    },
  ],
};

// ─── detectMaterial ────────────────────────────────────────────────────────

describe('detectMaterial()', () => {
  it('maps MDF enclosure types to mdf', () => {
    expect(detectMaterial('MDF - Heavy Duty')).toBe('mdf');
    expect(detectMaterial('MDF - Standard Duty')).toBe('mdf');
    expect(detectMaterial('mdf - regular duty')).toBe('mdf');
  });

  it('maps Birch enclosure types to birch', () => {
    expect(detectMaterial('Birch Ply - Standard Duty')).toBe('birch');
    expect(detectMaterial('Birch Ply - Heavy Duty')).toBe('birch');
  });

  it('defaults to birch for missing/ambiguous values', () => {
    expect(detectMaterial(undefined)).toBe('birch');
    expect(detectMaterial(null)).toBe('birch');
    expect(detectMaterial('')).toBe('birch');
    expect(detectMaterial('Solid Oak')).toBe('birch');
  });

  it('is a substring match — any "mdf" anywhere wins', () => {
    expect(detectMaterial('Premium MDF blend')).toBe('mdf');
  });
});

// ─── Guard rails ───────────────────────────────────────────────────────────

describe('resolveModifiedMAP() guard rails', () => {
  it('returns all-zeros for baseMap = 0', () => {
    expect(resolve1000('JL-W7-S12-RD-FP', '12', DEFAULT_PRICING_MODIFIERS, { baseMap: 0 }))
      .toEqual({ finalMap: 0, dealerPrice: 0, applied: [], breakdown: [] });
  });

  it('returns all-zeros for negative baseMap', () => {
    expect(resolve1000('JL-W7-S12-RD-FP', '12', DEFAULT_PRICING_MODIFIERS, { baseMap: -5 }))
      .toEqual({ finalMap: 0, dealerPrice: 0, applied: [], breakdown: [] });
  });

  it('returns all-zeros for NaN baseMap', () => {
    expect(resolve1000('JL-W7-S12-RD-FP', '12', DEFAULT_PRICING_MODIFIERS, { baseMap: NaN }))
      .toEqual({ finalMap: 0, dealerPrice: 0, applied: [], breakdown: [] });
  });

  it('a plain Performance name matches nothing — base passes through, dealer = 60%', () => {
    const r = resolve1000('SUN-SAv3-D10-HD', '10', DEFAULT_PRICING_MODIFIERS);
    expect(r.finalMap).toBe(1000);
    expect(r.dealerPrice).toBe(600);
    expect(r.applied).toEqual([]);
    expect(r.breakdown).toEqual([]);
  });
});

// ─── Every detector type on DEFAULT_PRICING_MODIFIERS ─────────────────────

describe('DEFAULT_PRICING_MODIFIERS detectors', () => {
  describe('name_ends (flatPack, −25%)', () => {
    it('fires on a trailing -FP', () => {
      const r = resolve1000('JL-W7-S12-RD-FP', '12', DEFAULT_PRICING_MODIFIERS);
      expect(r.finalMap).toBe(750);
      expect(r.dealerPrice).toBe(450);
      expect(r.applied).toEqual(['flatPack']);
      expect(r.breakdown).toEqual([
        { id: 'flatPack', label: 'Flat Pack', deltaDollars: -250 },
      ]);
    });

    it('is case-insensitive', () => {
      expect(resolve1000('jl-w7-s12-rd-fp', '12', DEFAULT_PRICING_MODIFIERS).finalMap).toBe(750);
    });

    it('does NOT fire on -FP- mid-name', () => {
      const r = resolve1000('JL-FP-S12-RD', '12', DEFAULT_PRICING_MODIFIERS);
      expect(r.finalMap).toBe(1000);
      expect(r.applied).toEqual([]);
    });
  });

  describe('name_starts (foundation, −30%)', () => {
    it('fires on a BHSF- prefix', () => {
      const r = resolve1000('BHSF-JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS);
      expect(r.finalMap).toBe(700);
      expect(r.dealerPrice).toBe(420);
      expect(r.applied).toEqual(['foundation']);
    });

    it('is case-insensitive', () => {
      expect(resolve1000('bhsf-jl-w7-s12-rd', '12', DEFAULT_PRICING_MODIFIERS).finalMap).toBe(700);
    });

    it('does NOT fire on BHSF- mid-name', () => {
      expect(resolve1000('JL-BHSF-S12-RD', '12', DEFAULT_PRICING_MODIFIERS).applied).toEqual([]);
    });
  });

  describe('name_contains (flushMount, absolute_by_size)', () => {
    it.each([
      ['JL-C3-S6.5-FM-RD', '6.5', 1025, 615],
      ['JL-W7-S8-FM-RD', '8', 1025, 615],
      ['JL-W7-S10-FM-RD', '10', 1025, 615],
      ['JL-W7-S12-FM-RD', '12', 1050, 630],
      ['JL-W7-S13.5-FM-RD', '13.5', 1050, 630],
      ['JL-W7-S15-FM-RD', '15', 1050, 630],
      ['JL-W7-S18-FM-RD', '18', 1100, 660],
    ])('%s size %s → finalMap %d / dealer %d', (name, size, finalMap, dealer) => {
      const r = resolve1000(name, size, DEFAULT_PRICING_MODIFIERS);
      expect(r.finalMap).toBe(finalMap);
      expect(r.dealerPrice).toBe(dealer);
      expect(r.applied).toEqual(['flushMount']);
    });

    it('size with no tier (21) matches the detector but applies nothing', () => {
      const r = resolve1000('JL-W7-S21-FM-RD', '21', DEFAULT_PRICING_MODIFIERS);
      expect(r.finalMap).toBe(1000);
      expect(r.applied).toEqual([]);
      expect(r.breakdown).toEqual([]);
    });
  });

  describe('input_flag (acrylicWindow, absolute_by_window_size)', () => {
    it('12x12 window adds $75', () => {
      const r = resolve1000('JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS, {
        inputs: { windowEnabled: true, windowSize: '12x12' },
      });
      expect(r.finalMap).toBe(1075);
      expect(r.dealerPrice).toBe(645);
      expect(r.applied).toEqual(['acrylicWindow']);
    });

    it('24x12 window adds $150', () => {
      const r = resolve1000('JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS, {
        inputs: { windowEnabled: true, windowSize: '24x12' },
      });
      expect(r.finalMap).toBe(1150);
      expect(r.dealerPrice).toBe(690);
    });

    it('custom window adds $150 (custom tier)', () => {
      const r = resolve1000('JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS, {
        inputs: { windowEnabled: true, windowSize: 'custom' },
      });
      expect(r.finalMap).toBe(1150);
    });

    it('windowEnabled without a windowSize applies nothing', () => {
      const r = resolve1000('JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS, {
        inputs: { windowEnabled: true },
      });
      expect(r.finalMap).toBe(1000);
      expect(r.applied).toEqual([]);
    });

    it('does not fire when inputs are missing (the Publish route passes inputs=null)', () => {
      const r = resolve1000('JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS, { inputs: null });
      expect(r.finalMap).toBe(1000);
      expect(r.applied).toEqual([]);
    });

    it('does not fire when the flag is falsy', () => {
      const r = resolve1000('JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS, {
        inputs: { windowEnabled: false, windowSize: '12x12' },
      });
      expect(r.finalMap).toBe(1000);
    });
  });

  describe('material_is (mdfDiscount) + disabled modifiers', () => {
    it('mdfDiscount is DISABLED by default — MDF material alone changes nothing', () => {
      const r = resolve1000('SUN-SAv3-D12-RD', '12', DEFAULT_PRICING_MODIFIERS, { material: 'mdf' });
      expect(r.finalMap).toBe(1000);
      expect(r.applied).toEqual([]);
    });

    it('select (BHSS-) is disabled with a null value — never applies', () => {
      const r = resolve1000('BHSS-JL-W7-S12-RD', '12', DEFAULT_PRICING_MODIFIERS);
      expect(r.finalMap).toBe(1000);
      expect(r.applied).toEqual([]);
    });
  });
});

// ─── Compounding + phase ordering ──────────────────────────────────────────

describe('percent compounding vs absolute upcharges (defaults)', () => {
  it('FP + Foundation compound multiplicatively: 1000 × 0.75 × 0.70 = 525', () => {
    const r = resolve1000('BHSF-JL-W7-S12-RD-FP', '12', DEFAULT_PRICING_MODIFIERS);
    expect(r.finalMap).toBe(525);
    expect(r.dealerPrice).toBe(315);
    // Percent modifiers apply in CONFIG order (flatPack before foundation).
    expect(r.applied).toEqual(['flatPack', 'foundation']);
    expect(r.breakdown[0]).toEqual({ id: 'flatPack', label: 'Flat Pack', deltaDollars: -250 });
    expect(r.breakdown[1].id).toBe('foundation');
    // Breakdown deltas are NOT rounded to cents (float artifact pinned).
    expect(r.breakdown[1].deltaDollars).toBeCloseTo(-225, 10);
  });

  it('absolute deltas add AFTER the compounded percents (same $ regardless of series)', () => {
    // Foundation −30% then FM +$50: 1000 × 0.70 + 50 = 750 (NOT (1000+50) × 0.70)
    const r = resolve1000('BHSF-JL-W7-S12-FM-RD', '12', DEFAULT_PRICING_MODIFIERS);
    expect(r.finalMap).toBe(750);
    expect(r.applied).toEqual(['foundation', 'flushMount']);
  });

  it('full stack FP + FN + FM + window: 1000×0.75×0.70 + 50 + 75 = 650', () => {
    const r = resolve1000('BHSF-JL-W7-S12-FM-RD-FP', '12', DEFAULT_PRICING_MODIFIERS, {
      inputs: { windowEnabled: true, windowSize: '12x12' },
    });
    expect(r.finalMap).toBe(650);
    expect(r.dealerPrice).toBe(390);
    // Phase 1 percents in config order, then phase 2 absolutes in config order.
    expect(r.applied).toEqual(['flatPack', 'foundation', 'flushMount', 'acrylicWindow']);
    expect(r.breakdown.map(b => b.deltaDollars)[2]).toBe(50);
    expect(r.breakdown.map(b => b.deltaDollars)[3]).toBe(75);
  });
});

// ─── Live-config-shaped modifiers ──────────────────────────────────────────

describe('live-config-shaped modifiers (FP −45, FN −37.5/−50 MDF, Perf MDF −30)', () => {
  it('plain Performance Birch: base passes through', () => {
    const r = resolve1000('SUN-SAv3-D12-RD', '12', LIVE_CONFIG);
    expect(r.finalMap).toBe(1000);
    expect(r.dealerPrice).toBe(600);
  });

  it('Flat Pack: 1000 × 0.55 = 550 / dealer 330', () => {
    const r = resolve1000('SUN-SAv3-D12-RD-FP', '12', LIVE_CONFIG);
    expect(r.finalMap).toBe(550);
    expect(r.dealerPrice).toBe(330);
    expect(r.applied).toEqual(['flatPack']);
  });

  it('Foundation Birch: 1000 × 0.625 = 625 / dealer 375', () => {
    const r = resolve1000('BHSF-SUN-SAv3-D12-RD', '12', LIVE_CONFIG, { material: 'birch' });
    expect(r.finalMap).toBe(625);
    expect(r.dealerPrice).toBe(375);
    expect(r.applied).toEqual(['foundation']);
  });

  it('Foundation MDF: materialOverrides.mdf −50 wins over the −37.5 default → 500', () => {
    const r = resolve1000('BHSF-SUN-SAv3-D12-RD', '12', LIVE_CONFIG, { material: 'mdf' });
    expect(r.finalMap).toBe(500);
    expect(r.dealerPrice).toBe(300);
    // mdfDiscount does NOT stack — BHSF- is in its nameExcludeStartsWith list.
    expect(r.applied).toEqual(['foundation']);
  });

  it('Performance MDF: mdfDiscount −30 → 700 / dealer 420', () => {
    const r = resolve1000('SUN-SAv3-D12-RD', '12', LIVE_CONFIG, { material: 'mdf' });
    expect(r.finalMap).toBe(700);
    expect(r.dealerPrice).toBe(420);
    expect(r.applied).toEqual(['mdfDiscount']);
  });

  it('Select (BHSS-) MDF: excluded from mdfDiscount and select is disabled → 1000', () => {
    const r = resolve1000('BHSS-SUN-SAv3-D12-RD', '12', LIVE_CONFIG, { material: 'mdf' });
    expect(r.finalMap).toBe(1000);
    expect(r.applied).toEqual([]);
  });

  it('Performance MDF Flat Pack compounds: 1000 × 0.55 × 0.70 = 385 / dealer 231', () => {
    const r = resolve1000('SUN-SAv3-D12-RD-FP', '12', LIVE_CONFIG, { material: 'mdf' });
    expect(r.finalMap).toBe(385);
    expect(r.dealerPrice).toBe(231);
    expect(r.applied).toEqual(['flatPack', 'mdfDiscount']);
  });

  it('Foundation MDF Flat Pack: 1000 × 0.55 × 0.50 = 275 / dealer 165', () => {
    const r = resolve1000('BHSF-SUN-SAv3-D12-RD-FP', '12', LIVE_CONFIG, { material: 'mdf' });
    expect(r.finalMap).toBe(275);
    expect(r.dealerPrice).toBe(165);
    expect(r.applied).toEqual(['flatPack', 'foundation']);
  });

  it('Flush Mount 13.5" absolute: 1000 + 50 = 1050', () => {
    const r = resolve1000('JL-W7-S13.5-FM-RD', '13.5', LIVE_CONFIG);
    expect(r.finalMap).toBe(1050);
    expect(r.applied).toEqual(['flushMount']);
  });

  it('Flush Mount 6.5" absolute: 1000 + 25 = 1025', () => {
    const r = resolve1000('JL-C3-S6.5-FM-RD', '6.5', LIVE_CONFIG);
    expect(r.finalMap).toBe(1025);
    expect(r.applied).toEqual(['flushMount']);
  });

  it('Flush Mount + 24x12 window: 1000 + 50 + 150 = 1200 / dealer 720', () => {
    const r = resolve1000('JL-W7-S12-FM-RD', '12', LIVE_CONFIG, {
      inputs: { windowEnabled: true, windowSize: '24x12' },
    });
    expect(r.finalMap).toBe(1200);
    expect(r.dealerPrice).toBe(720);
    expect(r.applied).toEqual(['flushMount', 'acrylicWindow']);
  });

  it('rounds to cents: 799.99 × 0.55 = 439.9945 → 439.99, dealer 263.99', () => {
    const r = resolveModifiedMAP({
      designName: 'SUN-SAv3-D12-RD-FP', size: '12', baseMap: 799.99, modifiers: LIVE_CONFIG,
    });
    expect(r.finalMap).toBe(439.99);
    expect(r.dealerPrice).toBe(263.99);
    // deltaDollars is cent-rounded since 2026-07-03 (was raw -359.9955).
    expect(r.breakdown[0].deltaDollars).toBe(-360);
  });

  it('empty design name + MDF still gets the mdfDiscount (exclusion list is skipped for blank names)', () => {
    const r = resolve1000('', '12', LIVE_CONFIG, { material: 'mdf' });
    expect(r.finalMap).toBe(700);
    expect(r.applied).toEqual(['mdfDiscount']);
  });
});

// ─── materialOverrides edge: material_is detector ignores overrides ───────

describe('materialOverrides on a material_is detector (the documented EXCEPTION)', () => {
  it('uses `value`, never materialOverrides.mdf, when detector.type === material_is', () => {
    const cfg: PricingModifiersConfig = {
      version: 1,
      modifiers: [{
        id: 'x', label: 'x',
        detector: { type: 'material_is', material: 'mdf' },
        kind: 'percent', value: -30,
        materialOverrides: { mdf: -99 }, // stale value that must NOT shadow -30
        enabled: true,
      }],
    };
    const r = resolve1000('FOO', '12', cfg, { material: 'mdf' });
    expect(r.finalMap).toBe(700); // -30 applied, not -99
    expect(r.applied).toEqual(['x']);
  });

  it('materialOverrides DOES apply on name detectors when material is mdf', () => {
    const cfg: PricingModifiersConfig = {
      version: 1,
      modifiers: [{
        id: 'y', label: 'y',
        detector: { type: 'name_starts', pattern: 'BHSF-' },
        kind: 'percent', value: -10,
        materialOverrides: { mdf: -20 },
        enabled: true,
      }],
    };
    expect(resolve1000('BHSF-A', '12', cfg, { material: 'mdf' }).finalMap).toBe(800);
    expect(resolve1000('BHSF-A', '12', cfg, { material: 'birch' }).finalMap).toBe(900);
    // material omitted → defaults to birch → default value
    expect(resolve1000('BHSF-A', '12', cfg).finalMap).toBe(900);
  });

  it('percent value of 0 or null is skipped (not applied, no breakdown row)', () => {
    const cfg: PricingModifiersConfig = {
      version: 1,
      modifiers: [
        { id: 'zero', label: 'z', detector: { type: 'name_starts', pattern: 'A' }, kind: 'percent', value: 0, enabled: true },
        { id: 'nul', label: 'n', detector: { type: 'name_starts', pattern: 'A' }, kind: 'percent', value: null, enabled: true },
      ],
    };
    const r = resolve1000('ABC', '12', cfg);
    expect(r.finalMap).toBe(1000);
    expect(r.applied).toEqual([]);
  });
});

// ─── parsePricingModifiers ─────────────────────────────────────────────────

describe('parsePricingModifiers()', () => {
  it('returns the DEFAULT config object (same reference) for null/undefined/empty', () => {
    expect(parsePricingModifiers(null)).toBe(DEFAULT_PRICING_MODIFIERS);
    expect(parsePricingModifiers(undefined)).toBe(DEFAULT_PRICING_MODIFIERS);
    expect(parsePricingModifiers('')).toBe(DEFAULT_PRICING_MODIFIERS);
  });

  it('returns the DEFAULT config for unparseable JSON', () => {
    expect(parsePricingModifiers('not json {')).toBe(DEFAULT_PRICING_MODIFIERS);
  });

  it('returns the DEFAULT config when the shape is wrong (no modifiers array)', () => {
    expect(parsePricingModifiers('{"version":2}')).toBe(DEFAULT_PRICING_MODIFIERS);
    expect(parsePricingModifiers('"a string"')).toBe(DEFAULT_PRICING_MODIFIERS);
    expect(parsePricingModifiers('[]')).toBe(DEFAULT_PRICING_MODIFIERS);
    expect(parsePricingModifiers('null')).toBe(DEFAULT_PRICING_MODIFIERS);
  });

  it('round-trips a valid config JSON verbatim (no normalization)', () => {
    const parsed = parsePricingModifiers(JSON.stringify(LIVE_CONFIG));
    expect(parsed).toEqual(LIVE_CONFIG);
    expect(parsed).not.toBe(DEFAULT_PRICING_MODIFIERS);
  });
});

// ─── migrateFromLegacyDiscounts ────────────────────────────────────────────

describe('migrateFromLegacyDiscounts()', () => {
  function percentValue(cfg: PricingModifiersConfig, id: string): number | null {
    const mod = cfg.modifiers.find(m => m.id === id) as PercentModifier;
    return mod.value;
  }

  it('negates the legacy POSITIVE discount percents into modifier values', () => {
    const cfg = migrateFromLegacyDiscounts(30, 35);
    expect(percentValue(cfg, 'flatPack')).toBe(-30);
    expect(percentValue(cfg, 'foundation')).toBe(-35);
  });

  it('already-negative legacy values stay negative (abs then negate)', () => {
    const cfg = migrateFromLegacyDiscounts(-40, -12.5);
    expect(percentValue(cfg, 'flatPack')).toBe(-40);
    expect(percentValue(cfg, 'foundation')).toBe(-12.5);
  });

  it('undefined legacy keys keep the code defaults (−25 / −30)', () => {
    const cfg = migrateFromLegacyDiscounts(undefined, undefined);
    expect(percentValue(cfg, 'flatPack')).toBe(-25);
    expect(percentValue(cfg, 'foundation')).toBe(-30);
    expect(cfg).toEqual(DEFAULT_PRICING_MODIFIERS);
  });

  it('returns a deep clone — never mutates DEFAULT_PRICING_MODIFIERS', () => {
    const cfg = migrateFromLegacyDiscounts(99, 99);
    expect(cfg).not.toBe(DEFAULT_PRICING_MODIFIERS);
    expect(percentValue(cfg, 'flatPack')).toBe(-99);
    expect(percentValue(DEFAULT_PRICING_MODIFIERS, 'flatPack')).toBe(-25);
    expect(percentValue(DEFAULT_PRICING_MODIFIERS, 'foundation')).toBe(-30);
  });

  it('a legacy 0 stays plain zero (normalized 2026-07-03; 0% modifiers are skipped at resolve time)', () => {
    const cfg = migrateFromLegacyDiscounts(0, 0);
    expect(Object.is(percentValue(cfg, 'flatPack'), 0)).toBe(true);
    const r = resolveModifiedMAP({
      designName: 'JL-W7-S12-RD-FP', size: '12', baseMap: 1000, modifiers: cfg,
    });
    expect(r.finalMap).toBe(1000);
    expect(r.applied).toEqual([]);
  });

  it('migrated config for the June-1 live values (45 / 37.5) — full snapshot', () => {
    expect(migrateFromLegacyDiscounts(45, 37.5)).toMatchSnapshot();
  });
});
