/**
 * CHARACTERIZATION tests for src/eps-parser.ts.
 *
 * Small inline EPS fixtures (kept in this file on purpose) exercise
 * parseEpsPaths, calculatePathsBounds, filterBoundingBoxPaths, and the
 * paths→DXF conversion. The kappa-circle fixtures pin the BULGE SIGN on
 * closed CCW vs CW polylines — the 2026-04 rotation-bug class where a
 * flipped bulge sign mirrors every arc on the CNC. All expected values
 * were observed by running the code.
 */
import { describe, it, expect } from 'vitest';
import {
  parseEpsPaths,
  calculatePathsBounds,
  filterBoundingBoxPaths,
  epsPathsToDxfEntities,
} from '../src/eps-parser';

// ── Inline fixtures ─────────────────────────────────────────────────────────

/** Closed 10×10 square, full-name PostScript commands, real EPS framing. */
const SQUARE_EPS = [
  '%!PS-Adobe-3.0 EPSF-3.0',
  '%%BoundingBox: 0 0 40 40',
  '%%EndPageSetup',
  'newpath',
  '0 0 moveto',
  '10 0 lineto',
  '10 10 lineto',
  '0 10 lineto',
  'closepath',
  'stroke',
  '%%Trailer',
].join('\n');

/** Kappa constant for approximating a quarter circle with one cubic Bezier. */
const K = 0.55228475;

/** Unit circle centered at (2,2), traversed COUNTER-CLOCKWISE, closed. */
const CCW_CIRCLE_EPS = [
  '%%EndPageSetup',
  'newpath',
  '3 2 moveto',
  `3 ${2 + K} ${2 + K} 3 2 3 curveto`,
  `${2 - K} 3 1 ${2 + K} 1 2 curveto`,
  `1 ${2 - K} ${2 - K} 1 2 1 curveto`,
  `${2 + K} 1 3 ${2 - K} 3 2 curveto`,
  'closepath',
  'fill',
].join('\n');

/** Same circle traversed CLOCKWISE. */
const CW_CIRCLE_EPS = [
  '%%EndPageSetup',
  'newpath',
  '3 2 moveto',
  `3 ${2 - K} ${2 + K} 1 2 1 curveto`,
  `${2 - K} 1 1 ${2 - K} 1 2 curveto`,
  `1 ${2 + K} ${2 - K} 3 2 3 curveto`,
  `${2 + K} 3 3 ${2 + K} 3 2 curveto`,
  'closepath',
  'fill',
].join('\n');

/** Abbreviated commands + scale/translate transform composition. */
const ABBREV_EPS = [
  '%%EndPageSetup',
  'np',
  '2 2 scale',
  '1 1 translate',
  '0 0 mo',
  '5 0 li',
  '5 5 li',
  'cp',
  'stroke',
].join('\n');

/** Outer rectangle spanning the full bounds + a small inner square. */
const BBOX_RECT_EPS = [
  '%%EndPageSetup',
  'newpath',
  '0 0 moveto',
  '20 0 lineto',
  '20 20 lineto',
  '0 20 lineto',
  'closepath',
  'stroke',
  'newpath',
  '5 5 moveto',
  '10 5 lineto',
  '10 10 lineto',
  '5 10 lineto',
  'closepath',
  'stroke',
].join('\n');

// ── parseEpsPaths ───────────────────────────────────────────────────────────

describe('parseEpsPaths', () => {
  it('parses a closed square: 3 line segments (closepath adds no segment)', () => {
    const paths = parseEpsPaths(SQUARE_EPS);
    expect(paths).toHaveLength(1);
    const p = paths[0];
    expect(p.isClosed).toBe(true);
    expect(p.segments).toHaveLength(3);
    expect(p.segments.every(s => s.type === 'line')).toBe(true);
    expect(p.startPoint).toEqual({ x: 0, y: 0 });
    expect(p.endPoint).toEqual({ x: 0, y: 10 }); // closepath does NOT move endPoint back
    expect(paths).toMatchSnapshot();
  });

  it('parses cubic beziers: kappa circle → 4 bezier segments, closed', () => {
    const paths = parseEpsPaths(CCW_CIRCLE_EPS);
    expect(paths).toHaveLength(1);
    expect(paths[0].isClosed).toBe(true);
    expect(paths[0].segments).toHaveLength(4);
    expect(paths[0].segments.every(s => s.type === 'bezier')).toBe(true);
    expect(paths[0].startPoint).toEqual({ x: 3, y: 2 });
    expect(paths[0].endPoint).toEqual({ x: 3, y: 2 });
  });

  it('handles abbreviated commands and composes scale∘translate transforms', () => {
    // 2 2 scale then 1 1 translate → p ↦ ((p.x+1)·2, (p.y+1)·2)
    const paths = parseEpsPaths(ABBREV_EPS);
    expect(paths).toHaveLength(1);
    const p = paths[0];
    expect(p.isClosed).toBe(true);
    expect(p.segments).toEqual([
      { type: 'line', start: { x: 2, y: 2 }, end: { x: 12, y: 2 } },
      { type: 'line', start: { x: 12, y: 2 }, end: { x: 12, y: 12 } },
    ]);
  });

  it('returns [] for empty input', () => {
    expect(parseEpsPaths('')).toEqual([]);
  });

  it('falls back to parsing the whole text when %%EndPageSetup is absent', () => {
    const noHeader = '0 0 moveto\n5 5 lineto\nstroke\n';
    const paths = parseEpsPaths(noHeader);
    expect(paths).toHaveLength(1);
    expect(paths[0].segments).toEqual([
      { type: 'line', start: { x: 0, y: 0 }, end: { x: 5, y: 5 } },
    ]);
  });

  it('strips % comments mid-stream', () => {
    const withComment = '%%EndPageSetup\n0 0 moveto % ignore 9 9 lineto\n5 0 lineto\nstroke\n';
    const paths = parseEpsPaths(withComment);
    expect(paths).toHaveLength(1);
    expect(paths[0].segments).toEqual([
      { type: 'line', start: { x: 0, y: 0 }, end: { x: 5, y: 0 } },
    ]);
  });

  it('a moveto with no drawing commands produces no path', () => {
    expect(parseEpsPaths('%%EndPageSetup\n3 3 moveto\nstroke\n')).toEqual([]);
  });

  it('recognizes a VCarve contour that returns to its start without closepath', () => {
    const eps = [
      '%%EndPageSetup',
      '0 0 moveto',
      '10 0 lineto',
      '10 10 lineto',
      '0 10 lineto',
      '0 0 lineto',
      'stroke',
    ].join('\n');

    const paths = parseEpsPaths(eps);
    expect(paths).toHaveLength(1);
    expect(paths[0].isClosed).toBe(true);
    expect(paths[0].startPoint).toEqual(paths[0].endPoint);
  });

  it('does not close a contour whose endpoint remains visibly separated', () => {
    const eps = [
      '%%EndPageSetup',
      '0 0 moveto',
      '10 0 lineto',
      '10 10 lineto',
      '0 10 lineto',
      '0 0.001 lineto',
      'stroke',
    ].join('\n');

    const paths = parseEpsPaths(eps);
    expect(paths).toHaveLength(1);
    expect(paths[0].isClosed).toBe(false);
  });
});

// ── calculatePathsBounds ────────────────────────────────────────────────────

describe('calculatePathsBounds', () => {
  it('square bounds are exact', () => {
    const bounds = calculatePathsBounds(parseEpsPaths(SQUARE_EPS));
    expect(bounds).toEqual({ minX: 0, minY: 0, maxX: 10, maxY: 10, width: 10, height: 10 });
  });

  it('returns null for no paths', () => {
    expect(calculatePathsBounds([])).toBeNull();
  });

  it('bezier CONTROL POINTS inflate the bounds (pinned behavior)', () => {
    // Control points at y=10 while the curve itself only reaches y=7.5 —
    // bounds still report maxY=10 because control points are included.
    const eps = '%%EndPageSetup\n0 0 moveto\n0 10 10 10 10 0 curveto\nstroke\n';
    const bounds = calculatePathsBounds(parseEpsPaths(eps));
    expect(bounds).toEqual({ minX: 0, minY: 0, maxX: 10, maxY: 10, width: 10, height: 10 });
  });
});

// ── filterBoundingBoxPaths ──────────────────────────────────────────────────

describe('filterBoundingBoxPaths', () => {
  it('drops the closed rectangle matching the overall bounds, keeps inner shapes', () => {
    const paths = parseEpsPaths(BBOX_RECT_EPS);
    expect(paths).toHaveLength(2);
    const bounds = calculatePathsBounds(paths)!;
    expect(bounds.width).toBe(20);
    const kept = filterBoundingBoxPaths(paths, bounds);
    expect(kept).toHaveLength(1);
    expect(kept[0].startPoint).toEqual({ x: 5, y: 5 });
  });

  it('keeps a lone shape whose own bounds ARE the overall bounds only if not a closed line-rect', () => {
    // The CCW circle spans the full bounds but is all-bezier → kept.
    const paths = parseEpsPaths(CCW_CIRCLE_EPS);
    const bounds = calculatePathsBounds(paths)!;
    expect(filterBoundingBoxPaths(paths, bounds)).toHaveLength(1);
  });

  it('drops a closed all-lines path spanning the full bounds even with >5 segments', () => {
    // Hexagon-ish closed outline touching all four bound extremes.
    const eps = [
      '%%EndPageSetup',
      'newpath',
      '0 0 moveto', '10 0 lineto', '20 5 lineto', '20 20 lineto',
      '10 20 lineto', '0 15 lineto', '0 0 lineto',
      'closepath', 'stroke',
      'newpath',
      '5 5 moveto', '8 5 lineto', '8 8 lineto', '5 8 lineto',
      'closepath', 'stroke',
    ].join('\n');
    const paths = parseEpsPaths(eps);
    const bounds = calculatePathsBounds(paths)!;
    const kept = filterBoundingBoxPaths(paths, bounds);
    expect(kept).toHaveLength(1);
    expect(kept[0].startPoint).toEqual({ x: 5, y: 5 });
  });
});

// ── epsPathsToDxfEntities ───────────────────────────────────────────────────

describe('epsPathsToDxfEntities', () => {
  it('closed line square → one closed LWPOLYLINE, 4 vertices, no bulges (byte-exact)', () => {
    const dxf = epsPathsToDxfEntities(parseEpsPaths(SQUARE_EPS), 'LOGO', 1, 0, 0);
    expect(dxf).toBe(
      '0\nLWPOLYLINE\n8\nLOGO\n70\n1\n90\n4\n' +
      '10\n0.0000\n20\n0.0000\n' +
      '10\n10.0000\n20\n0.0000\n' +
      '10\n10.0000\n20\n10.0000\n' +
      '10\n0.0000\n20\n10.0000\n',
    );
  });

  it('BULGE SIGN: closed CCW circle → four POSITIVE bulges of tan(90°/4)', () => {
    // The 2026-04 rotation-bug class: a sign flip here mirrors every arc.
    const dxf = epsPathsToDxfEntities(parseEpsPaths(CCW_CIRCLE_EPS), 'LOGO', 1, 0, 0);
    expect(dxf).toBe(
      '0\nLWPOLYLINE\n8\nLOGO\n70\n1\n90\n4\n' +
      '10\n3.0000\n20\n2.0000\n42\n0.414214\n' +
      '10\n2.0000\n20\n3.0000\n42\n0.414214\n' +
      '10\n1.0000\n20\n2.0000\n42\n0.414214\n' +
      '10\n2.0000\n20\n1.0000\n42\n0.414214\n',
    );
    // Redundant explicit guard so a formatting-only change can't silently
    // flip the sign inside an otherwise-updated snapshot/string.
    const bulges = [...dxf.matchAll(/42\n(-?[\d.]+)/g)].map(m => parseFloat(m[1]));
    expect(bulges).toHaveLength(4);
    for (const b of bulges) expect(b).toBeGreaterThan(0);
  });

  it('BULGE SIGN: closed CW circle → four NEGATIVE bulges', () => {
    const dxf = epsPathsToDxfEntities(parseEpsPaths(CW_CIRCLE_EPS), 'LOGO', 1, 0, 0);
    expect(dxf).toBe(
      '0\nLWPOLYLINE\n8\nLOGO\n70\n1\n90\n4\n' +
      '10\n3.0000\n20\n2.0000\n42\n-0.414214\n' +
      '10\n2.0000\n20\n1.0000\n42\n-0.414214\n' +
      '10\n1.0000\n20\n2.0000\n42\n-0.414214\n' +
      '10\n2.0000\n20\n3.0000\n42\n-0.414214\n',
    );
    const bulges = [...dxf.matchAll(/42\n(-?[\d.]+)/g)].map(m => parseFloat(m[1]));
    expect(bulges).toHaveLength(4);
    for (const b of bulges) expect(b).toBeLessThan(0);
  });

  it('closed circle drops the duplicate closing vertex (5 pushed → 90=4)', () => {
    const dxf = epsPathsToDxfEntities(parseEpsPaths(CCW_CIRCLE_EPS), 'LOGO', 1, 0, 0);
    expect(dxf).toContain('70\n1\n90\n4\n'); // closed flag, 4 vertices
  });

  it('open path keeps flags=0 and all vertices', () => {
    const eps = '%%EndPageSetup\n0 0 moveto\n10 0 lineto\n10 10 lineto\nstroke\n';
    const dxf = epsPathsToDxfEntities(parseEpsPaths(eps), 'L1', 1, 0, 0);
    expect(dxf).toContain('70\n0\n90\n3\n'); // open, 3 vertices
    expect(dxf).toMatchSnapshot();
  });

  it('applies scale and offset to every vertex', () => {
    const dxf = epsPathsToDxfEntities(parseEpsPaths(SQUARE_EPS), 'LOGO', 2, 5, -1);
    expect(dxf).toMatchSnapshot();
    expect(dxf).toContain('10\n5.0000\n20\n-1.0000\n');   // (0,0) → (5,−1)
    expect(dxf).toContain('10\n25.0000\n20\n19.0000\n');  // (10,10) → (25,19)
  });

  it('emits nothing for empty paths or single-vertex paths', () => {
    expect(epsPathsToDxfEntities([], 'L', 1, 0, 0)).toBe('');
    expect(epsPathsToDxfEntities(
      [{ segments: [], isClosed: false, startPoint: null, endPoint: null }],
      'L', 1, 0, 0,
    )).toBe('');
  });
});
