import { describe, expect, it } from 'vitest';
import {
  accBarcodeValue,
  accFilename,
  compactAccBaseName,
  naturalAccBaseName,
} from '../src/acc-naming';

describe('compact ACC machine-program naming', () => {
  it('produces the approved readable code for the reported MDF design', () => {
    expect(naturalAccBaseName('BHSF-SUN-XV4-S15-HD-MDF')).toBe('SUNXV4S15HM');
    expect(compactAccBaseName('BHSF-SUN-XV4-S15-HD-MDF')).toBe('SUNXV4S15HM');
    expect(accBarcodeValue('BHSF-SUN-XV4-S15-HD-MDF', 1)).toBe('SUNXV4S15HM1');
    expect(accFilename('BHSF-SUN-XV4-S15-HD-MDF', 1)).toBe('SUNXV4S15HM1.acc');
  });

  it('preserves the full configuration even when its size also appears in the model', () => {
    expect(naturalAccBaseName('BHSF-DB-3012R-D12-HD-MDF')).toBe('DB3012RD12HM');
    expect(compactAccBaseName('BHSF-DB-3012R-D12-HD-MDF')).toBe('DB3012RD12HM');
    expect(accBarcodeValue('BHSF-DB-3012R-D12-HD-MDF', 1)).toBe('DB3012RD12HM1');
    expect(accFilename('BHSF-DB-3012R-D12-HD-MDF', 1)).toBe('DB3012RD12HM1.acc');
    expect(accBarcodeValue('BHSF-DB-3512R-S12-HD', 5)).toBe('DB3512RS12H5');
  });

  it('collapses sales tier and Flat Pack variants of one physical design', () => {
    const variants = [
      'BHSP-SUN-XV4-S15-HD-MDF',
      'BHSF-SUN-XV4-S15-HD-MDF',
      'BHSS-SUN-XV4-S15-HD-MDF-FP.json',
    ];
    expect(new Set(variants.map(compactAccBaseName))).toEqual(new Set(['SUNXV4S15HM']));
  });

  it('does not add a legacy marker and collapses equivalent prefixed/unprefixed designs', () => {
    expect(compactAccBaseName('SUN-XV4-S15-HD-MDF')).toBe(
      compactAccBaseName('BHSF-SUN-XV4-S15-HD-MDF'),
    );
    expect(naturalAccBaseName('SUN-XV4-S15-HD-MDF')).toBe('SUNXV4S15HM');
    expect(compactAccBaseName('SUN-XV4-S15-HD-MDF-FP')).toBe(
      compactAccBaseName('SUN-XV4-S15-HD-MDF'),
    );
    expect(naturalAccBaseName('SUN-XV4-S15-HD-MDF-FP')).toBe('SUNXV4S15HM');
  });

  it('retains every token that can distinguish ACC geometry', () => {
    const names = [
      'SUN-XV4-S15-SD',
      'SUN-XV4-S15-RD',
      'SUN-XV4-S15-HD',
      'SUN-XV4-S15-HD-MDF',
      'SUN-XV4-S15-SUPB-HD',
      'SUN-XV4-S15-2P-HD',
      'SUN-XV4-S15-FM-HD',
      'SUN-XV4-S15-HD-KP',
      'SUN-XV4-S15-HD-C3',
    ];
    expect(new Set(names.map(compactAccBaseName)).size).toBe(names.length);
  });

  it('canonicalizes feature-token order', () => {
    expect(compactAccBaseName('SUN-XV4-S15-HD-MDF-SUPB-2P-FM')).toBe(
      compactAccBaseName('SUN-XV4-S15-FM-2P-SUPB-MDF-HD'),
    );
  });

  it('keeps normal long names fully readable', () => {
    expect(naturalAccBaseName('SUN-SAV3-D12-SUPB-SD')).toBe('SUNSAV3D12US');
    expect(compactAccBaseName('SUN-SAV3-D12-SUPB-SD')).toBe('SUNSAV3D12US');
    expect(accBarcodeValue('SUN-SAV3-D12-SUPB-SD', 8)).toBe('SUNSAV3D12US8');
  });

  it('does not truncate long identities and supports fixed and extended part numbers', () => {
    const long = 'BHSP-VERYLONGBRAND-VERYLONGMODEL-D123-SUPB-2P-FM-HD-MDF-C99';
    expect(compactAccBaseName(long)).toBe('VERYLONGBRANDVERYLONGMODELD123C99UPFHM');
    for (let part = 1; part <= 8; part++) {
      const value = accBarcodeValue(long, part);
      expect(value).toBe(`VERYLONGBRANDVERYLONGMODELD123C99UPFHM${part}`);
      expect(value.endsWith(String(part))).toBe(true);
      expect(accFilename(long, part)).toBe(`${value}.acc`);
    }
    expect(accBarcodeValue(long, 12)).toBe('VERYLONGBRANDVERYLONGMODELD123C99UPFHM12');
    expect(accFilename(long, 12)).toBe('VERYLONGBRANDVERYLONGMODELD123C99UPFHM12.acc');
  });

  it('rejects non-positive and non-integer ACC part numbers', () => {
    expect(() => accBarcodeValue('SUN-XV4-S15-HD', 0)).toThrow(/positive integer/);
    expect(() => accBarcodeValue('SUN-XV4-S15-HD', -1)).toThrow(/positive integer/);
    expect(() => accBarcodeValue('SUN-XV4-S15-HD', 1.5)).toThrow(/positive integer/);
  });
});
