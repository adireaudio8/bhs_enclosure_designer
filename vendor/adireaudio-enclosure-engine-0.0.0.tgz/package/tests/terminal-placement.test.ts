/**
 * CHARACTERIZATION tests for src/terminal-placement.ts — pins CURRENT
 * behavior (no-go bands, placement gates, snap-to-safe). Expected values
 * were observed by running the code against the shared CANONICAL_S12
 * fixture; do not "fix" a value without a deliberate behavior change.
 */
import { describe, it, expect } from 'vitest';
import { makeInputs } from './fixtures';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import {
  TERMINAL_WIDTH,
  TERMINAL_HEIGHT,
  TERMINAL_BOTTOM_OFFSET,
  TERMINAL_HALF_WIDTH,
  BINDING_POST_DEPTH,
  SAFETY_BORDER,
  defaultTerminalPanel,
  resolveTerminalPanel,
  hasTerminalCup,
  defaultTerminalXOffset,
  resolveTerminalXOffset,
  isTerminalRotated,
  computeNoGoBands,
  computeNoGoBandsFlat,
  panelWidthInches,
  resolveTerminalCenterX,
  checkTerminalPlacement,
  checkTerminalPlacementFlat,
  findNearestSafeXOffset,
  type BandContext,
} from '../src/terminal-placement';

// ── Shared real-engine fixtures (canonical S12) ────────────────────────────
const single = makeInputs(); // SBPB · single port · Birch SD
const calcSingle = calculateEnclosure(single);
const cutSingle = generateCutList(single, calcSingle);

const dual = makeInputs({ portQuantity: 'Dual' });
const calcDual = calculateEnclosure(dual);
const cutDual = generateCutList(dual, calcDual);

const supp = makeInputs({ enclosureConfiguration: 'Subs Up/Port Up' });

describe('geometry constants', () => {
  it('pins the cutout footprint and safety constants', () => {
    expect(TERMINAL_WIDTH).toBe(4.5);
    expect(TERMINAL_HEIGHT).toBe(2.75);
    expect(TERMINAL_BOTTOM_OFFSET).toBe(2.125);
    expect(TERMINAL_HALF_WIDTH).toBe(2.25);
    expect(BINDING_POST_DEPTH).toBe(2.0);
    expect(SAFETY_BORDER).toBe(0.5);
  });
});

describe('resolveTerminalPanel / defaultTerminalPanel / hasTerminalCup', () => {
  it('defaults: single port → Side Left, dual port → Back', () => {
    expect(defaultTerminalPanel(single)).toBe('Side Left');
    expect(defaultTerminalPanel(dual)).toBe('Back');
    expect(resolveTerminalPanel(single)).toBe('Side Left');
    expect(resolveTerminalPanel(dual)).toBe('Back');
  });

  it('explicit terminalPanel override wins, including None', () => {
    expect(resolveTerminalPanel(makeInputs({ terminalPanel: 'Back' }))).toBe('Back');
    expect(resolveTerminalPanel(makeInputs({ portQuantity: 'Dual', terminalPanel: 'Side Left' }))).toBe('Side Left');
    expect(resolveTerminalPanel(makeInputs({ terminalPanel: 'None' }))).toBe('None');
  });

  it('hasTerminalCup is false only for the explicit None opt-out', () => {
    expect(hasTerminalCup(single)).toBe(true);
    expect(hasTerminalCup(makeInputs({ terminalPanel: 'None' }))).toBe(false);
  });
});

describe('resolveTerminalXOffset / defaultTerminalXOffset', () => {
  it('SUPP on Side Left gets the port-clearance default (not centered)', () => {
    // panelWidth/2 − portWidth − pp2T − 2.25 − cupHalfHeight
    // = 9 − 1.75 − 0.709 − 2.25 − 1.375
    expect(defaultTerminalXOffset(supp, 'Side Left', 18)).toBe(2.9160000000000004);
    expect(resolveTerminalXOffset(supp, 'Side Left', 18)).toBe(2.9160000000000004);
  });

  it('every other config/panel defaults to 0 (centered)', () => {
    expect(defaultTerminalXOffset(single, 'Side Left', 18)).toBe(0);
    expect(defaultTerminalXOffset(supp, 'Back', 18)).toBe(0);
  });

  it('an explicit 0 offset overrides the SUPP default (?? semantics, not ||)', () => {
    const zeroed = makeInputs({ enclosureConfiguration: 'Subs Up/Port Up', terminalXOffset: 0 });
    expect(resolveTerminalXOffset(zeroed, 'Side Left', 18)).toBe(0);
  });

  it('an explicit non-zero offset passes through untouched', () => {
    expect(resolveTerminalXOffset(makeInputs({ terminalXOffset: 1.25 }), 'Side Left', 18)).toBe(1.25);
  });
});

describe('isTerminalRotated', () => {
  it('rotates only for SUPP on Side Left', () => {
    expect(isTerminalRotated(supp, 'Side Left')).toBe(true);
    expect(isTerminalRotated(supp, 'Back')).toBe(false);
    expect(isTerminalRotated(single, 'Side Left')).toBe(false);
  });
});

describe('panelWidthInches / resolveTerminalCenterX', () => {
  it('Side Left width = boxDepth; Back width = boxWidth − 2×wall', () => {
    expect(panelWidthInches('Side Left', single, calcSingle)).toBe(18);
    expect(panelWidthInches('Back', single, calcSingle)).toBe(19.156754214901326);
    expect(panelWidthInches('Back', dual, calcDual)).toBe(33.055041791510945);
  });

  it('center X = panelWidth/2 + offset', () => {
    expect(resolveTerminalCenterX(makeInputs({ terminalXOffset: 1.5 }), calcSingle, 'Side Left')).toBe(10.5);
    expect(resolveTerminalCenterX(single, calcSingle, 'Side Left')).toBe(9);
  });
});

// ── No-go bands: exact flat-context cases (deterministic dyadic numbers) ───
describe('computeNoGoBandsFlat', () => {
  const ctxSingle: BandContext = {
    isDualPort: false, portWidth: 2, pp1Depth: 10, pp2Width: 4,
    boxWidth: 21.5, boxDepth: 20, baffleThickness: 0.75, panelThicknessIn: 0.75,
  };
  const ctxDual: BandContext = {
    isDualPort: true, portWidth: 2, pp1Depth: 10, pp2Width: 4,
    boxWidth: 30, boxDepth: 20, baffleThickness: 0.75, panelThicknessIn: 0.75,
  };

  it('single port Back: one PP2 band flush against the interior right edge', () => {
    // baffleW = 21.5 − 2×0.75 = 20 → band [20−4, 20]
    expect(computeNoGoBandsFlat('Back', ctxSingle)).toEqual([
      { xMin: 16, xMax: 20, reason: 'PP2', label: 'Port Piece 2' },
    ]);
  });

  it('single port Back with pp2Width 0: no bands', () => {
    expect(computeNoGoBandsFlat('Back', { ...ctxSingle, pp2Width: 0 })).toEqual([]);
  });

  it('single port Side Left: never any bands (PP1 lives on the right wall)', () => {
    expect(computeNoGoBandsFlat('Side Left', ctxSingle)).toEqual([]);
  });

  it('dual port Back: symmetric left + right PP2 bands', () => {
    expect(computeNoGoBandsFlat('Back', ctxDual)).toEqual([
      { xMin: 2.75, xMax: 6.75, reason: 'PP2', label: 'Port Piece 2 (left chamber)' },
      { xMin: 23.25, xMax: 27.25, reason: 'PP2', label: 'Port Piece 2 (right chamber)' },
    ]);
  });

  it('dual port Side Left: PP1 band appears when port gap < post depth + safety (2.5")', () => {
    const bands = computeNoGoBandsFlat('Side Left', ctxDual); // gap = 2.0 < 2.5
    expect(bands).toHaveLength(1);
    expect(bands[0].xMin).toBe(0.25); // baffleT − SAFETY
    expect(bands[0].xMax).toBe(11.25); // baffleT + pp1Depth + SAFETY
    expect(bands[0].reason).toBe('PP1');

    expect(computeNoGoBandsFlat('Side Left', { ...ctxDual, portWidth: 2.49 })).toHaveLength(1);
  });

  it('dual port Side Left: gap exactly 2.5" produces NO band (strict <)', () => {
    expect(computeNoGoBandsFlat('Side Left', { ...ctxDual, portWidth: 2.5 })).toEqual([]);
  });
});

// ── checkTerminalPlacementFlat: pass/fail at the safety-border boundaries ──
describe('checkTerminalPlacementFlat boundaries', () => {
  const ctx: BandContext = {
    isDualPort: false, portWidth: 2, pp1Depth: 10, pp2Width: 4,
    boxWidth: 21.5, boxDepth: 20, baffleThickness: 0.75, panelThicknessIn: 0.75,
  }; // Back band = [16, 20] on a 20" panel

  it('centered cup is safe; footprint = center ± (2.25 + 0.5)', () => {
    const res = checkTerminalPlacementFlat({ panel: 'Back', panelWidth: 20, xOffset: 0, ctx });
    expect(res.safe).toBe(true);
    expect(res.footprint).toEqual({ xMin: 7.25, xMax: 12.75 });
  });

  it('footprint TOUCHING the band edge is still safe (strict interval overlap)', () => {
    const res = checkTerminalPlacementFlat({ panel: 'Back', panelWidth: 20, xOffset: 3.25, ctx });
    expect(res.safe).toBe(true);
    expect(res.footprint).toEqual({ xMin: 10.5, xMax: 16 }); // xMax == band.xMin
  });

  it('one 1/8" step further overlaps the PP2 band → unsafe with that band as conflict', () => {
    const res = checkTerminalPlacementFlat({ panel: 'Back', panelWidth: 20, xOffset: 3.375, ctx });
    expect(res.safe).toBe(false);
    expect(res.footprint).toEqual({ xMin: 10.625, xMax: 16.125 });
    expect(res.conflict).toEqual({ xMin: 16, xMax: 20, reason: 'PP2', label: 'Port Piece 2' });
  });

  it('footprint flush with the panel edge is safe (xMax == panelWidth allowed)', () => {
    const res = checkTerminalPlacementFlat({ panel: 'Side Left', panelWidth: 20, xOffset: 7.25, ctx });
    expect(res.safe).toBe(true);
    expect(res.footprint).toEqual({ xMin: 14.5, xMax: 20 });
  });

  it('past the right panel edge → unsafe, edge conflict spans [0, xMax] with reason PP2', () => {
    const res = checkTerminalPlacementFlat({ panel: 'Side Left', panelWidth: 20, xOffset: 7.375, ctx });
    expect(res.safe).toBe(false);
    expect(res.footprint).toEqual({ xMin: 14.625, xMax: 20.125 });
    // NB: edge overruns are reported with reason 'PP2' (pinned quirk) and a
    // synthetic band stretched to cover [min(xMin,0), max(xMax,panelWidth)].
    expect(res.conflict).toEqual({
      xMin: 0,
      xMax: 20.125,
      reason: 'PP2',
      label: 'Cutout extends past the panel edge (panel width 20.00″)',
    });
  });

  it('past the left panel edge → unsafe', () => {
    const res = checkTerminalPlacementFlat({ panel: 'Side Left', panelWidth: 20, xOffset: -7.375, ctx });
    expect(res.safe).toBe(false);
    expect(res.footprint).toEqual({ xMin: -0.125, xMax: 5.375 });
    expect(res.conflict?.xMin).toBe(-0.125);
    expect(res.conflict?.xMax).toBe(20);
  });
});

// ── High-level API against the real engine (canonical S12) ─────────────────
describe('computeNoGoBands + checkTerminalPlacement (real calc/cutList)', () => {
  it('single port: Back panel PP2 band (snapshot), Side Left clean', () => {
    expect(computeNoGoBands('Back', single, calcSingle, cutSingle)).toMatchSnapshot();
    expect(computeNoGoBands('Side Left', single, calcSingle, cutSingle)).toEqual([]);
  });

  it('single port default placement (Side Left, centered) is safe', () => {
    const res = checkTerminalPlacement(single, calcSingle, cutSingle);
    expect(res.safe).toBe(true);
    expect(res.footprint).toEqual({ xMin: 6.25, xMax: 11.75 });
  });

  it('single port centered on Back is UNSAFE — PP2 band reaches past panel center', () => {
    const res = checkTerminalPlacement(single, calcSingle, cutSingle, 'Back');
    expect(res.safe).toBe(false);
    expect(res.conflict?.reason).toBe('PP2');
    expect(res.conflict?.xMin).toBe(8.089813010632014);
    expect(res.footprint.xMax).toBe(12.328377107450663);
  });

  it('dual port: Back + Side Left bands (snapshot) — bands can extend past the physical panel', () => {
    // Pinned quirk: the canonical dual-port design's PP2 (folded port,
    // portLength2 ≈ 46.2") produces Back bands spanning [2.459, 46.92] and
    // [−12.44, 32.01] on a 33.06"-wide panel — the union covers the whole
    // panel, so no Back placement can pass (see the null-snap test below).
    expect(computeNoGoBands('Back', dual, calcDual, cutDual)).toMatchSnapshot();
    expect(computeNoGoBands('Side Left', dual, calcDual, cutDual)).toMatchSnapshot();
  });

  it('dual port default placement (Back, centered) is unsafe for the canonical box', () => {
    const res = checkTerminalPlacement(dual, calcDual, cutDual);
    expect(res.safe).toBe(false);
    expect(res.conflict?.label).toBe('Port Piece 2 (left chamber)');
  });
});

describe('findNearestSafeXOffset — snap round-trips', () => {
  it('already-safe offset passes through unchanged', () => {
    expect(findNearestSafeXOffset(single, calcSingle, cutSingle, 'Side Left', 1.5)).toBe(1.5);
  });

  it('offset inside the Back PP2 band snaps left in 1/8" steps to a safe X, and re-checks safe', () => {
    const band = computeNoGoBands('Back', single, calcSingle, cutSingle)[0];
    const pw = panelWidthInches('Back', single, calcSingle);
    const badOffset = (band.xMin + band.xMax) / 2 - pw / 2; // center of the band
    expect(badOffset).toBe(4.044906505316007);
    expect(checkTerminalPlacement(single, calcSingle, cutSingle, 'Back', badOffset).safe).toBe(false);

    const snapped = findNearestSafeXOffset(single, calcSingle, cutSingle, 'Back', badOffset);
    expect(snapped).toBe(-4.330093494683993);
    expect(checkTerminalPlacement(single, calcSingle, cutSingle, 'Back', snapped!).safe).toBe(true);
  });

  it('returns null when no safe X exists (canonical dual-port Back panel)', () => {
    expect(findNearestSafeXOffset(dual, calcDual, cutDual, 'Back', 0)).toBeNull();
  });
});
