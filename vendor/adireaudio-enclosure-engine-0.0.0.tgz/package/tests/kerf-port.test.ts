/**
 * CHARACTERIZATION tests for src/kerf-port.ts — these pin CURRENT behavior
 * (regression armor for real CNC cuts), they are not a correctness review.
 * Every expected number below was observed by running the code against the
 * shared CANONICAL_S12 fixture; do not "fix" a value without a deliberate,
 * reviewed behavior change.
 */
import { describe, it, expect } from 'vitest';
import { makeInputs, DEFAULT_MATERIAL_CONFIG } from './fixtures';
import {
  kerfPortGate,
  kerfDuty,
  resolveKerfThicknessIn,
  resolveKerfPattern,
  resolveKerfGeometry,
  kerfGrooveLayerName,
  checkKerfSubClearance,
  KERF_SPEC_18,
  KERF_SPEC_24,
  KERF_CENTERLINE_RADIUS_IN,
  KERF_STUB_IN,
  KERF_MIN_FLAT_PORT1_IN,
  KERF_SUB_SAFETY_IN,
  type KerfGeometry,
} from '../src/kerf-port';

const CONFIG = DEFAULT_MATERIAL_CONFIG;

// Canonical kerf-eligible inputs per duty (SBPB · single port · Birch · not flush).
const sdInputs = makeInputs({ kerfPortEnabled: true }); // Birch Ply - Standard Duty
const rdInputs = makeInputs({ kerfPortEnabled: true, enclosureType: 'Birch Ply - Regular Duty' });
const hdInputs = makeInputs({ kerfPortEnabled: true, enclosureType: 'Birch Ply - Heavy Duty' });

describe('locked manufacturing constants', () => {
  it('pins the bench-locked kerf constants', () => {
    expect(KERF_CENTERLINE_RADIUS_IN).toBe(2.0);
    expect(KERF_STUB_IN).toBe(3.0);
    expect(KERF_MIN_FLAT_PORT1_IN).toBe(1.5);
    expect(KERF_SUB_SAFETY_IN).toBe(0.25);
    expect(KERF_SPEC_18).toEqual({ grooveCount: 13, spacingMm: 7.0, depthMm: 16.25 });
    expect(KERF_SPEC_24).toEqual({ grooveCount: 14, spacingMm: 8.0, depthMm: 22.0 });
  });
});

describe('kerfPortGate — the full AND (enabled, SBPB, single port, Birch, !flush)', () => {
  it('passes for the canonical kerf-eligible design', () => {
    expect(kerfPortGate(sdInputs)).toBe(true);
  });

  it('duty does not gate — RD and HD Birch also pass', () => {
    expect(kerfPortGate(rdInputs)).toBe(true);
    expect(kerfPortGate(hdInputs)).toBe(true);
  });

  it('fails when kerfPortEnabled is unset', () => {
    expect(kerfPortGate(makeInputs())).toBe(false);
  });

  it('fails for non-SBPB configurations (SUPB and SUPU)', () => {
    expect(kerfPortGate(makeInputs({ kerfPortEnabled: true, enclosureConfiguration: 'Subs Up/Port Back' }))).toBe(false);
    expect(kerfPortGate(makeInputs({ kerfPortEnabled: true, enclosureConfiguration: 'Subs Up/Port Up' }))).toBe(false);
  });

  it('fails for dual port', () => {
    expect(kerfPortGate(makeInputs({ kerfPortEnabled: true, portQuantity: 'Dual' }))).toBe(false);
  });

  it('fails for MDF', () => {
    expect(kerfPortGate(makeInputs({ kerfPortEnabled: true, enclosureType: 'MDF - Standard Duty' }))).toBe(false);
  });

  it('fails for flush (recessed) mounting', () => {
    expect(kerfPortGate(makeInputs({ kerfPortEnabled: true, recessedMounting: true }))).toBe(false);
  });
});

describe('kerfDuty / resolveKerfThicknessIn', () => {
  it('parses the duty tier out of the enclosureType string', () => {
    expect(kerfDuty('Birch Ply - Standard Duty')).toBe('SD');
    expect(kerfDuty('Birch Ply - Regular Duty')).toBe('RD');
    expect(kerfDuty('Birch Ply - Heavy Duty')).toBe('HD');
    expect(kerfDuty('MDF - Heavy Duty')).toBe('HD');
    expect(kerfDuty(undefined)).toBe('RD'); // fallthrough default
  });

  it('bent thickness: SD→B1, RD→B2, HD→B2', () => {
    expect(resolveKerfThicknessIn(sdInputs, CONFIG)).toBe(0.709);
    expect(resolveKerfThicknessIn(rdInputs, CONFIG)).toBe(0.945);
    expect(resolveKerfThicknessIn(hdInputs, CONFIG)).toBe(0.945);
  });
});

describe('resolveKerfPattern — THE radius→count anchor', () => {
  it('default 2.0" radius reproduces the locked counts exactly: 13 (18mm) / 14 (24mm)', () => {
    const p18 = resolveKerfPattern(0.709, 2.0);
    expect(p18.grooveCount).toBe(13);
    expect(p18.spacingMm).toBe(7.0);
    expect(p18.depthMm).toBe(16.25);
    expect(p18.bendZoneWidthIn).toBe(3.582677165354331); // 13 × 7mm / 25.4

    const p24 = resolveKerfPattern(0.945, 2.0);
    expect(p24.grooveCount).toBe(14);
    expect(p24.spacingMm).toBe(8.0);
    expect(p24.depthMm).toBe(22.0);
    expect(p24.bendZoneWidthIn).toBe(4.409448818897638); // 14 × 8mm / 25.4
  });

  it('larger radius → MORE cuts, smaller radius → fewer (linear slope)', () => {
    expect(resolveKerfPattern(0.709, 3.0).grooveCount).toBe(20);
    expect(resolveKerfPattern(0.709, 1.0).grooveCount).toBe(7);
    expect(resolveKerfPattern(0.945, 3.0).grooveCount).toBe(21);
    expect(resolveKerfPattern(0.945, 1.0).grooveCount).toBe(7);
    expect(resolveKerfPattern(0.709, 2.5).grooveCount).toBe(16);
  });

  it('groove count clamps at a floor of 2 for a degenerate tiny radius', () => {
    expect(resolveKerfPattern(0.709, 0.1).grooveCount).toBe(2);
  });

  it('spacing + depth stay LOCKED per thickness regardless of radius', () => {
    for (const r of [0.1, 1.0, 2.0, 2.5, 3.0, 5.0]) {
      const p18 = resolveKerfPattern(0.709, r);
      expect(p18.spacingMm).toBe(KERF_SPEC_18.spacingMm);
      expect(p18.depthMm).toBe(KERF_SPEC_18.depthMm);
      const p24 = resolveKerfPattern(0.945, r);
      expect(p24.spacingMm).toBe(KERF_SPEC_24.spacingMm);
      expect(p24.depthMm).toBe(KERF_SPEC_24.depthMm);
    }
  });

  it('bendZoneWidthIn is always grooveCount × spacing converted to inches', () => {
    const p = resolveKerfPattern(0.709, 2.5); // 16 grooves
    expect(p.bendZoneWidthIn).toBe((16 * 7.0) / 25.4);
    expect(p.bendZoneWidthIn).toBe(4.409448818897638);
  });

  it('the 18/24 spec split lands on bent thickness ≥ 21mm', () => {
    // B1 (0.709" = 18.0086mm) → 18mm spec; B2 (0.945" = 24.003mm) → 24mm spec
    expect(resolveKerfPattern(CONFIG.B1, 2.0).depthMm).toBe(16.25);
    expect(resolveKerfPattern(CONFIG.B2, 2.0).depthMm).toBe(22.0);
  });
});

describe('resolveKerfGeometry — SD/HD continuous vs RD hybrid', () => {
  // Realistic hand-picked cut-list widths, held constant across duties so the
  // developed-length deltas below isolate the duty logic.
  const widths = { baffleWidthIn: 14.5, port1WidthIn: 16.0 };

  it('SD: one continuous 18mm piece (full snapshot)', () => {
    const geo = resolveKerfGeometry({ inputs: sdInputs, config: CONFIG, ...widths });
    expect(geo.duty).toBe('SD');
    expect(geo.isHybrid).toBe(false);
    expect(geo.bentThicknessIn).toBe(0.709);
    expect(geo.insideRadiusIn).toBe(1.6455); // 2.0 − 0.709/2
    expect(geo.baffleRunIn).toBe(12.8545); // 14.5 − insideRadius
    expect(geo.bentDevelopedLengthIn).toBe(30.79167716535433);
    expect(geo.flatPort1WidthIn).toBeUndefined();
    expect(geo.flatPort1ThicknessIn).toBeUndefined();
    expect(geo.grooveXsIn).toHaveLength(13);
    expect(geo).toMatchSnapshot();
  });

  it('HD: one continuous 24mm piece (full snapshot)', () => {
    const geo = resolveKerfGeometry({ inputs: hdInputs, config: CONFIG, ...widths });
    expect(geo.duty).toBe('HD');
    expect(geo.isHybrid).toBe(false);
    expect(geo.bentThicknessIn).toBe(0.945);
    expect(geo.insideRadiusIn).toBe(1.5275); // 2.0 − 0.945/2
    expect(geo.bentDevelopedLengthIn).toBe(31.854448818897637);
    expect(geo.grooveXsIn).toHaveLength(14);
    expect(geo).toMatchSnapshot();
  });

  it('RD: hybrid — bent 24mm piece with 3" stub + flat 18mm Port 1 (full snapshot)', () => {
    const geo = resolveKerfGeometry({ inputs: rdInputs, config: CONFIG, ...widths });
    expect(geo.duty).toBe('RD');
    expect(geo.isHybrid).toBe(true);
    expect(geo.bentThicknessIn).toBe(0.945);
    // bent piece stops at the stub: baffleRun + bendZone + 3"
    expect(geo.bentDevelopedLengthIn).toBe(20.381948818897637);
    // flat remainder = port1Width − insideRadius − stub = 16 − 1.5275 − 3
    expect(geo.flatPort1WidthIn).toBe(11.4725);
    expect(geo.flatPort1ThicknessIn).toBe(0.709); // B1
    expect(geo).toMatchSnapshot();
  });

  it('RD sliver fallback: leftover < 1.5" → bend the whole 24mm piece, no flat part', () => {
    const geo = resolveKerfGeometry({
      inputs: rdInputs, config: CONFIG, baffleWidthIn: 14.5, port1WidthIn: 5.5,
    });
    // remainder = 5.5 − 1.5275 − 3 = 0.9725 < 1.5 → NOT hybrid
    expect(geo.isHybrid).toBe(false);
    expect(geo.flatPort1WidthIn).toBeUndefined();
    expect(geo.flatPort1ThicknessIn).toBeUndefined();
    // continuous formula: baffleRun + bendZone + (port1Width − insideRadius)
    expect(geo.bentDevelopedLengthIn).toBe(21.354448818897637);
  });

  it('RD sliver boundary: remainder exactly 1.5" stays hybrid (>= comparison)', () => {
    // port1Width = insideRadius + stub + 1.5 = 1.5275 + 3 + 1.5
    const geo = resolveKerfGeometry({
      inputs: rdInputs, config: CONFIG, baffleWidthIn: 14.5, port1WidthIn: 6.0275,
    });
    expect(geo.isHybrid).toBe(true);
    expect(geo.flatPort1WidthIn).toBe(1.5);
  });

  it('kerfPortRadius override changes inside radius, groove count and developed length', () => {
    const geo = resolveKerfGeometry({
      inputs: makeInputs({ kerfPortEnabled: true, kerfPortRadius: 3.0 }),
      config: CONFIG, ...widths,
    });
    expect(geo.insideRadiusIn).toBe(2.6455);
    expect(geo.pattern.grooveCount).toBe(20);
    expect(geo.baffleRunIn).toBe(11.8545);
    expect(geo.bentDevelopedLengthIn).toBe(30.720811023622048);
  });

  it('too-small radius override clamps inside radius at 0 (no degenerate arc)', () => {
    const geo = resolveKerfGeometry({
      inputs: makeInputs({ kerfPortEnabled: true, kerfPortRadius: 0.1 }),
      config: CONFIG, ...widths,
    });
    expect(geo.insideRadiusIn).toBe(0);
    expect(geo.baffleRunIn).toBe(14.5); // full baffle width — nothing consumed by the arc
    expect(geo.pattern.grooveCount).toBe(2);
    expect(geo.bentDevelopedLengthIn).toBe(31.051181102362207);
  });

  it('groove centerlines: locked spacing, centered in the bend zone', () => {
    const geo = resolveKerfGeometry({ inputs: sdInputs, config: CONFIG, ...widths });
    expect(geo.grooveXsIn[0]).toBe(12.99229527559055);
    expect(geo.grooveXsIn[12]).toBe(16.29938188976378);
    // symmetric about the bend-zone center
    const center = geo.bendZoneStartIn + geo.bendZoneWidthIn / 2;
    expect((geo.grooveXsIn[0] + geo.grooveXsIn[12]) / 2).toBeCloseTo(center, 12);
    // consecutive spacing = 7mm in inches
    expect(geo.grooveXsIn[1] - geo.grooveXsIn[0]).toBeCloseTo(7 / 25.4, 12);
  });
});

describe('kerfGrooveLayerName — KERF_GROOVE_{depth}MM_DEEP', () => {
  it('names the two locked production depths', () => {
    expect(kerfGrooveLayerName(16.25)).toBe('KERF_GROOVE_16_25MM_DEEP');
    expect(kerfGrooveLayerName(22)).toBe('KERF_GROOVE_22MM_DEEP');
  });

  it('strips trailing zeros from fractional depths', () => {
    expect(kerfGrooveLayerName(16.5)).toBe('KERF_GROOVE_16_5MM_DEEP');
    expect(kerfGrooveLayerName(0.5)).toBe('KERF_GROOVE_0_5MM_DEEP');
  });

  it('QUIRK (pinned): a non-integer depth that rounds to an integer keeps a trailing underscore', () => {
    // 16.999 → toFixed(2) = "17.00" → strip zeros → "17." → "17_".
    // Unreachable with the locked specs (16.25 / 22.0) but pinned so a
    // future depth override can't silently change the layer-name contract.
    expect(kerfGrooveLayerName(16.999)).toBe('KERF_GROOVE_17_MM_DEEP');
  });
});

describe('checkKerfSubClearance', () => {
  // NB: per CALCULATION_AUDIT §9 this helper is currently UNWIRED (the live
  // guard is the kerf-aware calculateBaffleCheck) — pinned anyway since it is
  // exported engine surface.
  const geoSd = resolveKerfGeometry({
    inputs: sdInputs, config: CONFIG, baffleWidthIn: 14.5, port1WidthIn: 16.0,
  }); // baffleRunIn = 12.8545

  it('canonical 12.81" OD sub does NOT clear a 12.85" baffle run (safety margins)', () => {
    const res = checkKerfSubClearance(geoSd, 12.81, 1);
    expect(res.fits).toBe(false);
    expect(res.clearanceIn).toBe(-0.4555000000000007);
    expect(res.message).toBe(
      'Sub(s) need 13.31" across the baffle but only 12.85" is clear of the kerf bend (short 0.46"). Increase box width, reduce sub count, or disable kerf port.',
    );
  });

  it('two subs are far short', () => {
    const res = checkKerfSubClearance(geoSd, 12.81, 2);
    expect(res.fits).toBe(false);
    expect(res.clearanceIn).toBe(-13.515500000000001);
  });

  it('a 10" OD sub fits with clearance and an empty message', () => {
    const res = checkKerfSubClearance(geoSd, 10, 1);
    expect(res.fits).toBe(true);
    expect(res.clearanceIn).toBeCloseTo(2.3545, 10); // 12.8545 − (10 + 2×0.25)
    expect(res.message).toBe('');
  });

  it('needed formula: subCount×OD + (subCount+1)×0.25 (via a hand-built geometry)', () => {
    const geo = { baffleRunIn: 10.5 } as KerfGeometry;
    // needed = 10 + 2×0.25 = 10.5 → clearance 0 → fits (>= −1e-6)
    const res = checkKerfSubClearance(geo, 10, 1);
    expect(res.fits).toBe(true);
    expect(res.clearanceIn).toBe(0);
  });
});
