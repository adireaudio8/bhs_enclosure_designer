/**
 * CHARACTERIZATION tests for src/design-name-utils.ts.
 *
 * Pins the BHSP-/BHSS-/BHSF- prefix rules, the retired PE- alias system
 * (getDesignNameAliases must return []), and the exact SKU-match candidate
 * sets (order included) used to match ShipStation SKUs to design names.
 * All expected values were observed by running the code.
 */
import { describe, it, expect } from 'vitest';
import {
  normalizeDesignName,
  getDesignNameAliases,
  hasValidPrefix,
  getPrefixFromValue,
  stripPrefix,
  getSkuMatchCandidates,
} from '../src/design-name-utils';

describe('normalizeDesignName', () => {
  it('strips each valid brand prefix', () => {
    expect(normalizeDesignName('BHSP-B2-RXL-S12-HD')).toBe('B2-RXL-S12-HD');
    expect(normalizeDesignName('BHSS-B2-RXL-S12-HD')).toBe('B2-RXL-S12-HD');
    expect(normalizeDesignName('BHSF-B2-RXL-S12-HD')).toBe('B2-RXL-S12-HD');
  });

  it('strips .json (any case) before the prefix', () => {
    expect(normalizeDesignName('BHSP-Test.json')).toBe('Test');
    expect(normalizeDesignName('BHSP-Test.JSON')).toBe('Test');
    expect(normalizeDesignName('Test.json')).toBe('Test');
  });

  it('prefix detection is case-insensitive but the remainder keeps its case', () => {
    expect(normalizeDesignName('bhsp-MixedCase')).toBe('MixedCase');
    expect(normalizeDesignName('BhSf-abc')).toBe('abc');
  });

  it('strips only ONE prefix (first match wins, then break)', () => {
    expect(normalizeDesignName('BHSP-BHSS-X')).toBe('BHSS-X');
  });

  it('leaves names without a known prefix untouched', () => {
    expect(normalizeDesignName('B2-RXL-S12-HD')).toBe('B2-RXL-S12-HD');
    expect(normalizeDesignName('PE-OldStyle')).toBe('PE-OldStyle');
    expect(normalizeDesignName('')).toBe('');
  });

  it('a bare prefix normalizes to the empty string', () => {
    expect(normalizeDesignName('BHSP-')).toBe('');
  });

  it('does not strip a prefix that is not at the start', () => {
    expect(normalizeDesignName('X-BHSP-Y')).toBe('X-BHSP-Y');
  });
});

describe('getDesignNameAliases — retired PE- alias system', () => {
  it('ALWAYS returns [] (the PE- alias system is retired — pinned)', () => {
    expect(getDesignNameAliases('B2-RXL-S12-HD')).toEqual([]);
    expect(getDesignNameAliases('PE-Something')).toEqual([]);
    expect(getDesignNameAliases('')).toEqual([]);
  });
});

describe('hasValidPrefix', () => {
  it('accepts BHSP-/BHSS-/BHSF- in any case', () => {
    expect(hasValidPrefix('BHSP-X')).toBe(true);
    expect(hasValidPrefix('BHSS-X')).toBe(true);
    expect(hasValidPrefix('BHSF-X')).toBe(true);
    expect(hasValidPrefix('bhsp-x')).toBe(true);
    expect(hasValidPrefix('BhSf-x')).toBe(true);
  });

  it('requires the trailing dash and start-of-string position', () => {
    expect(hasValidPrefix('BHSP')).toBe(false);
    expect(hasValidPrefix('BHSPX')).toBe(false);
    expect(hasValidPrefix('XBHSP-')).toBe(false);
    expect(hasValidPrefix('')).toBe(false);
    expect(hasValidPrefix('PE-X')).toBe(false);
  });

  it('a bare prefix with dash counts as valid', () => {
    expect(hasValidPrefix('BHSP-')).toBe(true);
  });
});

describe('getPrefixFromValue', () => {
  it('returns the dash-less prefix code, uppercased regardless of input case', () => {
    expect(getPrefixFromValue('BHSP-Foo')).toBe('BHSP');
    expect(getPrefixFromValue('BHSS-Foo')).toBe('BHSS');
    expect(getPrefixFromValue('BHSF-Foo')).toBe('BHSF');
    expect(getPrefixFromValue('bhsf-foo')).toBe('BHSF');
  });

  it('returns null when no valid prefix is present', () => {
    expect(getPrefixFromValue('B2-RXL-S12-HD')).toBeNull();
    expect(getPrefixFromValue('BHSP')).toBeNull();
    expect(getPrefixFromValue('')).toBeNull();
  });
});

describe('stripPrefix', () => {
  it('strips the prefix but — unlike normalizeDesignName — keeps .json', () => {
    expect(stripPrefix('BHSP-Foo.json')).toBe('Foo.json');
    expect(stripPrefix('bhss-Bar')).toBe('Bar');
  });

  it('returns the value unchanged when no prefix matches', () => {
    expect(stripPrefix('Foo.json')).toBe('Foo.json');
    expect(stripPrefix('')).toBe('');
  });
});

describe('getSkuMatchCandidates', () => {
  it('returns [] for undefined / empty names', () => {
    expect(getSkuMatchCandidates(undefined)).toEqual([]);
    expect(getSkuMatchCandidates('')).toEqual([]);
  });

  it('prefixed name → as-is, normalized, and every prefix re-applied (exact order)', () => {
    expect(getSkuMatchCandidates('BHSP-B2-RXL-S12-HD')).toEqual([
      'BHSP-B2-RXL-S12-HD',
      'B2-RXL-S12-HD',
      'BHSS-B2-RXL-S12-HD',
      'BHSF-B2-RXL-S12-HD',
    ]);
  });

  it('bare (unprefixed) name → itself plus all three prefixed variants', () => {
    expect(getSkuMatchCandidates('B2-RXL-S12-HD')).toEqual([
      'B2-RXL-S12-HD',
      'BHSP-B2-RXL-S12-HD',
      'BHSS-B2-RXL-S12-HD',
      'BHSF-B2-RXL-S12-HD',
    ]);
  });

  it('lowercase .json filename → uppercased with-extension, bare, normalized, prefixed', () => {
    expect(getSkuMatchCandidates('bhsp-foo.json')).toEqual([
      'BHSP-FOO.JSON',
      'BHSP-FOO',
      'FOO',
      'BHSS-FOO',
      'BHSF-FOO',
    ]);
  });

  it('whitespace-only name yields bare-prefix candidates (pinned quirk)', () => {
    // The whitespace entries trim to '' and are skipped, but prefix+norm
    // ('BHSP-  ' etc.) trims to a bare prefix and IS emitted.
    expect(getSkuMatchCandidates('  ')).toEqual(['BHSP-', 'BHSS-', 'BHSF-']);
  });
});
