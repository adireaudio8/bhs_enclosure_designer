import { beforeEach, describe, expect, it } from 'vitest';
import { useEnclosureStore } from '../src/enclosure-store';
import { DEFAULT_MATERIAL_CONFIG } from '../src/types/enclosure';
import { makeInputs } from './fixtures';

describe('flush mount material changes', () => {
  beforeEach(() => {
    useEnclosureStore.setState({
      inputs: makeInputs(),
      materialConfig: DEFAULT_MATERIAL_CONFIG,
      brandCode: 'XXX',
    });
    useEnclosureStore.getState().recalculate();
  });

  it('keeps Flush Mount selected and swaps to the MDF construction', () => {
    useEnclosureStore.getState().loadInputs(makeInputs({
      enclosureType: 'Birch Ply - Regular Duty',
      recessedMounting: true,
    }));

    useEnclosureStore.getState().setEnclosureType('MDF - Regular Duty');

    const state = useEnclosureStore.getState();
    expect(state.inputs.recessedMounting).toBe(true);
    expect(state.modelNumber).toContain('-FM-RD-MDF');
    expect(state.cutList.find((part) => part.partName === 'Baffle')?.material).toBe('3/4" MDF');
    expect(state.cutList.find((part) => part.partName === 'Sub Mount Plate')?.material).toBe('1" MDF');
  });

  it('preserves SUPB port area while switching Birch to MDF and back', () => {
    useEnclosureStore.getState().loadInputs(makeInputs({
      enclosureType: 'Birch Ply - Regular Duty',
      enclosureConfiguration: 'Subs Up/Port Back',
      recessedMounting: true,
      portWidth: 2,
    }));

    const birch = useEnclosureStore.getState();
    const originalArea = birch.inputs.portWidth * birch.calculations.internalHeight;

    birch.setEnclosureType('MDF - Regular Duty');
    const mdf = useEnclosureStore.getState();
    expect(mdf.inputs.recessedMounting).toBe(true);
    expect(Math.abs(mdf.inputs.portWidth * mdf.calculations.internalHeight - originalArea)).toBeLessThan(0.1);

    mdf.setEnclosureType('Birch Ply - Regular Duty');
    const birchAgain = useEnclosureStore.getState();
    expect(birchAgain.inputs.recessedMounting).toBe(true);
    expect(Math.abs(birchAgain.inputs.portWidth * birchAgain.calculations.internalHeight - originalArea)).toBeLessThan(0.1);
  });
});
