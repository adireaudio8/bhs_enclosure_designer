// ─────────────────────────────────────────────────────────────────────────────
// CHARACTERIZATION tests for src/calculations.ts (with src/types/enclosure.ts).
//
// These tests PIN CURRENT BEHAVIOR (desktop-parity contract) — they are
// regression armor, not correctness reviews. Every explicit expected value
// below was produced by RUNNING the engine against the shared CANONICAL_S12
// fixture and hard-coding the observed output (2026-07-03). Do not "fix" a
// value here without deliberately deciding to change the engine's behavior —
// these numbers drive real CNC cuts and dealer prices.
//
// Reference: codebase-analysis-docs/TESTING_REVIEW.md §4 Tier 1,
//            codebase-analysis-docs/CALCULATION_AUDIT.md.
// ─────────────────────────────────────────────────────────────────────────────
import { describe, it, expect } from 'vitest';
import {
  calculateEnclosure,
  generateCutList,
  generateModelNumber,
  calculateBaffleCheck,
  calculateShippingInfo,
  getPartMaterial,
  getSubwooferCount,
  getGussetCount,
  roundUpToEighth,
} from '../src/calculations';
import type { MaterialConfig } from '../src/types/enclosure';
import { SUBWOOFER_SIZES } from '../src/types/enclosure';
import {
  CANONICAL_S12,
  makeInputs,
  DUTY_TYPES,
  CONFIGURATIONS,
  SUB_QUANTITIES,
  DEFAULT_MATERIAL_CONFIG,
} from './fixtures';

const BIRCH_RD = 'Birch Ply - Regular Duty' as const;

// Part names used by getAllPartMaterials / the cut list.
const PART_NAMES = [
  'Top', 'Bottom', 'Back', 'Baffle', 'Side Left', 'Side Right',
  'Port Piece 1', 'Port Piece 2', 'Gusset 1', 'Gusset 2', 'Gusset 3',
];

// ═════════════════════════════════════════════════════════════════════════════
// calculateEnclosure() — canonical matrix snapshots
// ═════════════════════════════════════════════════════════════════════════════

describe('calculateEnclosure — canonical matrix (snapshots)', () => {
  for (const duty of DUTY_TYPES) {
    it(`CANONICAL_S12 duty=${duty}`, () => {
      expect(calculateEnclosure(makeInputs({ enclosureType: duty }))).toMatchSnapshot();
    });
  }

  for (const configuration of CONFIGURATIONS) {
    it(`Birch-RD configuration=${configuration}`, () => {
      expect(
        calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD, enclosureConfiguration: configuration })),
      ).toMatchSnapshot();
    });
  }

  for (const qty of SUB_QUANTITIES) {
    it(`Birch-RD subwooferQuantity=${qty}`, () => {
      expect(
        calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD, subwooferQuantity: qty })),
      ).toMatchSnapshot();
    });
  }

  it('Birch-RD dual port', () => {
    expect(
      calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD, portQuantity: 'Dual' })),
    ).toMatchSnapshot();
  });

  it('Subs Up/Port Up is engine-identical to Subs Back/Port Back (Birch-RD)', () => {
    // types/enclosure.ts documents SUPU as a pure viewer rotation of SBPB —
    // every engine value must match the SBPB result exactly.
    const sbpb = calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD, enclosureConfiguration: 'Subs Back/Port Back' }));
    const supu = calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD, enclosureConfiguration: 'Subs Up/Port Up' }));
    expect(supu).toEqual(sbpb);
  });
});

describe('calculateEnclosure — audited scalars (CANONICAL_S12, Birch-RD, SBPB, single/single)', () => {
  const calc = calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD }));

  it('volume chain', () => {
    expect(calc.totalNeeded).toBe(2.15); // netAirSpace 2.0 + subDisplacement 0.15 + 0 gussets
    expect(calc.subCutoutAdd).toBe(0.05378214568551081); // π·(11.19/2)²·B2 / 1728
    expect(calc.gussetDisplacement).toBe(0);
    expect(calc.adjustedNeeded).toBe(2.096217854314489);
    expect(calc.netAirSpaceForPortCalculations).toBe(2);
    expect(calc.netAirSpacePerChamber).toBe(2);
  });

  it('internal dimensions (RD-SBPB: top+bottom = 1.5", baffle+back = B1+B2)', () => {
    expect(calc.internalHeight).toBe(14.5);            // 16 − 1.5
    expect(calc.internalDepthWithDB).toBe(16.346);     // 18 − (0.709 + 0.945)
    expect(calc.mountingDepthAvail).toBe(14.596);      // 18 − (1.75 + 0.709 + 0.945)
  });

  it('port chain', () => {
    expect(calc.portHeight).toBe(14.5);
    expect(calc.portArea).toBe(25.375);                // 1.75 × 14.5
    expect(calc.portLength1).toBe(16.416);             // 18 − (0.709 + 0.875)
    expect(calc.portLengthNoEC).toBe(29.232941204269313);
    expect(calc.portLength2).toBe(12.816941204269312); // NoEC − portLength1
    expect(calc.sqInPerCube).toBe(12.6875);            // 25.375 / 2.0
  });

  it('chamber solve + box width', () => {
    expect(calc.s1RightWidth).toBe(10.357941204269313);
    expect(calc.s1RightHeight).toBe(14.5);
    expect(calc.s1RightDepth).toBe(13.887);
    expect(calc.s1RightArea).toBe(1.2069968621547889);
    expect(calc.s1RightStillNeeded).toBe(0.8892209921597003);
    expect(calc.s2LeftWidth).toBe(6.482969046321412);
    expect(calc.s2LeftDepth).toBe(16.346);
    expect(calc.s2LeftArea).toBe(0.8892209921597003); // = s1RightStillNeeded by construction
    expect(calc.s2LeftStillNeeded).toBe(1536.5738744519622);
    expect(calc.boxWidth).toBe(20.717910250590723);   // s1 + s2 + portWidth + 3·B1 (raw, unrounded)
    expect(calc.internalWidth).toBe(19.299910250590724);
  });

  it('embedded baffle check (Y-direction limits the canonical S12)', () => {
    expect(calc.baffleCheck.mountLabel).toBe('Baffle');
    expect(calc.baffleCheck.netWidth).toBe(16.873);
    expect(calc.baffleCheck.edgeClearance).toBe(0.8449999999999998); // (14.5 − 12.81)/2
    expect(calc.baffleCheck.subToSubGap).toBe(2.0315000000000003);   // X-direction
    expect(calc.baffleCheck.status).toBe('OK');
  });

  it('duty-dependent internalHeight rules', () => {
    expect(calculateEnclosure(makeInputs()).internalHeight).toBe(14.5);            // SD: −1.5
    expect(calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD, enclosureConfiguration: 'Subs Up/Port Back' })).internalHeight).toBe(14.25); // RD-SUPB: −1.75 (thick Top)
    expect(calculateEnclosure(makeInputs({ enclosureType: 'Birch Ply - Heavy Duty' })).internalHeight).toBe(14); // HD: −2.0
    expect(calculateEnclosure(makeInputs({ enclosureType: 'MDF - Regular Duty' })).internalDepthWithDB).toBe(16.25); // 18 − (D1+D2)
  });

  it('dual port halves per-chamber air space and cutout add', () => {
    const dual = calculateEnclosure(makeInputs({ enclosureType: BIRCH_RD, portQuantity: 'Dual' }));
    expect(dual.netAirSpaceForPortCalculations).toBe(1);
    expect(dual.netAirSpacePerChamber).toBe(1);
    expect(dual.subCutoutAdd).toBe(calc.subCutoutAdd / 2);
  });
});

// ═════════════════════════════════════════════════════════════════════════════
// generateCutList()
// ═════════════════════════════════════════════════════════════════════════════

describe('generateCutList — canonical snapshots', () => {
  const snapshotCases: Array<[string, Parameters<typeof makeInputs>[0]]> = [
    ['Birch-SD SBPB single/single', {}],
    ['Birch-RD SBPB single/single', { enclosureType: BIRCH_RD }],
    ['Birch-HD SBPB single/single', { enclosureType: 'Birch Ply - Heavy Duty' }],
    ['MDF-RD SBPB single/single', { enclosureType: 'MDF - Regular Duty' }],
    ['Birch-RD SUPB single/single', { enclosureType: BIRCH_RD, enclosureConfiguration: 'Subs Up/Port Back' }],
    ['Birch-RD SBPB dual subs (gusset)', { enclosureType: BIRCH_RD, subwooferQuantity: 'Dual' }],
  ];
  for (const [name, overrides] of snapshotCases) {
    it(name, () => {
      const inputs = makeInputs(overrides);
      const calc = calculateEnclosure(inputs);
      expect(generateCutList(inputs, calc)).toMatchSnapshot();
    });
  }
});

describe('generateCutList — explicit part dimensions (CANONICAL_S12 Birch-RD)', () => {
  const inputs = makeInputs({ enclosureType: BIRCH_RD });
  const cut = generateCutList(inputs, calculateEnclosure(inputs));
  const row = (partName: string) => cut.find((r) => r.partName === partName)!;

  it('emits exactly the 8 single-sub/single-port parts in order', () => {
    expect(cut.map((r) => r.partName)).toEqual([
      'Top', 'Bottom', 'Back', 'Baffle', 'Side Left', 'Side Right', 'Port Piece 1', 'Port Piece 2',
    ]);
  });

  it('Top/Bottom use roundUpToEighth(boxWidth) × boxDepth', () => {
    expect(row('Top').width).toBe(20.75); // roundUpToEighth(20.717910250590723)
    expect(row('Top').height).toBe(18);
    expect(row('Bottom').width).toBe(20.75);
    expect(row('Bottom').height).toBe(18);
  });

  it('Back is roundedBoxWidth × internalHeight', () => {
    expect(row('Back').width).toBe(20.75);
    expect(row('Back').height).toBe(14.5);
  });

  it('Baffle width = roundedBoxWidth − (portWidth + B1)', () => {
    expect(row('Baffle').width).toBe(18.291); // 20.75 − (1.75 + 0.709)
    expect(row('Baffle').height).toBe(14.5);
  });

  it('Side Left uses front C2 + back C1 edge mills + 2× glue tolerance', () => {
    expect(row('Side Left').width).toBe(16.4); // 18 − (0.91 + 0.67 + 0.02)
  });

  it('Side Right uses one C1 edge mill + glue tolerance', () => {
    expect(row('Side Right').width).toBe(17.32); // 18 − (0.67 + 0.01)
  });

  it('Port Piece 1 subtracts port width + both mills + PP2 thickness + 2× glue', () => {
    expect(row('Port Piece 1').width).toBe(13.941); // 18 − (1.75 + 0.91 + 0.67 + 0.709 + 0.02)
    expect(row('Port Piece 1').height).toBe(14.5);
  });

  it('Port Piece 2 = portLength2 − portWidth', () => {
    expect(row('Port Piece 2').width).toBe(11.066941204269312);
  });
});

describe('RD thick-panel rule — getPartMaterial + cut-list rows', () => {
  it('RD SBPB: Baffle is the thick panel (24mm/B2), Top is thin', () => {
    const baffle = getPartMaterial('Baffle', BIRCH_RD);
    expect(baffle).toEqual({
      materialType: 'Birch Ply',
      materialDescription: '24mm Birch Ply',
      thicknessInches: 0.945,
      thicknessCode: 'B2',
    });
    const top = getPartMaterial('Top', BIRCH_RD);
    expect(top.materialDescription).toBe('18mm Birch Ply');
    expect(top.thicknessInches).toBe(0.709);
    expect(top.thicknessCode).toBe('B1');
  });

  it('RD SUPB: Top is the thick panel, Baffle is thin', () => {
    const top = getPartMaterial('Top', BIRCH_RD, DEFAULT_MATERIAL_CONFIG, 'Subs Up/Port Back');
    expect(top.materialDescription).toBe('24mm Birch Ply');
    expect(top.thicknessCode).toBe('B2');
    const baffle = getPartMaterial('Baffle', BIRCH_RD, DEFAULT_MATERIAL_CONFIG, 'Subs Up/Port Back');
    expect(baffle.materialDescription).toBe('18mm Birch Ply');
    expect(baffle.thicknessCode).toBe('B1');
  });

  it('MDF RD mirrors the rule with D1/D2 (1" thick panel)', () => {
    expect(getPartMaterial('Baffle', 'MDF - Regular Duty').materialDescription).toBe('1" MDF');
    expect(getPartMaterial('Baffle', 'MDF - Regular Duty').thicknessCode).toBe('D2');
    expect(getPartMaterial('Top', 'MDF - Regular Duty').materialDescription).toBe('3/4" MDF');
    expect(getPartMaterial('Top', 'MDF - Regular Duty', DEFAULT_MATERIAL_CONFIG, 'Subs Up/Port Back').materialDescription).toBe('1" MDF');
    expect(getPartMaterial('Baffle', 'MDF - Regular Duty', DEFAULT_MATERIAL_CONFIG, 'Subs Up/Port Back').materialDescription).toBe('3/4" MDF');
  });

  it('SD: every part is thin (18mm B1 / 3/4" D1) in both configurations', () => {
    for (const part of PART_NAMES) {
      for (const configuration of ['Subs Back/Port Back', 'Subs Up/Port Back']) {
        expect(getPartMaterial(part, 'Birch Ply - Standard Duty', DEFAULT_MATERIAL_CONFIG, configuration).thicknessCode).toBe('B1');
        expect(getPartMaterial(part, 'MDF - Standard Duty', DEFAULT_MATERIAL_CONFIG, configuration).thicknessCode).toBe('D1');
      }
    }
  });

  it('HD: every part is thick (24mm B2 / 1" D2) in both configurations', () => {
    for (const part of PART_NAMES) {
      for (const configuration of ['Subs Back/Port Back', 'Subs Up/Port Back']) {
        expect(getPartMaterial(part, 'Birch Ply - Heavy Duty', DEFAULT_MATERIAL_CONFIG, configuration).thicknessCode).toBe('B2');
        expect(getPartMaterial(part, 'MDF - Heavy Duty', DEFAULT_MATERIAL_CONFIG, configuration).thicknessCode).toBe('D2');
      }
    }
  });

  it('cut-list rows agree: RD-SBPB baffle thick, RD-SUPB top thick, SD all thin, HD all thick', () => {
    const cutFor = (overrides: Parameters<typeof makeInputs>[0]) => {
      const inputs = makeInputs(overrides);
      return generateCutList(inputs, calculateEnclosure(inputs));
    };

    const rdSbpb = cutFor({ enclosureType: BIRCH_RD });
    expect(rdSbpb.find((r) => r.partName === 'Baffle')!.material).toBe('24mm Birch Ply');
    expect(rdSbpb.filter((r) => r.partName !== 'Baffle').every((r) => r.material === '18mm Birch Ply')).toBe(true);

    const rdSupb = cutFor({ enclosureType: BIRCH_RD, enclosureConfiguration: 'Subs Up/Port Back' });
    expect(rdSupb.find((r) => r.partName === 'Top')!.material).toBe('24mm Birch Ply');
    expect(rdSupb.find((r) => r.partName === 'Baffle')!.material).toBe('18mm Birch Ply');
    expect(rdSupb.filter((r) => r.partName !== 'Top').every((r) => r.material === '18mm Birch Ply')).toBe(true);

    const sd = cutFor({});
    expect(sd.every((r) => r.material === '18mm Birch Ply' && r.thickness === 0.709)).toBe(true);

    const hd = cutFor({ enclosureType: 'Birch Ply - Heavy Duty' });
    expect(hd.every((r) => r.material === '24mm Birch Ply' && r.thickness === 0.945)).toBe(true);

    const mdfRd = cutFor({ enclosureType: 'MDF - Regular Duty' });
    expect(mdfRd.find((r) => r.partName === 'Baffle')!.material).toBe('1" MDF');
    expect(mdfRd.filter((r) => r.partName !== 'Baffle').every((r) => r.material === '3/4" MDF')).toBe(true);
  });

  it('gusset count = subCount − 1, each 5.0" wide × internalHeight', () => {
    const cutFor = (qty: 'Single' | 'Dual' | 'Triple' | 'Quad') => {
      const inputs = makeInputs({ enclosureType: BIRCH_RD, subwooferQuantity: qty });
      return generateCutList(inputs, calculateEnclosure(inputs));
    };
    expect(cutFor('Single').filter((r) => r.partName.startsWith('Gusset'))).toHaveLength(0);
    const dualGussets = cutFor('Dual').filter((r) => r.partName.startsWith('Gusset'));
    expect(dualGussets).toHaveLength(1);
    expect(dualGussets[0].width).toBe(5);
    expect(dualGussets[0].height).toBe(14.5);
    expect(cutFor('Quad').filter((r) => r.partName.startsWith('Gusset')).map((r) => r.partName))
      .toEqual(['Gusset 1', 'Gusset 2', 'Gusset 3']);
  });
});

// ═════════════════════════════════════════════════════════════════════════════
// generateModelNumber() — every suffix and the ORDER
// {config+model}[-SUPB]{-2P}{-FM}-{duty}{-MDF}{-C#}{-FP}{-KP}
// ═════════════════════════════════════════════════════════════════════════════

describe('generateModelNumber', () => {
  it('exposes the complete supported-size list in numeric order', () => {
    expect(SUBWOOFER_SIZES).toEqual(['6.5"', '8"', '10"', '12"', '13.5"', '15"', '18"', '21"']);
  });

  it('base: default brand XXX, missing model → MOD, quantity+size prefix', () => {
    expect(generateModelNumber(makeInputs())).toBe('XXX-MOD-S12-SD');
  });

  it('duty codes SD/RD/HD', () => {
    expect(generateModelNumber(makeInputs({ enclosureType: BIRCH_RD }))).toBe('XXX-MOD-S12-RD');
    expect(generateModelNumber(makeInputs({ enclosureType: 'Birch Ply - Heavy Duty' }))).toBe('XXX-MOD-S12-HD');
  });

  it('-MDF material suffix comes after the duty', () => {
    expect(generateModelNumber(makeInputs({ enclosureType: 'MDF - Regular Duty' }))).toBe('XXX-MOD-S12-RD-MDF');
  });

  it('-SUPB segment only for Subs Up/Port Back (SUPU gets none)', () => {
    expect(generateModelNumber(makeInputs({ enclosureConfiguration: 'Subs Up/Port Back' }))).toBe('XXX-MOD-S12-SUPB-SD');
    expect(generateModelNumber(makeInputs({ enclosureConfiguration: 'Subs Up/Port Up' }))).toBe('XXX-MOD-S12-SD');
  });

  it('-2P for dual port, before -FM and duty', () => {
    expect(generateModelNumber(makeInputs({ portQuantity: 'Dual' }))).toBe('XXX-MOD-S12-2P-SD');
    expect(generateModelNumber(makeInputs({ portQuantity: 'Dual', recessedMounting: true }))).toBe('XXX-MOD-S12-2P-FM-SD');
  });

  it('-FM (flush mount) is a separate segment BEFORE the duty code', () => {
    expect(generateModelNumber(makeInputs({ recessedMounting: true }))).toBe('XXX-MOD-S12-FM-SD');
  });

  it('-C{n} custom suffix; skipped when customNumber is missing', () => {
    expect(generateModelNumber(makeInputs({ isCustomEnclosure: true, customNumber: 42 }))).toBe('XXX-MOD-S12-SD-C42');
    expect(generateModelNumber(makeInputs({ isCustomEnclosure: true }))).toBe('XXX-MOD-S12-SD');
  });

  it('-FP for Flat Pack assembly', () => {
    expect(generateModelNumber(makeInputs({ assemblyMethod: 'Flat Pack' }))).toBe('XXX-MOD-S12-SD-FP');
  });

  it('-KP for kerf port, ALWAYS last (after -C# and -FP)', () => {
    expect(generateModelNumber(makeInputs({ kerfPortEnabled: true }))).toBe('XXX-MOD-S12-SD-KP');
    expect(generateModelNumber(makeInputs({
      kerfPortEnabled: true,
      isCustomEnclosure: true,
      customNumber: 7,
      assemblyMethod: 'Flat Pack',
    }))).toBe('XXX-MOD-S12-SD-C7-FP-KP');
  });

  it('-KP is gated: suppressed for MDF, dual port, flush mount, and SUPB', () => {
    expect(generateModelNumber(makeInputs({ kerfPortEnabled: true, enclosureType: 'MDF - Standard Duty' }))).toBe('XXX-MOD-S12-SD-MDF');
    expect(generateModelNumber(makeInputs({ kerfPortEnabled: true, portQuantity: 'Dual' }))).toBe('XXX-MOD-S12-2P-SD');
    expect(generateModelNumber(makeInputs({ kerfPortEnabled: true, recessedMounting: true }))).toBe('XXX-MOD-S12-FM-SD');
    expect(generateModelNumber(makeInputs({ kerfPortEnabled: true, enclosureConfiguration: 'Subs Up/Port Back' }))).toBe('XXX-MOD-S12-SUPB-SD');
  });

  it('Performance brand (PE) swaps config and model segments', () => {
    expect(generateModelNumber(makeInputs({ subwooferModel: '2.0V2' }), 'PE')).toBe('PE-S12-2.0V2-SD');
    expect(generateModelNumber(makeInputs({ subwooferModel: '2.0V2', enclosureConfiguration: 'Subs Up/Port Back' }), 'PE')).toBe('PE-S12-2.0V2-SUPB-SD');
    // non-PE brands: {brand}-{model}-{config}
    expect(generateModelNumber(makeInputs({ subwooferModel: '2.0V2' }), 'BHS')).toBe('BHS-2.0V2-S12-SD');
  });

  it('quantity prefix S/D/T/Q and size number', () => {
    expect(generateModelNumber(makeInputs({ subwooferQuantity: 'Dual' }))).toBe('XXX-MOD-D12-SD');
    expect(generateModelNumber(makeInputs({ subwooferQuantity: 'Triple' }))).toBe('XXX-MOD-T12-SD');
    expect(generateModelNumber(makeInputs({ subwooferQuantity: 'Quad' }))).toBe('XXX-MOD-Q12-SD');
    expect(generateModelNumber(makeInputs({ size: '15"' }))).toBe('XXX-MOD-S15-SD');
    expect(generateModelNumber(makeInputs({ size: '6.5"' }))).toBe('XXX-MOD-S6.5-SD');
    expect(generateModelNumber(makeInputs({ size: '6.5"', subwooferQuantity: 'Dual' }))).toBe('XXX-MOD-D6.5-SD');
  });

  it('kitchen sink (non-KP): [-SUPB]{-2P}{-FM}-{duty}{-MDF}{-C#}{-FP}', () => {
    expect(generateModelNumber(makeInputs({
      enclosureConfiguration: 'Subs Up/Port Back',
      portQuantity: 'Dual',
      recessedMounting: true,
      enclosureType: 'MDF - Heavy Duty',
      subwooferQuantity: 'Dual',
      isCustomEnclosure: true,
      customNumber: 3,
      assemblyMethod: 'Flat Pack',
    }))).toBe('XXX-MOD-D12-SUPB-2P-FM-HD-MDF-C3-FP');
  });
});

// ═════════════════════════════════════════════════════════════════════════════
// calculateBaffleCheck()
// ═════════════════════════════════════════════════════════════════════════════

describe('calculateBaffleCheck — status thresholds (direct calls, clean config)', () => {
  // A clean-number MaterialConfig makes the threshold boundaries exact:
  // SBPB single port, boxWidth 16 → netWidth = 16 − (1.75 + B1) − B1 − B1 = 12.75.
  // internalHeight passed as 0 → the Y clearance is skipped (stays null) and
  // the X clearance alone drives the status.
  const clean: MaterialConfig = { B1: 0.5, B2: 1, C1: 0.5, C2: 1, D1: 0.5, D2: 1, E1: 0.5, E2: 1 };

  it('edgeClearance exactly 0.5 → Tight Fit (boundary is inclusive)', () => {
    const r = calculateBaffleCheck(makeInputs({ outsideDiameter: 11.75 }), 0, 16, clean, 0, 0);
    expect(r.netWidth).toBe(12.75);
    expect(r.edgeClearance).toBe(0.5);
    expect(r.status).toBe('Tight Fit');
    expect(r.isWarning).toBe(true);
    expect(r.isFail).toBe(false);
  });

  it('edgeClearance exactly 0.25 → DOES NOT FIT (boundary is inclusive)', () => {
    const r = calculateBaffleCheck(makeInputs({ outsideDiameter: 12.25 }), 0, 16, clean, 0, 0);
    expect(r.edgeClearance).toBe(0.25);
    expect(r.status).toBe('DOES NOT FIT');
    expect(r.isFail).toBe(true);
    expect(r.isWarning).toBe(false);
  });

  it('edgeClearance just above 0.5 → OK', () => {
    const r = calculateBaffleCheck(makeInputs({ outsideDiameter: 11.74 }), 0, 16, clean, 0, 0);
    expect(r.edgeClearance).toBe(0.5049999999999999);
    expect(r.status).toBe('OK');
    expect(r.isFail).toBe(false);
    expect(r.isWarning).toBe(false);
  });

  it('outsideDiameter 0 → check is NOT APPLICABLE: visible=false, non-failing (fixed 2026-07-03)', () => {
    // Previously the thresholds still ran on a zeroed clearance and reported
    // DOES NOT FIT, hard-failing flush-variant cloning for designs that
    // merely lack OD data. Now matches the audit contract: skipped when OD=0.
    const r = calculateBaffleCheck(makeInputs({ outsideDiameter: 0 }), 0, 16, clean, 0, 0);
    expect(r.visible).toBe(false);
    expect(r.edgeClearance).toBe(0);
    expect(r.status).toBe('OK');
    expect(r.isFail).toBe(false);
    expect(r.isWarning).toBe(false);
  });

  it('Y-direction clearance (internalHeight) can drive Tight Fit / DOES NOT FIT', () => {
    // Canonical OD 12.81, wide box (X clearance 6.6565) — Y is the worst direction.
    const tight = calculateBaffleCheck(makeInputs(), 0, 30, DEFAULT_MATERIAL_CONFIG, 0, 13.7);
    expect(tight.netWidth).toBe(26.123);
    expect(tight.edgeClearance).toBe(0.4449999999999994); // (13.7 − 12.81)/2
    expect(tight.subToSubGap).toBe(6.6565);               // X gap unaffected by tight Y
    expect(tight.status).toBe('Tight Fit');

    const fail = calculateBaffleCheck(makeInputs(), 0, 30, DEFAULT_MATERIAL_CONFIG, 0, 13.2);
    expect(fail.edgeClearance).toBe(0.1949999999999994);
    expect(fail.status).toBe('DOES NOT FIT');
  });
});

describe('calculateBaffleCheck — kerf branch (via calculateEnclosure)', () => {
  // CANONICAL_S12 (Birch SD, SBPB, single slot port, not flush) passes the
  // kerf gate when kerfPortEnabled is set; boxWidth math is unchanged, only
  // the usable baffle width shrinks to the flat leg ahead of the bend.
  const nonKerf = calculateEnclosure(CANONICAL_S12);
  const kerf = calculateEnclosure(makeInputs({ kerfPortEnabled: true }));

  it('non-kerf SBPB baseline: label "Baffle"', () => {
    expect(nonKerf.baffleCheck.mountLabel).toBe('Baffle');
    expect(nonKerf.baffleCheck.netWidth).toBe(16.748);
    expect(nonKerf.baffleCheck.subToSubGap).toBe(1.9690000000000003);
    expect(nonKerf.baffleCheck.status).toBe('OK');
  });

  it('kerf: label "Baffle (kerf leg)", netWidth = (baffleWidth − insideRadius) − Side-Left wall', () => {
    // baffleWidth = roundUpToEighth(20.574754…)=20.625 − (1.75 + 0.709) = 18.166
    // insideRadius = 2.0 − 0.709/2 = 1.6455 ; netWidth = 18.166 − 1.6455 − 0.709
    expect(kerf.baffleCheck.mountLabel).toBe('Baffle (kerf leg)');
    expect(kerf.baffleCheck.netWidth).toBe(15.811500000000002);
    expect(kerf.baffleCheck.subToSubGap).toBe(1.500750000000001);
    expect(kerf.baffleCheck.netWidth).toBeLessThan(nonKerf.baffleCheck.netWidth);
    // Y-direction still limits the canonical S12, so status/edge match non-kerf.
    expect(kerf.baffleCheck.edgeClearance).toBe(0.8449999999999998);
    expect(kerf.baffleCheck.status).toBe('OK');
  });

  it('kerf toggle does not change the solved box geometry', () => {
    expect(kerf.boxWidth).toBe(nonKerf.boxWidth);
    expect(kerf.internalHeight).toBe(nonKerf.internalHeight);
    expect(kerf.portLength2).toBe(nonKerf.portLength2);
  });
});

describe('calculateBaffleCheck — flush-mount min-baffle-height gate (SBPB only)', () => {
  it('passes when internalHeight ≥ OD + 1.25', () => {
    // boxHeight 16 → internalHeight 14.5 ≥ 12.81 + 1.25 = 14.06
    const bc = calculateEnclosure(makeInputs({ recessedMounting: true })).baffleCheck;
    expect(bc.status).toBe('OK');
    expect(bc.mountLabel).toBe('Baffle');
    expect(bc.edgeClearance).toBe(0.8449999999999998);
  });

  it('fails with dedicated label when the box is too short — overrides a Tight-Fit clearance', () => {
    // boxHeight 15 → internalHeight 13.5 < 14.06. Raw edge clearance 0.345
    // would be "Tight Fit", but the flush gate forces DOES NOT FIT.
    const bc = calculateEnclosure(makeInputs({ recessedMounting: true, boxHeight: 15 })).baffleCheck;
    expect(bc.mountLabel).toBe('Baffle (flush mount needs taller box)');
    expect(bc.edgeClearance).toBe(0.34499999999999975);
    expect(bc.status).toBe('DOES NOT FIT');
    expect(bc.isFail).toBe(true);
    expect(bc.isWarning).toBe(false);
  });
});

describe('calculateBaffleCheck — SUPB mounting-surface labels', () => {
  it('single port, S2 too narrow for the sub → combined-chamber fallback "Top Panel (S2 + S1)"', () => {
    const bc = calculateEnclosure(makeInputs({ enclosureConfiguration: 'Subs Up/Port Back' })).baffleCheck;
    expect(bc.mountLabel).toBe('Top Panel (S2 + S1)');
    expect(bc.netWidth).toBe(16.697754214901327); // s2LeftWidth + s1RightWidth
    expect(bc.edgeClearance).toBe(1.3655);
    expect(bc.status).toBe('OK');
  });

  it('single port, small sub fits S2 alone → "Top Panel (S2 Left)"', () => {
    const bc = calculateEnclosure(makeInputs({ enclosureConfiguration: 'Subs Up/Port Back', outsideDiameter: 6 })).baffleCheck;
    expect(bc.mountLabel).toBe('Top Panel (S2 Left)');
    expect(bc.netWidth).toBe(6.339813010632013); // s2LeftWidth alone
    expect(bc.edgeClearance).toBe(0.16990650531600648);
    expect(bc.status).toBe('DOES NOT FIT');
  });

  it('dual port always uses S2 alone (chambers separate)', () => {
    const bc = calculateEnclosure(makeInputs({ enclosureConfiguration: 'Subs Up/Port Back', portQuantity: 'Dual' })).baffleCheck;
    expect(bc.mountLabel).toBe('Top Panel (S2 Left)');
    // Canonical S12 as a dual-port SUPB is geometrically impossible — the
    // solved S2 width goes deeply negative and the check reports it.
    expect(bc.netWidth).toBe(-29.68024771275179);
    expect(bc.status).toBe('DOES NOT FIT');
  });
});

// ═════════════════════════════════════════════════════════════════════════════
// calculateShippingInfo()
// ═════════════════════════════════════════════════════════════════════════════

describe('calculateShippingInfo — CANONICAL_S12 (Birch SD)', () => {
  const calc = calculateEnclosure(CANONICAL_S12);
  const cut = generateCutList(CANONICAL_S12, calc);
  const ship = calculateShippingInfo(CANONICAL_S12, calc, cut);

  it('carton auto-dimensions: depth+1.125, height+1.0, roundedBoxWidth+1.1875', () => {
    expect(ship.cartonLength).toBe(19.125);  // 18 + 1.125
    expect(ship.cartonWidth).toBe(17);       // 16 + 1.0
    expect(ship.cartonHeight).toBe(21.8125); // roundUpToEighth(20.574754…)=20.625 + 1.1875
  });

  it('external dims add 14mm walls (L/W) and 28mm flaps (H)', () => {
    expect(ship.externalLength).toBe(19.6762);  // 19.125 + 0.5512
    expect(ship.externalWidth).toBe(17.5512);   // 17 + 0.5512
    expect(ship.externalHeight).toBe(22.9149);  // 21.8125 + 1.1024
  });

  it('weights: enclosure + 3 lbs packaging; DIM = L×W×H ÷ 139; billable = max', () => {
    expect(ship.enclosureWeight).toBe(37.73420113024207);
    expect(ship.shippingWeight).toBe(40.73420113024207); // +3.0 packaging
    expect(ship.dimensionalWeight).toBe(56.931314249679545);
    expect(ship.dimensionalWeight).toBe((ship.externalLength * ship.externalWidth * ship.externalHeight) / 139);
    expect(ship.billableWeight).toBe(56.931314249679545); // DIM-bound for this box
    expect(ship.billableWeight).toBe(Math.max(ship.shippingWeight, ship.dimensionalWeight));
  });

  it('full ShippingInfo snapshot', () => {
    expect(ship).toMatchSnapshot();
  });
});

// ═════════════════════════════════════════════════════════════════════════════
// Small utility helpers (used throughout the cut list / shipping paths)
// ═════════════════════════════════════════════════════════════════════════════

describe('utility helpers', () => {
  it('roundUpToEighth', () => {
    expect(roundUpToEighth(20.717910250590723)).toBe(20.75);
    expect(roundUpToEighth(20.574754214901326)).toBe(20.625);
    expect(roundUpToEighth(16)).toBe(16);       // exact eighth unchanged
    expect(roundUpToEighth(16.001)).toBe(16.125);
  });

  it('getSubwooferCount / getGussetCount (gussets = subs − 1; unknown → Single)', () => {
    expect(getSubwooferCount('Single')).toBe(1);
    expect(getSubwooferCount('Dual')).toBe(2);
    expect(getSubwooferCount('Triple')).toBe(3);
    expect(getSubwooferCount('Quad')).toBe(4);
    expect(getSubwooferCount('???')).toBe(1);
    expect(getGussetCount('Single')).toBe(0);
    expect(getGussetCount('Dual')).toBe(1);
    expect(getGussetCount('Triple')).toBe(2);
    expect(getGussetCount('Quad')).toBe(3);
    expect(getGussetCount('???')).toBe(0);
  });
});
