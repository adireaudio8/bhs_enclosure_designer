/**
 * CHARACTERIZATION tests for MDF Top/Bottom drill-hole + guide-rectangle
 * PLACEMENT in src/dxf-generator.ts.
 *
 * MDF is true-dimension stock with NO mill-down relief, so every edge inset
 * on the Top/Bottom panels is the mating panel's true thickness + Glue
 * Tolerance. At the production default of 0.01" this yields:
 *   3/4" mate → 0.76 edge inset → 2.01 corner-relative (1.25 + 0.76)
 *   1"   mate → 1.01 edge inset → 2.26 corner-relative (1.25 + 1.01)
 *
 * Values match the desktop DrillHoleGenerator/GuideRectangleGenerator MDF
 * branches where they exist (SD/RD right side 2.01, RD single-port left
 * 2.26/2.01, RD-SUPB yOffset 0.76, RD-SBPB/HD yOffset 1.01). Where the
 * desktop omitted the MDF branch (SD yOffset, SD single-port left, HD side
 * holes) the engine completes the matrix from the same first principles —
 * see the block comment above getRightSideInsets in src/dxf-generator.ts.
 */
import { describe, it, expect } from 'vitest';
import { generatePartDxf, type PartDxfOptions } from '../src/dxf-generator';
import { DEFAULT_MATERIAL_CONFIG } from '../src/types/enclosure';

const W = 22.5;   // Bottom/Top panel width
const H = 18.25;  // Bottom/Top panel depth
const BW = 20.663;   // baffle part width
const P1W = 12.56;   // Port Piece 1 cut-list width
const EDGE = 0.375;  // drill-hole edge inset (EDGE_INSET)

function mdfOpts(bs: string, cfg: string, extra: Partial<PartDxfOptions> = {}): PartDxfOptions {
  return {
    buildStrength: bs,
    isBirchPly: false,
    enclosureConfiguration: cfg,
    portQuantity: 'Single',
    portWidth: 3,
    port1PartWidth: P1W,
    port2PartWidth: 10.2,
    materialThickness: 0.75,
    heavyThickness: 1.0,
    baffleWidth: BW,
    sideLeftDepth: 16.8,
    sideRightDepth: 17.5,
    backWidth: 21.1,
    extraHolesBack: 2,
    extraHolesFront: 2,
    extraHolesRight: 1,
    extraHolesLeft: 1,
    extraHolesHeight: 1,
    port2VerticalOffset: 0.25,
    includeGuides: true,
    ...extra,
  };
}

/** All CIRCLE entities on layers starting with the given prefix. */
function circles(dxf: string, layerPrefix: string): Array<{ x: number; y: number }> {
  const re = /0\nCIRCLE\n8\n([^\n]+)\n10\n([-\d.]+)\n20\n([-\d.]+)\n30\n0\.0\n40\n([-\d.]+)/g;
  const out: Array<{ x: number; y: number }> = [];
  for (let m = re.exec(dxf); m; m = re.exec(dxf)) {
    if (m[1].startsWith(layerPrefix)) out.push({ x: parseFloat(m[2]), y: parseFloat(m[3]) });
  }
  return out;
}

/** All closed 4-vertex POLYLINE rects on the given layer, as {x,y,w,h}. */
function rects(dxf: string, layer: string): Array<{ x: number; y: number; w: number; h: number }> {
  const L = layer.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const v = '10\\n([-\\d.]+)\\n20\\n([-\\d.]+)\\n30\\n0\\.0';
  const re = new RegExp(
    `0\\nPOLYLINE\\n8\\n${L}\\n66\\n1\\n70\\n1\\n` +
    `0\\nVERTEX\\n8\\n${L}\\n${v}\\n0\\nVERTEX\\n8\\n${L}\\n${v}\\n` +
    `0\\nVERTEX\\n8\\n${L}\\n${v}\\n0\\nVERTEX\\n8\\n${L}\\n${v}\\n0\\nSEQEND`,
    'g',
  );
  const out: Array<{ x: number; y: number; w: number; h: number }> = [];
  for (let m = re.exec(dxf); m; m = re.exec(dxf)) {
    const x = parseFloat(m[1]), y = parseFloat(m[2]);
    out.push({ x, y, w: parseFloat(m[3]) - x, h: parseFloat(m[6]) - parseFloat(m[4]) });
  }
  return out;
}

/** Drill circles on a vertical hole line at the given x. */
function holeLineYs(dxf: string, atX: number): number[] {
  return circles(dxf, '8MM_DRILL')
    .filter(c => Math.abs(c.x - atX) < 1e-6)
    .map(c => c.y)
    .sort((a, b) => a - b);
}

/** Min/max drill-hole Y on a vertical hole line — the corner insets. */
function holeLineSpan(dxf: string, atX: number): { min: number; max: number } {
  const ys = holeLineYs(dxf, atX);
  expect(ys.length).toBeGreaterThanOrEqual(2);
  return { min: ys[0], max: ys[ys.length - 1] };
}

/** The Side Left guide rect on the Bottom panel (x=0, w=0.375, tall). */
function sideLeftGuideY(dxf: string): number {
  const gs = rects(dxf, 'Guides').filter(r =>
    Math.abs(r.x) < 1e-6 && Math.abs(r.w - 0.375) < 1e-6 && r.h > 5);
  expect(gs.length).toBe(1);
  return gs[0].y;
}

// Expected corner-relative insets per duty (single port).
// left = getLeftSideInsets, right = getRightSideInsets, yOff = getGuideYOffset
// (= getPortBaseOffset). RD splits by config for yOff only.
const EXPECT_MDF = [
  { bs: 'Standard Duty', cfg: 'Subs Back/Port Back', left: [2.01, 2.01], rightTop: 2.01, yOff: 0.76 },
  { bs: 'Standard Duty', cfg: 'Subs Up/Port Back',   left: [2.01, 2.01], rightTop: 2.01, yOff: 0.76 },
  { bs: 'Regular Duty',  cfg: 'Subs Back/Port Back', left: [2.26, 2.01], rightTop: 2.01, yOff: 1.01 },
  { bs: 'Regular Duty',  cfg: 'Subs Up/Port Back',   left: [2.26, 2.01], rightTop: 2.01, yOff: 0.76 },
  { bs: 'Heavy Duty',    cfg: 'Subs Back/Port Back', left: [2.26, 2.26], rightTop: 2.26, yOff: 1.01 },
  { bs: 'Heavy Duty',    cfg: 'Subs Up/Port Back',   left: [2.26, 2.26], rightTop: 2.26, yOff: 1.01 },
] as const;

describe('MDF Bottom panel — drill hole corner insets (single port)', () => {
  for (const e of EXPECT_MDF) {
    it(`${e.bs} / ${e.cfg}: left {${e.left[0]}, ${e.left[1]}}, right {1.25, ${e.rightTop}}`, () => {
      const dxf = generatePartDxf('Bottom', W, H, mdfOpts(e.bs, e.cfg));
      const left = holeLineSpan(dxf, EDGE);
      expect(left.min).toBeCloseTo(e.left[0], 6);          // front-edge inset (baffle mate)
      expect(left.max).toBeCloseTo(H - e.left[1], 6);      // back-edge inset (back mate)
      const right = holeLineSpan(dxf, W - EDGE);
      expect(right.min).toBeCloseTo(1.25, 6);              // plain corner inset
      expect(right.max).toBeCloseTo(H - e.rightTop, 6);    // back-edge inset (back mate)
    });
  }
});

describe('MDF Top panel — X-mirrored drill hole corner insets (single port)', () => {
  for (const e of EXPECT_MDF) {
    it(`${e.bs} / ${e.cfg}: mirrored left/right hole lines carry the same insets`, () => {
      const dxf = generatePartDxf('Top', W, H, mdfOpts(e.bs, e.cfg));
      // Top mirrors X: LEFT-side insets appear at x = W - EDGE, RIGHT-side at x = EDGE.
      const left = holeLineSpan(dxf, W - EDGE);
      expect(left.min).toBeCloseTo(e.left[0], 6);
      expect(left.max).toBeCloseTo(H - e.left[1], 6);
      const right = holeLineSpan(dxf, EDGE);
      expect(right.min).toBeCloseTo(1.25, 6);
      expect(right.max).toBeCloseTo(H - e.rightTop, 6);
    });
  }
});

describe('MDF Bottom panel — guide yOffset and port hole base (single port)', () => {
  for (const e of EXPECT_MDF) {
    it(`${e.bs} / ${e.cfg}: Side Left guide starts at ${e.yOff}, Port 1 hole at p1w/2 + ${e.yOff}`, () => {
      const dxf = generatePartDxf('Bottom', W, H, mdfOpts(e.bs, e.cfg));
      expect(sideLeftGuideY(dxf)).toBeCloseTo(e.yOff, 6);
      // Port 1 hole: x = baffleWidth - 0.375, y = port1PartWidth/2 + portBase
      const portYs = holeLineYs(dxf, BW - EDGE);
      expect(portYs).toContainEqual(expect.closeTo(P1W / 2 + e.yOff, 6));
      // Port 2 hole row: y = port1PartWidth + portBase + port2VerticalOffset + 0.375
      const p2y = P1W + e.yOff + 0.25 + EDGE;
      const p2 = circles(dxf, '8MM_DRILL').filter(c => Math.abs(c.y - p2y) < 1e-6);
      expect(p2.length).toBeGreaterThanOrEqual(1);
    });
  }
});

describe('MDF dual port — left hole line mirrors right side', () => {
  it('Heavy Duty dual: both side hole lines use {1.25, 2.26}', () => {
    const dxf = generatePartDxf('Bottom', W, H, mdfOpts('Heavy Duty', 'Subs Back/Port Back', { portQuantity: 'Dual' }));
    for (const atX of [EDGE, W - EDGE]) {
      const span = holeLineSpan(dxf, atX);
      expect(span.min).toBeCloseTo(1.25, 6);
      expect(span.max).toBeCloseTo(H - 2.26, 6);
    }
  });
  it('Standard Duty dual: both side hole lines use {1.25, 2.01}', () => {
    const dxf = generatePartDxf('Bottom', W, H, mdfOpts('Standard Duty', 'Subs Back/Port Back', { portQuantity: 'Dual' }));
    for (const atX of [EDGE, W - EDGE]) {
      const span = holeLineSpan(dxf, atX);
      expect(span.min).toBeCloseTo(1.25, 6);
      expect(span.max).toBeCloseTo(H - 2.01, 6);
    }
  });
});

describe('MDF flush mount (recessed) — thin-baffle overrides', () => {
  it('HD flush: yOff 0.76, left {2.01, 2.26} (3/4" front baffle, 1" back)', () => {
    const dxf = generatePartDxf('Bottom', W, H, mdfOpts('Heavy Duty', 'Subs Back/Port Back', { recessedMounting: true }));
    expect(sideLeftGuideY(dxf)).toBeCloseTo(0.76, 6);
    const left = holeLineSpan(dxf, EDGE);
    expect(left.min).toBeCloseTo(2.01, 6);
    expect(left.max).toBeCloseTo(H - 2.26, 6);
  });
  it('RD flush: yOff 0.76, left {2.01, 2.01}', () => {
    const dxf = generatePartDxf('Bottom', W, H, mdfOpts('Regular Duty', 'Subs Back/Port Back', { recessedMounting: true }));
    expect(sideLeftGuideY(dxf)).toBeCloseTo(0.76, 6);
    const left = holeLineSpan(dxf, EDGE);
    expect(left.min).toBeCloseTo(2.01, 6);
    expect(left.max).toBeCloseTo(H - 2.01, 6);
  });
});

describe('MDF has no mill-down relief', () => {
  it('MDF Back/Baffle/Port Piece 2 DXFs contain no MILL_DOWN entities', () => {
    for (const [name, w, h] of [['Back', 21.1, 14.5], ['Baffle', 20.663, 14.5], ['Port Piece 2', 10.2, 14.5]] as const) {
      const dxf = generatePartDxf(name, w, h, mdfOpts('Regular Duty', 'Subs Back/Port Back'));
      expect(dxf).not.toContain('MILL_DOWN');
    }
  });
  it('Birch SD keeps the milled-mate insets (0.68-class) — unchanged by the MDF fix', () => {
    const dxf = generatePartDxf('Bottom', W, H, mdfOpts('Standard Duty', 'Subs Back/Port Back', { isBirchPly: true, materialThickness: 0.709, heavyThickness: 0.945 }));
    expect(sideLeftGuideY(dxf)).toBeCloseTo(0.68, 6);
    const left = holeLineSpan(dxf, EDGE);
    expect(left.min).toBeCloseTo(1.93, 6);
    expect(left.max).toBeCloseTo(H - 1.93, 6);
  });
});

describe('configured Glue Tolerance drives MDF placement', () => {
  it('explicit 0.01 is byte-identical to the backwards-compatible default', () => {
    const implicit = generatePartDxf('Bottom', W, H, mdfOpts('Standard Duty', 'Subs Back/Port Back'));
    const explicit = generatePartDxf('Bottom', W, H, mdfOpts('Standard Duty', 'Subs Back/Port Back', {
      glueTolerance: 0.01,
      materialConfig: DEFAULT_MATERIAL_CONFIG,
    }));
    expect(explicit).toBe(implicit);
  });

  it('uses measured D1 plus the configured tolerance for holes, guides, and ports', () => {
    const materialConfig = { ...DEFAULT_MATERIAL_CONFIG, D1: 0.755 };
    const dxf = generatePartDxf('Bottom', W, H, mdfOpts('Standard Duty', 'Subs Back/Port Back', {
      materialConfig,
      glueTolerance: 0.02,
    }));
    const mateOffset = 0.755 + 0.02;
    expect(sideLeftGuideY(dxf)).toBeCloseTo(mateOffset, 6);
    const left = holeLineSpan(dxf, EDGE);
    expect(left.min).toBeCloseTo(1.25 + mateOffset, 6);
    expect(left.max).toBeCloseTo(H - (1.25 + mateOffset), 6);
    const portYs = holeLineYs(dxf, BW - EDGE);
    expect(portYs).toContainEqual(expect.closeTo(P1W / 2 + mateOffset, 6));
  });

  it('rejects negative tolerance instead of emitting unsafe geometry', () => {
    expect(() => generatePartDxf('Bottom', W, H, mdfOpts('Standard Duty', 'Subs Back/Port Back', {
      glueTolerance: -0.01,
    }))).toThrow('Glue tolerance must be a finite, non-negative number');
  });
});

describe('configured Glue Tolerance drives Birch placement', () => {
  it('uses measured milled C1 plus tolerance without changing material topology', () => {
    const materialConfig = { ...DEFAULT_MATERIAL_CONFIG, C1: 0.675 };
    const dxf = generatePartDxf('Bottom', W, H, mdfOpts('Standard Duty', 'Subs Back/Port Back', {
      isBirchPly: true,
      materialThickness: materialConfig.B1,
      heavyThickness: materialConfig.B2,
      materialConfig,
      glueTolerance: 0.02,
    }));
    const mateOffset = 0.675 + 0.02;
    expect(sideLeftGuideY(dxf)).toBeCloseTo(mateOffset, 6);
    const left = holeLineSpan(dxf, EDGE);
    expect(left.min).toBeCloseTo(1.25 + mateOffset, 6);
    expect(left.max).toBeCloseTo(H - (1.25 + mateOffset), 6);
  });
});
