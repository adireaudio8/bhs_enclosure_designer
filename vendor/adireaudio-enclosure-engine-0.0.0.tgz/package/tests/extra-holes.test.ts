/**
 * CHARACTERIZATION tests for src/extra-holes.ts.
 *
 * Pins the desktop-parity edge-screw thresholds (CalculateExtraHolesFromWidth
 * / AutoCalculateHeightExtraHoles) at, just below, and just above every
 * boundary, plus the full auto-calc against the canonical S12 cut list.
 * All expected values were observed by running the code.
 */
import { describe, it, expect } from 'vitest';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import {
  extraHolesFromWidth,
  heightExtraHolesFromMaxPanelHeight,
  autoCalculateExtraHoles,
} from '../src/extra-holes';
import type { CutListItem } from '../src/types/enclosure';
import { CANONICAL_S12 } from './fixtures';

describe('extraHolesFromWidth — desktop thresholds <11 / ≤18.5 / <34 / ≥34', () => {
  it('non-positive and non-finite widths → 0', () => {
    expect(extraHolesFromWidth(0)).toBe(0);
    expect(extraHolesFromWidth(-5)).toBe(0);
    expect(extraHolesFromWidth(NaN)).toBe(0);
    expect(extraHolesFromWidth(Infinity)).toBe(0);
  });

  it('11" boundary: below → 0, at → 1', () => {
    expect(extraHolesFromWidth(10.999)).toBe(0);
    expect(extraHolesFromWidth(11)).toBe(1);
    expect(extraHolesFromWidth(11.001)).toBe(1);
  });

  it('18.5" boundary: at → 1 (inclusive), above → 2', () => {
    expect(extraHolesFromWidth(18.499)).toBe(1);
    expect(extraHolesFromWidth(18.5)).toBe(1);
    expect(extraHolesFromWidth(18.501)).toBe(2);
  });

  it('34" boundary: below → 2, at → 3 (exclusive upper bound on 2)', () => {
    expect(extraHolesFromWidth(33.999)).toBe(2);
    expect(extraHolesFromWidth(34)).toBe(3);
    expect(extraHolesFromWidth(100)).toBe(3);
  });
});

describe('heightExtraHolesFromMaxPanelHeight — desktop thresholds <8 / ≤16 / >16', () => {
  it('non-positive and non-finite heights → 0', () => {
    expect(heightExtraHolesFromMaxPanelHeight(0)).toBe(0);
    expect(heightExtraHolesFromMaxPanelHeight(-1)).toBe(0);
    expect(heightExtraHolesFromMaxPanelHeight(NaN)).toBe(0);
    expect(heightExtraHolesFromMaxPanelHeight(Infinity)).toBe(0);
  });

  it('8" boundary: below → 0, at → 1', () => {
    expect(heightExtraHolesFromMaxPanelHeight(7.999)).toBe(0);
    expect(heightExtraHolesFromMaxPanelHeight(8)).toBe(1);
  });

  it('16" boundary: at → 1 (inclusive), above → 2', () => {
    expect(heightExtraHolesFromMaxPanelHeight(15.999)).toBe(1);
    expect(heightExtraHolesFromMaxPanelHeight(16)).toBe(1);
    expect(heightExtraHolesFromMaxPanelHeight(16.001)).toBe(2);
    expect(heightExtraHolesFromMaxPanelHeight(40)).toBe(2);
  });
});

describe('autoCalculateExtraHoles', () => {
  it('canonical S12 cut list — pinned counts', () => {
    // Canonical dims driving these: Bottom 20.625w × 18h(depth),
    // Baffle 18.166w × 14.5h, Back 14.5h, Port Piece 2 14.5h.
    const calc = calculateEnclosure(CANONICAL_S12);
    const cutList = generateCutList(CANONICAL_S12, calc);
    expect(autoCalculateExtraHoles(cutList)).toEqual({
      bottomExtraHoles: 1,       // Bottom depth 18 → 1
      bottomRightExtraHoles: 1,  // same source as bottomExtraHoles
      bottomBackExtraHoles: 2,   // Bottom width 20.625 → 2
      bottomFrontExtraHoles: 1,  // Baffle width 18.166 → 1
      heightExtraHoles: 1,       // max(Back,Baffle,PP2) height 14.5 → 1
    });
  });

  it('missing parts contribute 0 (empty cut list → all zeros)', () => {
    expect(autoCalculateExtraHoles([])).toEqual({
      bottomExtraHoles: 0,
      bottomRightExtraHoles: 0,
      bottomBackExtraHoles: 0,
      bottomFrontExtraHoles: 0,
      heightExtraHoles: 0,
    });
  });

  it('maps each panel dimension to the documented output field', () => {
    // Synthetic list picked so every field lands in a DIFFERENT bucket.
    const synthetic: CutListItem[] = [
      { partName: 'Bottom', width: 35, height: 12, quantity: 1, material: 'x', thickness: 0.709 },
      { partName: 'Baffle', width: 19, height: 7, quantity: 1, material: 'x', thickness: 0.709 },
      { partName: 'Back', width: 35, height: 17, quantity: 1, material: 'x', thickness: 0.709 },
      { partName: 'Port Piece 2', width: 5, height: 5, quantity: 1, material: 'x', thickness: 0.709 },
    ];
    expect(autoCalculateExtraHoles(synthetic)).toEqual({
      bottomExtraHoles: 1,       // Bottom HEIGHT (depth) 12 → 1
      bottomRightExtraHoles: 1,
      bottomBackExtraHoles: 3,   // Bottom width 35 → 3
      bottomFrontExtraHoles: 2,  // Baffle width 19 → 2
      heightExtraHoles: 2,       // max(17, 7, 5) = 17 → 2
    });
  });
});
