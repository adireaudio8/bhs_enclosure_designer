import { describe, expect, it } from 'vitest';
import { generatePocketLogoToolpath } from '../src/pocket-logo-toolpath';

const LOGO_LAYER = 'ENGRAVE_LOGO_ON_LINE_0625';

interface Vertex {
  x: number;
  y: number;
  bulge?: number;
}

function logoDxf(contours: Vertex[][], closed = true): string {
  const lines = ['0', 'SECTION', '2', 'ENTITIES'];
  for (const vertices of contours) {
    lines.push(
      '0', 'LWPOLYLINE',
      '8', LOGO_LAYER,
      '70', closed ? '1' : '0',
      '90', String(vertices.length),
    );
    for (const vertex of vertices) {
      lines.push('10', String(vertex.x), '20', String(vertex.y));
      if (vertex.bulge !== undefined) lines.push('42', String(vertex.bulge));
    }
  }
  lines.push('0', 'ENDSEC', '0', 'EOF');
  return lines.join('\n');
}

function rectangle(minX: number, minY: number, maxX: number, maxY: number): Vertex[] {
  return [
    { x: minX, y: minY },
    { x: maxX, y: minY },
    { x: maxX, y: maxY },
    { x: minX, y: maxY },
  ];
}

function passCount(xxl: string): number {
  return (xxl.match(/^G0 /gm) ?? []).length / 2;
}

function cutEndpoints(xxl: string): Array<{ x: number; y: number }> {
  return [...xxl.matchAll(/^G[123] X=([-\d.]+) Y=([-\d.]+) Z=1\.587 /gm)]
    .map((match) => ({ x: Number(match[1]), y: Number(match[2]) }));
}

function commandCount(xxl: string, command: 'G1' | 'G2' | 'G3'): number {
  return (xxl.match(new RegExp(`^${command} `, 'gm')) ?? []).length;
}

function numericAttributes(line: string): Record<string, number> {
  return Object.fromEntries(
    [...line.matchAll(/\b([XYZIJ])=([-\d.]+)/g)]
      .map((match) => [match[1], Number(match[2])]),
  );
}

function expectControllerSafeArcs(xxl: string): void {
  let current: { x: number; y: number } | null = null;
  let checked = 0;

  for (const line of xxl.split('\n')) {
    const command = line.match(/^(G[0-3])\b/)?.[1];
    if (!command) continue;
    const attributes = numericAttributes(line);
    const end = {
      x: attributes.X ?? current?.x ?? 0,
      y: attributes.Y ?? current?.y ?? 0,
    };

    if ((command === 'G2' || command === 'G3') && current) {
      expect(attributes.I).toBeTypeOf('number');
      expect(attributes.J).toBeTypeOf('number');
      const startRadius = Math.hypot(current.x - attributes.I, current.y - attributes.J);
      const endRadius = Math.hypot(end.x - attributes.I, end.y - attributes.J);
      expect(Math.abs(startRadius - endRadius)).toBeLessThan(0.003);
      checked += 1;
    }
    current = end;
  }

  expect(checked).toBeGreaterThan(0);
}

function expectNoLinearCutThroughBox(
  xxl: string,
  minX: number,
  minY: number,
  maxX: number,
  maxY: number,
): void {
  let current = { x: 0, y: 0, z: 0 };

  for (const line of xxl.split('\n')) {
    const command = line.match(/^(G[0-3])\b/)?.[1];
    if (!command) continue;
    const attributes = numericAttributes(line);
    const end = {
      x: attributes.X ?? current.x,
      y: attributes.Y ?? current.y,
      z: attributes.Z ?? current.z,
    };

    if (command === 'G1' && Math.abs(end.z - 1.5875) < 0.001) {
      const distance = Math.hypot(end.x - current.x, end.y - current.y);
      const samples = Math.max(1, Math.ceil(distance / 0.25));
      for (let sample = 0; sample <= samples; sample++) {
        const position = sample / samples;
        const x = current.x + (end.x - current.x) * position;
        const y = current.y + (end.y - current.y) * position;
        expect(x > minX && x < maxX && y > minY && y < maxY).toBe(false);
      }
    }
    current = end;
  }
}

describe('pocket logo toolpath geometry', () => {
  it('shrinks a convex contour and terminates instead of running to a hard pass limit', () => {
    const xxl = generatePocketLogoToolpath(
      logoDxf([rectangle(10, 10, 14, 14)]),
      'Heavy Duty',
    );

    expect(xxl).not.toBeNull();
    expect(passCount(xxl!)).toBe(1);
    expect(xxl!.length).toBeLessThan(100_000);

    const points = cutEndpoints(xxl!);
    expect(Math.min(...points.map((point) => point.x))).toBeGreaterThan(10 * 25.4);
    expect(Math.max(...points.map((point) => point.x))).toBeLessThan(14 * 25.4);
    expect(Math.min(...points.map((point) => point.y))).toBeGreaterThan(10 * 25.4);
    expect(Math.max(...points.map((point) => point.y))).toBeLessThan(14 * 25.4);
    expect(commandCount(xxl!, 'G2') + commandCount(xxl!, 'G3')).toBe(0);
  });

  it('handles a concave outline without expanding beyond its source bounds', () => {
    const concaveL: Vertex[] = [
      { x: 5, y: 5 },
      { x: 11, y: 5 },
      { x: 11, y: 7 },
      { x: 7, y: 7 },
      { x: 7, y: 11 },
      { x: 5, y: 11 },
    ];
    const xxl = generatePocketLogoToolpath(logoDxf([concaveL]), 'Regular Duty');

    expect(xxl).not.toBeNull();
    expect(xxl).toContain(';Step Over   : 1.587 mm (50% of tool diameter)');
    expect(passCount(xxl!)).toBeGreaterThan(0);
    expect(passCount(xxl!)).toBeLessThan(10);
    for (const point of cutEndpoints(xxl!)) {
      expect(point.x).toBeGreaterThan(5 * 25.4);
      expect(point.x).toBeLessThan(11 * 25.4);
      expect(point.y).toBeGreaterThan(5 * 25.4);
      expect(point.y).toBeLessThan(11 * 25.4);
    }
  });

  it('preserves a hole even when both contours have the same winding', () => {
    const xxl = generatePocketLogoToolpath(
      logoDxf([
        rectangle(10, 10, 20, 20),
        rectangle(13, 13, 17, 17),
      ]),
      'Regular Duty',
    );

    expect(xxl).not.toBeNull();
    const holeMin = 13 * 25.4;
    const holeMax = 17 * 25.4;
    const pointsInsideHole = cutEndpoints(xxl!).filter((point) => (
      point.x > holeMin && point.x < holeMax && point.y > holeMin && point.y < holeMax
    ));
    expect(pointsInsideHole).toEqual([]);
    // The annulus eventually splits into corner pockets as the outer contour
    // shrinks into the expanding hole, so those ambiguous branches start new
    // chains instead of taking unsafe shortcuts.
    expect(passCount(xxl!)).toBeGreaterThan(1);
    expect(passCount(xxl!)).toBeLessThan(20);
    expectNoLinearCutThroughBox(xxl!, holeMin, holeMin, holeMax, holeMax);
  });

  it('preserves an island inside a hole', () => {
    const xxl = generatePocketLogoToolpath(
      logoDxf([
        rectangle(4, 4, 20, 20),
        rectangle(8, 8, 16, 16),
        rectangle(10, 10, 14, 14),
      ]),
      'Heavy Duty',
    );

    expect(xxl).not.toBeNull();
    const islandMin = 10 * 25.4;
    const islandMax = 14 * 25.4;
    expect(cutEndpoints(xxl!).some((point) => (
      point.x > islandMin && point.x < islandMax
      && point.y > islandMin && point.y < islandMax
    ))).toBe(true);
    expect(passCount(xxl!)).toBeGreaterThan(2);
    expect(passCount(xxl!)).toBeLessThan(25);
  });

  it('normalizes a self-intersecting contour and still terminates safely', () => {
    const bowTie: Vertex[] = [
      { x: 5, y: 5 },
      { x: 13, y: 13 },
      { x: 5, y: 13 },
      { x: 13, y: 5 },
    ];
    const xxl = generatePocketLogoToolpath(logoDxf([bowTie]), 'Regular Duty');

    expect(xxl).not.toBeNull();
    expect(passCount(xxl!)).toBeGreaterThan(0);
    expect(passCount(xxl!)).toBeLessThan(200);
    expect(xxl!.length).toBeLessThan(500_000);
  });

  it('reconstructs DXF bulge curves as controller-safe pocket arcs', () => {
    // Two 180-degree bulge edges form a closed 4-inch circle.
    const circle: Vertex[] = [
      { x: 10, y: 12, bulge: 1 },
      { x: 14, y: 12, bulge: 1 },
    ];
    const xxl = generatePocketLogoToolpath(logoDxf([circle]), 'Regular Duty');

    expect(xxl).not.toBeNull();
    expect(commandCount(xxl!, 'G2') + commandCount(xxl!, 'G3')).toBeGreaterThan(50);
    expect(commandCount(xxl!, 'G1')).toBeLessThan(100);
    expect(passCount(xxl!)).toBe(1);
    expect(xxl!.length).toBeLessThan(30_000);
    expectControllerSafeArcs(xxl!);
  });

  it('rejects source geometry that leaves the physical sheet', () => {
    expect(() => generatePocketLogoToolpath(
      logoDxf([rectangle(-1, 1, 3, 3)]),
      'Regular Duty',
    )).toThrow(/leaves the 96x48 sheet/i);
  });

  it('returns null when the logo has no closed pocketable contour', () => {
    expect(generatePocketLogoToolpath(
      logoDxf([rectangle(1, 1, 4, 4)], false),
      'Regular Duty',
    )).toBeNull();
  });

  it('keeps many independent contours bounded and compact', () => {
    const contours = Array.from({ length: 22 }, (_, index) => {
      const column = index % 11;
      const row = Math.floor(index / 11);
      const minX = 2 + column * 3;
      const minY = 2 + row * 3;
      return rectangle(minX, minY, minX + 2, minY + 2);
    });
    const xxl = generatePocketLogoToolpath(logoDxf(contours), 'Heavy Duty');

    expect(xxl).not.toBeNull();
    expect(passCount(xxl!)).toBe(22);
    expect(xxl!.length).toBeLessThan(1_000_000);
  });

  it('orders completed pocket chains by the nearest safe-height entry', () => {
    const contours = [
      rectangle(30, 20, 32, 22),
      rectangle(2, 2, 4, 4),
      rectangle(24, 4, 26, 6),
      rectangle(8, 18, 10, 20),
      rectangle(16, 9, 18, 11),
    ];
    const xxl = generatePocketLogoToolpath(logoDxf(contours), 'Heavy Duty');

    expect(xxl).not.toBeNull();
    const lines = xxl!.split(/\r?\n/);
    const entries: Array<{ start: Vertex; end: Vertex }> = [];
    let active: { start: Vertex; end: Vertex } | null = null;
    for (const line of lines) {
      const move = line.match(/^G[0123]\s+X=(-?\d+(?:\.\d+)?)\s+Y=(-?\d+(?:\.\d+)?)/);
      if (!move) continue;
      const point = { x: Number(move[1]), y: Number(move[2]) };
      if (/^G0\s+.*Z=-38\.100\b/.test(line)) {
        if (active) entries.push(active);
        active = { start: point, end: point };
      } else if (active && !/^G0\b/.test(line)) {
        active.end = point;
      }
    }
    if (active) entries.push(active);

    expect(entries).toHaveLength(contours.length);
    let current = { x: 0, y: 0 };
    for (let index = 0; index < entries.length; index++) {
      const chosenDistance = Math.hypot(
        entries[index].start.x - current.x,
        entries[index].start.y - current.y,
      );
      const nearestRemaining = Math.min(...entries.slice(index).map((entry) => Math.hypot(
        entry.start.x - current.x,
        entry.start.y - current.y,
      )));
      expect(chosenDistance).toBeCloseTo(nearestRemaining, 6);
      current = entries[index].end;
    }
  });

  it('starts a new chain when a narrow pocket splits during inward offsetting', () => {
    const dumbbell: Vertex[] = [
      { x: 2, y: 2 },
      { x: 4, y: 2 },
      { x: 4, y: 2.925 },
      { x: 6, y: 2.925 },
      { x: 6, y: 2 },
      { x: 8, y: 2 },
      { x: 8, y: 4 },
      { x: 6, y: 4 },
      { x: 6, y: 3.075 },
      { x: 4, y: 3.075 },
      { x: 4, y: 4 },
      { x: 2, y: 4 },
    ];
    const xxl = generatePocketLogoToolpath(logoDxf([dumbbell]), 'Regular Duty');

    expect(xxl).not.toBeNull();
    expect(passCount(xxl!)).toBe(2);
    expect(xxl!.length).toBeLessThan(100_000);
  });
});
