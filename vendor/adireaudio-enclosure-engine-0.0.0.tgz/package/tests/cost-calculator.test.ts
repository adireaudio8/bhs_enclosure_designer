/**
 * CHARACTERIZATION tests for src/cost-calculator.ts.
 *
 * These pin CURRENT behavior (regression armor for dealer-facing costs) —
 * they are not a correctness review. Every hard-coded dollar/weight value
 * below was captured by running the engine (vitest observation run,
 * 2026-07-03) against the shared CANONICAL_S12 fixture with
 * DEFAULT_COST_SETTINGS + DEFAULT_MATERIAL_CONFIG. Do not "fix" a number
 * here from first principles — if a value changes, the engine changed.
 */
import { describe, it, expect } from 'vitest';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import {
  calculateCostFromCutList,
  calculateDesignCost,
  parseDesignDataInputs,
  parseCostSettings,
  DEFAULT_COST_SETTINGS,
  type CostSettings,
} from '../src/cost-calculator';
import type { CutListItem, EnclosureInputs } from '../src/types/enclosure';
import { CANONICAL_S12, makeInputs, DUTY_TYPES, DEFAULT_MATERIAL_CONFIG } from './fixtures';

// ─── Helpers ────────────────────────────────────────────────────────────────

type CostOptions = Parameters<typeof calculateCostFromCutList>[2];

/** Build the cut list the same way the Build tab does (engine defaults:
 *  DEFAULT_MATERIAL_CONFIG, glueTolerance 0.01). */
function buildCutList(inputs: EnclosureInputs) {
  const calcs = calculateEnclosure(inputs);
  return { calcs, cutList: generateCutList(inputs, calcs) };
}

/** Canonical options for an assembled (non-FP, non-bare) build of `inputs`. */
function optionsFor(inputs: EnclosureInputs, boxWidth: number, overrides: Partial<CostOptions> = {}): CostOptions {
  return {
    isFlatPack: false,
    isBare: false,
    enclosureType: inputs.enclosureType,
    enclosureConfiguration: inputs.enclosureConfiguration,
    subwooferQuantity: inputs.subwooferQuantity,
    sizeCode: '12',
    materialConfig: DEFAULT_MATERIAL_CONFIG,
    boxDepth: inputs.boxDepth,
    boxHeight: inputs.boxHeight,
    boxWidth,
    ...overrides,
  };
}

function runCost(
  inputs: EnclosureInputs,
  overrides: Partial<CostOptions> = {},
  settings: CostSettings = DEFAULT_COST_SETTINGS,
) {
  const { calcs, cutList } = buildCutList(inputs);
  const cost = calculateCostFromCutList(cutList, settings, optionsFor(inputs, calcs.boxWidth, overrides));
  return { calcs, cutList, cost };
}

const BIRCH_RD = makeInputs({ enclosureType: 'Birch Ply - Regular Duty' });
const MDF_RD = makeInputs({ enclosureType: 'MDF - Regular Duty' });

// Desktop-format design_data (flat PascalCase, string values) semantically
// identical to CANONICAL_S12 @ Birch-RD.
const DESKTOP_DESIGN_DATA = {
  SelectedEnclosureType: 'Birch Ply - Regular Duty',
  SelectedEnclosureConfiguration: 'Subs Back/Port Back',
  SelectedSubwooferQuantity: 'Single',
  SelectedPortQuantity: 'Single',
  SelectedSize: '12"',
  SelectedAssemblyMethod: 'Press Together',
  BoxDepthText: '18',
  BoxHeightText: '16',
  PortWidthText: '1.75',
  TuningFrequencyText: '32',
  NetAirSpaceText: '2.0',
  SubDisplacementText: '0.15',
  SubCutoutDiameterText: '11.19',
  OutsideDiameterText: '12.81',
  GlueTolerance: '0.015',
};

const WEB_DESIGN_DATA = {
  inputs: { ...CANONICAL_S12, enclosureType: 'Birch Ply - Regular Duty' as const },
  glueTolerance: 0.015,
};
const WEB_DESIGN_DATA_WITHOUT_GLUE_TOLERANCE = {
  inputs: { ...CANONICAL_S12, enclosureType: 'Birch Ply - Regular Duty' as const },
};

// ─── calculateCostFromCutList ───────────────────────────────────────────────

describe('calculateCostFromCutList', () => {
  describe('full breakdown snapshots — 6 duty types @ CANONICAL_S12', () => {
    for (const duty of DUTY_TYPES) {
      it(duty, () => {
        const { cost } = runCost(makeInputs({ enclosureType: duty }));
        expect(cost).toMatchSnapshot();
      });
    }
  });

  it('empty cut list returns the all-zero CostResult', () => {
    const cost = calculateCostFromCutList([], DEFAULT_COST_SETTINGS, {
      isFlatPack: false,
      isBare: false,
      enclosureType: 'Birch Ply - Regular Duty',
      subwooferQuantity: 'Single',
      sizeCode: '12',
    });
    expect(cost).toEqual({
      materialCost: 0, glueCost: 0, dowelPinsCost: 0, portPaintCost: 0,
      cardboardCost: 0, packagingPlyCost: 0, fixedCosts: 0, finishingCost: 0, totalCost: 0,
      surfaceAreaSqFt: 0, enclosureWeight: 0, shippingWeight: 0,
      dimensionalWeight: 0, billableWeight: 0,
      externalLength: 0, externalWidth: 0, externalHeight: 0,
    });
  });

  describe('CANONICAL_S12 Birch-RD component pins', () => {
    const { cost } = runCost(BIRCH_RD);

    it('material cost includes the 10% waste multiplier', () => {
      expect(cost.materialCost).toBe(45.51);
      // Same cut list at 0% waste — the 10% multiplier is the only delta.
      const { cost: zeroWaste } = runCost(BIRCH_RD, {}, { ...DEFAULT_COST_SETTINGS, materialWastePercentage: 0 });
      expect(zeroWaste.materialCost).toBe(41.37);
    });

    it('edge glue cost (assembled, SBPB, no flush parts)', () => {
      expect(cost.glueCost).toBe(0.09);
    });

    it('glue cost is 0 when no materialConfig is passed', () => {
      const { calcs, cutList } = buildCutList(BIRCH_RD);
      const opts = optionsFor(BIRCH_RD, calcs.boxWidth);
      delete opts.materialConfig;
      const noMc = calculateCostFromCutList(cutList, DEFAULT_COST_SETTINGS, opts);
      expect(noMc.glueCost).toBe(0);
    });

    it('dowel pins: 53 holes @ $0.02 for Single; 83 holes for Quad', () => {
      expect(cost.dowelPinsCost).toBe(1.06); // 53 × 0.02
      // costPerDowelPin=1 exposes the raw hole count
      const { cost: holes } = runCost(BIRCH_RD, {}, { ...DEFAULT_COST_SETTINGS, costPerDowelPin: 1 });
      expect(holes.dowelPinsCost).toBe(53);
      const { cost: quadHoles } = runCost(BIRCH_RD, { subwooferQuantity: 'Quad' }, { ...DEFAULT_COST_SETTINGS, costPerDowelPin: 1 });
      expect(quadHoles.dowelPinsCost).toBe(83);
    });

    it('port paint: 12" Single = 0.66 can @ $8', () => {
      expect(cost.portPaintCost).toBe(5.28);
    });

    it('port paint matrix: Dual uses stored fraction; Triple/Quad = single × subCount', () => {
      expect(runCost(BIRCH_RD, { subwooferQuantity: 'Dual' }).cost.portPaintCost).toBe(10); // 1.25 × 8
      expect(runCost(BIRCH_RD, { subwooferQuantity: 'Triple' }).cost.portPaintCost).toBe(15.84); // 0.66×3 × 8
      expect(runCost(BIRCH_RD, { subwooferQuantity: 'Quad' }).cost.portPaintCost).toBe(21.12); // 0.66×4 × 8
      expect(runCost(BIRCH_RD, { sizeCode: '6.5', subwooferQuantity: 'Quad' }).cost.portPaintCost).toBe(8); // 0.25×4 × 8
      expect(runCost(BIRCH_RD, { sizeCode: '8' }).cost.portPaintCost).toBe(2.64); // 0.33 × 8
      expect(runCost(BIRCH_RD, { sizeCode: '' }).cost.portPaintCost).toBe(0); // no size code → no paint
    });

    it('cardboard: 1 sheet when the dieline fits 48×96, 2 sheets when it must split', () => {
      expect(cost.cardboardCost).toBe(12);
      const { cost: big } = runCost(BIRCH_RD, { boxDepth: 60, boxHeight: 40, boxWidth: 45 });
      expect(big.cardboardCost).toBe(24);
    });

    it('fixed costs: binding post + wire whip + bag + foam corners (assembled)', () => {
      expect(cost.fixedCosts).toBe(6); // 2.50 + 1.25 + 0.75 + 1.50
    });

    it('finishing (Full tier): surfaceArea × (labor 0.50 + materials 0.35)', () => {
      expect(cost.surfaceAreaSqFt).toBeCloseTo(13.783457618334507, 10);
      expect(cost.finishingCost).toBe(11.72);
    });

    it('total = sum of 2dp-rounded components', () => {
      expect(cost.totalCost).toBe(81.66);
    });
  });

  describe('finishing tiers', () => {
    it('Flat Pack: $0 finishing, drops glue/port paint/foam corners, adds packaging ply', () => {
      const { cost } = runCost(BIRCH_RD, { isFlatPack: true, dutyType: 'RD' });
      expect(cost.finishingCost).toBe(0);
      expect(cost.glueCost).toBe(0);
      expect(cost.portPaintCost).toBe(0);
      expect(cost.fixedCosts).toBe(4.5); // no foam corners
      expect(cost.packagingPlyCost).toBe(11.81); // crating ply via flat-pack optimizer
      expect(cost.totalCost).toBe(74.88);
    });

    it('Bare/Foundation Birch: sanding-only = surfaceArea × labor × 0.25', () => {
      const { cost } = runCost(BIRCH_RD, { isBare: true });
      // 13.7835 × (0.50 × 0.25) = 1.7229 → 1.72
      expect(cost.finishingCost).toBe(1.72);
      expect(cost.totalCost).toBe(71.66);
    });

    it('isFoundation and isBare are the same tier (identical result)', () => {
      const bare = runCost(BIRCH_RD, { isBare: true }).cost;
      const foundation = runCost(BIRCH_RD, { isFoundation: true }).cost;
      expect(foundation).toEqual(bare);
    });

    it('Bare/Foundation MDF: fraction is 0.30 (falls back to Birch labor rate when MDF rates are 0)', () => {
      const { cost } = runCost(MDF_RD, { isBare: true });
      // 13.8900 × (0.50 × 0.30) = 2.0835 → 2.08
      expect(cost.finishingCost).toBe(2.08);
    });

    it('MDF-specific finishing rates are used when configured > 0', () => {
      const mdfSettings = { ...DEFAULT_COST_SETTINGS, finishingLaborPerSqFtMDF: 0.8, finishingMaterialsPerSqFtMDF: 0.55 };
      // Full: 13.8900 × (0.80 + 0.55) = 18.7515 → 18.75
      expect(runCost(MDF_RD, {}, mdfSettings).cost.finishingCost).toBe(18.75);
      // Bare: 13.8900 × (0.80 × 0.30) = 3.3336 → 3.33
      expect(runCost(MDF_RD, { isBare: true }, mdfSettings).cost.finishingCost).toBe(3.33);
      // Birch designs ignore the MDF rates entirely
      expect(runCost(BIRCH_RD, {}, mdfSettings).cost.finishingCost).toBe(11.72);
    });

    it('Full MDF with default settings falls back to Birch rates (MDF rates default 0)', () => {
      expect(runCost(MDF_RD).cost.finishingCost).toBe(11.81);
    });
  });

  describe('face-to-face glue (flush mount)', () => {
    it('SBPB flush: Sub Mount Plate contributes width × height face glue (no thickness multiplier)', () => {
      const plain = runCost(BIRCH_RD).cost;
      const flushInputs = makeInputs({ enclosureType: 'Birch Ply - Regular Duty', recessedMounting: true });
      const { cutList, cost: flush } = runCost(flushInputs);

      const plate = cutList.find(p => p.partName === 'Sub Mount Plate');
      expect(plate).toBeDefined();
      expect(plate!.width).toBeCloseTo(17.603, 10);
      expect(plate!.height).toBeCloseTo(14.5, 10);
      expect(plate!.material).toBe('24mm Birch Ply');

      // Plain SBPB edge glue is $0.09; the plate's 17.603×14.5 = 255.2 in²
      // face joint adds ≈ $0.11 (255.2 × (25/400)/144) → $0.20 total.
      expect(plain.glueCost).toBe(0.09);
      expect(flush.glueCost).toBe(0.2);
    });

    it('SUPB flush: Sub Mount Cap contributes width × height face glue (no thickness multiplier)', () => {
      const supb = makeInputs({ enclosureType: 'Birch Ply - Regular Duty', enclosureConfiguration: 'Subs Up/Port Back' });
      const supbFlush = makeInputs({
        enclosureType: 'Birch Ply - Regular Duty',
        enclosureConfiguration: 'Subs Up/Port Back',
        recessedMounting: true,
      });
      const plain = runCost(supb).cost;
      const { cutList, cost: flush } = runCost(supbFlush);

      const cap = cutList.find(p => p.partName === 'Sub Mount Cap');
      expect(cap).toBeDefined();
      expect(cap!.width).toBeCloseTo(21.25, 10); // rounded boxWidth of the flush variant
      expect(cap!.height).toBeCloseTo(18, 10); // boxDepth
      expect(cap!.material).toBe('18mm Birch Ply');

      // Plain SUPB edge glue is $0.08; the cap's 21.25×18 = 382.5 in²
      // face joint adds ≈ $0.17 → $0.25 total.
      expect(plain.glueCost).toBe(0.08);
      expect(flush.glueCost).toBe(0.25);
    });
  });

  describe('weight math (densities: Birch 0.0246, MDF 0.029 lb/in³)', () => {
    it('Birch-RD: enclosureWeight = Σ part volume × 0.0246; shipping = +3.0 lb packaging', () => {
      const { cutList, cost } = runCost(BIRCH_RD);
      expect(cutList.every(p => p.material.includes('Birch'))).toBe(true);
      let expected = 0;
      for (const p of cutList) expected += p.width * p.height * p.quantity * p.thickness * 0.0246;
      expect(cost.enclosureWeight).toBeCloseTo(expected, 10);
      expect(cost.enclosureWeight).toBeCloseTo(39.29427869044207, 8);
      expect(cost.shippingWeight).toBeCloseTo(cost.enclosureWeight + 3.0, 12);
    });

    it('MDF-RD: enclosureWeight = Σ part volume × 0.029', () => {
      const { cutList, cost } = runCost(MDF_RD);
      expect(cutList.every(p => p.material.includes('MDF'))).toBe(true);
      let expected = 0;
      for (const p of cutList) expected += p.width * p.height * p.quantity * p.thickness * 0.029;
      expect(cost.enclosureWeight).toBeCloseTo(expected, 10);
      // 2026-07-08 MDF full-stock-mate sizing fix: Side Left / Side Right /
      // Port Piece 1 shrank (E→D mates, −0.063 lb), then the option-A baffle
      // correction (true D2 PP2 mate, baffle 18.541→18.5) dropped another
      // 0.017 lb vs the pre-fix 49.31430745729644.
      expect(cost.enclosureWeight).toBeCloseTo(49.23399195729643, 8);
      expect(cost.shippingWeight).toBeCloseTo(52.23399195729643, 8);
    });

    it('Birch-RD external dims + DIM weight; billable = max(shipping, dimensional)', () => {
      const { cost } = runCost(BIRCH_RD);
      expect(cost.externalLength).toBeCloseTo(19.6762, 6); // (18+1.125) + 0.5512
      expect(cost.externalWidth).toBeCloseTo(17.5512, 6); // (16+1.0) + 0.5512
      expect(cost.externalHeight).toBeCloseTo(23.007810250590722, 8); // (boxWidth+1.1875) + 1.1024
      expect(cost.dimensionalWeight).toBeCloseTo(57.16214670687538, 8);
      // DIM weight (57.16) > shipping (42.29) → billable is dimensional
      expect(cost.billableWeight).toBe(cost.dimensionalWeight);
    });

    it('MDF-HD: shipping weight exceeds DIM weight → billable is shipping', () => {
      const { cost } = runCost(makeInputs({ enclosureType: 'MDF - Heavy Duty' }));
      // 2026-07-08 MDF full-stock-mate sizing fix (−0.081 lb) + option-A
      // baffle correction (true D2 mate, −0.022 lb) vs the pre-fix
      // 66.67744307712375.
      expect(cost.shippingWeight).toBeCloseTo(66.57391307712376, 8);
      expect(cost.dimensionalWeight).toBeCloseTo(61.56851908897034, 8);
      expect(cost.billableWeight).toBe(cost.shippingWeight);
    });
  });

  it('prices and weighs every added labyrinth divider, including glue and dowels', () => {
    const inputs = makeInputs({
      enclosureType: 'Birch Ply - Regular Duty',
      tuningFrequency: 20,
      netAirSpace: 1.5,
      boxDepth: 18,
      boxHeight: 16,
      portWidth: 2,
    });
    const { calcs, cutList, cost } = runCost(inputs);
    const withoutAddedDividers = cutList.filter(part => !/^Port Piece ([3-9]|[1-9]\d+)$/.test(part.partName));
    const reduced = calculateCostFromCutList(
      withoutAddedDividers,
      DEFAULT_COST_SETTINGS,
      optionsFor(inputs, calcs.boxWidth),
    );

    expect(calcs.labyrinthPort.active).toBe(true);
    expect(cutList.some(part => part.partName === 'Port Piece 3')).toBe(true);
    expect(cost.materialCost).toBeGreaterThan(reduced.materialCost);
    expect(cost.glueCost).toBeGreaterThan(reduced.glueCost);
    expect(cost.dowelPinsCost).toBeGreaterThan(reduced.dowelPinsCost);
    expect(cost.enclosureWeight).toBeGreaterThan(reduced.enclosureWeight);
  });
});

// ─── calculateDesignCost ────────────────────────────────────────────────────

describe('calculateDesignCost', () => {
  it('web-format design_data ({ inputs: {...} }) resolves — full snapshot', () => {
    const cost = calculateDesignCost(WEB_DESIGN_DATA, DEFAULT_COST_SETTINGS, 'BHS-2.0V2-S12');
    expect(cost).not.toBeNull();
    // This fixture explicitly saves 0.015, so it preserves the historical
    // snapshot while separate tests below verify the corrected 0.01 fallback.
    expect(cost!.totalCost).toBe(81.65);
    expect(cost).toMatchSnapshot();
  });

  it('desktop-format design_data (flat PascalCase strings) resolves — full snapshot', () => {
    const cost = calculateDesignCost(DESKTOP_DESIGN_DATA, DEFAULT_COST_SETTINGS, 'BHS-2.0V2-S12');
    expect(cost).not.toBeNull();
    expect(cost).toMatchSnapshot();
  });

  it('web and desktop formats of the same design produce the identical CostResult', () => {
    const web = calculateDesignCost(WEB_DESIGN_DATA, DEFAULT_COST_SETTINGS, 'BHS-2.0V2-S12');
    const desktop = calculateDesignCost(DESKTOP_DESIGN_DATA, DEFAULT_COST_SETTINGS, 'BHS-2.0V2-S12');
    expect(desktop).toEqual(web);
  });

  it('missing tolerance uses the engine-wide 0.01 default, matching Build', () => {
    const cost = calculateDesignCost(
      WEB_DESIGN_DATA_WITHOUT_GLUE_TOLERANCE,
      DEFAULT_COST_SETTINGS,
      'BHS-2.0V2-S12',
    );
    expect(cost!.totalCost).toBe(81.66);
  });

  it('caller fallback fills legacy designs, but a saved per-design value wins', () => {
    const fallback = calculateDesignCost(
      WEB_DESIGN_DATA_WITHOUT_GLUE_TOLERANCE,
      DEFAULT_COST_SETTINGS,
      'BHS-2.0V2-S12',
      undefined,
      0.02,
    );
    const saved = calculateDesignCost(
      WEB_DESIGN_DATA,
      DEFAULT_COST_SETTINGS,
      'BHS-2.0V2-S12',
      undefined,
      0.02,
    );
    expect(fallback!.totalCost).toBeLessThan(81.66);
    expect(saved!.totalCost).toBe(81.65);
  });

  it('"-FP" design-name suffix triggers the flat-pack path', () => {
    const cost = calculateDesignCost(WEB_DESIGN_DATA, DEFAULT_COST_SETTINGS, 'BHS-2.0V2-S12-FP');
    expect(cost!.finishingCost).toBe(0);
    expect(cost!.portPaintCost).toBe(0);
    expect(cost!.fixedCosts).toBe(4.5);
    expect(cost!.packagingPlyCost).toBe(11.81);
    expect(cost!.totalCost).toBe(74.87);
  });

  it('"BHSF-" design-name prefix triggers the Foundation (sanding-only) tier', () => {
    const cost = calculateDesignCost(WEB_DESIGN_DATA, DEFAULT_COST_SETTINGS, 'BHSF-2.0V2-S12');
    expect(cost!.finishingCost).toBe(1.72);
    expect(cost!.totalCost).toBe(71.65);
  });

  it('returns null for null / unparseable design_data', () => {
    expect(calculateDesignCost(null, DEFAULT_COST_SETTINGS, 'X')).toBeNull();
    expect(calculateDesignCost({}, DEFAULT_COST_SETTINGS, 'X')).toBeNull();
  });

  it('stub-poisoned inputs return null, never NaN (fixed 2026-07-03)', () => {
    // A desktop design that some writer gave a stub `inputs` object: the
    // parser short-circuits to the stub (see parseDesignDataInputs tests)
    // and calculateEnclosure runs on undefined dims WITHOUT throwing.
    // Previously this produced a CostResult with NaN totals alongside
    // real-looking per-line costs — publishable garbage. The finite-guard
    // in calculateDesignCost now returns null like the other failure paths,
    // so callers' existing null-handling shows "no cost" instead.
    const poisoned = {
      inputs: { enclosureType: 'Birch Ply - Regular Duty' },
      ...DESKTOP_DESIGN_DATA,
    };
    const cost = calculateDesignCost(poisoned, DEFAULT_COST_SETTINGS, 'BHS-2.0V2-S12');
    expect(cost).toBeNull();
  });
});

// ─── parseDesignDataInputs ──────────────────────────────────────────────────

describe('parseDesignDataInputs', () => {
  it('returns null for null/undefined', () => {
    expect(parseDesignDataInputs(null)).toBeNull();
    expect(parseDesignDataInputs(undefined)).toBeNull();
  });

  it('web format: short-circuits to the exact `inputs` object reference', () => {
    const result = parseDesignDataInputs(WEB_DESIGN_DATA);
    expect(result).toBe(WEB_DESIGN_DATA.inputs);
  });

  it('POISONING PIN: a stub `inputs` object short-circuits even when full desktop fields exist', () => {
    // This is exactly why the API route must not write stub inputs onto
    // desktop-saved design_data: the stub wins and the rich PascalCase
    // fields sitting right next to it are never read.
    const stub = { enclosureType: 'Birch Ply - Regular Duty' };
    const poisoned = { inputs: stub, ...DESKTOP_DESIGN_DATA };
    const result = parseDesignDataInputs(poisoned);
    expect(result).toBe(stub);
    expect((result as Record<string, unknown>).boxDepth).toBeUndefined();
    expect((result as Record<string, unknown>).boxHeight).toBeUndefined();
  });

  it('desktop format: parses flat PascalCase string values — snapshot + key pins', () => {
    const result = parseDesignDataInputs(DESKTOP_DESIGN_DATA)!;
    expect(result.boxDepth).toBe(18);
    expect(result.boxHeight).toBe(16);
    expect(result.portWidth).toBe(1.75);
    expect(result.tuningFrequency).toBe(32);
    expect(result.netAirSpace).toBe(2);
    expect(result.subDisplacement).toBe(0.15);
    expect(result.subCutoutDiameter).toBe(11.19);
    expect(result.outsideDiameter).toBe(12.81);
    expect(result.enclosureType).toBe('Birch Ply - Regular Duty');
    expect(result.enclosureConfiguration).toBe('Subs Back/Port Back');
    expect(result.size).toBe('12"');
    expect(result).toMatchSnapshot();
  });

  it('desktop format: minimal design gets desktop defaults (SUPB config, Birch RD, 12")', () => {
    const result = parseDesignDataInputs({ BoxDepthText: '18', BoxHeightText: '16' })!;
    expect(result.enclosureType).toBe('Birch Ply - Regular Duty');
    expect(result.enclosureConfiguration).toBe('Subs Up/Port Back'); // parser default ≠ calculator default (SBPB)
    expect(result.subwooferQuantity).toBe('Single');
    expect(result.portQuantity).toBe('Single');
    expect(result.size).toBe('12"');
    expect(result.assemblyMethod).toBe('Press Together');
    expect(result.isCustomEnclosure).toBe(false);
  });

  it('camelCase *Text keys are read too (web-ish flat saves)', () => {
    const result = parseDesignDataInputs({ boxDepthText: '18', boxHeightText: '16', portWidthText: '1.75' })!;
    expect(result.boxDepth).toBe(18);
    expect(result.boxHeight).toBe(16);
    expect(result.portWidth).toBe(1.75);
  });

  it('*Text-then-bare-key fallback: bare OutsideDiameter/SubCutoutDiameter are picked up', () => {
    const result = parseDesignDataInputs({
      BoxDepthText: '18',
      BoxHeightText: '16',
      OutsideDiameter: '12.81', // no OutsideDiameterText
      SubCutoutDiameter: 11.19, // numeric bare key also works
    })!;
    expect(result.outsideDiameter).toBe(12.81);
    expect(result.subCutoutDiameter).toBe(11.19);
  });

  it('*Text key takes precedence over the bare key when both exist', () => {
    const result = parseDesignDataInputs({
      BoxDepthText: '18',
      BoxHeightText: '16',
      OutsideDiameterText: '13',
      OutsideDiameter: '99',
    })!;
    expect(result.outsideDiameter).toBe(13);
  });

  it('returns null when both boxDepth and boxHeight are missing/zero', () => {
    expect(parseDesignDataInputs({ SelectedEnclosureType: 'Birch Ply - Regular Duty' })).toBeNull();
    expect(parseDesignDataInputs({ BoxDepthText: '0', BoxHeightText: '0' })).toBeNull();
  });
});

// ─── parseCostSettings ──────────────────────────────────────────────────────

describe('parseCostSettings', () => {
  it('maps desktop PascalCase keys, accepts camelCase, ignores non-numbers and unknown keys', () => {
    const parsed = parseCostSettings({
      Birch18mmPerSheet: 90, // PascalCase → mapped
      birch24mmPerSheet: 120, // camelCase → direct
      MaterialWastePercentage: '15', // string → ignored, default kept
      bogusKey: 5, // unknown → ignored
    });
    expect(parsed.birch18mmPerSheet).toBe(90);
    expect(parsed.birch24mmPerSheet).toBe(120);
    expect(parsed.materialWastePercentage).toBe(10); // default retained
    expect(parsed.mdf34PerSheet).toBe(DEFAULT_COST_SETTINGS.mdf34PerSheet);
    expect('bogusKey' in parsed).toBe(false);
  });
});

// ─── Cut-list fixture sanity (guards the snapshot inputs themselves) ────────

describe('CANONICAL_S12 Birch-RD cut list sanity (inputs to every cost pin above)', () => {
  it('part names and materials are stable', () => {
    const { cutList } = buildCutList(BIRCH_RD);
    expect(cutList.map((p: CutListItem) => `${p.partName} [${p.material}]`)).toEqual([
      'Top [18mm Birch Ply]',
      'Bottom [18mm Birch Ply]',
      'Back [18mm Birch Ply]',
      'Baffle [24mm Birch Ply]', // RD-SBPB: baffle is the thick panel
      'Side Left [18mm Birch Ply]',
      'Side Right [18mm Birch Ply]',
      'Port Piece 1 [18mm Birch Ply]',
      'Port Piece 2 [18mm Birch Ply]',
    ]);
  });
});
