/**
 * CHARACTERIZATION tests for src/acrylic-window.ts.
 *
 * These pin CURRENT behavior (regression armor for CNC window cutouts) —
 * every expected number below was produced by running the code against the
 * shared CANONICAL_S12 fixture, not derived from first principles.
 */
import { describe, it, expect } from 'vitest';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import {
  WINDOW_PLATE_OVERHANG_PER_SIDE,
  WINDOW_WALL_CLEARANCE,
  DEFAULT_WINDOW_CORNER_RADIUS,
  resolveAcrylicThickness,
  resolveWindowPanel,
  resolveWindowDimensions,
  resolveHostPanelBox,
  resolveWindowSafeArea,
  resolveAutoFitPlateDimensions,
  resolveEffectiveWindowOffsets,
} from '../src/acrylic-window';
import type { EnclosureInputs } from '../src/types/enclosure';
import { makeInputs } from './fixtures';

// ── Shared fixtures (canonical S12, SBPB single port, SD Birch) ─────────────
const winInputs = makeInputs({ windowEnabled: true, windowSize: '12x12' });
const calc = calculateEnclosure(winInputs);
const cutList = generateCutList(winInputs, calc);

describe('module constants', () => {
  it('pins the plate/cutout overhang and wall clearance', () => {
    expect(WINDOW_PLATE_OVERHANG_PER_SIDE).toBe(1.25);
    expect(WINDOW_WALL_CLEARANCE).toBe(0.5);
    expect(DEFAULT_WINDOW_CORNER_RADIUS).toBe(0.125);
  });
});

describe('resolveAcrylicThickness', () => {
  it('HD duty gets 3/8", everything else 1/4"', () => {
    expect(resolveAcrylicThickness(makeInputs({ enclosureType: 'Birch Ply - Heavy Duty' }))).toBe(0.375);
    expect(resolveAcrylicThickness(makeInputs({ enclosureType: 'MDF - Heavy Duty' }))).toBe(0.375);
    expect(resolveAcrylicThickness(makeInputs({ enclosureType: 'Birch Ply - Standard Duty' }))).toBe(0.25);
    expect(resolveAcrylicThickness(makeInputs({ enclosureType: 'Birch Ply - Regular Duty' }))).toBe(0.25);
    expect(resolveAcrylicThickness(makeInputs({ enclosureType: 'MDF - Standard Duty' }))).toBe(0.25);
  });
});

describe('resolveWindowPanel', () => {
  it('maps each enclosure configuration to its host panel', () => {
    expect(resolveWindowPanel(makeInputs({ enclosureConfiguration: 'Subs Back/Port Back' }))).toBe('Top');
    expect(resolveWindowPanel(makeInputs({ enclosureConfiguration: 'Subs Up/Port Back' }))).toBe('Baffle');
    expect(resolveWindowPanel(makeInputs({ enclosureConfiguration: 'Subs Up/Port Up' }))).toBe('Bottom');
  });

  it('falls back to Top for unknown configurations', () => {
    const bogus = makeInputs({
      enclosureConfiguration: 'Bogus Config' as EnclosureInputs['enclosureConfiguration'],
    });
    expect(resolveWindowPanel(bogus)).toBe('Top');
  });
});

describe('resolveWindowDimensions', () => {
  it('returns all-zero when the window is disabled', () => {
    expect(resolveWindowDimensions(makeInputs())).toEqual({
      plateW: 0, plateH: 0, cutoutW: 0, cutoutH: 0,
    });
  });

  it('12x12 plate covers a 9.5x9.5 cutout', () => {
    expect(resolveWindowDimensions(winInputs)).toEqual({
      plateW: 12, plateH: 12, cutoutW: 9.5, cutoutH: 9.5,
    });
  });

  it('defaults to 12x12 when windowSize is unset but enabled', () => {
    expect(resolveWindowDimensions(makeInputs({ windowEnabled: true }))).toEqual({
      plateW: 12, plateH: 12, cutoutW: 9.5, cutoutH: 9.5,
    });
  });

  it('24x12 defaults to landscape (24 wide)', () => {
    expect(resolveWindowDimensions(makeInputs({ windowEnabled: true, windowSize: '24x12' }))).toEqual({
      plateW: 24, plateH: 12, cutoutW: 21.5, cutoutH: 9.5,
    });
  });

  it('24x12 portrait swaps the axes', () => {
    expect(resolveWindowDimensions(makeInputs({
      windowEnabled: true, windowSize: '24x12', windowOrientation: 'portrait',
    }))).toEqual({ plateW: 12, plateH: 24, cutoutW: 9.5, cutoutH: 21.5 });
  });

  it('custom size reads windowCustomWidth/Height directly as PLATE dims', () => {
    expect(resolveWindowDimensions(makeInputs({
      windowEnabled: true, windowSize: 'custom', windowCustomWidth: 8, windowCustomHeight: 6,
    }))).toEqual({ plateW: 8, plateH: 6, cutoutW: 5.5, cutoutH: 3.5 });
  });

  it('custom size falls back to 12 per-axis for missing / non-positive values', () => {
    expect(resolveWindowDimensions(makeInputs({ windowEnabled: true, windowSize: 'custom' })))
      .toEqual({ plateW: 12, plateH: 12, cutoutW: 9.5, cutoutH: 9.5 });
    expect(resolveWindowDimensions(makeInputs({
      windowEnabled: true, windowSize: 'custom', windowCustomWidth: 0, windowCustomHeight: -3,
    }))).toEqual({ plateW: 12, plateH: 12, cutoutW: 9.5, cutoutH: 9.5 });
    expect(resolveWindowDimensions(makeInputs({
      windowEnabled: true, windowSize: 'custom', windowCustomWidth: NaN, windowCustomHeight: NaN,
    }))).toEqual({ plateW: 12, plateH: 12, cutoutW: 9.5, cutoutH: 9.5 });
  });

  it('cutout floors at 1" for tiny custom plates (degenerate-hole guard)', () => {
    // NOTE (pinned quirk): a 2x3 plate yields a 1x1 cutout — the 1" floor
    // overrides the plate−2.5 formula, leaving only 0.5"/1.0" of overhang.
    expect(resolveWindowDimensions(makeInputs({
      windowEnabled: true, windowSize: 'custom', windowCustomWidth: 2, windowCustomHeight: 3,
    }))).toEqual({ plateW: 2, plateH: 3, cutoutW: 1, cutoutH: 1 });
  });
});

describe('resolveHostPanelBox', () => {
  it('Top host spans boxWidth x boxDepth (SBPB)', () => {
    const box = resolveHostPanelBox(winInputs, calc);
    expect(box.panelW).toBeCloseTo(20.574754214901326, 10);
    expect(box.panelH).toBe(18);
  });

  it('Baffle host is boxWidth − 2·sideT wide by internalHeight (SUPB)', () => {
    const supb = makeInputs({ windowEnabled: true, enclosureConfiguration: 'Subs Up/Port Back' });
    const supbCalc = calculateEnclosure(supb);
    const box = resolveHostPanelBox(supb, supbCalc);
    expect(box.panelW).toBeCloseTo(19.156754214901326, 10); // boxW − 2×0.709
    expect(box.panelH).toBe(14.5); // internalHeight
  });

  it('Bottom host (SUPU) has the same extents as Top', () => {
    const supu = makeInputs({ windowEnabled: true, enclosureConfiguration: 'Subs Up/Port Up' });
    const supuCalc = calculateEnclosure(supu);
    expect(resolveHostPanelBox(supu, supuCalc)).toEqual(resolveHostPanelBox(winInputs, calculateEnclosure(makeInputs({ windowEnabled: true }))));
  });
});

describe('resolveWindowSafeArea', () => {
  it('SBPB single port (canonical, with cut list): pinned rect', () => {
    const safe = resolveWindowSafeArea(winInputs, calc, cutList);
    // xMin = sideT(0.709) + clearance(0.5)
    expect(safe.xMin).toBeCloseTo(1.209, 12);
    expect(safe.xMax).toBeCloseTo(16.906754214901326, 10);
    // yMin = baffleT(0.709, SD thin) + clearance(0.5)
    expect(safe.yMin).toBeCloseTo(1.209, 12);
    // yMax = baffleT + PP1 cut-list width(14.181) − clearance
    expect(safe.yMax).toBeCloseTo(14.39, 10);
  });

  it('without a cut list, PP1 depth falls back to the calc-derived estimate', () => {
    const safe = resolveWindowSafeArea(winInputs, calc);
    expect(safe.yMax).toBeCloseTo(15.65, 10); // 0.709 + (18 − 1.75 − 0.709 − 0.1) − 0.5
    expect(safe.xMin).toBeCloseTo(1.209, 12); // X unchanged vs cut-list path
    expect(safe.xMax).toBeCloseTo(16.906754214901326, 10);
  });

  it('RD-SBPB uses the THICK baffle (0.945) for yMin while sides stay thin', () => {
    const rd = makeInputs({ windowEnabled: true, enclosureType: 'Birch Ply - Regular Duty' });
    const rdCalc = calculateEnclosure(rd);
    const rdCut = generateCutList(rd, rdCalc);
    const safe = resolveWindowSafeArea(rd, rdCalc, rdCut);
    expect(safe.yMin).toBeCloseTo(1.445, 12);  // 0.945 + 0.5 (thick baffle)
    expect(safe.xMin).toBeCloseTo(1.209, 12);  // 0.709 + 0.5 (thin side)
    expect(safe.yMax).toBeCloseTo(14.386000000000001, 10);
  });

  it('HD-SBPB thickens every wall (0.945)', () => {
    const hd = makeInputs({ windowEnabled: true, enclosureType: 'Birch Ply - Heavy Duty' });
    const hdCalc = calculateEnclosure(hd);
    const hdCut = generateCutList(hd, hdCalc);
    const safe = resolveWindowSafeArea(hd, hdCalc, hdCut);
    expect(safe.xMin).toBeCloseTo(1.445, 12);
    expect(safe.yMin).toBeCloseTo(1.445, 12);
    expect(safe.xMax).toBeCloseTo(18.05764281559601, 10);
    expect(safe.yMax).toBeCloseTo(13.91, 10);
  });

  it('SUPB baffle host: panel-edge margin only (no interior walls)', () => {
    const supb = makeInputs({ windowEnabled: true, enclosureConfiguration: 'Subs Up/Port Back' });
    const supbCalc = calculateEnclosure(supb);
    const supbCut = generateCutList(supb, supbCalc);
    const safe = resolveWindowSafeArea(supb, supbCalc, supbCut);
    expect(safe.xMin).toBe(0.5);
    expect(safe.yMin).toBe(0.5);
    expect(safe.xMax).toBeCloseTo(18.656754214901326, 10); // panelW − 0.5
    expect(safe.yMax).toBe(14);                            // internalHeight − 0.5
  });

  it('dual port centers the chamber between the two PP1 walls', () => {
    const dual = makeInputs({ windowEnabled: true, portQuantity: 'Dual' });
    const dualCalc = calculateEnclosure(dual);
    const dualCut = generateCutList(dual, dualCalc);
    const safe = resolveWindowSafeArea(dual, dualCalc, dualCut);
    // xMin = t + portW + ppT + c = 0.709 + 1.75 + 0.709 + 0.5
    expect(safe.xMin).toBeCloseTo(3.668, 12);
    expect(safe.xMax).toBeCloseTo(30.80504179151094, 10);
    expect(safe.yMin).toBeCloseTo(1.209, 12);
    expect(safe.yMax).toBeCloseTo(14.39, 10);
  });

  it('snapshot: safe-area matrix across configurations/duties', () => {
    const variants: Record<string, ReturnType<typeof resolveWindowSafeArea>> = {};
    const cases: Array<[string, Partial<EnclosureInputs>]> = [
      ['SBPB-SD-single', {}],
      ['SBPB-SD-dual', { portQuantity: 'Dual' }],
      ['SBPB-HD-single', { enclosureType: 'Birch Ply - Heavy Duty' }],
      ['SBPB-RD-single', { enclosureType: 'Birch Ply - Regular Duty' }],
      ['SBPB-MDF-SD-single', { enclosureType: 'MDF - Standard Duty' }],
      ['SUPB-SD', { enclosureConfiguration: 'Subs Up/Port Back' }],
      ['SUPU-SD', { enclosureConfiguration: 'Subs Up/Port Up' }],
    ];
    for (const [label, overrides] of cases) {
      const inp = makeInputs({ windowEnabled: true, ...overrides });
      const c = calculateEnclosure(inp);
      variants[label] = resolveWindowSafeArea(inp, c, generateCutList(inp, c));
    }
    expect(variants).toMatchSnapshot();
  });
});

describe('resolveAutoFitPlateDimensions', () => {
  const safe = resolveWindowSafeArea(winInputs, calc, cutList);

  it('leaves a fitting plate untouched (shrunk=false)', () => {
    expect(resolveAutoFitPlateDimensions({ plateW: 12, plateH: 12 }, safe)).toEqual({
      plateW: 12, plateH: 12, cutoutW: 9.5, cutoutH: 9.5, shrunk: false,
    });
    expect(resolveAutoFitPlateDimensions({ plateW: 8, plateH: 8 }, safe)).toEqual({
      plateW: 8, plateH: 8, cutoutW: 5.5, cutoutH: 5.5, shrunk: false,
    });
  });

  it('caps each axis independently at the safe-area extent (no aspect lock)', () => {
    const fitted = resolveAutoFitPlateDimensions({ plateW: 24, plateH: 12 }, safe);
    expect(fitted.shrunk).toBe(true);
    expect(fitted.plateW).toBeCloseTo(safe.xMax - safe.xMin, 12); // W capped
    expect(fitted.plateW).toBeCloseTo(15.697754214901326, 10);
    expect(fitted.plateH).toBe(12);                               // H untouched
    expect(fitted.cutoutW).toBeCloseTo(13.197754214901326, 10);
    expect(fitted.cutoutH).toBe(9.5);
  });

  it('point/empty safe area collapses the plate to 0x0 — but the cutout floor still reports 1x1', () => {
    // NOTE (pinned quirk / possible bug): cutoutFromPlate floors at 1", so a
    // fully-collapsed plate (0x0) still reports a 1x1 cutout — a hole larger
    // than the plate that would cover it. Recorded in the report's anomalies.
    expect(resolveAutoFitPlateDimensions(
      { plateW: 12, plateH: 12 },
      { xMin: 5, xMax: 5, yMin: 3, yMax: 3 },
    )).toEqual({ plateW: 0, plateH: 0, cutoutW: 1, cutoutH: 1, shrunk: true });
  });

  it('inverted safe area (xMax < xMin) clamps the extent at 0, not negative', () => {
    const fitted = resolveAutoFitPlateDimensions(
      { plateW: 12, plateH: 12 },
      { xMin: 6, xMax: 4, yMin: 6, yMax: 4 },
    );
    expect(fitted.plateW).toBe(0);
    expect(fitted.plateH).toBe(0);
    expect(fitted.shrunk).toBe(true);
  });
});

describe('resolveEffectiveWindowOffsets', () => {
  it('returns 0/0 when the window is disabled', () => {
    expect(resolveEffectiveWindowOffsets(makeInputs(), calc, cutList)).toEqual({ x: 0, y: 0 });
  });

  it('clamps legacy 0/0 saved offsets into the safe range (canonical 12x12)', () => {
    // The canonical chamber is not Y-centered on the panel, so a saved
    // (0,0) gets its Y pulled to the nearest fitting offset at render time.
    const eff = resolveEffectiveWindowOffsets(winInputs, calc, cutList);
    expect(eff.x).toBe(0);
    expect(eff.y).toBeCloseTo(-0.6099999999999994, 10);
  });

  it('clamps way-out-of-range saved offsets to the range edges', () => {
    const eff = resolveEffectiveWindowOffsets(
      makeInputs({ windowEnabled: true, windowXOffset: 999, windowYOffset: -999 }),
      calc,
      cutList,
    );
    expect(eff.x).toBeCloseTo(0.6193771074506635, 10);
    expect(eff.y).toBeCloseTo(-1.7910000000000004, 10);
  });

  it('passes through in-range saved offsets unchanged', () => {
    const small = makeInputs({
      windowEnabled: true, windowSize: 'custom',
      windowCustomWidth: 5, windowCustomHeight: 4,
      windowXOffset: -1, windowYOffset: 0.5,
    });
    expect(resolveEffectiveWindowOffsets(small, calc, cutList)).toEqual({ x: -1, y: 0.5 });
  });

  it('snapshot: effective offsets for the canonical variants', () => {
    const out: Record<string, { x: number; y: number }> = {};
    const cases: Array<[string, Partial<EnclosureInputs>]> = [
      ['default-12x12', { windowEnabled: true }],
      ['saved-999', { windowEnabled: true, windowXOffset: 999, windowYOffset: 999 }],
      ['saved-neg999', { windowEnabled: true, windowXOffset: -999, windowYOffset: -999 }],
      ['24x12-landscape', { windowEnabled: true, windowSize: '24x12' }],
      ['supb-default', { windowEnabled: true, enclosureConfiguration: 'Subs Up/Port Back' }],
    ];
    for (const [label, overrides] of cases) {
      const inp = makeInputs(overrides);
      const c = calculateEnclosure(inp);
      out[label] = resolveEffectiveWindowOffsets(inp, c, generateCutList(inp, c));
    }
    expect(out).toMatchSnapshot();
  });
});
