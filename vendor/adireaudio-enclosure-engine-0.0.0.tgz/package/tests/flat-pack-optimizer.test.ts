/**
 * CHARACTERIZATION tests for src/flat-pack-optimizer.ts.
 *
 * calculateOptimalStack smoke coverage + one full snapshot on the canonical
 * cut list (generated via generateCutList from the shared fixtures) so the
 * 2D bin-packing / box-dim / dim-weight pipeline is frozen end-to-end.
 * All expected values were observed by running the code.
 */
import { describe, it, expect } from 'vitest';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import {
  calculateOptimalStack,
  DEFAULT_FLAT_PACK_SETTINGS,
} from '../src/flat-pack-optimizer';
import type { CutListItem } from '../src/types/enclosure';
import { CANONICAL_S12 } from './fixtures';

const panel = (
  partName: string,
  width: number,
  height: number,
  material = '18mm Birch Ply',
  quantity = 1,
): CutListItem => ({ partName, width, height, quantity, material, thickness: 0.709 });

describe('DEFAULT_FLAT_PACK_SETTINGS', () => {
  it('pins the shipping constants', () => {
    expect(DEFAULT_FLAT_PACK_SETTINGS).toEqual({
      sidePadding: 0.5,
      verticalPadding: 0.5,
      birchDensity: 0.0246,
      mdfDensity: 0.029,
      packagingWeight: 3.0,
    });
  });
});

describe('calculateOptimalStack — smoke', () => {
  it('empty cut list → empty result carrying only packaging weight', () => {
    const r = calculateOptimalStack([], 'SD');
    expect(r.footprintLength).toBe(0);
    expect(r.panelCount).toBe(0);
    expect(r.layerCount).toBe(0);
    expect(r.packagingWeight).toBe(3);
    expect(r.totalShippedWeight).toBe(3);
    // NOTE (pinned quirk): billable weights stay 0 here even though
    // totalShippedWeight is 3 — the empty-result path skips the
    // max(total, dimensional) rule used everywhere else.
    expect(r.billableWeightUPS).toBe(0);
    expect(r.billableWeightUSPS).toBe(0);
    expect(r.stackedPanels).toEqual([]);
    expect(r.warnings).toEqual([]);
  });

  it('single 20x10 18mm birch Top panel — pinned box math', () => {
    const r = calculateOptimalStack([panel('Top', 20, 10)], 'SD');
    expect(r.footprintLength).toBe(20);
    expect(r.footprintWidth).toBe(10);
    expect(r.stackHeight).toBe(0.709);
    // box = footprint + 2×0.5 padding; exterior adds 14mm walls / 28mm flaps
    expect(r.boxLength).toBe(21);
    expect(r.boxWidth).toBe(11);
    expect(r.boxHeight).toBe(1.709);
    expect(r.exteriorLength).toBeCloseTo(21.5512, 10);
    expect(r.exteriorWidth).toBeCloseTo(11.5512, 10);
    expect(r.exteriorHeight).toBeCloseTo(2.8114, 10);
    // weight = 20·10·0.709·0.0246
    expect(r.panelWeight).toBeCloseTo(3.48828, 10);
    expect(r.totalShippedWeight).toBeCloseTo(6.48828, 10);
    expect(r.dimensionalWeightUPS).toBeCloseTo(5.0350802975281725, 10);
    expect(r.dimensionalWeightUSPS).toBeCloseTo(4.2161214539543135, 10);
    expect(r.billableWeightUPS).toBeCloseTo(6.48828, 10);   // actual > dim
    expect(r.billableWeightUSPS).toBeCloseTo(6.48828, 10);
    expect(r.layerCount).toBe(1);
    expect(r.panelCount).toBe(1);
    expect(r.fillerPieceCount).toBe(0);
    // packaging ply areas
    expect(r.pkgTopBottomArea).toBe(462);
    expect(r.pkgFrontBackArea).toBeCloseTo(29.778, 10);
    expect(r.pkgSidesArea).toBeCloseTo(14.18, 10);
    expect(r.pkgTotalArea).toBeCloseTo(607.1496, 10);
  });

  it('quantity expands into per-piece layers (2× full-footprint panels → 2 layers)', () => {
    const r = calculateOptimalStack([panel('Top', 10, 10, '18mm Birch Ply', 2)], 'SD');
    expect(r.panelCount).toBe(2);
    expect(r.layerCount).toBe(2);
    expect(r.stackHeight).toBeCloseTo(1.418, 10);
    expect(r.panelWeight).toBeCloseTo(2 * 10 * 10 * 0.709 * 0.0246, 10);
    expect(r.stackedPanels.map(p => p.stackPosition)).toEqual([1, 2]);
  });

  it('footprint falls back to the largest panel when no Top/Bottom exists', () => {
    const r = calculateOptimalStack(
      [panel('Side Left', 16, 14), panel('Back', 12, 6)],
      'SD',
    );
    expect(r.footprintLength).toBe(16);
    expect(r.footprintWidth).toBe(14);
    expect(r.warnings).toEqual([]);
  });

  it('warns (but does not throw) when a panel exceeds the footprint', () => {
    const r = calculateOptimalStack(
      [panel('Top', 10, 10), panel('Giant', 30, 12)],
      'SD',
    );
    expect(r.warnings).toEqual(['Panel "Giant" (30.0x12.0) exceeds footprint']);
    // the giant panel never lands in a layer
    expect(r.stackedPanels.map(p => p.partName)).toEqual(['Top']);
  });
});

describe('calculateOptimalStack — thickness matrix (via stackHeight)', () => {
  const single = (material: string, dutyType: string, partName = 'Top') =>
    calculateOptimalStack([panel(partName, 10, 10, material)], dutyType).stackHeight;

  it('pure 18mm / 24mm birch material strings', () => {
    expect(single('18mm Birch Ply', 'SD')).toBe(0.709);
    expect(single('24mm Birch Ply', 'SD')).toBe(0.945);
    expect(single('24mm Birch Ply', 'HD')).toBe(0.945);
  });

  it('mixed 18mm/24mm: HD → all 24mm; RD → Baffle 24mm, others 18mm', () => {
    expect(single('18mm/24mm Birch Ply', 'HD')).toBe(0.945);
    expect(single('18mm/24mm Birch Ply', 'RD', 'Baffle')).toBe(0.945);
    expect(single('18mm/24mm Birch Ply', 'RD', 'Top')).toBe(0.709);
  });

  it('MDF: HD (or heavy in the material string) → 1.0, otherwise 0.75', () => {
    expect(single('MDF', 'HD')).toBe(1.0);
    expect(single('MDF - Heavy Duty', 'SD')).toBe(1.0);
    expect(single('MDF', 'SD')).toBe(0.75);
    expect(single('MDF', 'RD')).toBe(0.75);
  });

  it('unknown materials default to 18mm birch (pinned: Acrylic ends up 0.709)', () => {
    expect(single('Acrylic', 'SD')).toBe(0.709);
  });

  it('MDF density (0.029) drives panel weight', () => {
    const r = calculateOptimalStack([panel('Top', 10, 10, 'MDF')], 'SD');
    expect(r.panelWeight).toBeCloseTo(10 * 10 * 0.75 * 0.029, 10);
  });
});

describe('calculateOptimalStack — canonical cut list', () => {
  const calc = calculateEnclosure(CANONICAL_S12);
  const cutList = generateCutList(CANONICAL_S12, calc);
  const result = calculateOptimalStack(cutList, 'SD');

  it('pinned headline numbers (SD, canonical S12)', () => {
    expect(result.footprintLength).toBe(20.625); // Top panel drives footprint
    expect(result.footprintWidth).toBe(18);
    expect(result.panelCount).toBe(8);
    expect(result.layerCount).toBe(8);           // every panel gets its own layer
    expect(result.stackHeight).toBeCloseTo(5.672, 10); // 8 × 0.709
    expect(result.panelWeight).toBeCloseTo(37.73420113024207, 10);
    expect(result.totalShippedWeight).toBeCloseTo(40.73420113024207, 10);
    expect(result.billableWeightUPS).toBeCloseTo(40.73420113024207, 10);
    expect(result.fillerPieceCount).toBe(11);
    expect(result.fillerWeight).toBeCloseTo(15.810510719322053, 10);
    expect(result.pkgTotalArea).toBeCloseTo(1525.5071999999998, 10);
    expect(result.warnings).toEqual([]);
  });

  it('stack order: Top, Bottom, Back, Baffle, Side Right, Side Left, PP1, PP2', () => {
    expect(result.stackedPanels.map(p => p.partName)).toEqual([
      'Top', 'Bottom', 'Back', 'Baffle',
      'Side Right', 'Side Left', 'Port Piece 1', 'Port Piece 2',
    ]);
  });

  it('full result snapshot (freezes the packing + filler layout)', () => {
    expect(result).toMatchSnapshot();
  });
});
