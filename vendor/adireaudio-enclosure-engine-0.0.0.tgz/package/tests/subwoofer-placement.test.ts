/**
 * CHARACTERIZATION tests for src/subwoofer-placement.ts (SUPB top-panel sub
 * cutout placement) — pins CURRENT behavior. Expected values were observed
 * by running the code against the shared CANONICAL_S12 fixture; do not
 * "fix" a value without a deliberate behavior change.
 */
import { describe, it, expect } from 'vitest';
import { makeInputs } from './fixtures';
import { calculateEnclosure, generateCutList } from '../src/calculations';
import {
  SUB_SAFETY_BORDER,
  OUTER_EDGE_SAFETY_BORDER,
  resolveSupbAutoCenterY,
  resolveAutoCenter,
  applyOffsets,
  computeSafeZone,
  getSafeOffsetRange,
  computeSubSafeCenterRect,
  checkSubwooferPlacement,
  findNearestSafeOffsets,
  resolveSupbSubLayout,
} from '../src/subwoofer-placement';

// ── Shared real-engine fixtures ─────────────────────────────────────────────
// Canonical S12 as SUPB (single port, single sub).
const supb = makeInputs({ enclosureConfiguration: 'Subs Up/Port Back' });
const calc = calculateEnclosure(supb);
const cut = generateCutList(supb, calc);

// Dual-sub SUPB variant (bigger box, 4 cuft).
const dualSub = makeInputs({
  enclosureConfiguration: 'Subs Up/Port Back', subwooferQuantity: 'Dual',
  netAirSpace: 4.0, boxHeight: 18, boxDepth: 20,
});
const calcDualSub = calculateEnclosure(dualSub);
const cutDualSub = generateCutList(dualSub, calcDualSub);

const staggeredDual = makeInputs({
  enclosureConfiguration: 'Subs Up/Port Back', subwooferQuantity: 'Dual',
  outsideDiameter: 10, subCutoutDiameter: 8.5,
  netAirSpace: 2.0, boxHeight: 18, boxDepth: 16, portWidth: 1.75,
});
const calcStaggeredDual = calculateEnclosure(staggeredDual);
const cutStaggeredDual = generateCutList(staggeredDual, calcStaggeredDual);

const straightDual = makeInputs({
  enclosureConfiguration: 'Subs Up/Port Back', subwooferQuantity: 'Dual',
  netAirSpace: 4.0, boxHeight: 18, boxDepth: 16, portWidth: 2,
});
const calcStraightDual = calculateEnclosure(straightDual);
const cutStraightDual = generateCutList(straightDual, calcStraightDual);

const noFitDual = makeInputs({
  enclosureConfiguration: 'Subs Up/Port Back', subwooferQuantity: 'Dual',
  outsideDiameter: 10, subCutoutDiameter: 8.5,
  netAirSpace: 1.5, boxHeight: 14, boxDepth: 16, portWidth: 1.25,
});
const calcNoFitDual = calculateEnclosure(noFitDual);
const cutNoFitDual = generateCutList(noFitDual, calcNoFitDual);

// Dual-PORT dual-sub SUPB variant.
const dualPort = makeInputs({
  enclosureConfiguration: 'Subs Up/Port Back', portQuantity: 'Dual',
  subwooferQuantity: 'Dual', netAirSpace: 4.0, boxHeight: 18, boxDepth: 20,
});
const calcDualPort = calculateEnclosure(dualPort);
const cutDualPort = generateCutList(dualPort, calcDualPort);

describe('safety constants', () => {
  it('pins the two safety borders', () => {
    expect(SUB_SAFETY_BORDER).toBe(0.25);
    expect(OUTER_EDGE_SAFETY_BORDER).toBe(0.5);
  });
});

describe('resolveSupbAutoCenterY', () => {
  it('S2-only with room to spare: legacy boxDepth/2 preserved', () => {
    expect(resolveSupbAutoCenterY({
      boxDepth: 18, portWidth: 1.75, wallT: 0.709, tBaffle: 0.709, tBack: 0.709,
      s1Depth: 0, useCombined: false, halfOD: 6.405, halfCutout: 5.595,
    })).toBe(9);
  });

  it('combined legacy cy below the valid window: clamps UP to validMin', () => {
    // legacy = (18 − 4 − 0.75)/2 = 6.625; outerMin = 6.5 + 0.5 = 7.0 binds.
    expect(resolveSupbAutoCenterY({
      boxDepth: 18, portWidth: 4, wallT: 0.75, tBaffle: 0.75, tBack: 0.75,
      s1Depth: 12, useCombined: true, halfOD: 6.5, halfCutout: 5.5,
    })).toBe(7);
  });

  it('combined legacy cy above the valid window: clamps DOWN to validMax', () => {
    // legacy = (20 − 2 − 0.7)/2 = 8.65; chamberMax = (0.7+8) − 3 − 0.25 binds.
    expect(resolveSupbAutoCenterY({
      boxDepth: 20, portWidth: 2, wallT: 0.7, tBaffle: 0.7, tBack: 0.7,
      s1Depth: 8, useCombined: true, halfOD: 3.5, halfCutout: 3,
    })).toBe(5.449999999999999);
  });

  it('bias window empty (sub too big for the outer borders): falls back to legacy', () => {
    // outerMin = 6.5 > outerMax = 5.5 → collapsed → legacy boxDepth/2 = 6.
    expect(resolveSupbAutoCenterY({
      boxDepth: 12, portWidth: 2, wallT: 0.709, tBaffle: 0.709, tBack: 0.709,
      s1Depth: 0, useCombined: false, halfOD: 6, halfCutout: 5,
    })).toBe(6);
  });
});

describe('resolveAutoCenter', () => {
  it('canonical SUPB single 12": falls back to the COMBINED chamber (S2 too narrow)', () => {
    const auto = resolveAutoCenter(supb, calc);
    expect(auto.useCombined).toBe(true);
    expect(auto.cx).toBe(9.057877107450663); // t + (s2+s1)/2
    expect(auto.cy).toBe(7.7705);
    expect(auto.chamberWidth).toBe(16.697754214901327);
  });

  it('dual-sub variant: S2 alone fits both subs (volume-derived s2LeftWidth)', () => {
    const auto = resolveAutoCenter(dualSub, calcDualSub);
    expect(auto.useCombined).toBe(false);
    expect(auto.cx).toBe(15.432694093610078);
    expect(auto.cy).toBe(10); // boxDepth/2
    expect(auto.chamberWidth).toBe(29.447388187220156);
  });

  it('dual port: box center, chamberWidth 0, never combined', () => {
    const auto = resolveAutoCenter(dualPort, calcDualPort);
    expect(auto).toEqual({
      cx: 16.92743803395599, // boxWidth/2
      cy: 10, // boxDepth/2
      chamberWidth: 0,
      useCombined: false,
    });
  });
});

describe('applyOffsets', () => {
  it('adds the user offsets to the auto center (unset → 0)', () => {
    expect(applyOffsets({ cx: 5, cy: 7 }, makeInputs({ subwooferXOffset: 1.25, subwooferYOffset: -0.5 })))
      .toEqual({ cx: 6.25, cy: 6.5 });
    expect(applyOffsets({ cx: 5, cy: 7 }, makeInputs())).toEqual({ cx: 5, cy: 7 });
  });
});

describe('computeSafeZone', () => {
  it('canonical SUPB single: combined front strip, capped at PP1 left face', () => {
    expect(computeSafeZone(supb, calc, cut)).toEqual({
      xMin: 0.709,
      xMax: 17.457,
      yMin: 0.709,
      yMax: 14.832,
      label: 'Combined S1+S2 chamber (front strip, left of PP1 / port channel)',
    });
  });

  it('dual-sub variant: S2-only zone spans the full depth', () => {
    expect(computeSafeZone(dualSub, calcDualSub, cutDualSub)).toEqual({
      xMin: 0.709,
      xMax: 23.957,
      yMin: 0.709,
      yMax: 19.291,
      label: 'S2 Left chamber (sub fits)',
    });
  });

  it('dual port: left chamber between the port channels', () => {
    expect(computeSafeZone(dualPort, calcDualPort, cutDualPort)).toEqual({
      xMin: 3.168,
      xMax: 4.241356565579512,
      yMin: 0.709,
      yMax: 19.291,
      label: 'Dual-port left chamber (S2 Left)',
    });
  });
});

describe('getSafeOffsetRange / computeSubSafeCenterRect — canonical single sub', () => {
  it('pins the slider min/max offsets', () => {
    expect(getSafeOffsetRange(supb, calc, cut)).toEqual({
      xMin: -2.1528771074506627,
      xMax: 2.554122892549339,
      yMin: -0.8654999999999999,
      yMax: 1.2165000000000017,
    });
  });

  it('pins the absolute safe-center rectangle (not collapsed)', () => {
    expect(computeSubSafeCenterRect(supb, calc, cut)).toEqual({
      xMin: 6.905,
      xMax: 11.612000000000002,
      yMin: 6.905,
      yMax: 8.987000000000002,
      collapsed: false,
    });
  });

  it('an oversized sub (30" OD in an 18"-deep box) collapses the rectangle', () => {
    const huge = makeInputs({
      enclosureConfiguration: 'Subs Up/Port Back', outsideDiameter: 30, subCutoutDiameter: 28,
    });
    const calcH = calculateEnclosure(huge);
    const cutH = generateCutList(huge, calcH);
    const rect = computeSubSafeCenterRect(huge, calcH, cutH);
    expect(rect.collapsed).toBe(true);
    expect(rect.xMin).toBeGreaterThan(rect.xMax);
    expect(rect.yMin).toBeGreaterThan(rect.yMax);
    // ...and there is no snappable safe placement at all.
    expect(findNearestSafeOffsets(huge, calcH, cutH, { x: 0, y: 0 })).toBeNull();
  });
});

describe('checkSubwooferPlacement — boundary pass/fail (canonical single sub)', () => {
  const range = getSafeOffsetRange(supb, calc, cut);

  it('default (no offsets) placement is safe at the auto center', () => {
    const res = checkSubwooferPlacement(supb, calc, cut);
    expect(res.safe).toBe(true);
    expect(res.center).toEqual({ cx: 9.057877107450663, cy: 7.7705 });
    expect(res.conflict).toBeUndefined();
  });

  it('just inside the +X limit: safe', () => {
    expect(checkSubwooferPlacement(supb, calc, cut, range.xMax - 0.01, 0).safe).toBe(true);
  });

  it('past the +X limit: cutout hits PP1 / port channel (chamber constraint binds)', () => {
    const res = checkSubwooferPlacement(supb, calc, cut, range.xMax + 0.01, 0);
    expect(res.safe).toBe(false);
    expect(res.conflict?.axis).toBe('x');
    expect(res.conflict?.side).toBe('max');
    expect(res.conflict?.overrun).toBeCloseTo(0.01, 10);
    expect(res.conflict?.label).toBe('Sub cutout would overlap PP1 / port channel / Side Right wall');
  });

  it('past the −X limit: flange overhangs the box left face (OUTER constraint binds)', () => {
    const res = checkSubwooferPlacement(supb, calc, cut, range.xMin - 0.01, 0);
    expect(res.safe).toBe(false);
    expect(res.conflict?.axis).toBe('x');
    expect(res.conflict?.side).toBe('min');
    expect(res.conflict?.label).toBe('Sub flange would overhang the box’s left face');
  });

  it('past the +Y limit: cutout hits the L-shape port leg at the back', () => {
    const res = checkSubwooferPlacement(supb, calc, cut, 0, range.yMax + 0.01);
    expect(res.safe).toBe(false);
    expect(res.conflict?.axis).toBe('y');
    expect(res.conflict?.side).toBe('max');
    expect(res.conflict?.label).toBe('Sub cutout would overlap PP2 / L-shape port leg at the back');
  });

  it('past the −Y limit: flange overhangs the box front face', () => {
    const res = checkSubwooferPlacement(supb, calc, cut, 0, range.yMin - 0.01);
    expect(res.safe).toBe(false);
    expect(res.conflict?.axis).toBe('y');
    expect(res.conflict?.side).toBe('min');
    expect(res.conflict?.label).toBe('Sub flange would overhang the box’s front face');
  });
});

describe('findNearestSafeOffsets — snap round-trips', () => {
  const range = getSafeOffsetRange(supb, calc, cut);

  it('already-safe desired offsets pass through unchanged', () => {
    expect(findNearestSafeOffsets(supb, calc, cut, { x: 0, y: 0 })).toEqual({ x: 0, y: 0 });
  });

  it('too far right: snaps back onto the +X limit and re-checks safe', () => {
    const snapped = findNearestSafeOffsets(supb, calc, cut, { x: range.xMax + 2, y: 0 });
    expect(snapped).toEqual({ x: range.xMax, y: 0 }); // x = 2.554122892549339
    expect(checkSubwooferPlacement(supb, calc, cut, snapped!.x, snapped!.y).safe).toBe(true);
  });

  it('too far forward: snaps onto the −Y limit and re-checks safe', () => {
    const snapped = findNearestSafeOffsets(supb, calc, cut, { x: 0, y: range.yMin - 1 });
    expect(snapped).toEqual({ x: 0, y: range.yMin }); // y = -0.8654999999999999
    expect(checkSubwooferPlacement(supb, calc, cut, snapped!.x, snapped!.y).safe).toBe(true);
  });
});

describe('multi-sub distribution (Dual subs, single port)', () => {
  it('rejects the old anomaly fixture because its Port Piece 2 is physically negative', () => {
    expect(cutDualSub.find(part => part.partName === 'Port Piece 2')!.width).toBeLessThan(0);
    const layout = resolveSupbSubLayout(dualSub, calcDualSub, cutDualSub);
    expect(layout.safe).toBe(false);
    expect(layout.diagnostic).toContain('Port geometry is invalid');

    const range = getSafeOffsetRange(dualSub, calcDualSub, cutDualSub);
    expect(range.xMin).toBeGreaterThan(range.xMax);
    expect(range.yMin).toBeGreaterThan(range.yMax);
    const res = checkSubwooferPlacement(dualSub, calcDualSub, cutDualSub);
    expect(res.safe).toBe(false);
    expect(res.conflict?.label).toContain('Port geometry is invalid');
    expect(findNearestSafeOffsets(dualSub, calcDualSub, cutDualSub, { x: 0, y: 0 })).toBeNull();
  });

  it('uses a minimal deterministic diagonal stagger when the straight row is just too wide', () => {
    const layout = resolveSupbSubLayout(staggeredDual, calcStaggeredDual, cutStaggeredDual, 0, 0);
    expect(layout.safe).toBe(true);
    expect(layout.mode).toBe('staggered');
    expect(layout.points).toHaveLength(2);
    expect(layout.points[0].x).toBeLessThan(layout.points[1].x);
    expect(layout.points[0].y).not.toBe(layout.points[1].y);
    expect(Math.hypot(
      layout.points[1].x - layout.points[0].x,
      layout.points[1].y - layout.points[0].y,
    )).toBeCloseTo(staggeredDual.outsideDiameter + SUB_SAFETY_BORDER, 6);
    expect(layout.gussets[0].x).toBeCloseTo((layout.points[0].x + layout.points[1].x) / 2, 12);
    expect(layout.gussets[0].y).toBeCloseTo((layout.points[0].y + layout.points[1].y) / 2, 12);
    expect(checkSubwooferPlacement(staggeredDual, calcStaggeredDual, cutStaggeredDual).safe).toBe(true);
    expect(calcStaggeredDual.baffleCheck.mountLabel).toBe('Top Panel (diagonal stagger)');
    expect(calcStaggeredDual.baffleCheck.isFail).toBe(false);
  });

  it('keeps the established straight row byte-stable when it already fits', () => {
    const layout = resolveSupbSubLayout(straightDual, calcStraightDual, cutStraightDual, 0, 0);
    expect(layout.safe).toBe(true);
    expect(layout.mode).toBe('straight');
    const wallT = cutStraightDual.find(part => part.partName === 'Side Left')!.thickness;
    const chamberW = calcStraightDual.s2LeftWidth;
    const gap = (chamberW - straightDual.outsideDiameter * 2) / 3;
    expect(layout.points).toEqual([
      { x: wallT + gap + straightDual.outsideDiameter / 2, y: 8 },
      { x: wallT + gap * 2 + straightDual.outsideDiameter * 1.5, y: 8 },
    ]);
  });

  it('translates both staggered subs and the gusset together', () => {
    const base = resolveSupbSubLayout(staggeredDual, calcStaggeredDual, cutStaggeredDual, 0, 0);
    const moved = resolveSupbSubLayout(staggeredDual, calcStaggeredDual, cutStaggeredDual, 0, 0.125);
    expect(moved.safe).toBe(true);
    expect(moved.points[0].x - base.points[0].x).toBeCloseTo(0, 12);
    expect(moved.points[1].y - base.points[1].y).toBeCloseTo(0.125, 12);
    expect(moved.gussets[0].x - base.gussets[0].x).toBeCloseTo(0, 12);
    expect(moved.gussets[0].y - base.gussets[0].y).toBeCloseTo(0.125, 12);
  });

  it('rejects valid port geometry when neither a straight nor staggered dual layout fits', () => {
    expect(calcNoFitDual.portLength2).toBeGreaterThan(0);
    expect(cutNoFitDual.find(part => part.partName === 'Port Piece 2')!.width).toBeGreaterThan(0);
    const layout = resolveSupbSubLayout(noFitDual, calcNoFitDual, cutNoFitDual);
    expect(layout.safe).toBe(false);
    expect(layout.diagnostic).toContain('do not fit safely');
    expect(calcNoFitDual.baffleCheck.mountLabel).toBe('Top Panel (no safe 2D layout)');
    expect(calcNoFitDual.baffleCheck.isFail).toBe(true);
  });
});

describe('dual port (Dual subs)', () => {
  it('default placement is unsafe — box-center cx sits far right of the left-chamber zone', () => {
    const res = checkSubwooferPlacement(dualPort, calcDualPort, cutDualPort);
    expect(res.safe).toBe(false);
    expect(res.center).toEqual({ cx: 16.92743803395599, cy: 10 });
    expect(res.conflict?.axis).toBe('x');
    expect(res.conflict?.side).toBe('max');
    expect(res.conflict?.overrun).toBe(20.844974229306395);
    expect(res.conflict?.label).toBe('Sub cutout would overlap PP1 / port channel / Side Right wall');
  });
});
