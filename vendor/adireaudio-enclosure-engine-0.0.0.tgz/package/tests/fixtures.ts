import { DEFAULT_INPUTS, DEFAULT_MATERIAL_CONFIG } from '../src/types/enclosure';
import type { EnclosureInputs } from '../src/types/enclosure';

export { DEFAULT_MATERIAL_CONFIG };

// Canonical single-12" ported box — realistic catalog-shaped values (≈ the
// BHS 2.0V2 S12: 2.0 cu ft net, 32 Hz). All characterization fixtures derive
// from this via overrides so snapshots stay comparable across test files.
// DO NOT tweak these numbers casually: every snapshot in the suite pins
// outputs computed from them.
export const CANONICAL_S12: EnclosureInputs = {
  ...DEFAULT_INPUTS,
  boxDepth: 18,
  boxHeight: 16,
  portWidth: 1.75,
  tuningFrequency: 32,
  netAirSpace: 2.0,
  subDisplacement: 0.15,
  subCutoutDiameter: 11.19,
  outsideDiameter: 12.81,
  size: '12"',
};

export function makeInputs(overrides: Partial<EnclosureInputs> = {}): EnclosureInputs {
  return { ...CANONICAL_S12, ...overrides };
}

/** The canonical characterization matrix used by the calc + cost suites. */
export const DUTY_TYPES = [
  'Birch Ply - Standard Duty',
  'Birch Ply - Regular Duty',
  'Birch Ply - Heavy Duty',
  'MDF - Standard Duty',
  'MDF - Regular Duty',
  'MDF - Heavy Duty',
] as const;

export const CONFIGURATIONS = [
  'Subs Back/Port Back',
  'Subs Up/Port Back',
  'Subs Up/Port Up',
] as const;

export const SUB_QUANTITIES = ['Single', 'Dual', 'Triple', 'Quad'] as const;
