# @adireaudio/enclosure-engine

Shared core for Adire Audio's enclosure calculator suite. Pure TypeScript — calc engine, DXF generator, cost calculator, types, 3D viewer, Zustand store, and supporting helpers.

Consumed by:
- **Calculator** (`enclosure-calculator-web`) — internal admin tool. Primary driver of engine changes.
- **Storefront** (`bassheadsupply-headless-woo`) — customer-facing custom enclosure designer. Receives engine updates passively.

## What lives here

```
src/
├── types/                   # EnclosureInputs, EnclosureCalculations, MaterialConfig, etc.
├── calculations.ts          # calculateEnclosure, generateCutList, baffle check
├── cost-calculator.ts       # cost pipeline + parsers
├── dxf-generator.ts         # DXF + ACC + barcode PDF generation
├── terminal-placement.ts    # terminal cup safe-zone math
├── subwoofer-placement.ts   # SUPB sub cutout safe-zone math
├── extra-holes.ts           # auto-calc helpers for ACC content
├── design-name-utils.ts     # name normalization + alias generation
├── flat-pack-optimizer.ts   # flat pack panel layout
├── eps-parser.ts            # EPS file parser
├── pocket-logo-toolpath.ts  # pocket/logo CNC toolpath generation
├── debug-log.ts             # shared debug logger
├── enclosure-store.ts       # Zustand store
├── enclosure-viewer-3d.tsx  # Three.js / R3F viewer
├── calculations-display.tsx # readout component
├── cut-list.tsx             # cut list component
└── index.ts                 # barrel export
```

**Stays in the consumers' `src/`:** React components specific to that app, API routes, page-level wrappers, Zustand selectors, anything that touches `localStorage`/Supabase/WC directly.

## Consuming

Ships TypeScript source. Consumers must add it to `transpilePackages` in `next.config.ts`:

```ts
transpilePackages: ['@adireaudio/enclosure-engine']
```

Consumer `package.json` pins to a specific commit SHA:

```json
"@adireaudio/enclosure-engine": "git+https://github.com/adireaudio8/enclosure-engine.git#<sha>"
```

Vercel needs a `GH_PAT` env var with `Contents:Read` on this repo for the install to fetch it. The consumers' `vercel-install.sh` shim handles auth via `git config url.insteadOf`.

## Workflow when modifying engine code

The calculator is the primary driver — almost all engine changes start there. The storefront gets updates passively, only bumped when a change actually affects it.

```bash
# 1. Edit + push the engine
cd Software\ Dev/enclosure-engine
# ...edit src/...
git add -A && git commit -m "fix: ..." && git push origin main
SHA=$(git rev-parse HEAD)

# 2. Bump the calculator
cd ../Enclosure\ Calculator\ -\ Web
# Edit package.json: change the engine #<old-sha> to #$SHA, then run
# `npm install` ON THE FULL SPEC to force lockfile re-resolution:
npm install "@adireaudio/enclosure-engine@git+https://github.com/adireaudio8/enclosure-engine.git#$SHA"
# Verify the lockfile picked up the NEW SHA (full 40 chars):
grep -A2 '"node_modules/@adireaudio/enclosure-engine"' package-lock.json
git add package.json package-lock.json
git commit -m "engine: bump to $SHA for <reason>"
git push origin main

# 3. Storefront — only bump if the change matters there
# (most calculator-driven engine work doesn't touch storefront-visible behavior)
```

**Why `npm install <spec>` instead of plain `npm install`.** The lockfile records each git dep's `resolved` URL with the full commit SHA. A plain `npm install` after a SHA bump in package.json doesn't always rewrite that — npm trusts the existing lockfile entry as long as the dep name matches. The result: package.json says #1c8fa9b, lockfile still says #e349180, npm fetches the OLD commit, Vercel deploys byte-identical bundles, and "the new feature isn't there." We ate this on 2026-05-03 (Wire-button removal silently failed to land for hours). Running `npm install` against the explicit `<name>@<spec>` form forces re-resolution and rewrites the lockfile entry.

**Vercel handles this automatically now.** The consumers' `vercel-install.sh` shim parses the engine spec out of package.json and re-installs it after the main install, so deploys force lockfile reconciliation. The local-dev step above is the only place this still matters.

**Calculator and storefront can be on different engine refs.** That's fine — they're independent consumers. Don't bump the storefront just to keep them in sync; only bump it when the change is relevant.

## Extraction phases (history)

All five complete as of 2026-05-02. See `EXTRACTION_LOG.md` for the per-phase migration history.

- [x] Phase 1: types
- [x] Phase 2: pure calc engine + helpers
- [x] Phase 3: cost calculator
- [x] Phase 4: DXF generator + supporting modules
- [x] Phase 5: 3D viewer + Zustand store + display components
- [x] Peer-dep loosening (`fbca118`): three.js 0.x ranges relaxed from `^` to `>=` so consumers can stay on different versions
