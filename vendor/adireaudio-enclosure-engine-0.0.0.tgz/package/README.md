# @adireaudio/enclosure-engine

Shared core for Adire Audio's enclosure calculator suite. Pure TypeScript — calc engine, DXF generator, cost calculator, types, 3D viewer, Zustand store, and supporting helpers.

## Default driver spacing leaves the brace its gap (2026-11-16)

Andrew, the same day, for the designs still refused. When drivers on a baffle are placed
automatically (no saved positions) and even spacing would leave the outside frames closer than
the brace's gap (`braceGapIn`, plus 1/4 in with flush mounting), `profileBaffleCenters` spaces
them by exactly that gap and shares the rest of the span equally between the two ends. A layout
whose even spacing already gives the brace its gap never moves, so no design that passes today
changes; if the spaced drivers would cross the panel's position limits (`bafflePositionBounds`),
the even layout stays and the brace message tells what the box lacks. Every consumer follows:
the layout verdict, the brace centres and their drilling, the cutting exports, the fit check and
the 3D viewer all read these centres. Subs Up/Port Back is unchanged. On Andrew's designs, 19 of
the 27 left refused now make their files, and none of the 227 that passed moved; 8 still need
box changes (two duals a little narrow, five dual 18 Subs Up whose port does not fit, the dual
6.5 too near a side edge). Coverage: `tests/brace-spacing-default.test.ts`.

## Frames on a baffle: 1/8 in past the top and bottom, and the brace's gap (2026-11-16)

Andrew, after a logo export refused 110 designs on the subwoofer layout check. For drivers on a
baffle (Subs Back/Port Back, Subs Up/Port Up), an outside frame may run up to 1/8 in past the
baffle's top and bottom edges (`BAFFLE_FRAME_OVERHANG_IN`): the top and bottom panels sit flush
around the baffle, so the frame rests on them, and its screws, nearer the cutout, stay in the
baffle. The side edges, the space between frames and flush (recessed) mounting keep 1/4 in; the
cutout keeps its own clearances. Two frames with a baffle brace between them need 1.25 in
heavy duty and 1 in regular and standard duty (`braceGapIn`, never less than the brace plus
1/8 in a side), in place of the brace plus 1/4 in a side. One module, `subwoofer-clearances.ts`,
gives these numbers to the layout verdict (and so the cutting exports and the fit check),
movement limits and the custom-outline check. A frame past the edge within the allowance is a
Tight Fit with its own message. That release left the default driver positions as they
were (the section above gives the spacing that followed). Subs Up/Port Back (drivers on the
top panel, whose edges are the outside of the box) and
its gussets are unchanged. On Andrew's designs 83 of the 110 now make their files; 27 still
need box changes (21 duals or triples with frames closer than the brace gap, 5 dual 18 Subs Up
whose port does not fit, one dual 6.5 too near a side edge). Coverage: `tests/fit-check.test.ts`,
`tests/brace-outside-diameter.test.ts`, the calculation snapshots (the new wording).

## Fit check and subwoofer depth (2026-11-13)

`checkDesignFit(inputs, calc, cutList)` (`fit-check.ts`) lists every reason a design
will not build, or only just fits, by part: Subwoofer (the drivers alone,
`calc.subwooferFit`, non-enumerable), Subwoofer depth, Port (a round port's own
reasons), Terminal cup (its place on its panel, the check the cutting files make,
and a side tube too close to it) and Window (as it will be cut: offsets kept in
the safe area; a plate made smaller is a warning). Status is the worst of them.
It only reports. `baffleCheck` keeps its meaning (the customer designer stops a
checkout on it); its `diagnostic` now gives the drivers' reason before a round
port's instead of only the port's.

`subwooferMountingDepth` (inches, optional): the subwoofer's depth from the face its
frame sits on to the back of its motor. Only the 3-D view and the fit check read
it; calculations and cut list do not change. The drivers are drawn that deep (the
model is stretched behind its mounting face; a custom outline gets a plain motor),
their motors red when too deep. `subwooferDepthCheck` compares it with the room:
`mountingDepthAvail` for drivers on the baffle (to the slot port's wall, a round
port's tube behind an opening, or the back panel); for Subs Up/Port Back, the
top's outside face to the bottom panel. Under 0.25 in to spare is a warning. A
round port's `mountingDepthAvail` is now measured from the baffle's outside face,
like a slot port's (it was from the inside face). Coverage: `tests/fit-check.test.ts`.

## Round flared port (2026-11-13)

`roundPortEnabled` replaces the slot with round tube port(s) flared on both ends,
on Subs Back/Port Back and Subs Up/Port Up designs with the single port setting,
not with kerf, forced labyrinth or flush mount (`roundPortGate`). Inputs:
`roundPortDiameter` (inside), `roundPortQuantity`, `roundPortFlareRadius`
(default 1.6 in), `roundPortWall` (0.125 in), `roundPortElbowRadius` (1.0 tube
diameters, to the centreline), `roundPortFlangeWidth` (0.75 in beyond the hole)
and `roundPortLocation`: `Baffle` (default, beside the drivers) or `Side Right`
(in the right side panel; the left side keeps the terminal cup).
`roundPortHeight` places the hole's centre above the bottom of the side panel,
`Side Right` only; missing means centred.

Length: face to face, flares included. A flare counts for the integral of throat
area over local area, the end allowance is the slot formula's 1.463 x radius
scaled by throat/mouth area, and an elbow counts for slightly less than its
centreline; with no flare this is exactly the slot formula. A tube that would end
within one diameter of the far wall gets one 90-degree elbow, its second leg along
the back wall (baffle) or forward along the left wall (side). The outside of tube,
flares and elbow inside the box comes out of the airspace; box width follows.
Agrees with the November 2026 flow simulations within 1-3 %; not yet measured.

The baffle spans the box, both sides sit between baffle and back, and there are
no port panels. `calc.roundPort` (non-enumerable, kept by `snapshotRenderGeometry`)
gives the location and the port centres on its panel. For the side,
`round-port-side.ts` checks the tube against the terminal cup and posts (0.5 in),
the cup's plate and braces (0.25 in), measures mounting depth (from the baffle's
outside face) to the nearest part of a tube behind a driver opening, and centres the drivers between an elbowed
tube's inner flare and the right side when they fit and gain at least 1/8 in of
depth (`placeDriversRightOfTube`). Positions set by hand are never moved.

Refuse, do not repair: holes or flanges that do not fit, a height outside its
range, a second leg within a diameter of the far wall or the baffle, a box too
small for the elbow and any collision above fail the design with a plain
`diagnostics` message; nothing is moved or clamped. Cutting files are refused for
every round-port design: `generateAllFiles` and `generatePartDxf` throw
`ROUND_PORT_CUTTING_FILES_MESSAGE`. Slot designs are unchanged. Coverage:
`tests/round-port*.test.ts`. The calculator and the customer designer pin the
same revision; the designer offers no round-port control.

## Independent finishing labor (2026-11-05)

`parseCostSettings` resolves four independent rates: Performance Birch/MDF and
Foundation Birch/MDF. `calculateFinishingCost` is shared by live Build and saved
design costs. Each explicit rate is dollars per exterior square foot; zero is
valid and does not fall back to another material. Foundation has sanding labor
and no finishing materials. Flat Pack remains zero finishing.

Missing keys migrate from the legacy Birch/MDF rates, including the former
25% Birch / 30% MDF Foundation factors, preserving current cost estimates.
Those factors are migration defaults only. Settings parsed/saved with all four
keys remain independent when one rate changes. Existing finishing-material
rules are preserved. No retail/dealer price, geometry, or manufacturing changes.
Validation: 950 engine tests and TypeScript pass. Both active consumers must
adopt the same revision.

## Product-photo export angles (2026-10-28)

PNG exports now use Front-Left (34 degrees left, 21 degrees up), Front-Right
(41 degrees right, 22 degrees up), and Front (centered, 25 degrees up), matching
the three whole-box views on the American Bass Dual 12 King listing. `Front`
replaces `Rear-Left` in the third filename. Both clean and dimensioned variants
use these export-only presets; the optional acrylic-window view is retained.
Interactive Reset, lens/zoom scale, lighting, driver display, CNC geometry,
pricing and saved data are unchanged. No terminal-cup close-up is added.
939 tests and typecheck pass; actual six-image 2560 x 1920 captures were inspected
for all three enclosure configurations. Both consumers must adopt this revision.

## Window-specific preview hosts (2026-10-28)

`EnclosureViewer3D` accepts an optional `onPopout` callback. When supplied, the
host opens and synchronizes its own preview; the viewer does not write the global
calculator storage or open the unscoped viewer route. Existing consumers that
omit it retain their previous behavior. Calculation and manufacturing geometry
are unchanged. The web calculator uses this hook for independent employee windows.

## Side Left terminal placement and roundover (2026-10-27)

`resolveTerminalPlacementOffset` now uses the finished Side Left cut-list width
and actual Port Piece 2 stock. The shared automatic formula drives preview,
controls, validation, full/guide exports and direct part exports. Explicit saved
offsets, including zero, remain authoritative. SUPP still centers the rotated
opening across panel height; other orientations retain their 2.125-inch bottom
clearance. The calculator adopts the resolved automatic offset when customization
is enabled, with no jump or browser slider rounding of that saved value.

`SideLeftTerminalPreview` uses the same watertight surface as Back/Top, combining
the opening and outside quarter-circle lip so rotation/shift cannot separate them.
Nominal opening and screw spacing stay unchanged. HD automatic SUPP exports now
shift the cup and its two mounting holes by the thick-minus-thin stock difference
(0.236 inch for default birch, 0.250 inch for MDF). No 8 mm router dowels, ACC,
panel sizes, rear terminals, stored designs or historical nests are rewritten.
Regenerate Side Left DXFs to use the corrected automatic HD position.

932 tests pass, including all six duties/materials, saved milling/glue/stock,
automatic/custom agreement, the actual preview transform, ray-cast roundover
checks, unchanged drilling and historical non-terminal manufacturing geometry.
Typecheck passes; lint retains two existing viewer-hook warnings, zero errors.
Both consumer revisions must move together as described below.

## Automatic cardboard layout (2026-10-26)

`getCardboardLayout` selects one, two, then four pieces against 96 x 48-inch
stock, preserving the 1.5-inch left datum and checking both rotations.
`generateCardboardFiles` is the shared full/box-only export entry point.
Four-piece cartons have two Long and two Short wall blanks, each with a
45 mm glue tab and end flaps. DXFs keep the `SplitBox-` prefix; the distinct
XXL stems start `B1` / `B2`, with descriptor keys `box:long` / `box:short`.

## Logo and carton program names (2026-11-17)

One rule for both, 14 characters at most (`logoXxlFilename`, `boxXxlFilename`):
letter + brand (lower case) + MODEL (capitals) + size (lower case) + markers.
Letters: `L` logo, `B` carton, `B1` / `B2` four-piece walls. Markers only when
they apply: `u` SUPB, `f` flat pack (cartons only), `c1`/`c2` custom, `m` MDF.
Series and duty are left out, so identical programs share a name. A long name
shortens the model, then the brand; never the size or a marker. Examples:
`BHSP-DC-LVL3-D10-RD` → `LdcLVL3d10` / `BdcLVL3d10`;
`BHSF-SUN-SAV3-D12-RD-MDF` → `LsunSAV3d12m` / `BsunSAV3d12m`.
The old carton rule (`B_` + the whole name cut at 14) gave 99 names to designs
of different sizes. Barcodes follow the names; regenerate logo and carton
programs to adopt them. Coverage: `tests/dxf-naming.test.ts`.
Sheet cost follows 1/2/4 pieces. If even four will not fit, export reports it.
Existing 350 DW machine cutting/scoring depths are retained; a first carton
assembly and material/setup check remain necessary. No shipping service or
carton strength rating is implied. Coverage: `tests/cardboard-layout.test.ts`.

## Rear terminal corners and roundover (2026-10-25)

Original Back and SUPP Top terminal openings share `TerminalPanelPreview`.
Rounded corners use smooth normals and explicit boundary outlines, removing
the dense facet lines from the former Top mesh. R/O now creates a real
outside-only quarter-circle lip (1/4 inch); the nominal 4.5 by 2.75 inch
through opening and 3/8-inch corners remain unchanged beneath it.
Panel orientation, full Back width, floor-relative height and backing plate
are preserved. No manufacturing dimensions, DXF, ACC, stock or stored inputs
change. Tests check watertight geometry, winding, normals, outline segments
and ray-cast lip depth. All 907 tests and typecheck pass; lint retains only
the two pre-existing viewer hook warnings. Side Left's separate lip and
automatic offset mismatch remain outside this rendering correction.

## Rear-wall terminal placement (2026-10-24 height correction)

`terminalPanel: 'Top'` places the cup on the upright rear wall for Subs Up/Port Up.
The opening is 4.5 by 2.75 inches; its bottom sits a fixed 2.125 inches above the
inside floor. Add the full stock thickness of cut-list Back (SUPP's floor),
not its milled edge or a glue allowance. HD birch: opening bottom 3.070 inches,
center 4.445 inches above the outside bottom. Top DXF coordinates use
`X = panelWidth / 2 - physicalOffset` and `Y = panelDepth - floorStock - 3.5`
for the center, matching Top's existing X mirroring, and mirror
the mounting-hole row to physical up. Preview and DXF share that center.
The full 6.5 by 4.75 inch mounting plate clears assembly walls/braces by 1/8 inch;
the safety check uses actual duty stock, saved milling/glue, port returns and
labyrinth dividers. Invalid or incomplete Top geometry blocks exports.
Top is supported only in Subs Up/Port Up; switching configuration requires a
different terminal panel. Existing Back values/defaults retain their original
cut-list identity (underneath in SUPP). The Back-with-cup preview now retains
the full Back width instead of subtracting both side thicknesses.
Saved design parsing retains Top and None. No stored designs are migrated.
Tests cover all six duty/material combinations, exact cutout/mounting-hole
coordinates, unchanged 8 mm drilling and ACC, persistence and clearance guards.
The backing plate and clearance checks use the same raised height. Existing
exports are not rewritten; regenerate the Top files to apply the height change.
The separate automatic SUPP Side Left offset mismatch remains pending: the
viewer uses box depth and duty PP2 stock, while DXF uses finished Side Left
width and thin stock. This height correction does not change that legacy path.

## Preview camera and frame dimensions (2026-10-23)

Reset restores world-up, zoom, current box center and viewport-aware framing;
it clears pending orbit motion and cancels view-cube animation. OrbitControls
is now the default control shared by the cube. The 35-degree lens reduces
perspective exaggeration. Dims: Full draws outside-frame outlines at every
actual driver center and reports frame/cutout dimensions and measured spacing.
The generic cone/basket remains illustrative. Manufacturing geometry, drilling,
fit rules and exported cutting files are unchanged. 875 tests and typecheck pass;
lint retains only the two existing viewer hook warnings.

## Brace clearance outside the driver frames (2026-10-23)

Front baffle braces now follow the midpoint between adjacent driver centers.
Reserve the actual brace stock thickness plus 0.25 inch clear of each outside
frame, including flush recess expansion. The same geometry controls fit,
movement limits, viewer, baffle/plate router dowels and cutting exports. Top
braces likewise clear the full outside frame and keep their shared DXF/ACC datum.
Automatic and manual fit verdicts agree, including Tight Fit and flush height.
Typed coordinates, sliders and nudges use one movement helper; other drivers
never move as a side effect. Tests cover all six duties/materials, Single through
Quad, moving drilling and the automatic round labyrinth opening.

Previously accepted layouts with a brace below the frame can now fail fit.
Regenerate a complete matched cutting set after changing positions; do not mix
old baffle/plate drill files with new brace locations. Panel dimensions, tuning,
stored designs and historical nests are not changed by this release.

## Independent driver positions (2026-10-23)

`subwooferPositions` now supports one center per driver, Single through Quad,
for every mounting orientation. Coordinates are inches on the finished mounting
panel: SUPB uses Top X from Side Left / Y from the front; SBPB and SUPP use
baffle X from left / Y from bottom. DXF margins and Top mirroring are applied
only during export. The viewer, flush plate/cap and custom EPS openings retain
both coordinates. The brace-clearance follow-up above also checks automatic layouts.

`resolveSubwooferLayout` validates requested positions without moving other
subs. It rejects malformed counts, nonfinite centers, frame/recess collisions,
chamber/port conflicts and brace conflicts. Cutting tolerance is checked at
export, including single-part DXF and ACC-only exports. SUPB triple/quad braces
share a depth datum for ACC 08 and use the same centers for Top/Bottom drilling.
Front baffle braces and their router dowels follow adjacent driver midpoints.
Dual-port Top layouts conservatively stay ahead of both
return walls. Native EPS curve conversion is unchanged.

Changing quantity preserves remaining driver indices and seeds new controls.
Changing between Top and baffle resets positions because the coordinate frame
changes. Full design loads preserve saved overrides and clear absent ones.
`tests/independent-all-subwoofers.test.ts` covers the duty/material/orientation
matrix, persistence, flush construction, native profiles and DXF/ACC alignment.

## Nominal Top/Bottom cutting outlines (2026-10-21)

Top and Bottom now cut at their nominal cut-list dimensions, including guide
DXFs, all duties, birch and MDF. The former 1/32-inch-per-edge trim allowance
has been removed. Hole coordinates, milling, openings, ACC programs and nominal
panel calculations are unchanged. The existing manufacturing baseline protects
all geometry outside the single outer profile; it was not regenerated.

## Frozen custom subwoofer profiles (2026-10-19)

October 20 follow-up: version-2 profiles retain the parsed EPS
`sourcePath` in centered inches. Custom cutting DXF uses the exact same
`epsPathToPolylineVertices` curve converter as logo `epsPathsToDxfEntities`;
the latter's output remains unchanged. Native arcs survive cutout allowance
and mirroring; sampled polygons are only for fit/area/display. Version-1
profiles remain readable but cannot generate new cutting files without
explicitly re-uploading the source EPS and updating the design. XXL validation
belongs in the consumer and must not reconstruct these curves. No database
migration or automatic saved-design rewrite is part of this change.

`subwooferCutoutProfile` stores a versioned, centered inch-based opening contour
and outside-frame dimensions in design inputs. The calculator imports it through
the existing EPS parser; the engine validates the geometry and uses the same
outline in area calculations, fit checks, preview, flush parts and closed DXF
polylines. Total machining clearance offsets the full opening by half the value.
Saved inputs never consult the live model library. Circular designs retain the
existing path. Custom top layouts search one/two-row grids, with conservative
dual-port bounds and explicit brace checks. The generic frame silhouette is not
a physical driver/basket model. See `tests/subwoofer-profile.test.ts` for geometry
and manufacturing contracts.

Consumed by:
- **Calculator** (`enclosure-calculator-web`) — internal admin tool. Primary driver of engine changes.
- **Customer website designer** (`bhs_enclosure_designer`) — Vercel-hosted custom enclosure designer exposed through Shopify at `/apps/enclosure-designer`. It installs a vendored npm tarball built from this repo.

## Parallel-consumer release invariant

The calculator and customer website designer must remain on the **same full engine commit** whenever either consumer advances its engine. An engine update is not complete when only one consumer has moved.

- The calculator records the engine revision as a full git SHA in `package.json` and `package-lock.json`.
- The designer packages this repo with its `sync:engine` script, stores the tarball at `vendor/adireaudio-enclosure-engine-0.0.0.tgz`, and refreshes its provenance and `package-lock.json`.
- Both consumers must pass their checks, be pushed and deployed, and the live Shopify route `/apps/enclosure-designer` must be verified before the engine release is closed.
- The customer app intentionally exposes fewer controls and no manufacturing-only cut-list, cost, or DXF/CNC surfaces. That UI distinction does not permit engine-revision drift.

## Enclosure series identity (2026-09-11)

`canonicalDesignName` keeps BHSP (Performance), BHSF (Foundation), and BHSS
(Select) as separate identities. Historical unprefixed enclosure names resolve
only to Performance. BHS remains a brand code. Material, duty, custom and size
tokens are retained. `generateModelNumber` now includes the series, defaults to
Performance, and accepts an explicit series when creating a variant. The store
preserves Foundation/Select when loading and editing designs.

Compact machine-program identifiers and existing printed barcodes retain their
established geometry-based format; they are references to the prefixed design,
not additional catalog identities. Consumers must retain legacy-name reads
while converting their catalog and inventory records.

## Manufacturing profiles (October 2026)

`manufacturing-profile.ts` resolves versioned stock, milling-depth and glue
settings. New mating geometry derives finished thickness from full stock minus
milling depth, ignoring legacy C1/C2 and manual Port 2 offset fields. Defaults
match existing CNC depths: SD/RD 0.864 mm, HD 0.762 mm. MDF is not milled.
Glue clearance is per mating edge; ordinary folded Port 2 placement derives
from glue minus milling depth. Saved profiles are authoritative; consumers
resolve current global defaults when loading legacy designs.

`generateAllFiles` recalculates from the supplied inputs/profile and emits a
manufacturing record. DXF comments carry milling requirements for downstream
nesting/CAM checks without renaming machining layers. Consumers must preserve
these comments during nesting. The calculator checks them against Cut operation
depths; Build does not change router operations automatically.

`manufacturing-profile.test.ts` independently checks assembled dimensions and
DXF/ACC drilling across all duties, materials, orientations, single/dual ports
and flush variants. The original trim baseline remains historical; the reviewed
manufacturing-v1 baseline records the intentional geometry changes.

## What lives here

### Viewer specifications and annotated renders (2026-10-15)

Full dimensions shows total net airspace, requested tuning and total port area.
Only dual-port enclosures add an Each port row; driver quantity does not affect
the displayed port count. Every preset PNG includes these values in a reserved
bottom-right box, with the geometry and dimension labels fitted above it.
`captureEnclosureRenderSet` freezes the render geometry for the set, explicitly
preserving non-enumerable labyrinth data. Its preset angles, clean/dimension
variants and acrylic-window feature views remain shared by both apps.
`EnclosureViewer3D` accepts optional `toolbarActions` so the calculator pop-out
can offer its image-only ZIP download without adding app dependencies here.

### Automatic triple/quad SUPB placement (2026-10-15)

Single-port Subs Up / Port Back now preserves valid straight rows, then searches
two-row grids and staggered layouts for three or four drivers. Both orientations
and the curved PP2 corner are checked against actual cut-list geometry. It never
changes enclosure size, tuning, volume or port dimensions to manufacture a fit.
New arrangements retain 0.5-inch outer flange margin, 0.25-inch flange gap and
0.25-inch cutout-to-wall clearance. The existing n-1 upright five-inch braces
are positioned in remaining solid wood; they keep a common depth center and
at least five inches between centers, with 0.25-inch clearance at holes/walls.
Labyrinth braces remain entirely outside the maze band.

The same final centers drive fit, preview, Top/Bottom dowels, cutouts and ACC 08.
Multi-row full **and ACC-only** exports include `*-Subwoofer-Layout.txt` with
physical coordinates and the explicit ACC depth reference; do not assume that
brace Y equals either subwoofer row. Existing ACC program numbers/formats stay
unchanged. Unsafe automatic layouts show display-only drivers in an
approximate arrangement and a port/placement diagnostic. This sketch never
supplies holes, braces, a passing fit verdict or CNC coordinates. Exported images retain
a failed-fit banner. Valid layouts keep their certified centers. Manual dual
overrides and other configurations retain their established controls.

Fit spacing uses the actual displayed centers: minimum flange distance to all
four panel edges and minimum Euclidean flange gap across every driver pair.
`clearanceBasis` distinguishes resolved layout, display-only preview, and
unavailable measurements. When the physical solver rejects a port before
placing drivers, the preview sketch can still report its measured spacing, but
`isFail`, the diagnostic, and manufacturing guards remain unchanged. Never
display the old single-row formula for an unresolved stagger or grid.

Driver color represents the measured surface spacing separately from the
overall fit: normal materials when edge clearance and inter-driver gap are
finite and nonnegative, amber when either is negative or unavailable. A port
or brace error alone does not recolor drivers. Approximate placement notices,
failed-fit image banners, and all manufacturing guards remain in place.

The unresolved quad preview prefers a clear row, then a square 2x2 grid, then
an equal-step zigzag with three equal neighboring diagonal flange gaps. It
centers the rows within the available depth and retains the known straight
port-wall boundary. If no balanced arrangement clears, the bounded fallback
search remains. This changes approximate preview centers only; resolved
production layouts and machining coordinates are unchanged.

The reported Audio Control quad-12 at 16-inch height, 24-inch depth, 7 cu ft,
7-inch port and 34 Hz still fails: PP2 is -1.814124 inches. Separate test inputs
at 32 Hz demonstrate a stagger; 28-inch depth/28 Hz demonstrate a 2x2 grid. These
are test alternatives, not silent edits or approved production dimensions.

### Independent dual SUPB centers (2026-10-05)

Dual-sub, single-port Subs Up / Port Back layouts can save two absolute
`subwooferPositions` centers (inches: X from Side Left, Y from front).
These override legacy shared offsets; omitting them restores automatic placement.
The solver preserves existing valid rows/staggers, then searches the curved
cutout-clearance boundary around the PP2 corner when the rectangular search fails.
It retains the 0.5-inch flange-to-outer-edge and 0.25-inch cutout-to-wall margins,
requires 0.25 inch between independently placed flanges, and checks the existing
5-inch midpoint gusset. Labyrinth layouts retain their unobstructed chamber band.

Calculations, viewer holes/drivers/gussets, DXF cutouts, Top/Bottom drilling and
ACC gusset programs consume the same final centers. Unsafe finite manual positions
remain visible for correction; full and ACC-only exports reject them. Save/load
and browser persistence retain exact precision; reset clears all placement overrides.
Single/triple/quad and dual-port layouts retain their existing controls.

The reported 39.5605 × 22.5 × 21-inch SAV3 dual-15 now finds a stagger without
enlarging the box (0.2585-inch flange gap, still classified Tight Fit).
Regression tests cover that geometry, independent movement, invalid positions,
saved-data replacement and matched manufacturing coordinates, including flush mounting.

### Optional dowel channels (layout revised 2026-09-27)

`EnclosureInputs.addDowChannels` is opt-in per design. Full exports add directed
`DOW_CHANNEL_RAMP_0_4` LINEs at Bottom sockets for Side Left, Side Right and
Port 1. Each Bottom line starts 0.5 inch toward the front/baffle from its socket
and ends at the socket center (local Y - 0.5 inch to Y), deepening toward the
back. Existing Baffle channels retain their original local Y + 0.5 inch to Y
direction. Back, Port Piece 2, Top and other Bottom sockets have no channels.
Original holes, their depths and the Top/Bottom trim allowance remain unchanged.

Consumers must preserve line direction through nesting and use tool 107 with
the 3/8-inch cutter for a surface-to-0.4-inch ramp. The calculator uses four
passes ending at 0.1, 0.2, 0.3 and 0.4 inch. Disabled design output is unchanged.
Saved DXFs, nests and XXLs are not rewritten: regenerate DXFs, re-nest, then
regenerate XXLs to adopt the revised layout. Physical machining acceptance is
still required.

### Short manufacturing program codes

Generated ACC, logo XXL, and carton XXL files carry operation/material metadata.
The calculator's server registry assigns immutable eight-character codes from
`23456789ABCDEFGHJKMNPQRSTUVWXYZ`. `applyManufacturingCodes` changes only the
filename; machine program bytes and geometry stay unchanged. The optional code
map in `generateAccBarcodesPdf` must come from the same registered release.
Missing, malformed, or duplicate codes fail the export. Legacy naming remains
the default, and enclosure QR codes are independent of these machine codes.

The engine does not allocate codes or decide which release a physical item uses.
Those responsibilities belong to the calculator's database and authenticated API.

```
src/
├── types/                   # EnclosureInputs, EnclosureCalculations, MaterialConfig, etc.
├── calculations.ts          # calculateEnclosure, generateCutList, baffle check
├── carton-dimensions.ts     # canonical assembled-carton clearance formula
├── cost-calculator.ts       # cost pipeline + parsers
├── dxf-generator.ts         # DXF + ACC + barcode PDF generation
├── terminal-placement.ts    # terminal cup safe-zone math
├── subwoofer-placement.ts   # SUPB sub cutout safe-zone math
├── extra-holes.ts           # auto-calc helpers for ACC content
├── labyrinth-port.ts        # automatic serpentine slot-port resolver
├── round-port.ts            # round flared port: length, elbow, airspace, panel layout
├── round-port-side.ts       # side-mounted round port: clearances, depth, driver placement
├── design-name-utils.ts     # name normalization + alias generation
├── flat-pack-optimizer.ts   # flat pack panel layout
├── eps-parser.ts            # EPS file parser
├── pocket-logo-toolpath.ts  # pocket/logo CNC toolpath generation
├── debug-log.ts             # shared debug logger
├── enclosure-store.ts       # Zustand store
├── enclosure-viewer-3d.tsx  # Three.js / R3F viewer
├── calculations-display.tsx # readout component
├── cut-list.tsx             # cut list component
└── index.ts                 # barrel export
```

**Stays in the consumers' `src/`:** React components specific to that app, API routes, page-level wrappers, Zustand selectors, anything that touches `localStorage`/Supabase/WC directly.

## Consuming

Ships TypeScript source. Consumers must add it to `transpilePackages` in `next.config.ts`:

```ts
transpilePackages: ['@adireaudio/enclosure-engine']
```

The calculator's `package.json` pins to a specific commit SHA:

```json
"@adireaudio/enclosure-engine": "git+https://github.com/adireaudio8/enclosure-engine.git#<sha>"
```

The calculator's Vercel project needs a `GH_PAT` env var with `Contents:Read` on this repo; its `vercel-install.sh` handles auth via `git config url.insteadOf`. The customer designer does not clone this private repo during deployment—it vendors the `npm pack` tarball and must record/verify that the tarball was built from the same engine commit as the calculator pin.

## Workflow when modifying engine code

The calculator is the primary driver for many engine changes, but the calculator and customer designer are one engine release unit. Every revision adopted by either consumer must be propagated to the other in the same work.

```bash
# 1. Edit + push the engine
cd Software\ Dev/enclosure-engine
# ...edit src/...
git add -A && git commit -m "fix: ..." && git push origin main
SHA=$(git rev-parse HEAD)

# 2. Bump the calculator
cd ../Enclosure\ Calculator\ -\ Web
# Edit package.json: change the engine #<old-sha> to #$SHA, then run
# `npm install` ON THE FULL SPEC to force lockfile re-resolution:
npm install "@adireaudio/enclosure-engine@git+https://github.com/adireaudio8/enclosure-engine.git#$SHA"
# Verify the lockfile picked up the NEW SHA (full 40 chars):
grep -A2 '"node_modules/@adireaudio/enclosure-engine"' package-lock.json
git add package.json package-lock.json
git commit -m "engine: bump to $SHA for <reason>"
git push origin main

# 3. Package the SAME engine commit for the customer website designer
cd ../bhs_enclosure_designer
npm run sync:engine -- --engine-dir ../enclosure-engine
npm install "@adireaudio/enclosure-engine@file:vendor/adireaudio-enclosure-engine-0.0.0.tgz"
npm run verify:engine-parity
npm run typecheck
npm run build
# Commit the tarball + provenance + package-lock.json, push main, deploy,
# and verify https://bassheadsupply.com/apps/enclosure-designer.
```

**Why `npm install <spec>` instead of plain `npm install`.** The lockfile records each git dep's `resolved` URL with the full commit SHA. A plain `npm install` after a SHA bump in package.json doesn't always rewrite that — npm trusts the existing lockfile entry as long as the dep name matches. The result: package.json says #1c8fa9b, lockfile still says #e349180, npm fetches the OLD commit, Vercel deploys byte-identical bundles, and "the new feature isn't there." We ate this on 2026-05-03 (Wire-button removal silently failed to land for hours). Running `npm install` against the explicit `<name>@<spec>` form forces re-resolution and rewrites the lockfile entry.

**Calculator Vercel handles its git pin defensively.** The calculator's `vercel-install.sh` parses the engine spec out of `package.json` and re-installs it after the main install, so calculator deploys force lockfile reconciliation. The designer's vendored tarball has no equivalent automatic GitHub refresh; its tarball, provenance, and lockfile must be updated explicitly for every parallel engine release.

**Designer tarball integrity gotcha:** replacing the `.tgz` without changing its file path leaves the old integrity hash in `package-lock.json`; a plain `npm install` can fail with `EINTEGRITY`. Reinstall the full explicit file spec shown above so npm rewrites the integrity and adds any new transitive dependencies.

**Calculator and customer designer may not remain on different engine refs.** If a consumer cannot be updated and validated, do not call the engine release complete or deploy the other consumer as the finished engine update. Record the blocker and keep the parity work open.

## Carton clearance contract

## Shipping weight policy (2026-09-07)

Packaged shipping and billable weights always round **up** to whole pounds
using `roundShippingWeight`: 62.1 becomes 63; 73 stays 73. Apply this after
adding packaging, not to individual panels or raw enclosure mass. Dimensions
remain fractional inches; this policy does not round carton geometry.

### Carton dimensions

`calculateCartonDimensions` owns the standard assembled-enclosure carton
formula. It preserves the original allowances (depth + 1.125 inches, height +
1.000 inches, rounded box width + 1.1875 inches) and then adds 3.3 mm at each
opposing side, or 6.6 mm to every finished carton dimension. Consumers should
call this helper instead of duplicating those offsets. Flat-pack shipping uses
its separate panel-stack optimizer and is not changed by this rule.

## Automatic labyrinth slot ports

The engine automatically replaces the normal one-fold PP1/PP2 layout with a
serpentine divider layout when the legacy volume solve would make the remaining
S2 chamber negative. This is derived geometry: it is recalculated from the
enclosure inputs and is deliberately not serialized into saved calculation
rows. A saved `forceLabyrinthPort` input can also activate the same resolver
manually for an otherwise valid single, non-kerf port with a second leg; leaving
the input false or absent preserves automatic behavior.

Current manufacturing-review boundary (2026-08-07):

- Calculation, box-width solve, cut list, baffle/subwoofer fit checks, and the
  3D viewer support the layout in all three enclosure orientations.
- The resolver is limited to single-port, non-kerf designs. Dual-port and kerf
  designs retain their existing geometry.
- `generateCutList` emits `Port Piece 1` through the required final divider.
- Full DXF/ACC export is enabled for operator CAM review. Every PP2+ divider
  receives Top/Bottom alignment drilling, the established PP2 mill-down/edge
  convention, and an `ASSEMBLY_FRONT_ANCHOR` or `ASSEMBLY_BACK_ANCHOR`
  reference layer. The package also contains a bottom-view assembly-reference
  DXF and a coordinate manifest.
- ACC 01..07 keep their established meanings, optional SUPB gusset stays 08,
  and labyrinth Port 3+ continues at 09+. The barcode PDF paginates as needed.
- Material cost and weight already follow every cut-list row; glue and dowel
  estimates now include all added dividers.
- These files are explicitly marked for manual review. Physical first-cut and
  acoustic acceptance are still required before production use.
- The distinct PP1-only range (`0 < portLength2 <= portWidth`) remains governed
  by the calculator plan in `codebase-analysis-docs/plans/PP1_ONLY_SLOT_PORT_PLAN.md`.

Focused coverage lives in `tests/labyrinth-port.test.ts`,
`tests/dxf-naming.test.ts`, and `tests/cost-calculator.test.ts`. Physical
first-cut acceptance is still required before production use.

## Extraction phases (history)

All five complete as of 2026-05-02. See `EXTRACTION_LOG.md` for the per-phase migration history.

- [x] Phase 1: types
- [x] Phase 2: pure calc engine + helpers
- [x] Phase 3: cost calculator
- [x] Phase 4: DXF generator + supporting modules
- [x] Phase 5: 3D viewer + Zustand store + display components
- [x] Peer-dep loosening (`fbca118`): three.js 0.x ranges relaxed from `^` to `>=` so consumers can stay on different versions
