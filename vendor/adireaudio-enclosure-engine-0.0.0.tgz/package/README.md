# @adireaudio/enclosure-engine

Shared core for Adire Audio's enclosure calculator suite. Pure TypeScript — calc engine, DXF generator, cost calculator, types, 3D viewer, Zustand store, and supporting helpers.

## Brace clearance outside the driver frames (2026-10-23)

Front baffle braces now follow the midpoint between adjacent driver centers.
Reserve the actual brace stock thickness plus 0.25 inch clear of each outside
frame, including flush recess expansion. The same geometry controls fit,
movement limits, viewer, baffle/plate router dowels and cutting exports. Top
braces likewise clear the full outside frame and keep their shared DXF/ACC datum.
Automatic and manual fit verdicts agree, including Tight Fit and flush height.
Typed coordinates, sliders and nudges use one movement helper; other drivers
never move as a side effect. Tests cover all six duties/materials, Single through
Quad, moving drilling and the automatic round labyrinth opening.

Previously accepted layouts with a brace below the frame can now fail fit.
Regenerate a complete matched cutting set after changing positions; do not mix
old baffle/plate drill files with new brace locations. Panel dimensions, tuning,
stored designs and historical nests are not changed by this release.

## Independent driver positions (2026-10-23)

`subwooferPositions` now supports one center per driver, Single through Quad,
for every mounting orientation. Coordinates are inches on the finished mounting
panel: SUPB uses Top X from Side Left / Y from the front; SBPB and SUPP use
baffle X from left / Y from bottom. DXF margins and Top mirroring are applied
only during export. The viewer, flush plate/cap and custom EPS openings retain
both coordinates. The brace-clearance follow-up above also checks automatic layouts.

`resolveSubwooferLayout` validates requested positions without moving other
subs. It rejects malformed counts, nonfinite centers, frame/recess collisions,
chamber/port conflicts and brace conflicts. Cutting tolerance is checked at
export, including single-part DXF and ACC-only exports. SUPB triple/quad braces
share a depth datum for ACC 08 and use the same centers for Top/Bottom drilling.
Front baffle braces and their router dowels follow adjacent driver midpoints.
Dual-port Top layouts conservatively stay ahead of both
return walls. Native EPS curve conversion is unchanged.

Changing quantity preserves remaining driver indices and seeds new controls.
Changing between Top and baffle resets positions because the coordinate frame
changes. Full design loads preserve saved overrides and clear absent ones.
`tests/independent-all-subwoofers.test.ts` covers the duty/material/orientation
matrix, persistence, flush construction, native profiles and DXF/ACC alignment.

## Nominal Top/Bottom cutting outlines (2026-10-21)

Top and Bottom now cut at their nominal cut-list dimensions, including guide
DXFs, all duties, birch and MDF. The former 1/32-inch-per-edge trim allowance
has been removed. Hole coordinates, milling, openings, ACC programs and nominal
panel calculations are unchanged. The existing manufacturing baseline protects
all geometry outside the single outer profile; it was not regenerated.

## Frozen custom subwoofer profiles (2026-10-19)

October 20 follow-up: version-2 profiles retain the parsed EPS
`sourcePath` in centered inches. Custom cutting DXF uses the exact same
`epsPathToPolylineVertices` curve converter as logo `epsPathsToDxfEntities`;
the latter's output remains unchanged. Native arcs survive cutout allowance
and mirroring; sampled polygons are only for fit/area/display. Version-1
profiles remain readable but cannot generate new cutting files without
explicitly re-uploading the source EPS and updating the design. XXL validation
belongs in the consumer and must not reconstruct these curves. No database
migration or automatic saved-design rewrite is part of this change.

`subwooferCutoutProfile` stores a versioned, centered inch-based opening contour
and outside-frame dimensions in design inputs. The calculator imports it through
the existing EPS parser; the engine validates the geometry and uses the same
outline in area calculations, fit checks, preview, flush parts and closed DXF
polylines. Total machining clearance offsets the full opening by half the value.
Saved inputs never consult the live model library. Circular designs retain the
existing path. Custom top layouts search one/two-row grids, with conservative
dual-port bounds and explicit brace checks. The generic frame silhouette is not
a physical driver/basket model. See `tests/subwoofer-profile.test.ts` for geometry
and manufacturing contracts.

Consumed by:
- **Calculator** (`enclosure-calculator-web`) — internal admin tool. Primary driver of engine changes.
- **Customer website designer** (`bhs_enclosure_designer`) — Vercel-hosted custom enclosure designer exposed through Shopify at `/apps/enclosure-designer`. It installs a vendored npm tarball built from this repo.

## Parallel-consumer release invariant

The calculator and customer website designer must remain on the **same full engine commit** whenever either consumer advances its engine. An engine update is not complete when only one consumer has moved.

- The calculator records the engine revision as a full git SHA in `package.json` and `package-lock.json`.
- The designer packages this repo with its `sync:engine` script, stores the tarball at `vendor/adireaudio-enclosure-engine-0.0.0.tgz`, and refreshes its provenance and `package-lock.json`.
- Both consumers must pass their checks, be pushed and deployed, and the live Shopify route `/apps/enclosure-designer` must be verified before the engine release is closed.
- The customer app intentionally exposes fewer controls and no manufacturing-only cut-list, cost, or DXF/CNC surfaces. That UI distinction does not permit engine-revision drift.

## Enclosure series identity (2026-09-11)

`canonicalDesignName` keeps BHSP (Performance), BHSF (Foundation), and BHSS
(Select) as separate identities. Historical unprefixed enclosure names resolve
only to Performance. BHS remains a brand code. Material, duty, custom and size
tokens are retained. `generateModelNumber` now includes the series, defaults to
Performance, and accepts an explicit series when creating a variant. The store
preserves Foundation/Select when loading and editing designs.

Compact machine-program identifiers and existing printed barcodes retain their
established geometry-based format; they are references to the prefixed design,
not additional catalog identities. Consumers must retain legacy-name reads
while converting their catalog and inventory records.

## Manufacturing profiles (October 2026)

`manufacturing-profile.ts` resolves versioned stock, milling-depth and glue
settings. New mating geometry derives finished thickness from full stock minus
milling depth, ignoring legacy C1/C2 and manual Port 2 offset fields. Defaults
match existing CNC depths: SD/RD 0.864 mm, HD 0.762 mm. MDF is not milled.
Glue clearance is per mating edge; ordinary folded Port 2 placement derives
from glue minus milling depth. Saved profiles are authoritative; consumers
resolve current global defaults when loading legacy designs.

`generateAllFiles` recalculates from the supplied inputs/profile and emits a
manufacturing record. DXF comments carry milling requirements for downstream
nesting/CAM checks without renaming machining layers. Consumers must preserve
these comments during nesting. The calculator checks them against Cut operation
depths; Build does not change router operations automatically.

`manufacturing-profile.test.ts` independently checks assembled dimensions and
DXF/ACC drilling across all duties, materials, orientations, single/dual ports
and flush variants. The original trim baseline remains historical; the reviewed
manufacturing-v1 baseline records the intentional geometry changes.

## What lives here

### Viewer specifications and annotated renders (2026-10-15)

Full dimensions shows total net airspace, requested tuning and total port area.
Only dual-port enclosures add an Each port row; driver quantity does not affect
the displayed port count. Every preset PNG includes these values in a reserved
bottom-right box, with the geometry and dimension labels fitted above it.
`captureEnclosureRenderSet` freezes the render geometry for the set, explicitly
preserving non-enumerable labyrinth data. Its preset angles, clean/dimension
variants and acrylic-window feature views remain shared by both apps.
`EnclosureViewer3D` accepts optional `toolbarActions` so the calculator pop-out
can offer its image-only ZIP download without adding app dependencies here.

### Automatic triple/quad SUPB placement (2026-10-15)

Single-port Subs Up / Port Back now preserves valid straight rows, then searches
two-row grids and staggered layouts for three or four drivers. Both orientations
and the curved PP2 corner are checked against actual cut-list geometry. It never
changes enclosure size, tuning, volume or port dimensions to manufacture a fit.
New arrangements retain 0.5-inch outer flange margin, 0.25-inch flange gap and
0.25-inch cutout-to-wall clearance. The existing n-1 upright five-inch braces
are positioned in remaining solid wood; they keep a common depth center and
at least five inches between centers, with 0.25-inch clearance at holes/walls.
Labyrinth braces remain entirely outside the maze band.

The same final centers drive fit, preview, Top/Bottom dowels, cutouts and ACC 08.
Multi-row full **and ACC-only** exports include `*-Subwoofer-Layout.txt` with
physical coordinates and the explicit ACC depth reference; do not assume that
brace Y equals either subwoofer row. Existing ACC program numbers/formats stay
unchanged. Unsafe automatic layouts show display-only drivers in an
approximate arrangement and a port/placement diagnostic. This sketch never
supplies holes, braces, a passing fit verdict or CNC coordinates. Exported images retain
a failed-fit banner. Valid layouts keep their certified centers. Manual dual
overrides and other configurations retain their established controls.

Fit spacing uses the actual displayed centers: minimum flange distance to all
four panel edges and minimum Euclidean flange gap across every driver pair.
`clearanceBasis` distinguishes resolved layout, display-only preview, and
unavailable measurements. When the physical solver rejects a port before
placing drivers, the preview sketch can still report its measured spacing, but
`isFail`, the diagnostic, and manufacturing guards remain unchanged. Never
display the old single-row formula for an unresolved stagger or grid.

Driver color represents the measured surface spacing separately from the
overall fit: normal materials when edge clearance and inter-driver gap are
finite and nonnegative, amber when either is negative or unavailable. A port
or brace error alone does not recolor drivers. Approximate placement notices,
failed-fit image banners, and all manufacturing guards remain in place.

The unresolved quad preview prefers a clear row, then a square 2x2 grid, then
an equal-step zigzag with three equal neighboring diagonal flange gaps. It
centers the rows within the available depth and retains the known straight
port-wall boundary. If no balanced arrangement clears, the bounded fallback
search remains. This changes approximate preview centers only; resolved
production layouts and machining coordinates are unchanged.

The reported Audio Control quad-12 at 16-inch height, 24-inch depth, 7 cu ft,
7-inch port and 34 Hz still fails: PP2 is -1.814124 inches. Separate test inputs
at 32 Hz demonstrate a stagger; 28-inch depth/28 Hz demonstrate a 2x2 grid. These
are test alternatives, not silent edits or approved production dimensions.

### Independent dual SUPB centers (2026-10-05)

Dual-sub, single-port Subs Up / Port Back layouts can save two absolute
`subwooferPositions` centers (inches: X from Side Left, Y from front).
These override legacy shared offsets; omitting them restores automatic placement.
The solver preserves existing valid rows/staggers, then searches the curved
cutout-clearance boundary around the PP2 corner when the rectangular search fails.
It retains the 0.5-inch flange-to-outer-edge and 0.25-inch cutout-to-wall margins,
requires 0.25 inch between independently placed flanges, and checks the existing
5-inch midpoint gusset. Labyrinth layouts retain their unobstructed chamber band.

Calculations, viewer holes/drivers/gussets, DXF cutouts, Top/Bottom drilling and
ACC gusset programs consume the same final centers. Unsafe finite manual positions
remain visible for correction; full and ACC-only exports reject them. Save/load
and browser persistence retain exact precision; reset clears all placement overrides.
Single/triple/quad and dual-port layouts retain their existing controls.

The reported 39.5605 × 22.5 × 21-inch SAV3 dual-15 now finds a stagger without
enlarging the box (0.2585-inch flange gap, still classified Tight Fit).
Regression tests cover that geometry, independent movement, invalid positions,
saved-data replacement and matched manufacturing coordinates, including flush mounting.

### Optional dowel channels (layout revised 2026-09-27)

`EnclosureInputs.addDowChannels` is opt-in per design. Full exports add directed
`DOW_CHANNEL_RAMP_0_4` LINEs at Bottom sockets for Side Left, Side Right and
Port 1. Each Bottom line starts 0.5 inch toward the front/baffle from its socket
and ends at the socket center (local Y - 0.5 inch to Y), deepening toward the
back. Existing Baffle channels retain their original local Y + 0.5 inch to Y
direction. Back, Port Piece 2, Top and other Bottom sockets have no channels.
Original holes, their depths and the Top/Bottom trim allowance remain unchanged.

Consumers must preserve line direction through nesting and use tool 107 with
the 3/8-inch cutter for a surface-to-0.4-inch ramp. The calculator uses four
passes ending at 0.1, 0.2, 0.3 and 0.4 inch. Disabled design output is unchanged.
Saved DXFs, nests and XXLs are not rewritten: regenerate DXFs, re-nest, then
regenerate XXLs to adopt the revised layout. Physical machining acceptance is
still required.

### Short manufacturing program codes

Generated ACC, logo XXL, and carton XXL files carry operation/material metadata.
The calculator's server registry assigns immutable eight-character codes from
`23456789ABCDEFGHJKMNPQRSTUVWXYZ`. `applyManufacturingCodes` changes only the
filename; machine program bytes and geometry stay unchanged. The optional code
map in `generateAccBarcodesPdf` must come from the same registered release.
Missing, malformed, or duplicate codes fail the export. Legacy naming remains
the default, and enclosure QR codes are independent of these machine codes.

The engine does not allocate codes or decide which release a physical item uses.
Those responsibilities belong to the calculator's database and authenticated API.

```
src/
├── types/                   # EnclosureInputs, EnclosureCalculations, MaterialConfig, etc.
├── calculations.ts          # calculateEnclosure, generateCutList, baffle check
├── carton-dimensions.ts     # canonical assembled-carton clearance formula
├── cost-calculator.ts       # cost pipeline + parsers
├── dxf-generator.ts         # DXF + ACC + barcode PDF generation
├── terminal-placement.ts    # terminal cup safe-zone math
├── subwoofer-placement.ts   # SUPB sub cutout safe-zone math
├── extra-holes.ts           # auto-calc helpers for ACC content
├── labyrinth-port.ts        # automatic serpentine slot-port resolver
├── design-name-utils.ts     # name normalization + alias generation
├── flat-pack-optimizer.ts   # flat pack panel layout
├── eps-parser.ts            # EPS file parser
├── pocket-logo-toolpath.ts  # pocket/logo CNC toolpath generation
├── debug-log.ts             # shared debug logger
├── enclosure-store.ts       # Zustand store
├── enclosure-viewer-3d.tsx  # Three.js / R3F viewer
├── calculations-display.tsx # readout component
├── cut-list.tsx             # cut list component
└── index.ts                 # barrel export
```

**Stays in the consumers' `src/`:** React components specific to that app, API routes, page-level wrappers, Zustand selectors, anything that touches `localStorage`/Supabase/WC directly.

## Consuming

Ships TypeScript source. Consumers must add it to `transpilePackages` in `next.config.ts`:

```ts
transpilePackages: ['@adireaudio/enclosure-engine']
```

The calculator's `package.json` pins to a specific commit SHA:

```json
"@adireaudio/enclosure-engine": "git+https://github.com/adireaudio8/enclosure-engine.git#<sha>"
```

The calculator's Vercel project needs a `GH_PAT` env var with `Contents:Read` on this repo; its `vercel-install.sh` handles auth via `git config url.insteadOf`. The customer designer does not clone this private repo during deployment—it vendors the `npm pack` tarball and must record/verify that the tarball was built from the same engine commit as the calculator pin.

## Workflow when modifying engine code

The calculator is the primary driver for many engine changes, but the calculator and customer designer are one engine release unit. Every revision adopted by either consumer must be propagated to the other in the same work.

```bash
# 1. Edit + push the engine
cd Software\ Dev/enclosure-engine
# ...edit src/...
git add -A && git commit -m "fix: ..." && git push origin main
SHA=$(git rev-parse HEAD)

# 2. Bump the calculator
cd ../Enclosure\ Calculator\ -\ Web
# Edit package.json: change the engine #<old-sha> to #$SHA, then run
# `npm install` ON THE FULL SPEC to force lockfile re-resolution:
npm install "@adireaudio/enclosure-engine@git+https://github.com/adireaudio8/enclosure-engine.git#$SHA"
# Verify the lockfile picked up the NEW SHA (full 40 chars):
grep -A2 '"node_modules/@adireaudio/enclosure-engine"' package-lock.json
git add package.json package-lock.json
git commit -m "engine: bump to $SHA for <reason>"
git push origin main

# 3. Package the SAME engine commit for the customer website designer
cd ../bhs_enclosure_designer
npm run sync:engine -- --engine-dir ../enclosure-engine
npm install "@adireaudio/enclosure-engine@file:vendor/adireaudio-enclosure-engine-0.0.0.tgz"
npm run verify:engine-parity
npm run typecheck
npm run build
# Commit the tarball + provenance + package-lock.json, push main, deploy,
# and verify https://bassheadsupply.com/apps/enclosure-designer.
```

**Why `npm install <spec>` instead of plain `npm install`.** The lockfile records each git dep's `resolved` URL with the full commit SHA. A plain `npm install` after a SHA bump in package.json doesn't always rewrite that — npm trusts the existing lockfile entry as long as the dep name matches. The result: package.json says #1c8fa9b, lockfile still says #e349180, npm fetches the OLD commit, Vercel deploys byte-identical bundles, and "the new feature isn't there." We ate this on 2026-05-03 (Wire-button removal silently failed to land for hours). Running `npm install` against the explicit `<name>@<spec>` form forces re-resolution and rewrites the lockfile entry.

**Calculator Vercel handles its git pin defensively.** The calculator's `vercel-install.sh` parses the engine spec out of `package.json` and re-installs it after the main install, so calculator deploys force lockfile reconciliation. The designer's vendored tarball has no equivalent automatic GitHub refresh; its tarball, provenance, and lockfile must be updated explicitly for every parallel engine release.

**Designer tarball integrity gotcha:** replacing the `.tgz` without changing its file path leaves the old integrity hash in `package-lock.json`; a plain `npm install` can fail with `EINTEGRITY`. Reinstall the full explicit file spec shown above so npm rewrites the integrity and adds any new transitive dependencies.

**Calculator and customer designer may not remain on different engine refs.** If a consumer cannot be updated and validated, do not call the engine release complete or deploy the other consumer as the finished engine update. Record the blocker and keep the parity work open.

## Carton clearance contract

## Shipping weight policy (2026-09-07)

Packaged shipping and billable weights always round **up** to whole pounds
using `roundShippingWeight`: 62.1 becomes 63; 73 stays 73. Apply this after
adding packaging, not to individual panels or raw enclosure mass. Dimensions
remain fractional inches; this policy does not round carton geometry.

### Carton dimensions

`calculateCartonDimensions` owns the standard assembled-enclosure carton
formula. It preserves the original allowances (depth + 1.125 inches, height +
1.000 inches, rounded box width + 1.1875 inches) and then adds 3.3 mm at each
opposing side, or 6.6 mm to every finished carton dimension. Consumers should
call this helper instead of duplicating those offsets. Flat-pack shipping uses
its separate panel-stack optimizer and is not changed by this rule.

## Automatic labyrinth slot ports

The engine automatically replaces the normal one-fold PP1/PP2 layout with a
serpentine divider layout when the legacy volume solve would make the remaining
S2 chamber negative. This is derived geometry: it is recalculated from the
enclosure inputs and is deliberately not serialized into saved calculation
rows. A saved `forceLabyrinthPort` input can also activate the same resolver
manually for an otherwise valid single, non-kerf port with a second leg; leaving
the input false or absent preserves automatic behavior.

Current manufacturing-review boundary (2026-08-07):

- Calculation, box-width solve, cut list, baffle/subwoofer fit checks, and the
  3D viewer support the layout in all three enclosure orientations.
- The resolver is limited to single-port, non-kerf designs. Dual-port and kerf
  designs retain their existing geometry.
- `generateCutList` emits `Port Piece 1` through the required final divider.
- Full DXF/ACC export is enabled for operator CAM review. Every PP2+ divider
  receives Top/Bottom alignment drilling, the established PP2 mill-down/edge
  convention, and an `ASSEMBLY_FRONT_ANCHOR` or `ASSEMBLY_BACK_ANCHOR`
  reference layer. The package also contains a bottom-view assembly-reference
  DXF and a coordinate manifest.
- ACC 01..07 keep their established meanings, optional SUPB gusset stays 08,
  and labyrinth Port 3+ continues at 09+. The barcode PDF paginates as needed.
- Material cost and weight already follow every cut-list row; glue and dowel
  estimates now include all added dividers.
- These files are explicitly marked for manual review. Physical first-cut and
  acoustic acceptance are still required before production use.
- The distinct PP1-only range (`0 < portLength2 <= portWidth`) remains governed
  by the calculator plan in `codebase-analysis-docs/plans/PP1_ONLY_SLOT_PORT_PLAN.md`.

Focused coverage lives in `tests/labyrinth-port.test.ts`,
`tests/dxf-naming.test.ts`, and `tests/cost-calculator.test.ts`. Physical
first-cut acceptance is still required before production use.

## Extraction phases (history)

All five complete as of 2026-05-02. See `EXTRACTION_LOG.md` for the per-phase migration history.

- [x] Phase 1: types
- [x] Phase 2: pure calc engine + helpers
- [x] Phase 3: cost calculator
- [x] Phase 4: DXF generator + supporting modules
- [x] Phase 5: 3D viewer + Zustand store + display components
- [x] Peer-dep loosening (`fbca118`): three.js 0.x ranges relaxed from `^` to `>=` so consumers can stay on different versions
