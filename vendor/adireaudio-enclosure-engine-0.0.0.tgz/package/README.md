# @adireaudio/enclosure-engine

Shared core for Adire Audio's enclosure calculator suite. Pure TypeScript — calc engine, DXF generator, cost calculator, types, 3D viewer, Zustand store, and supporting helpers.

Consumed by:
- **Calculator** (`enclosure-calculator-web`) — internal admin tool. Primary driver of engine changes.
- **Customer website designer** (`bhs_enclosure_designer`) — Vercel-hosted custom enclosure designer exposed through Shopify at `/apps/enclosure-designer`. It installs a vendored npm tarball built from this repo.

## Parallel-consumer release invariant

The calculator and customer website designer must remain on the **same full engine commit** whenever either consumer advances its engine. An engine update is not complete when only one consumer has moved.

- The calculator records the engine revision as a full git SHA in `package.json` and `package-lock.json`.
- The designer packages this repo with its `sync:engine` script, stores the tarball at `vendor/adireaudio-enclosure-engine-0.0.0.tgz`, and refreshes its provenance and `package-lock.json`.
- Both consumers must pass their checks, be pushed and deployed, and the live Shopify route `/apps/enclosure-designer` must be verified before the engine release is closed.
- The customer app intentionally exposes fewer controls and no manufacturing-only cut-list, cost, or DXF/CNC surfaces. That UI distinction does not permit engine-revision drift.

## Enclosure series identity (2026-09-11)

`canonicalDesignName` keeps BHSP (Performance), BHSF (Foundation), and BHSS
(Select) as separate identities. Historical unprefixed enclosure names resolve
only to Performance. BHS remains a brand code. Material, duty, custom and size
tokens are retained. `generateModelNumber` now includes the series, defaults to
Performance, and accepts an explicit series when creating a variant. The store
preserves Foundation/Select when loading and editing designs.

Compact machine-program identifiers and existing printed barcodes retain their
established geometry-based format; they are references to the prefixed design,
not additional catalog identities. Consumers must retain legacy-name reads
while converting their catalog and inventory records.

## What lives here

```
src/
├── types/                   # EnclosureInputs, EnclosureCalculations, MaterialConfig, etc.
├── calculations.ts          # calculateEnclosure, generateCutList, baffle check
├── carton-dimensions.ts     # canonical assembled-carton clearance formula
├── cost-calculator.ts       # cost pipeline + parsers
├── dxf-generator.ts         # DXF + ACC + barcode PDF generation
├── terminal-placement.ts    # terminal cup safe-zone math
├── subwoofer-placement.ts   # SUPB sub cutout safe-zone math
├── extra-holes.ts           # auto-calc helpers for ACC content
├── labyrinth-port.ts        # automatic serpentine slot-port resolver
├── design-name-utils.ts     # name normalization + alias generation
├── flat-pack-optimizer.ts   # flat pack panel layout
├── eps-parser.ts            # EPS file parser
├── pocket-logo-toolpath.ts  # pocket/logo CNC toolpath generation
├── debug-log.ts             # shared debug logger
├── enclosure-store.ts       # Zustand store
├── enclosure-viewer-3d.tsx  # Three.js / R3F viewer
├── calculations-display.tsx # readout component
├── cut-list.tsx             # cut list component
└── index.ts                 # barrel export
```

**Stays in the consumers' `src/`:** React components specific to that app, API routes, page-level wrappers, Zustand selectors, anything that touches `localStorage`/Supabase/WC directly.

## Consuming

Ships TypeScript source. Consumers must add it to `transpilePackages` in `next.config.ts`:

```ts
transpilePackages: ['@adireaudio/enclosure-engine']
```

The calculator's `package.json` pins to a specific commit SHA:

```json
"@adireaudio/enclosure-engine": "git+https://github.com/adireaudio8/enclosure-engine.git#<sha>"
```

The calculator's Vercel project needs a `GH_PAT` env var with `Contents:Read` on this repo; its `vercel-install.sh` handles auth via `git config url.insteadOf`. The customer designer does not clone this private repo during deployment—it vendors the `npm pack` tarball and must record/verify that the tarball was built from the same engine commit as the calculator pin.

## Workflow when modifying engine code

The calculator is the primary driver for many engine changes, but the calculator and customer designer are one engine release unit. Every revision adopted by either consumer must be propagated to the other in the same work.

```bash
# 1. Edit + push the engine
cd Software\ Dev/enclosure-engine
# ...edit src/...
git add -A && git commit -m "fix: ..." && git push origin main
SHA=$(git rev-parse HEAD)

# 2. Bump the calculator
cd ../Enclosure\ Calculator\ -\ Web
# Edit package.json: change the engine #<old-sha> to #$SHA, then run
# `npm install` ON THE FULL SPEC to force lockfile re-resolution:
npm install "@adireaudio/enclosure-engine@git+https://github.com/adireaudio8/enclosure-engine.git#$SHA"
# Verify the lockfile picked up the NEW SHA (full 40 chars):
grep -A2 '"node_modules/@adireaudio/enclosure-engine"' package-lock.json
git add package.json package-lock.json
git commit -m "engine: bump to $SHA for <reason>"
git push origin main

# 3. Package the SAME engine commit for the customer website designer
cd ../bhs_enclosure_designer
npm run sync:engine -- --engine-dir ../enclosure-engine
npm install "@adireaudio/enclosure-engine@file:vendor/adireaudio-enclosure-engine-0.0.0.tgz"
npm run verify:engine-parity
npm run typecheck
npm run build
# Commit the tarball + provenance + package-lock.json, push main, deploy,
# and verify https://bassheadsupply.com/apps/enclosure-designer.
```

**Why `npm install <spec>` instead of plain `npm install`.** The lockfile records each git dep's `resolved` URL with the full commit SHA. A plain `npm install` after a SHA bump in package.json doesn't always rewrite that — npm trusts the existing lockfile entry as long as the dep name matches. The result: package.json says #1c8fa9b, lockfile still says #e349180, npm fetches the OLD commit, Vercel deploys byte-identical bundles, and "the new feature isn't there." We ate this on 2026-05-03 (Wire-button removal silently failed to land for hours). Running `npm install` against the explicit `<name>@<spec>` form forces re-resolution and rewrites the lockfile entry.

**Calculator Vercel handles its git pin defensively.** The calculator's `vercel-install.sh` parses the engine spec out of `package.json` and re-installs it after the main install, so calculator deploys force lockfile reconciliation. The designer's vendored tarball has no equivalent automatic GitHub refresh; its tarball, provenance, and lockfile must be updated explicitly for every parallel engine release.

**Designer tarball integrity gotcha:** replacing the `.tgz` without changing its file path leaves the old integrity hash in `package-lock.json`; a plain `npm install` can fail with `EINTEGRITY`. Reinstall the full explicit file spec shown above so npm rewrites the integrity and adds any new transitive dependencies.

**Calculator and customer designer may not remain on different engine refs.** If a consumer cannot be updated and validated, do not call the engine release complete or deploy the other consumer as the finished engine update. Record the blocker and keep the parity work open.

## Carton clearance contract

## Shipping weight policy (2026-09-07)

Packaged shipping and billable weights always round **up** to whole pounds
using `roundShippingWeight`: 62.1 becomes 63; 73 stays 73. Apply this after
adding packaging, not to individual panels or raw enclosure mass. Dimensions
remain fractional inches; this policy does not round carton geometry.

### Carton dimensions

`calculateCartonDimensions` owns the standard assembled-enclosure carton
formula. It preserves the original allowances (depth + 1.125 inches, height +
1.000 inches, rounded box width + 1.1875 inches) and then adds 3.3 mm at each
opposing side, or 6.6 mm to every finished carton dimension. Consumers should
call this helper instead of duplicating those offsets. Flat-pack shipping uses
its separate panel-stack optimizer and is not changed by this rule.

## Automatic labyrinth slot ports

The engine automatically replaces the normal one-fold PP1/PP2 layout with a
serpentine divider layout when the legacy volume solve would make the remaining
S2 chamber negative. This is derived geometry: it is recalculated from the
enclosure inputs and is deliberately not serialized into saved calculation
rows. A saved `forceLabyrinthPort` input can also activate the same resolver
manually for an otherwise valid single, non-kerf port with a second leg; leaving
the input false or absent preserves automatic behavior.

Current manufacturing-review boundary (2026-08-07):

- Calculation, box-width solve, cut list, baffle/subwoofer fit checks, and the
  3D viewer support the layout in all three enclosure orientations.
- The resolver is limited to single-port, non-kerf designs. Dual-port and kerf
  designs retain their existing geometry.
- `generateCutList` emits `Port Piece 1` through the required final divider.
- Full DXF/ACC export is enabled for operator CAM review. Every PP2+ divider
  receives Top/Bottom alignment drilling, the established PP2 mill-down/edge
  convention, and an `ASSEMBLY_FRONT_ANCHOR` or `ASSEMBLY_BACK_ANCHOR`
  reference layer. The package also contains a bottom-view assembly-reference
  DXF and a coordinate manifest.
- ACC 01..07 keep their established meanings, optional SUPB gusset stays 08,
  and labyrinth Port 3+ continues at 09+. The barcode PDF paginates as needed.
- Material cost and weight already follow every cut-list row; glue and dowel
  estimates now include all added dividers.
- These files are explicitly marked for manual review. Physical first-cut and
  acoustic acceptance are still required before production use.
- The distinct PP1-only range (`0 < portLength2 <= portWidth`) remains governed
  by the calculator plan in `codebase-analysis-docs/plans/PP1_ONLY_SLOT_PORT_PLAN.md`.

Focused coverage lives in `tests/labyrinth-port.test.ts`,
`tests/dxf-naming.test.ts`, and `tests/cost-calculator.test.ts`. Physical
first-cut acceptance is still required before production use.

## Extraction phases (history)

All five complete as of 2026-05-02. See `EXTRACTION_LOG.md` for the per-phase migration history.

- [x] Phase 1: types
- [x] Phase 2: pure calc engine + helpers
- [x] Phase 3: cost calculator
- [x] Phase 4: DXF generator + supporting modules
- [x] Phase 5: 3D viewer + Zustand store + display components
- [x] Peer-dep loosening (`fbca118`): three.js 0.x ranges relaxed from `^` to `>=` so consumers can stay on different versions
