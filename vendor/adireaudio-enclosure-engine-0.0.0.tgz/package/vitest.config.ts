import { defineConfig } from 'vitest/config';

// Tests cover the PURE engine surface (calculations, cost, pricing modifiers,
// DXF/filename rules, placement/feature math) in a plain Node environment.
// The React/R3F viewer, the Zustand store, and browser-only file generation
// (barcode PDFs) are intentionally out of scope — see tests/README.md.
export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
  },
});
