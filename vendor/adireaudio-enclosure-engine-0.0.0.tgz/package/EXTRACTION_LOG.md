# Extraction Log

History of the `@adireaudio/enclosure-engine` extraction from `enclosure-calculator-web`.

## Why this package exists

The calculator (employee-facing) and the Basshead Supply storefront's planned customer-facing custom enclosure designer both need the same enclosure math, data shapes, DXF output, and 3D preview. Copying code between two repos guarantees drift. A shared package gives one source of truth.

## Architecture

Three independent repos:
- `enclosure-calculator-web` — internal employee tool
- `bassheadsupply-headless-woo` — public storefront
- `enclosure-engine` (this repo) — shared core

Both apps depend on the engine via GitHub git-dep, pinned to a specific commit SHA in `package.json`. Vercel installs the pinned commit on every build.

Local dev uses `npm link` so engine edits flow live into both apps without push/install/bump.

## Phase 1 — Types (2026-05-01)

Commit: `d3c64a4`

**Moved into the engine:**
- `src/types/enclosure.ts` — verbatim copy of the calculator's types module (interfaces, defaults, dropdown lists). No behavior changes.

**Calculator changes:**
- 15 files: imports swapped from `@/types/enclosure` → `@adireaudio/enclosure-engine`. Files: `store/enclosure-store.ts`, `hooks/usePricingGeneration.ts`, `lib/calculations.ts`, `lib/cost-calculator.ts`, `lib/extra-holes.ts`, `lib/flat-pack-optimizer.ts`, `lib/generate-design-files.ts`, `lib/dxf-generator.ts`, `lib/pricing-data.ts`, `lib/terminal-placement.ts`, `lib/subwoofer-placement.ts`, `components/design/design-inputs.tsx`, `components/tabs/BuildTab.tsx`, `components/tabs/NestTab.tsx`, `components/tabs/PricingTab.tsx`.
- `next.config.ts`: added `transpilePackages: ['@adireaudio/enclosure-engine']`
- `package.json`: added `"@adireaudio/enclosure-engine": "github:adireaudio8/enclosure-engine#d3c64a4"`
- Removed: `src/types/enclosure.ts` (now sourced from engine)

**Verification:**
- `npm install` resolved engine from GitHub: 5 seconds, no errors
- `npm link` symlink: `node_modules/@adireaudio/enclosure-engine` → local engine folder
- `tsc --noEmit` on calculator: zero errors

## Phase 2 — Pure calc engine + helpers (2026-05-01)

Commit: `73ac90b`

**Moved into the engine:**
- `src/calculations.ts` — main calc engine (volume, port, internal/external dimensions, baffle check, cut list, model number, shipping info)
- `src/extra-holes.ts` — auto-calc edge-screw hole counts from cut-list panel widths
- `src/terminal-placement.ts` — terminal cup placement validation, no-go bands, snap-to-safe X helper
- `src/subwoofer-placement.ts` — SUPB sub cutout placement helpers, OD-based validation
- `src/flat-pack-optimizer.ts` — 2D bin packing for flat-pack panel shipping
- `src/design-name-utils.ts` — BHSP/BHSS/BHSF prefix normalization + SKU-match candidate generation

Inside the engine these now import types via `./types/enclosure` (relative). The barrel `src/index.ts` re-exports all six modules alongside the existing types module — wildcard re-exports, no name collisions across the seven.

**Calculator changes (15 files):**
- `store/enclosure-store.ts`, `hooks/usePricingGeneration.ts`, `lib/cost-calculator.ts`, `lib/dxf-generator.ts`, `lib/generate-design-files.ts`, `lib/pricing-data.ts`, `lib/pricing-export.ts`, `components/build/build-tab.tsx`, `components/design/design-inputs.tsx`, `components/design/enclosure-viewer-3d.tsx`, `components/LbsTransferModal.tsx`, `components/tabs/BuildTab.tsx`, `components/tabs/InventoryTab.tsx`, `components/tabs/PlanningTab.tsx`, `components/tabs/PricingTab.tsx`.
- All `from '@/lib/<name>'` imports for the six moved modules → `from '@adireaudio/enclosure-engine'`. One relative-path miss in `lib/pricing-export.ts` (`from './calculations'`) caught by `tsc --noEmit` and fixed in the same pass.

**Verification:**
- `tsc --noEmit` on calculator: zero errors after the one follow-up fix.
- Engine wildcard barrel: no symbol collisions surfaced.

## Phase 3 — Cost calculator (2026-05-02)

Commit: `944f43b`

**Moved into the engine:**
- `src/cost-calculator.ts` — full cost engine (material + glue + dowel pins + port paint + cardboard + flat-pack crating + finishing + weights, plus `parseDesignDataInputs` that reads both web-saved and desktop-saved `design_data` shapes)

Inside the engine the imports are now relative — three separate paths because cost-calculator pulls from three sibling modules:
- `./types/enclosure` for the type imports
- `./calculations` for `calculateEnclosure`, `generateCutList`, `getPartMaterial`, `getGussetCount`
- `./flat-pack-optimizer` for `calculateOptimalStack`

Added to the `src/index.ts` barrel alongside the previously-exported modules.

**Calculator changes (4 files):**
- `types/pricing.ts`, `hooks/usePricingGeneration.ts`, `components/tabs/PricingTab.tsx`, `lib/pricing-data.ts`. All `from '@/lib/cost-calculator'` → `from '@adireaudio/enclosure-engine'`.

**Verification:**
- `tsc --noEmit` on calculator: zero errors.
- Wildcard barrel still has no symbol collisions across the eight modules.

## Phase 4 — DXF generator + supporting modules (2026-05-02)

Commit: `a1cf230`

**Moved into the engine:**
- `src/dxf-generator.ts` — the heaviest module so far. DXF + ACC + box-dieline + logo file generation plus the SCM Xilog Plus `.xxl` toolpath emitter.
- `src/eps-parser.ts` — Encapsulated PostScript path parser used by logo DXF generation
- `src/pocket-logo-toolpath.ts` — pocket-logo CNC toolpath generator (concentric inward offset passes)
- `src/debug-log.ts` — app-wide debug ring buffer + React subscriber hook

Inside the engine, dxf-generator's imports are now relative to its siblings: `./types/enclosure`, `./calculations`, `./eps-parser`, `./pocket-logo-toolpath`, `./debug-log`, `./terminal-placement`.

**First peer dependencies declared:**
`debug-log.ts` uses React's `useEffect`/`useState`, and `dxf-generator.ts` uses `jspdf` + `jsbarcode` for ACC barcode PDFs. The engine's `package.json` now declares:
- `react`, `react-dom` (^19) — peer
- `jspdf` (^4) — peer
- `jsbarcode` (^3) — peer

These are also installed as `devDependencies` in the engine so the engine is self-typecheckable in isolation; consumers do not ship those packages.

**Calculator changes (11 files):**
- 9 import-path swaps (one per consumer): `store/enclosure-store.ts`, `lib/generate-design-files.ts`, `components/design/design-tab.tsx`, `components/design/enclosure-viewer-3d.tsx`, `components/pricing/AdvancedStatsModal.tsx`, `components/tabs/BuildTab.tsx` (two swaps in one edit — dxf-generator + debug-log), `components/tabs/PricingTab.tsx`, `components/tabs/TrackTab.tsx`, `components/DebugLogPanel.tsx`.
- Two **inline `import('@/lib/dxf-generator').GeneratedFile`** type expressions inside `BuildTab.tsx` (lines 748 + 1071) — caught by `tsc`, not by my alias-only grep.
- Three **dynamic `await import('./debug-log')`** calls in `lib/api.ts` (relative path, also missed by alias grep) repointed to `await import('@adireaudio/enclosure-engine')`. The dynamic-import shape is preserved so the lazy chunk still defers; it now pulls the whole engine's barrel rather than just debug-log, an acceptable tradeoff for an error-only path.

**Verification:**
- `tsc --noEmit` on calculator: zero errors after the three follow-up fixes above.
- Engine wildcard barrel: still no symbol collisions across the twelve modules.

## Phase 5 — 3D viewer + Zustand store + calc/cut display (2026-05-02)

Commit: `b195cae`

**Moved into the engine:**
- `src/enclosure-viewer-3d.tsx` — full Three.js / R3F 3D viewer (panel rendering, port geometry, sub cutouts, gussets, no-go-band overlays for terminal/sub placement, logo debossing). Largest single component file.
- `src/calculations-display.tsx` — 3-column readout: internal dimensions / port lengths / S1 + S2 chambers
- `src/cut-list.tsx` — cut-list table
- `src/enclosure-store.ts` — Zustand store with `persist` middleware. Owns `inputs`, `calculations`, `cutList`, `shippingInfo`, `modelNumber`, `flatPackResult`, `generatedFiles`, `materialConfig`, `brandCode`, `glueTolerance`, `selectedLogoName/Mode`, `logoEpsContent`. Setters cascade through `recalculate()` to keep all derived state consistent.

Inside the engine the moved files use relative imports for sibling modules (`./enclosure-store`, `./calculations`, `./eps-parser`, `./terminal-placement`, `./flat-pack-optimizer`, `./dxf-generator`). Barrel `src/index.ts` now re-exports all sixteen modules.

**New peer dependencies declared:**
- `three` (^0.180), `@react-three/fiber` (^9), `@react-three/drei` (^10) — for the 3D viewer
- `zustand` (^5) — for the store

Plus matching `devDependencies` so the engine typechecks in isolation.

**Calculator changes (7 files):**
- `components/design/design-tab.tsx`: 3 import-block swaps (calculations-display, cut-list, store) + 1 dynamic-import swap (`import('./enclosure-viewer-3d')` → `import('@adireaudio/enclosure-engine')`)
- `components/design/design-inputs.tsx`, `components/build/build-tab.tsx`, `components/tabs/BuildTab.tsx`, `components/tabs/NestTab.tsx`: store path swap
- `app/viewer/page.tsx`: store + viewer paths
- `components/tabs/BuildTab.tsx`: a second dynamic import (`import('@/components/design/enclosure-viewer-3d')` for `captureEnclosureRenderSet`) caught by tsc, repointed to engine

**Stays in the calculator:**
- `components/design/design-tab.tsx` — calculator-specific tab shell with auth, save/load via API, file generation
- `components/design/design-inputs.tsx` — form sections that fetch brands/models from the calculator's API. The customer designer will have its own simpler form against storefront product data.

**Verification:**
- `tsc --noEmit` on calculator: zero errors after the BuildTab dynamic-import follow-up.
- Engine wildcard barrel: still no symbol collisions across sixteen modules.

## Post-extraction tweaks

### Peer dependency range loosening (2026-05-02)

Commit: `fbca118`

The engine originally declared peer deps with caret ranges (e.g. `three: "^0.180.0"`). For Three.js's `0.x` versioning that resolves to `>=0.180.0 <0.181.0` in npm semver — too tight to coexist with consumers running `^0.182.0`.

Loosened all peer deps to `>=` ranges:
- `three: ">=0.180.0"` (was `^0.180.0`)
- `@react-three/fiber: ">=9.0.0"`, `@react-three/drei: ">=10.0.0"`
- `react: ">=19.0.0"`, `react-dom: ">=19.0.0"`
- `zustand: ">=5.0.0"`, `jspdf: ">=4.0.0"`, `jsbarcode: ">=3.0.0"`

Triggered by the storefront npm install hitting the conflict during its Stage A engine wiring. No other functional change.

## Status

Engine extraction complete. Both consumers share the same calc engine, DXF generator, 3D viewer, and Zustand store from `@adireaudio/enclosure-engine`:

- **Calculator** (`enclosure-calculator-web`) — in production, pinned at `e349180` (Phase 5 log update)
- **Storefront** (`bassheadsupply-headless-woo`) — in production wiring as of 2026-05-02, pinned at `fbca118` (peer-dep loosening tip). Customer-facing custom enclosure designer in build (Stage B committed; Stages C / D / E pending). See `Software Dev/Woo - Headless - BHS/CUSTOMER_DESIGNER_PLAN.md` for the implementation plan + handoff notes.

## Setup for a fresh clone of either app

1. Clone this repo alongside the app.
2. From the engine folder: `npm link`
3. From the app folder: `npm install` (pulls the engine from GitHub, installs)
4. From the app folder: `npm link @adireaudio/enclosure-engine` (overrides with local for dev)

## Operating notes

- After every engine push, bump the commit SHA in each consumer's `package.json`. The link makes it painless during dev — only matters for production deploys.
- `npm link` survives `npm install` but not `npm ci` or `rm -rf node_modules`. If wiped, re-run `npm link @adireaudio/enclosure-engine` from the consumer's folder.
- Engine declares no runtime deps yet. Heavy peer deps (`react`, `three`, `@react-three/fiber`, `@react-three/drei`, `zustand`) will be added as `peerDependencies` in Phase 5 when components land.
