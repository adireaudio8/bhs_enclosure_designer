// Minimal, TARGETED lint config — React Hooks rules only.
//
// The engine's React/R3F source (esp. enclosure-viewer-3d.tsx) is consumed by
// the web app + storefront but was never linted by either repo. That blind spot
// shipped the 2026-06-18 X-Ray white-screen crash: a hook placed AFTER a
// conditional early return (a Rules-of-Hooks violation tsc can't see). This
// config closes exactly that gap — it does NOT impose a full style regime on
// the (large, never-linted) codebase; it only runs the two react-hooks rules.
//
//   react-hooks/rules-of-hooks   → ERROR  (the crash class — hooks must be
//                                  unconditional, before any early return)
//   react-hooks/exhaustive-deps  → WARN   (stale-closure hygiene; non-fatal,
//                                  and several sites already opt out inline)
//
// Run with: npm run lint

import reactHooks from 'eslint-plugin-react-hooks';
import tsParser from '@typescript-eslint/parser';
import tsPlugin from '@typescript-eslint/eslint-plugin';

export default [
  { ignores: ['dist/**', 'node_modules/**'] },
  {
    files: ['src/**/*.{ts,tsx}'],
    // The source carries inline `eslint-disable @typescript-eslint/...` comments
    // for the web app's full lint config; here those rules are off, so don't
    // flag the directives as "unused" (they're used in the consuming repo).
    linterOptions: { reportUnusedDisableDirectives: 'off' },
    plugins: {
      'react-hooks': reactHooks,
      // Registered but NOT enabled — the source carries inline
      // `// eslint-disable @typescript-eslint/...` directives (written for the
      // web app's full lint config); registering the plugin makes those rule
      // names resolve so they don't error here. We do not turn the rules on.
      '@typescript-eslint': tsPlugin,
    },
    languageOptions: {
      parser: tsParser,
      ecmaVersion: 'latest',
      sourceType: 'module',
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    rules: {
      'react-hooks/rules-of-hooks': 'error',
      'react-hooks/exhaustive-deps': 'warn',
    },
  },
];
